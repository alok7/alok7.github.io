# Shining Tools Limited: SME research 365

Information cutoff: 20 October 2026. Market reference: secondary-corroborated 19 October 2026 close of ₹180, not a primary-verified or executable quote. Original name “Shining Tools”, null symbol and pending listing status remain separately preserved; verified issuer is Shining Tools Limited, BSE SME, SHTL / 544607 / INE0D8001018.

Read report.html or report.md, then the financial, business and peer supplements. BQS, Growth Quality Score (GQS) and IAS remain NS. The record completes research with identified evidence gaps; it is not an investment recommendation, default/fraud finding, publication instruction or trade authorization.

Run python3 build.py and python3 verify.py. All runtime inputs are declared in build.INPUTS. The code uses Python standard library only. Current monthly calculations use local Decimal precision40. All scenarios, including failed paths, are retained in canonical_paths.json.gz. The original 164-path trial is separately retained in development/v1_initial and reproduces with its original precision28. Its known limitations are explicitly documented.

Cold recovery must use a new empty inputs-only directory, then guarded_rebuild.py --fresh. It rejects cached outputs and prohibits undeclared reads/network/subprocess through a cooperative Python audit hook, not an OS security sandbox. Rebuild regenerates metrics, scorecard, report, monthly paths, producer attestation and independently authored replay results. Original PDFs, OCR and raw market pages are intentionally excluded and are not runtime inputs. Exact source URLs, dates, page references and original hashes remain in the authored extracts.

The compact/full packages contain identical authored research, runtime inputs, outputs and both independent/producer attestations. Compression differs, not evidence. No existing Library file, Git content, public page or batch manifest is changed by this package.
