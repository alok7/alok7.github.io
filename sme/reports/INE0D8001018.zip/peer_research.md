# Shining Tools: economic peer supplement

## 8. Economic peer checks

All metrics below are derived from current primary records available before the cutoff, not aggregator values. Operating EBITDA is PBT plus finance cost plus D&A less all other income. Reported exceptional/employee-obligation costs remain unless separately discussed. All cash-conversion figures use ratios of sums. These are economic comparisons, not full peer ratings or same-price investment rankings.

| Standalone peer | Fiscal year end | Revenue | Revenue YoY | Operating EBITDA margin | CFO | PAT | Two-year CFO/PAT | CFO minus cash operating capex |
|---|---|---:|---:|---:|---:|---:|---:|---:|
|Kennametal India|30 June 2026|1,510.70|29.09%|20.10%|18.30|196.00|0.546 x|−35.30|
|Forbes Precision/TOTEM|31 March 2026|251.0113|7.89%|21.09%|27.5529|28.7730|1.371 x|9.1611|
|Birla Precision|31 March 2026|238.4013|15.07%|7.09%|34.4824|11.6236|3.370 x|7.2025|
|Wendt India|31 March 2026|209.31|−2.59%|19.03%|32.86|22.75|1.077 x|21.47|

Kennametal is the direct global-parent cutting-tool/hard-metal benchmark. Its FY 2026 hard-metal revenue was ₹1,363.6 crore, while machining solutions contributed ₹147.1 crore and incurred a segment loss. Although revenue and PAT grew strongly, inventory absorbed ₹313.9 crore and receivables ₹79.2 crore, partly funded by ₹162.6 crore additional payables. The low current cash conversion is a useful warning against awarding quality solely for a large brand or growth. The balance sheet shows no bank borrowing,₹46 crore cash and ₹1.9 crore leases. A ₹5.2 crore Labour Code gratuity charge is retained in reported operating earnings. June versus March timing differs. [PEER-KENN26, PDF 4–8]

Forbes Precision's carbide/HSS round tools directly overlap with Shining; its service component is much smaller. Reported ROCE was 22%, debt/equity 0.10 and receivables turnover 7.94 x, about 46 days. PAT was effectively flat despite 7.89% revenue growth, and inventory absorbed ₹24.4908 crore. Its ₹5.90 crore Labour Code obligation is retained in the table. The company-reported headline EBITDA includes other income and is not the comparable operating margin used here. [PEER-FORBES26, PDF 69–71,100,117,125]

Birla is a relevant weaker/mixed comparator, also named in Shining's prospectus. It has cutting tools, holders and precision components, not an identical mix. Other income ₹9.1302 crore includes interest ₹4.6361 crore and balances written back ₹2.8526 crore, so the PAT recovery should not be mistaken for entirely operating growth. Its high CFO/PAT also reflects non-cash provisions, liability movements and recovery of employee/other loans. Net receivables imply 92.05 days on an average-net-balance/total-sales basis. The published 3.43 x turnover implies 106.41 days and does not reconcile to those net balances; both definitions are retained. Its cash capex excludes a separate ₹14.50 crore related-party loan outflow. [PEER-BIRLA26, printed 100–103,124–125,136–139]

Wendt is an adjacent superabrasives/grinding and precision-components comparator, not a pure carbide-round-tool peer. Standalone revenue and PAT declined; machine dispatch approvals and pricing concessions hurt results. CFO benefited from ₹17.33 crore receivables release, despite ₹11.77 crore inventory absorption. Its reported 15% ROCE excludes intangibles and is not comparable to full-acquisition-capital post-tax ROIC. FY 2025 cash capex included ₹35.56 crore intangible payments;FY 2026 also invested ₹17.27 crore in a German subsidiary, outside the table's cash operating capex. [PEER-WENDT26, printed 16,127–130,175]

Peer ratios therefore bound expectations rather than determine Shining's score. Shining's high reported margin needs reconciliation to product mix, rental-to-owned machinery economics, depreciation vintages, cash conversion and working capital. Larger peers demonstrate that comparable product capability is available; they do not prove that Shining lacks a valuable niche. Same-cutoff peer prices and valuation multiples remain ND.


Primary values, dates, scopes, original hashes and exact URLs are preserved in peer_inputs.json. No same-date peer price or valuation is asserted.
