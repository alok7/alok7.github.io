"""Vintages remain distinct. Exact Decimal calculations, no hidden neutral/missing fills."""
from decimal import Decimal as D, localcontext
from statistics import median
Z=D(0)
def convert(src):
 non={'scope','unit','source_id','pages','audit_status'}
 return {k:D(v)/100 if isinstance(v,str)and k not in non else v for k,v in src.items()}
def calculate(f,m):
 with localcontext()as ctx:
  ctx.prec=40
  return _calculate(f,m)
def _calculate(f,m):
 hist=[];prev=None;tax=D(f['normalization']['tax_rate'])
 for src in f['financial_years']:
  r=convert(src);r['core_ebit']=r['pbt']+r['finance']-r['other_income'];r['core_ebitda']=r['core_ebit']+r['da'];r['nopat']=max(Z,r['core_ebit'])*(1-tax);r['normalized_pat']=(r['core_ebit']-r['finance'])*(1-tax)if r['core_ebit']>=r['finance']else r['core_ebit']-r['finance'];r['debt']=r['debt_long']+r['debt_short'];r['available_cash']=r['cash']-D('.1783')if r['year']==2026 else r['cash'];r['net_debt']=r['debt']-r['available_cash'];r['fcf_proxy']=None if r['cfo']is None else r['cfo']-r['capex_cash_gross'];r['basic_onwc']=r['ar']+r['inventory']-r['ap'];r['core_ic_proxy']=r['basic_onwc']+r['ppe']+r['cwip'];r['funding_ic']=r['equity']+r['debt']-r['available_cash']-r['investments'];r['cost_proxy']=r['revenue']-r['core_ebitda'];r['ebitda_margin']=r['core_ebitda']/r['revenue'];r['pat_margin']=r['pat_total']/r['revenue'];r['coverage']=r['core_ebit']/r['finance'];r['net_debt_ebitda']=r['net_debt']/r['core_ebitda'];r['eps_current_year_end_shares']=r['pat_owners']*10000000/r['issued']
  if prev:
   r['addition']=r['revenue']-prev['revenue'];r['growth']=r['revenue']/prev['revenue']-1;r['ar_days']=(r['ar']+prev['ar'])/2/r['revenue']*365;r['inventory_cost_proxy_days']=(r['inventory']+prev['inventory'])/2/r['cost_proxy']*365;r['payable_cost_proxy_days']=(r['ap']+prev['ap'])/2/r['cost_proxy']*365;r['ccc_cost_proxy_days']=r['ar_days']+r['inventory_cost_proxy_days']-r['payable_cost_proxy_days'];r['roce_funding']=r['core_ebit']/((r['funding_ic']+prev['funding_ic'])/2);r['roic_funding']=r['nopat']/((r['funding_ic']+prev['funding_ic'])/2);r['roe']=r['pat_owners']/((r['equity']+prev['equity'])/2)
  hist.append(r);prev=r
 cagr=[]
 for years in [3,5]:
  a=hist[-years-1];b=hist[-1];cagr.append({'years':years,'from':a['year'],'to':b['year'],'start':a['revenue'],'end':b['revenue'],'cagr':(b['revenue']/a['revenue'])**(D(1)/years)-1,'basis':'Original audited operating revenue; product/service volume-price decomposition not fully disclosed.'})
 conversion=[]
 for years in[3,5]:
  a=hist[-years:];cf=sum(x['cfo']for x in a);pat=sum(x['pat_total']for x in a);conversion.append({'vintage':'Original annual statements','years':years,'from':a[0]['year'],'to':a[-1]['year'],'cfo':cf,'pat':pat,'ratio':cf/pat,'after_finance_ratio':(cf-sum(x['finance']for x in a))/pat,'capital_creditor_adjusted_ratio':(cf-D('.5464'))/pat,'limitations':'Original annual vintages not a homogenized IPO restatement. Capital-creditor recast applies FY26 only; interest outside reported CFO.'})
 rest=[convert(x)for x in f['restated_years']];cf=sum(x['cfo']for x in rest);pat=sum(x['pat_total']for x in rest);conversion.append({'vintage':'IPO-restated FY23–25 only','years':3,'from':2023,'to':2025,'cfo':cf,'pat':pat,'ratio':cf/pat,'after_finance_ratio':(cf-sum(x['finance']for x in rest))/pat,'capital_creditor_adjusted_ratio':None,'limitations':'Independent vintage-coherent positive counterevidence; not spliced into original annual ratio.'})
 incremental=[]
 for years in[3,5]:
  a=hist[-years-1];b=hist[-1];seg=hist[-years:];delta=b['funding_ic']-a['funding_ic'];dn=b['nopat']-a['nopat'];capex=sum(x['capex_cash_gross']for x in seg);da=sum(x['da']for x in seg);wc=b['basic_onwc']-a['basic_onwc'];bridge=capex-da+wc;incremental.append({'years':years,'from':a['year'],'to':b['year'],'delta_nopat':dn,'delta_funding_ic':delta,'ratio':dn/delta if delta>D('.01')else None,'gross_capex':capex,'da':da,'delta_basic_onwc':wc,'identified_net_investment':bridge,'residual':delta-bridge,'limitations':'Original annual accounting proxy, not project IRR; IPO cohort immature, historical depreciation restated, other advances/claims and original finance classifications prevent clean attribution.'})
 last=hist[-1];price=D(m['quote']['price']);shares=m['issued_shares'];cap=price*shares/10000000;ev=cap+last['debt']-last['available_cash'];lot=m['lot_size'];lv=price*lot;budgetlots=int(D(500000)//lv)
 obs=m['secondary_observations'];values=[D(r['turnover_inr'])for r in obs];mean=sum(values)/len(values);med=median(values);basis=min(mean,med)
 market={'price':price,'price_date':m['quote']['date'],'price_quality':'Secondary corroborated, not primary verified/executable','shares':shares,'market_cap':cap,'ev_march_balance_bridge':ev,'pe_reported':cap/last['pat_total'],'pe_normalized':cap/last['normalized_pat'],'pb':cap/last['equity'],'ev_core_ebitda':ev/last['core_ebitda'],'fcf_yield':last['fcf_proxy']/cap,'lot':lot,'lot_value':lv,'budget_lots':budgetlots,'budget_shares':budgetlots*lot,'budget_cost':budgetlots*lv,'secondary_observed_sessions':len(obs),'secondary_mean_turnover':mean,'secondary_median_turnover':med,'secondary_partial_exit_days':{str(p):D(500000)/(p*basis)for p in[D('.02'),D('.05'),D('.10')]},'primary_20_day':None,'primary_60_day':None,'missing_dates_treated_as_zero':False,'limitations':'17 secondary observed sessions23Sep–19Oct only; not a20/60-session liquidity sample.14Oct absent, not proven zero; deliverable quantity not total volume. No L point score derived.'}
 interim=f['interim'];return {'history':hist,'restated_history':rest,'cagr':cagr,'cash_conversion':conversion,'incremental_returns':incremental,'market':market,'latest_normalization':{'original_prior_pat':hist[-2]['pat_total'],'restated_prior_pat':rest[-1]['pat_total'],'reported_pat_growth':last['pat_total']/hist[-2]['pat_total']-1,'restated_comparison_pat_growth':last['pat_total']/rest[-1]['pat_total']-1,'normalized_pat':last['normalized_pat'],'reported_pat':last['pat_total'],'core_ebitda':last['core_ebitda'],'adjusted_operating_cfo':last['cfo']-D('.5464'),'adjusted_cash_capex':last['capex_cash_gross']-D('.5464'),'same_adjusted_fcf':last['fcf_proxy'],'core_committed_roic_fy26':last['nopat']/((D('16.1745')+D('31.0696'))/2),'core_committed_incremental_one_year':(last['nopat']-hist[-2]['nopat'])/(D('31.0696')-D('16.1745'))},'interim':interim}
