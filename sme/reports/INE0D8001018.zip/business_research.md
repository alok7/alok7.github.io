# Shining Tools Limited: business, physical capacity and economic peer evidence

Information cutoff: 20 October 2026. Historical operating scope: standalone Shining Tools Limited, ISIN INE0D8001018. This note supports the complete v3.0 company research; it is not a separate buy recommendation. All quantities and financial inputs below are source-specific. INR crore unless explicitly stated.

## 1. What the business actually sells

Shining manufactures solid-carbide end mills, ballnose tools, drills, threadmills, custom tools, tiny tools and reamers under TIXNA. It also regrinds, resharpens and arranges recoating of customers' existing tools. Standard tools generally require 8–10 days; custom tools require customer-approved drawings and typically 1–3 weeks, depending on complexity. Recoating is outsourced to Oerlikon Balzer Coating India Pvt Ltd or Nissin Advanced coating Indo Co Private Limited. Shining says it does not own coating capacity because of initial capital cost and technology barriers. The investment thesis therefore concerns a local specialist grinding/design/service operation, not a fully vertically integrated carbide or coating producer. [ST-PROS, printed 164–167/PDF 169–172]

The company identifies automobile, engineering, aerospace, defence, space, medical and energy applications, but their sales mix is ND. Customer qualification and application engineering can create useful relationship friction, particularly for customized repeat orders. However, customer retention, qualification duration, market share and industry-relative pricing premiums are not quantified. No long-term customer contracts were disclosed. The IPO document's foreign and domestic market-size discussion also mixes machine tools with cutting tools, making those headline TAMs unsuitable as verified bottom-up demand ceilings. [ST-PROS, printed 33–34,147–149,164–167; ST-AR26, printed 42/PDF 48]

## 2. Physical capacity: preserve the two different unit classes

The original engineer certificate, inspected 10 May 2025 and visually checked on PDF 4, records five CNC tool grinders. It shows a historical 100,000-unit allocation, expanded to 125,000 annual units. Its 89% utilization figure refers to annualized April 2024–February 2025, not the later full FY 2025 period. The final prospectus refers to a newer independent engineer certificate dated 20 September 2025 and reports the same 125,000-unit installed baseline. The final prospectus's 90% FY 2025 utilization is a period/rounding difference, not an adverse finding. [ST-CE, PDF 4; ST-PROS, printed 103–104/PDF 108–109]

| Annual allocated capacity | Historical baseline | Proposed increment | Proposed total |
|---|---:|---:|---:|
| Newly manufactured cutting tools |45,000|54,000|99,000|
| Reconditioning service jobs |80,000|96,000|176,000|
| Total heterogeneous units/jobs |125,000|150,000|275,000|
| Grinding machines |5|6|11|

The seven physical new-tool categories in the baseline are end mills 15,625; ballnose 5,000; drills 7,500; threadmills 1,875; custom tools 11,250; tiny tools 1,875; and reamers 1,875. These physical categories are different from the standardized/customized revenue categories. All 275,000 planned units must not be modeled as high-realization new tools. Nor should the model assume eleven machines are already operating and add the IPO six again. The category allocations share grinding infrastructure; machine-hour bottlenecks, complexity and changeover effects are ND. [ST-PROS, printed 103–104/PDF 108–109]

The FY 2026 annual report gives only an above 90% utilization statement without a current capacity denominator. Its equipment discussion identifies Walter grinding and Zoller inspection capabilities but does not provide a complete installed-machine or commissioning register. It reports ₹8.0838 crore plant-and-machinery additions, while a separate foreign-exchange disclosure attributes ₹4.69256 crore outflow to two machine purchases. Those are positive investment evidence, not proof that the entire six-machine project reached qualified commercial output. Current machine count, actual FY 2026 unit production, commissioning dates and product-level utilization remain ND. Capital advances and cash paid also cannot be equated to productive commissioning. [ST-AR26, PDF 6, 41, 48, 82]

## 3. Production and revenue bridge

| Period | New-tool production | Service jobs | Product sales | Service revenue | Product revenue/production unit, INR | Service revenue/job, INR |
|---|---:|---:|---:|---:|---:|---:|
|FY 2023|33,245|61,394|7.3372|2.9843|2,207.01|486.09|
|FY 2024|29,510|56,956|7.7034|2.8261|2,610.44|496.19|
|FY 2025|39,346|72,825|11.8372|2.8916|3,008.49|397.06|
|FY 2026|ND|ND|15.4717|2.8232|ND|ND|

Production quantities come from the final prospectus's operational KPIs, printed 129–130/PDF 134–135. FY 2023–FY 2025 revenue split comes from printed 162/PDF 167; FY 2025 and FY 2026 product/service totals are controlled to ST-AR26 note 19, printed 79/PDF 85. The prospectus's two FY 2025 product categories sum to ₹11.8373 crore, one thousand rupees above the ₹11.8372 crore audited product total. Preserve the rounding difference rather than altering either source.

The unit ratios above are mixed-production realization proxies, not verified invoiced selling prices: production is not confirmed sales volume, inventories can move, and mix differs. FY 2025 new-tool production rose 33.33% while product revenue grew 53.66%, indicating both increased output and stronger realized mix/pricing in the aggregate proxy. Reconditioning jobs rose 27.86% but revenue increased only 2.32%, so service volume did not translate into similar revenue growth. For FY 2026, products added ₹3.6345 crore while services declined ₹0.0684 crore; the total operating sales addition was ₹3.5661 crore. FY 2026 volume versus price/mix is not separately disclosed.

Customized tools represented 52.73% of operating revenue in FY 2023, 59.63% in FY 2024, 73.19% in FY 2025 and 79.98% in the April–July 2025 stub. Standard tools fell from 18.36% to 7.18% over FY 2023–FY 2025. The final prospectus provides selected invoice examples of increased prices: Capiq Engineering's specified end mill rose from ₹1,752 in FY 2023 to ₹3,065 in FY 2025, while a specified Varun Metacraft drill rose from ₹8,080 to ₹13,240. These are useful positive counterevidence, but not a complete price index or proof that every customer accepts such increases. [ST-PROS, printed 162,244–245/PDF 167,249–250]

Management also attributes part of FY 2024 profit improvement to elimination of ₹1.55 crore annual machinery rent after purchasing the machinery. This is an ownership/capital-allocation and margin bridge, not incremental revenue growth. Reconditioning is described as requiring no new raw-material consumption; it still requires labor, machine time and outsourced coating/job-work. A gross margin based only on carbide consumption would therefore overstate the full economic contribution. [ST-PROS, printed 241–245/PDF 246–250]

## 4. Funded expansion versus the execution still to establish

The final IPO plan earmarked ₹9.0653 crore for machinery and installation:₹8.3358 crore for six ANCA grinding machines and ₹0.7295 crore for two filters and two oil chillers. The ANCA basket comprised one CPX Linear, three FX5 Linear and two FX5E Linear machines. The quote was AUD 1,492,000 translated at ₹55.87/AUD, dated 21 September 2025 with 90-day validity. Quoted plant prices and reported later capital expenditure are distinct vintages. [ST-PROS, printed 105–106/PDF 110–111]

The existing property has 1,603.27 square metres of land and 1,945.86 square metres of built-up space. Proposed expansion required 400 square metres against 642.21 square metres free on the ground/first floors. This supports physical site fit, not demand or commissioning. [ST-PROS, printed 102–103/PDF 107–108]

Management originally expected December 2025 commissioning, January 2026 ramp-up,₹1.50–1.75 crore monthly incremental output capacity and ₹3.00–3.50 crore incremental FY 2026 sales from new machinery. Its forecast FY 2026 turnover was ₹21.33 crore. Actual operating revenue was ₹18.2949 crore, 14.23% below that forecast, but still 24.21% above FY 2025. No complete commissioning/output reconciliation was located. The shortfall warrants investigation, not an assertion that the machines never arrived. [ST-PROS, printed 120–121/PDF 125–126; ST-AR26 note 19]

At FY 2025 realization proxies, full utilization of the old 45,000-tool/80,000-job mix gives ₹16.71469 crore annual revenue; the planned 99,000-tool/176,000-job mix gives ₹36.77232 crore. These are scenario checks, not sales forecasts. FY 2026 revenue exceeding the first figure could reflect richer mix, prices or actual capacity additions; it cannot identify which. A much larger model revenue path needs additional productive capacity, higher price/mix, greater service value or acquisitions, each with its funding and demand support.

Replacement capex is ND. The original equipment register contains installations from 2013 onward; age and maintenance demands matter. FY 2026 machinery-repair expense rose to ₹0.1610 crore from ₹0.0367 crore, with other repairs ₹0.0175 crore versus ₹0.0203 crore. Reported depreciation is WDV, single-shift, Schedule II/estimated useful-life based, not a direct replacement-capex estimate. A model maintenance floor should be an explicit sensitivity, not an invented disclosed commitment. [ST-CE, PDF 5–6; ST-AR26 accounting policy and note 26, printed 82/PDF 88]

## 5. Demand concentration and the limits of supplier evidence

The top customer rose from 7.48% of operating sales in FY 2023 to 19.85% in FY 2025; the top ten rose from 43.19% to 56.91%. April–July 2025 figures were 17.95% and 54.80%, respectively, a modest improvement over the FY 2025 peak but an unequal stub period. No FY 2026 concentration table was located. The annual report's broad claim of no client concentration does not supersede the numeric prospectus record. [ST-PROS, printed 33–34,163; ST-AR26, printed 42]

Gujarat accounted for 89.96%, 88.95%, 92.68% and 93.50% of sales in FY 2023, FY 2024, FY 2025 and the April–July 2025 stub. Industry variety therefore does not imply geographic diversity. Regional factory disruption or loss of a few important accounts is a credible linked stress. [ST-PROS, printed 161–162]

One disclosure footnote calls the customer denominator product sales. Its reported 19.85% equals ₹292.35 lakh divided by ₹1,472.88 lakh total operating sales, not product-only sales; the business table also describes total revenue. The analysis uses total operating sales and preserves that footnote discrepancy.

For raw carbide, the top supplier represented 59.29%, 56.02%, 46.11% and 32.32% over the same periods. The top five supplied 98.72% in FY 2025; there were nine raw-carbide suppliers. No long-term supplier agreement was disclosed. Management reports no previous procurement difficulty or losses from vendor departures, a material positive counterpoint. However, the FY 2025 all-purchases table gives its largest supplier ₹124.73 lakh whereas the raw-carbide subset gives ₹147.18 lakh. Different denominators alone cannot reconcile a subset maximum exceeding the overall maximum. Supplier identity/scope clarification is needed, without inferring diversion or fraud. [ST-PROS, printed 39–40,163–164]

## 6. Orders and newer perimeter evidence

A verified 12 May 2026 filing announces a Chandan Process order for 50 “Qts” of brazed carbide anvils,₹2.006 crore including 18% GST, or ₹1.70 crore excluding GST. Delivery was due within six months, with 100% payment at delivery. The filing says there is no related-party or promoter interest. Receipt of the order is verified; execution, collection and the meaning of Qts for comparison to normal tool units are not. Do not add this amount to recognized revenue without a reconciliation. [ST-ORDER-MAY, PDF 1–2]

Secondary discovery indicates a 24 August 2026 first export order from YIWU KAIPAN IMPORT & EXPORT CO., LIMITED for USD 95,292 and 1,708 units described as machinery, with 15-day delivery and partial shipments/payments. Its original attachment was located, but BSE returned HTTP 403 through direct and web reads. It is not promoted to verified fulfillment or revenue. The exact primary target is:
https://www.bseindia.com/xml-data/corpfiling/AttachLive/27a8d005-5bcc-41e7-9609-9cd729ce9292.pdf

Similarly, secondary sources describe 10 September 2026 incorporation of Shinvi Tools Limited, 55% held by Shining and ₹1 lakh paid-up capital. The primary subsidiary-approval target returned HTTP 403:
https://www.bseindia.com/xml-data/corpfiling/AttachLive/9530b108-088f-4e40-92cf-cf728100611a.pdf

The historical financial scope remains standalone; a future subsidiary/NCI bridge should not assume zero claims or assign unsupported growth value. Discovery sources are retained separately and are not substitutes for the underlying filings.

## 7. Financing source constraint

The 8 July 2026 CRISIL rationale continues B/Stable with an issuer-not-cooperating suffix. It explicitly relies on limited or dated information and says the rating lacks a forward-looking component. The table lists ₹3.70 crore cash credit plus ₹4.30 crore proposed long-term facility, totaling ₹8.00 crore. The proposed amount is not verified available funding. The ₹3.70 crore rating quantum is not a current lender sanction certificate and differs from the prospectus facility vintage. Any draw headroom must remain conditional until reconciled with sanctioned limits, utilization, covenants and renewal conditions. Non-cooperation is an evidence warning, not an established default. [ST-CRISIL26, Rating Action, Detailed Rationale and Instrument Annexure]

The original primary HTML was successfully preserved, separately from the web tool response. Original HTML SHA-256: 804f3ad51d69f6d9e09cccb8a00c0b603879055abfedda58b326b96c0d6e5f41.

## 8. Economic peer checks

All metrics below are derived from current primary records available before the cutoff, not aggregator values. Operating EBITDA is PBT plus finance cost plus D&A less all other income. Reported exceptional/employee-obligation costs remain unless separately discussed. All cash-conversion figures use ratios of sums. These are economic comparisons, not full peer ratings or same-price investment rankings.

| Standalone peer | Fiscal year end | Revenue | Revenue YoY | Operating EBITDA margin | CFO | PAT | Two-year CFO/PAT | CFO minus cash operating capex |
|---|---|---:|---:|---:|---:|---:|---:|---:|
|Kennametal India|30 June 2026|1,510.70|29.09%|20.10%|18.30|196.00|0.546 x|−35.30|
|Forbes Precision/TOTEM|31 March 2026|251.0113|7.89%|21.09%|27.5529|28.7730|1.371 x|9.1611|
|Birla Precision|31 March 2026|238.4013|15.07%|7.09%|34.4824|11.6236|3.370 x|7.2025|
|Wendt India|31 March 2026|209.31|−2.59%|19.03%|32.86|22.75|1.077 x|21.47|

Kennametal is the direct global-parent cutting-tool/hard-metal benchmark. Its FY 2026 hard-metal revenue was ₹1,363.6 crore, while machining solutions contributed ₹147.1 crore and incurred a segment loss. Although revenue and PAT grew strongly, inventory absorbed ₹313.9 crore and receivables ₹79.2 crore, partly funded by ₹162.6 crore additional payables. The low current cash conversion is a useful warning against awarding quality solely for a large brand or growth. The balance sheet shows no bank borrowing,₹46 crore cash and ₹1.9 crore leases. A ₹5.2 crore Labour Code gratuity charge is retained in reported operating earnings. June versus March timing differs. [PEER-KENN26, PDF 4–8]

Forbes Precision's carbide/HSS round tools directly overlap with Shining; its service component is much smaller. Reported ROCE was 22%, debt/equity 0.10 and receivables turnover 7.94 x, about 46 days. PAT was effectively flat despite 7.89% revenue growth, and inventory absorbed ₹24.4908 crore. Its ₹5.90 crore Labour Code obligation is retained in the table. The company-reported headline EBITDA includes other income and is not the comparable operating margin used here. [PEER-FORBES26, PDF 69–71,100,117,125]

Birla is a relevant weaker/mixed comparator, also named in Shining's prospectus. It has cutting tools, holders and precision components, not an identical mix. Other income ₹9.1302 crore includes interest ₹4.6361 crore and balances written back ₹2.8526 crore, so the PAT recovery should not be mistaken for entirely operating growth. Its high CFO/PAT also reflects non-cash provisions, liability movements and recovery of employee/other loans. Net receivables imply 92.05 days on an average-net-balance/total-sales basis. The published 3.43 x turnover implies 106.41 days and does not reconcile to those net balances; both definitions are retained. Its cash capex excludes a separate ₹14.50 crore related-party loan outflow. [PEER-BIRLA26, printed 100–103,124–125,136–139]

Wendt is an adjacent superabrasives/grinding and precision-components comparator, not a pure carbide-round-tool peer. Standalone revenue and PAT declined; machine dispatch approvals and pricing concessions hurt results. CFO benefited from ₹17.33 crore receivables release, despite ₹11.77 crore inventory absorption. Its reported 15% ROCE excludes intangibles and is not comparable to full-acquisition-capital post-tax ROIC. FY 2025 cash capex included ₹35.56 crore intangible payments;FY 2026 also invested ₹17.27 crore in a German subsidiary, outside the table's cash operating capex. [PEER-WENDT26, printed 16,127–130,175]

Peer ratios therefore bound expectations rather than determine Shining's score. Shining's high reported margin needs reconciliation to product mix, rental-to-owned machinery economics, depreciation vintages, cash conversion and working capital. Larger peers demonstrate that comparable product capability is available; they do not prove that Shining lacks a valuable niche. Same-cutoff peer prices and valuation multiples remain ND.

## 9. Inputs that would change the operating conclusion

1. A machine-by-machine purchase, delivery, commissioning and qualification register reconciled to IPO cash uses and capital advances.
2. FY 2026 and subsequent new-tool/service quantities, realized prices and machine-hours by product family.
3. Updated top-customer/supplier concentration, ageing, credit terms and the supplier-table discrepancy reconciliation.
4. Evidence of execution and collection on Chandan and export orders, rather than order-receipt headlines.
5. Current bank sanction, utilization, covenant and renewal evidence, including reconciliation of ₹3.7 crore versus ₹5 crore facility vintages.
6. A replacement/maintenance budget and actual service downtime, rather than assuming depreciation equals cash capex.
7. The incorporated subsidiary's primary ownership, capital commitments, operations and minority claims.

## Source identities and archive treatment

Exact URLs, document dates, page references, file SHA-256 and monetary/physical inputs are in business_inputs.json and peer_inputs.json. Primary originals, extracted text and OCR remain local research evidence and are not intended for source-safe delivery archives. The authored inputs retain the facts, formulas and limitations needed for reproduction.

- ST-PROS: https://www.tixnatools.com/wp-content/uploads/2025/11/PROSPECTUS.pdf
- ST-CE: https://www.tixnatools.com/wp-content/uploads/2025/06/CE-Report_Final_14-6-25.pdf
- ST-AR26: https://www.tixnatools.com/wp-content/uploads/2026/09/Annual-report-FY-2025-26.pdf
- ST-ORDER-MAY: https://www.tixnatools.com/wp-content/uploads/2026/07/Intimation-regarding-Award-of-Order.pdf
- ST-CRISIL26: https://www.crisil.com/mnt/winshare/Ratings/RatingList/RatingDocs/ShiningToolsLimited_July%2008_%202026_RR_398546.html
- PEER-KENN26: https://in.investors.kennametal.com/static-files/f15f9897-0e93-493d-926d-ec63c9d8d545
- PEER-FORBES26: https://forbesprecision.co.in/wp-content/uploads/2026/07/Annual-Report-2025-2026.pdf
- PEER-BIRLA26: https://www.birlaprecision.com/documents/investor/Financial%20Results/ANNUAL%20REPORTS/AR-25-26.pdf?v=1
- PEER-WENDT26: https://wendtindia.com/wp-content/uploads/2026/07/Wendt-AR-2026-Hires.pdf
