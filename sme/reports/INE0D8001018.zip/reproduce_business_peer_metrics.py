#!/usr/bin/env python3
"""Reproduce authored business/peer arithmetic using only the two JSON inputs.

Run from any working directory. Stdout is the calculated economic-metric output;
no source PDF, network connection or private helper is a runtime dependency.
Decimal precision is 28, matching the authored inputs. This script validates
arithmetic, not source truth, installed capacity, or the investment conclusion.
"""
import json
from pathlib import Path
from decimal import Decimal as D, localcontext

ROOT = Path(__file__).resolve().parent


def match(actual, expected, label):
    if D(actual) != D(expected):
        raise AssertionError(f"{label}: calculated {actual}, stored {expected}")


def reproduce():
    business = json.loads((ROOT / "business_inputs.json").read_text())
    peers = json.loads((ROOT / "peer_inputs.json").read_text())
    out = {"decimal_precision": 28, "historical_unit_economics": [], "capacity_scenarios": {}, "FY2026_mix": {}, "peers": []}
    for row in business["historical_unit_economics"]:
        quantity = sum(row["product_units_by_category"].values())
        match(quantity, row["new_tool_production_units"], row["period"] + " production sum")
        match(quantity + row["reconditioning_jobs"], row["all_units_heterogeneous"], row["period"] + " units/jobs")
        rev = {k: D(v) for k, v in row["revenue_crore"].items()}
        match(rev["product"] + rev["service"], rev["total"], row["period"] + " audited revenue")
        values = {
            "product_revenue_per_production_unit_inr": rev["product"] * 10**7 / quantity,
            "service_revenue_per_job_inr": rev["service"] * 10**7 / row["reconditioning_jobs"],
        }
        for key, value in values.items():
            match(value, row[key], row["period"] + " " + key)
        out["historical_unit_economics"].append({"period": row["period"], **{k: str(v) for k, v in values.items()}})
    cap = business["capacity"]
    match(sum(cap["base_by_product"].values()), cap["base_new_tool_annual_units"], "base product capacity")
    match(sum(cap["increment_by_product"].values()), cap["planned_increment_new_tool_units"], "increment product capacity")
    match(cap["base_new_tool_annual_units"] + cap["base_service_annual_jobs"], cap["base_total_heterogeneous_units"], "base units/jobs")
    match(cap["base_total_heterogeneous_units"] + cap["planned_increment_heterogeneous_units"], cap["planned_total_heterogeneous_units"], "planned total units/jobs")
    match(cap["base_grinding_machines"] + cap["planned_new_grinding_machines"], cap["planned_total_grinding_machines"], "planned total grinders")
    unit = out["historical_unit_economics"][-1]
    new_rate = D(unit["product_revenue_per_production_unit_inr"])
    service_rate = D(unit["service_revenue_per_job_inr"])
    for key, new_units, service_jobs in [
        ("FY2025_realization_full_old_capacity_revenue_crore", cap["base_new_tool_annual_units"], cap["base_service_annual_jobs"]),
        ("FY2025_realization_full_planned_capacity_revenue_crore", cap["planned_total_new_tool_units"], cap["planned_total_service_jobs"]),
    ]:
        value = (new_rate * new_units + service_rate * service_jobs) / 10**7
        match(value, cap[key], key)
        out["capacity_scenarios"][key] = str(value)
    mix = business["FY2026_mix"]
    prior = business["historical_unit_economics"][-1]["revenue_crore"]
    mix_values = {
        "service_pct": D(mix["service_revenue_crore"]) / D(mix["total_revenue_crore"]) * 100,
        "product_yoy_pct": (D(mix["product_revenue_crore"]) / D(prior["product"]) - 1) * 100,
        "service_yoy_pct": (D(mix["service_revenue_crore"]) / D(prior["service"]) - 1) * 100,
    }
    for key, value in mix_values.items():
        match(value, mix[key], key)
    out["FY2026_mix"] = {k: str(v) for k, v in mix_values.items()}
    for row in peers["peers"]:
        v = {k: D(n) / D(row["divisor_to_crore"]) for k, n in row["raw"].items()}
        for key, value in v.items():
            match(value, row["crore"][key], row["company"] + " " + key)
        e = v["PBT"] + v["finance_cost"] + v["DA"] - v["other_income"]
        pe = v["prior_PBT"] + v["prior_finance_cost"] + v["prior_DA"] - v["prior_other_income"]
        values = {
            "revenue_yoy_pct": (v["revenue"] / v["prior_revenue"] - 1) * 100,
            "PAT_yoy_pct": (v["PAT"] / v["prior_PAT"] - 1) * 100,
            "operating_EBITDA_crore": e,
            "prior_operating_EBITDA_crore": pe,
            "operating_EBITDA_margin_pct": e / v["revenue"] * 100,
            "prior_operating_EBITDA_margin_pct": pe / v["prior_revenue"] * 100,
            "CFO_PAT_latest": v["CFO"] / v["PAT"],
            "CFO_PAT_2Y_ratio_of_sums": (v["CFO"] + v["prior_CFO"]) / (v["PAT"] + v["prior_PAT"]),
            "reported_FCF_proxy_crore": v["CFO"] - v["cash_capex"],
        }
        if "closing_receivables" in v:
            values["average_receivable_days_sales_proxy"] = (v["closing_receivables"] + v["opening_receivables"]) / 2 / v["revenue"] * 365
        elif "receivables_turnover" in row.get("reported_ratios", {}):
            values["average_receivable_days_from_reported_turnover"] = D(365) / D(row["reported_ratios"]["receivables_turnover"])
        if set(values) != set(row["derived"]):
            raise AssertionError(row["company"] + ": unhandled derived metric")
        for key, value in values.items():
            match(value, row["derived"][key], row["company"] + " " + key)
        out["peers"].append({"company": row["company"], "period": row["period"], "derived": {k: str(v) for k, v in values.items()}})
    return out


if __name__ == "__main__":
    with localcontext() as context:
        context.prec = 28
        print(json.dumps(reproduce(), indent=2, ensure_ascii=False))
