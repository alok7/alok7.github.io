# Shining Tools Limited | SME research 365

Information cutoff: 20 October 2026. Market reference: 19 October 2026. Master Prompt v3.0. INR crore unless noted. GQS means Growth Quality Score.

## 1. Executive Verdict

Shining Tools manufactures TIXNA solid-carbide cutting tools and reconditions used tools. The useful strength is real industrial revenue expansion, with five-year audited operating-revenue CAGR of 18.12%, technical customization and an IPO-funded equipment program. The decisive uncertainty is whether that new capital can turn into collected, per-share earnings: current commissioned throughput is not established, working capital absorbed cash, original and IPO-restated profits require different comparisons, and current bank availability is unverified. At the secondary-corroborated ₹ 180 close, the business is approximately 32.6× normalized earnings, not an obvious cash-supported bargain. This is a small industrial reinvestment/special-situation research watch, not an evidence-backed compounder. BQS, GQS and IAS remain NS for specified missing factors, not a disguised low score. Reconciled commissioning, capital returns, current funding and executable market data could change that conclusion. No observed default or fraud is established. [AR26 PDF 68–70,85–95; Prospectus PDF 108–109,134–135,288; MKT_IIFL]

## 2. Research Header, Gates and Data Confidence

| Item | Verified or qualified value |
|---|---|
| Issuer/security | Shining Tools Limited / BSE SME / SHTL / 544607 / INE0D8001018 |
| Dates | Information 20 October 2026; secondary close 19 October 2026 |
| Price and current-share market cap | ₹180.00 / ₹101.85 crore; primary close unavailable |
| Issued / authorized shares | 5,658,400 / 6,500,000, March annual and dated interoperability metadata |
| Framework | v 3.0 / SHA256 68d4de4255427df276318d0231530b867a453e740c74150e9768bf1387224137 |
| Scope / currency | Standalone Indian GAAP; INR crore |
| Horizon / equity hurdle | 5 years, optional 10;15% nominal, before investor taxes |
| Implementation reference | ₹5 lakh, not a recommended allocation;1,200-share lot |

The original list had “Shining Tools”, ISIN INE0D8001018 and a null symbol with listing verification pending. Those fields are preserved unchanged. The issuer's May 2026 BSE filing names SHTL / 544607; BSE's 14 November 2025 release confirms SME listing. The official 19 October interoperability master is metadata for the BSE-only security, not evidence of an NSE listing or a trade. Its SHTL$ symbol must not replace the BSE symbol silently. [Results26 PDF 1; AR26 PDF 2,22; MKT_INTEROP]

Historical audited scope is standalone Indian GAAP Accounting Standards, not Ind AS. September 2026 subsidiary and August management-change leads are separately qualified in the business supplement; no subsidiary profit, cash or NCI is invented. Fiscal 2026 is the latest verified full year. September 2026 results were not located by the information cutoff, and no later TTM or quarterly CFO has been manufactured. The April–July 2025 IPO stub is four months despite occasional document wording of five; it is not annualized. [AR26 policies; Results26; Prospectus]

| Gate | Status | Finding / closure |
|---|---|---|
| G1 | Conditional | Resolved historical legal lapses and ongoing control/compliance weaknesses; no substantiated severe current diversion found. Verify database audit trail, continued timely statutory compliance and current related-party terms. |
| G2 | Conditional | Original and IPO-restated figures are explicitly bridged; main audit unmodified. Carry-forward/useful-life and financing classifications limit comparable-return confidence. Obtain accounting-policy/carry-forward reconciliation and loan-wise financing bridge, retaining both original and restated evidence. |
| G3 | Hold — unresolved | Current bank cash/headroom and exact maturity schedule unverified; March-only conditional funding failures are not observed default. Current bank confirmations, sanctioned availability, loan-wise repayment and capex commitments. |
| G4 | Hold — unresolved | Listing/ISIN/lot resolved, but primary turnover/depth and current implementation restrictions not verified. Primary BSE20/60-session data and live executable lot/spread/circuit checks. |

| Subject | Confidence |
|---|---|
| identity | High |
| original financial extraction | High |
| vintage comparability | Medium |
| governance | Medium |
| volume price growth | Medium |
| incremental capital returns | Low |
| current funding | Low |
| valuation and implementation | Low |

“Clear” would mean no obstacle found, not a guarantee. Here current funding and implementation are unresolved. The historical financial disclosures are usable with explicit bridges; neither a clean main audit nor a resolved legal contravention erases other weaknesses. Overall confidence in a current investment conclusion is Low because its weakest material inputs are current funding/capital returns and execution data.

## 3. Scorecard and Calculation Audit

| Measure | Raw / final | Known weighted contribution | Coverage | Missing bound | Dependency-aware bound |
|---|---|---|---|---|---|
| BQS | NS / NS | 4.3400 | 80.00% | 4.5400 to 6.3400 | 4.5400 to 6.3400 |
| GQS | NS / NS | 5.2500 | 85.00% | 5.4000 to 6.7500 | 5.4000 to 6.7500 |
| IAS | NS / NS | 1.2000 | 30.00% | 1.9000 to 8.2000 | 2.7850 to 7.2850 |

| Factor | Score / confidence | Evidence and contrary evidence | BQS / GQS / IAS contributions |
|---|---|---|---|
| GOV | 5 / Medium | Historical section 185 director-connected loans were disclosed as violations; loans were repaid and May 2025 compounding paid. FY24–25 audit-trail weaknesses and recurrent statutory-filing/payment lapses persist as stewardship concerns; FY26 application trail reportedly operated but database assurance remains absent. Contrary: Unmodified main opinions and clean IFC, no bank default/fraud reported, completed late filings and settled old loans are meaningful counterevidence. Judgment: Mixed stewardship, not evidenced severe current diversion. Do not apply governance override or infer misconduct from auditor change. IDs: AUDIT_LEGAL, AUDIT_TRAIL, AR26, Prospectus | 1.00 / NA / NA |
| MOAT | 5 / Medium | Custom tools, design approval and resharpening provide technical familiarity and repeat-service relationships. Gujarat was 92.68% of FY25 revenue; top customer 19.85%, top 10 56.91%, and no long-term contracts limit bargaining power. Contrary: Selected customer invoice price increases and replacement of rental machinery support better economics; neither demonstrates broad durable pricing power against Kennametal/Sandvik. Judgment: Useful but contestable niche process/customer position; no verified market-share lead or persistent excess-return moat. IDs: ST-PROS, ST-CE, PEERS | 1.00 / NA / NA |
| REV | 7 / Medium | Preselected five-year original audited operating-revenue CAGR FY21–26 is 18.1177% from ₹7.9571 crore to ₹18.2949 crore; schedule starts 7. FY26 product sales grew 30.70% while services fell 2.37%; H2 revenue growth slowed to 9.52% from the strong first half. Contrary: Three-year reported CAGR21.02% and growing new-tool quantities FY23–25 are positive, but production≠sales and price/mix gains prevent claiming all growth is volume. Judgment: Keep 7 with no trajectory adjustment. No small-base penalty. Underlying expansion is evidenced; incomplete price/volume split limits confidence toMedium and historical scores to 8. IDs: FY22, FY23, AR26, Results26, ST-PROS | 0.84 / 2.80 / NA |
| DUR | 6 / Medium | Consumable cutting tools and reconditioning address repeat industrial machining demand across an established local customer base. IPO plan adds 54,000 new-tools and 96,000 service jobs, but actual commissioned units and utilization denominator remainND. Contrary: A ₹1.70 crore ex-GST domestic order supports demand access; lack of broad geography and customer contracts plus global specialist competition bound runway. Judgment: Accessible demand exists but scaling beyond the specified factory/machine plan is conditional, not an unbounded TAM. IDs: ST-ORDER-MAY, ST-PROS, ST-AR26 | 0.60 / 1.20 / NA |
| CAP | NS / Low | Original 3Y/5Y funding-side incremental NOPAT/IC proxies are 14.17%/15.17%, with ₹1.3781 crore/₹2.1715 crore investment-bridge residuals. FY26 IPO capital is immature:₹3.93 crore capital advances and unverified commissioning; historical machinery-rent conversion and depreciation restatements alter the apparent profit return. Contrary: Core committed FY26 ROIC proxy 15.90% and lower debt provide positive evidence, but not a mature project return. Judgment: NS: full investment denominator, useful-life comparability, timing and product economics do not establish incremental unit/project returns sufficiently. No false penalty for temporarily uncommissioned capital. IDs: AR26, Restated, ST-CE, CAPITAL_BRIDGE | NS / NS / NA |
| CASH | 5 / Medium | FY26 reported CFO ₹1.0287 crore/PAT ₹3.8903 crore=0.2644x; excluding capital creditors gives operatingCFO ₹0.4823 crore, paired with equal capex adjustment. FY24–26 original ratio of sums 0.7209x and inventory/receivables/advances absorption show recent weaker realization. Contrary: OriginalFY22–26 CFO/PAT1.2952x and coherent IPO-restatedFY23–25 ratio 1.7756x are strong contrary facts; FY24 collections/inventory release helped. Judgment: Mixed history, recent deterioration. Not persistent whole-period destruction; no CASH≤3 or GQS cap merely because the IPO expansion year absorbed cash. IDs: AR26, FY24, Restated, CASH_BRIDGE | 0.50 / 0.50 / NA |
| BAL | NS / Low | March gross debt ₹6.2960 crore versus unrestricted cash ₹0.1053 crore; the ₹0.1783 crore IPO balance is restricted to machinery. Reported ₹1.7244 crore current bank maturities do not reconcile to printed instalments; July 2026 CRISIL rating isB/Stable INC and its ₹3.7 crore CC quantum is not a live sanction/headroom certificate. Contrary: IPO increased equity to ₹25.8616 crore; net debt/coreEBITDA about 0.93x and auditor reports no bank default or one-year survival uncertainty atMarch 26. Judgment: NS for current funding resilience, not an evidenced default. Require current bank balances/sanctions/maturity bridge; failed conditional model paths cannot establish actual insolvency. IDs: AR26, ST-CRISIL26, Prospectus | NS / NA / NA |
| EXEC | 5 / Medium | Prospectus projected ₹21.33 crore FY26 sales; actual ₹18.2949 crore was 14.23% lower. Dec 2025 commissioning/Jan 2026 ramp were promised, yet current output/capacity denominator remains undisclosed; spending does not prove all six machines operating. Contrary: Revenue still grew 24.21%; IPO use-of-proceeds certificate reports no deviation and planned machinery spending substantially occurred. Judgment: Mixed delivery merits 5: the single revenue forecast miss is a real adverse fact, but missing commissioning detail is an evidence gap, not a second proven failure. Positive growth and substantial deployment prevent a repeated-failure score. IDs: ST-PROS, AR26, Deviation | 0.40 / NA / NA |
| EARN | 5 / Medium | FY26 PAT ₹3.8903 crore grows 116.68% on originalFY25₹1.7954 crore but only 32.77% on restated ₹2.9301 crore; the bridge is explicitly disclosed. Core EBITDA ₹6.6766 crore and normalizedPAT ₹3.1252 crore remove all ₹0.4092 crore other income and normalize tax; FY26 deferred-tax credit ₹0.5329 crore and historical rent elimination distort headlines. Contrary: Revenue and recurring core operating profit grew, and IPO financed assets rather than an offer-for-sale; not all profit improvement is non-operating. Judgment: Mixed per-share operating progress after fresh shares and changing depreciation basis. No claim of 116.7% like-for-like profit growth. IDs: AR26, Restated, Prospectus, EARNINGS_BRIDGE | NA / 0.75 / NA |
| R | NS / Low | All monthly paths are source-ineligible because current liquidity, capacity and funding terms are unresolved. Strict source-only funding gates fail against stale March anchors; conditional funding cases are not supported base forecasts. Contrary: Conditional financed paths can survive and some ten-year stress envelopes cross high-return hurdles. Judgment: NS: do not turn a scenario-only IRR into a prospective-return score. IDs: MODEL, AR26, ST-CRISIL26 | NA / NA / NS |
| D | 4 / Medium | At the qualified ₹180 close, normalizedP/E is 32.59x and reportedFCF yield−10.84%; working capital and capex create correlated funding stress. Conditional funded reference and linked stress cases show substantial capital-loss exposure; single-customer loss and slow collections hurt simultaneously. Contrary: Reported leverage is modest relative to coreEBITDA and asset/equity base increased afterIPO; current default is not established. Judgment: Material impairment risk at the proxy entry price, not a predicted liquidation recovery. Scenario evidence and balance-sheet weakness support lower resilience. IDs: MODEL, AR26, MKT_IIFL | NA / NA / 0.80 |
| P | 4 / Medium | Proxy market capitalization ₹101.8512 crore implies 26.18x reported or 32.59x normalized earnings. Fully utilized planned capacity atFY25 proxy realizations supports only ₹36.77 crore revenue before further paid expansion, versus ambitious growth needed by return grids. Contrary: Reinvestment and price/mix improvements may beat conservative economics; the qualified price is not proof that all growth is priced in. Judgment: Several execution/capital assumptions must work together. This is a conditional valuation judgment, not a primary-quote execution recommendation. IDs: MODEL, ST-PROS, MKT_IIFL | NA / NA / 0.40 |
| L | NS / Low | Official interoperability master verifies 1,200-share lot and 5,658,400 issued; ₹216,000 per lot at proxy price. Only 17 secondary observed trading sessions are available; primary 20/60-session turnover, actual spread and restrictions not retrieved. Contrary: Two lots cost ₹432,000 within the ₹5 lakh reference, and secondary history contains trades; missing NSE rows do not mean no BSE trading. Judgment: NS: incomplete liquidity sample and no primary execution validation. Never impute omitted 14 Oct or NSE absence as zero. IDs: MKT_INTEROP, MKT_IIFL, MKT_BLINKX | NA / NA / NS |

Factors are integer judgments assigned once and reused. Exact Decimal arithmetic, original weights and half-up one-decimal display are used; missing weights are not redistributed. Bounds are mathematical missing-data bounds, not confidence intervals or ranked estimates. BQS uses GOV 20%, MOAT 20%, REV 12%, DUR 10%, CAP 12%, CASH 10%, BAL 8%, EXEC 8%. GQS uses REV 40%, DUR 20%, EARN 15%, CAP 15%, CASH 10%. IAS uses final BQS25%, R 35%, D 20%, P 10%, L 10%. No disclosed override is triggered: current severe governance failure, evidenced funding failure or persistent CAP/CASH≤3 are not established. NS remains NS.

The preselected growth window is the available six-observation FY2021–FY2026 series, not whichever CAGR scores best. The 18.12% CAGR starts REV at 7, without a trajectory uplift. Moving uncertain GOV and CASH by one point changes BQS's known contribution by up to 0.30 and GQS by 0.10, but does not cure missing CAP/BAL. Nearby scores would not justify spurious ranking precision.

## 4. Business Overview

The company operates a Rajkot-region manufacturing unit making end mills, drills, ballnose, thread mills, reamers and customized solid-carbide tools; it also regrinds, sharpens and recoats used tools. Custom orders depend on drawings, application knowledge and approval. The prospectus describes standard-tool delivery around 8–10 days and custom-tool lead time around 1–3 weeks, not long-duration committed backlog. Coating is outsourced to named specialist vendors rather than owned in-house. Goods revenue is recognized on transfer of risks/rewards and service income upon completion. Collections, not dispatch alone, ultimately fund growth. [ST-PROS printed 164–167/PDF 169–172; AR26 policy PDF 73]

FY2026 product revenue was₹ 15.4717 crore and service revenue₹ 2.8232 crore, compared with₹ 11.8372 crore/₹ 2.8916 crore in FY2025. Products supplied all of the net revenue increase: +₹ 3.6345 crore less₹ 0.0684 crore lower services. The recurring service stream is useful but declined 2.37%; it is not automatically a growing installed-base annuity. Gujarat contributed 92.68% of FY2025 revenue. Named aerospace, defence, automotive, medical and other end markets are claimed application categories, not a disclosed sales-mix allocation. [AR26 PDF 85; ST-PROS PDF 166–167]

## 5. Moat / Industry Position

Mechanism → evidence → durability → failure: custom design/application knowledge and repeat sharpening can reduce a customer's incentive to switch; the company has actual product/service sales and technical process experience. But no verified switching-cost duration, protected market share or broad price premium is disclosed. Customers can switch to larger specialist suppliers or rival local vendors, and the company's 92.68% Gujarat concentration limits proof of national distribution. The top customer represented 19.85% and top 10 56.91% of FY2025 operating revenue; no long-term agreements guarantee retention. These percentages use total operations despite a misleading “product sales” footnote. [ST-PROS customer table and business chapter]

Selected invoice samples show price increases between FY2023 and FY2025, and the purchase of previously rented machinery removed approximately₹ 1.55 crore annual rent. Both support real improvement. Selected invoices do not establish market-wide pricing power, while rent-to-ownership substitutes depreciation/capital commitments for operating rent. A capex decision cannot be counted once as a moat and again as unexplained organic profit growth. [ST-PROS printed 244–245/PDF 249–250; audit supplement]

| Peer / period / scope | Revenue / PAT ₹cr | Core EBITDA margin /2Y CFO-PAT | Economic interpretation / primary |
|---|---|---|---|
| Kennametal India Limited / year ended 2026-06-30 / Standalone; issuer states no subsidiary, associate or JV for these periods. June fiscal year. | 1,510.70 / 196.00 | 20.10% / 0.546× | Direct cutting-tool and hard-metal benchmark; much larger global-parent technology/distribution platform, not a size-matched valuation peer. FY26 inventory absorbed ₹313.9 crore and receivables ₹79.2 crore, partly funded by ₹162.6 crore additional payables; CFO was only ₹18.3 crore despite ₹196.0 crore PAT. [Primary](https://in.investors.kennametal.com/static-files/f15f9897-0e93-493d-926d-ec63c9d8d545) PDF4 P&L,5 segments,6 balance sheet,7 cash flow,8 notes |
| Forbes Precision Tools and Machine Parts Limited / year ended 2026-03-31 / Standalone precision cutting tools and related components; inherited operating business from demerger makes incorporation age misleading. | 251.01 / 28.77 | 21.09% / 1.371× | Direct Indian round-cutting-tool comparator: carbide and HSS taps, drills, end mills and reaming, under TOTEM. FY26 PAT was essentially flat despite 7.89% revenue growth; inventory absorbed ₹24.4908 crore. [Primary](https://forbesprecision.co.in/wp-content/uploads/2026/07/Annual-Report-2025-2026.pdf) PDF69 P&L;70–71 cash flow;100 revenue;117 ratios;125 Labour Codes |
| Birla Precision Technologies Limited / year ended 2026-03-31 / Standalone selected for like-scope table; consolidated FY26 revenue ₹247.1283 crore/PAT ₹11.2727 crore are different and not substituted. | 238.40 / 11.62 | 7.09% / 3.370× | Relevant weaker/mixed direct comparator used in Shining prospectus, but not pure-play: cutting tools, tool holders and precision components. Net receivables grew 36.84% versus revenue 15.07%. Average net receivables imply 92.05days using total sales. The reported 3.43x turnover implies 106.41days and does not reconcile to the two stated net balance-sheet balances; retain this denominator/definition discrepancy. [Primary](https://www.birlaprecision.com/documents/investor/Financial%20Results/ANNUAL%20REPORTS/AR-25-26.pdf?v=1) PDF51 printed 100–101 statements;PDF52 printed 102–103 cash flow;PDF63 printed 124–125 other income;PDF69–70 printed 136–139 ratios |
| Wendt (India) Limited / year ended 2026-03-31 / Standalone to avoid new German subsidiary scope distortion; consolidatedFY26 revenue ₹236.32 crore/PAT ₹14.55 crore differ. | 209.31 / 22.75 | 19.03% / 1.077× | Adjacent precision-consumables comparator: superabrasive grinding/honing tools, machines and precision components; not a carbide-round-tool pure-play. Revenue declined 2.59%, operatingEBITDA22% andPAT40.59%; customer dispatch clearances delayed machine business and pricing concessions affected margins. [Primary](https://wendtindia.com/wp-content/uploads/2026/07/Wendt-AR-2026-Hires.pdf) PDF18 printed 16 operating review;PDF129 printed 127 P&L;PDF131–132 printed 129–130 cash flow;PDF177 printed 175 ratios |

The peer comparison uses economically relevant carbide/cutting-tool, high-speed-tool and superabrasive businesses, not unrelated companies containing “Tools” in their names. Kennametal has superior scale/technology access but weak latest cash realization from inventory growth; Forbes Precision/TOTEM is a closer cutting-tool benchmark; Birla Precision illustrates weaker margins and normalization complexity; Wendt offers a specialist precision/superabrasive comparison with a different mix. Fiscal dates, scope, leases and other income are explicit in peer_inputs.json and peer_research.md. Two-year cash conversion is a ratio of sums, not an average of ratios. No same-date peer valuation premium is invented.

## 6. Revenue Growth & Scale

| Window | Revenue endpoints ₹cr | CAGR / basis |
|---|---|---|
| 2023–2026 | 10.32 → 18.29 | 21.02% / original operating revenue |
| 2021–2026 | 7.96 → 18.29 | 18.12% / original operating revenue |

| FY | Revenue ₹cr | Annual addition ₹cr | YoY |
|---|---|---|---|
| 2021 | 7.96 | ND / NS | NS |
| 2022 | 10.07 | 2.11 | 26.56% |
| 2023 | 10.32 | 0.25 | 2.49% |
| 2024 | 10.53 | 0.21 | 2.01% |
| 2025 | 14.73 | 4.20 | 39.88% |
| 2026 | 18.29 | 3.57 | 24.21% |

Ten-year CAGR is ND because eleven comparable observations were not located. Five-year growth is real but includes pandemic-base context, product mix and pricing. The FY2023–2025 disclosed physical record shows new-tool production 33,245→29,510→39,346 and reconditioning 61,394→56,956→72,825. Production is not verified sold volume, so revenue/production is only a mixed-product realization proxy. The sequence demonstrates a FY2024 volume dip despite broadly flat revenue, then a FY2025 recovery; it is not uniform volume compounding. [ST-PROS PDF 134–135,167]

H1 FY2026 operating revenue₹ 8.0056 crore compares with an implied prior H1₹ 5.3340 crore (+50.09%); H2₹ 10.2893 crore compares with₹ 9.3948 crore (+9.52%). H2 PBT fell 16.86%, while PAT benefited from net tax credits. H2 is audited annual minus unaudited first-half balancing data, not an independently complete new annual period. This slows the case for extrapolating the 24.21% full-year growth rate. No positive REV trajectory adjustment is warranted. [Results26 PDF 6]

## 7. Growth Quality & Reinvestment Runway

The certified base is five grinding machines, annual allocation 45,000 new tools and 80,000 reconditioning jobs. The IPO plan buys six machines plus auxiliaries, adding 54,000 tools and 96,000 jobs, for 99,000/176,000 at eleven machines. It is incorrect to call all 275,000 “new tools”, or to begin with eleven machines and add six again. New tools and reconditioning share machinery time; quoted category capacities are not independent guarantees at every product mix. [ST-CE PDF 4, visually checked; ST-PROS PDF 108–109]

Holding FY2025 proxy realizations constant, full use of old allocated capacity gives₹ 16.7147 crore annual revenue and the complete proposed plan₹ 36.7723 crore. This is a physical consistency check, not a sales forecast. FY2026 revenue exceeding the old proxy ceiling can reflect mix/prices or new machines; it cannot prove exact commissioning. Management says utilization exceeds 90% without a current denominator. The report describes two imported-machine purchases; capitalization and₹ 8.8870 crore machinery-object spending do not prove all six machines were revenue-generating. Actual FY2026 output by product remains ND. [AR26 PDF 43–48; ST-PROS; business supplement]

The quoted six-machine program is₹ 9.0653 crore, with imported ANCA equipment and auxiliaries, exposed to exchange rate, installation, qualification and customer demand. Capital advances₹ 3.93 crore remain at March 2026. Repeated expansion in the model must pay whole machine blocks, sustain working capital, observe lead times and retain replacement capital. Margin expansion from old rented assets cannot establish the return on new machines. CAP is NS until a commissioned cohort and investment/cash bridge exist; therefore GQS cannot be a numeric growth endorsement.

## 8. Management, Governance & Execution

Five Ghonia-family promoters held approximately 70.66% after IPO; concentration is control evidence, not automatically alignment or abuse. The company disclosed related-party purchases, repayments and remuneration. FY2026 purchases from Shree Industries₹ 0.8487 crore, outstanding₹ 0.1683 crore, director remuneration₹ 0.2400 crore, sitting fees₹ 0.1370 crore and additional CFO-director salary₹ 0.0598 crore should be assessed against PAT and cash, without assuming that every commercial related-party transaction leaks cash. Market terms were not independently benchmarked. [AR26 PDF 78–79,90–92]

Historical section 185 loans were a real compliance breach. The annual report says₹ 4.1569415 crore was fully recovered by 31 March 2024. The prospectus describes a 13 May 2025 penalty/compounding order; the annual report distinguishes an interim direction on 13 May and a final 17 June 2025 order. The₹ 30 lakh total was₹ 6 lakh each for the company and four applicants, not₹ 30 lakh company expense. Preserve the chronology discrepancy while recognizing repayment and paid compounding. No outstanding diversion is inferred from a settled historical matter. [Prospectus PDF 45–46; AR26 PDF 37–38; FY23/FY24 CARO]

The main statutory opinions and IFC opinions are unmodified/clean. Separate CARO and statutory observations include irregular statutory dues and audit-trail issues. FY2024–2025 application-level operation was deficient; FY2026 application logs reportedly operated throughout, but database-layer assurance remains unavailable. The board calls these observations “qualifications”, although the main opinion is unmodified. Late MGT-14, MSME-I, MGT-7 and AOC-4 filings are disclosed as completed; they should not be presented as still pending. The earlier auditor resignation said no concerns. These are mixed stewardship findings, not a categorical clean bill or an allegation of fraud. [Original audit vintages; AR26 PDF 33–35,44,54–67]

| Dated promise/event | Observed by cutoff | Assessment |
|---|---|---|
| Oct 2025 IPO plan | ₹21.33 crore FY26 sales forecast vs ₹18.2949 crore actual | 14.23% below forecast; real 24.21% growth remains positive |
| Dec 2025 /Jan 2026 planned commissioning/ramp | Substantial spending; actual current capacity/output ND | Do not label all six machines commissioned or missing proof as a second confirmed breach |
| 31 Mar 2026 proceeds update | ₹16.9217 crore used of ₹17.10 crore;₹0.1783 crore machine balance | No deviation reported; current subsequent use not verified |
| 12 May 2026 Chandan Process order | ₹2.006 crore inclGST =₹1.70 crore net; delivery within 6months | Not presumed overdue at 20 Oct;100% payment at delivery not collected cash |
| Jul 2026 rating surveillance | B/Stable Issuer Not Cooperating; dated information | Obtain current financial/lender cooperation evidence |

Execution is scored 5, mixed. The sales forecast miss is documented, but absence of commissioning detail is a gap, not another proven missed deadline. Positive actual growth and substantially deployed/no-deviation IPO proceeds are contrary evidence. Latest management/subsidiary/export leads and their access limitations are recorded in the business supplement, not silently omitted or treated as verified cash flows.

## 9. Financial Forensics

| FY / original source | Revenue | Core EBITDA / EBIT | PAT / normalized | CFO | Cash capex / FCF | Debt / available cash | Equity |
|---|---|---|---|---|---|---|---|
| 2021 / FY22 | 7.96 | 2.07 / 1.24 | 0.06 / 0.06 | ND / NS | 1.82 / ND / NS | 11.25 / 0.11 | 2.41 |
| 2022 / FY22 | 10.07 | 1.89 / 1.19 | 0.05 / 0.07 | 2.07 | 0.44 / 1.63 | 10.47 / 0.12 | 2.46 |
| 2023 / FY23 | 10.32 | 1.84 / 1.10 | 0.08 / -0.03 | 2.49 | 0.11 / 2.37 | 9.05 / 0.20 | 2.54 |
| 2024 / FY24 | 10.53 | 4.21 / 3.46 | 1.96 / 1.91 | 3.32 | 1.40 / 1.92 | 7.54 / 0.34 | 4.50 |
| 2025 / AR26 | 14.73 | 6.29 / 3.83 | 1.80 / 2.24 | 1.17 | 2.97 / -1.81 | 8.18 / 0.05 | 7.99 |
| 2026 / AR26 | 18.29 | 6.68 / 5.01 | 3.89 / 3.13 | 1.03 | 12.07 / -11.04 | 6.30 / 0.11 | 25.86 |

The main history uses each original annual vintage; the IPO-restated FY2023–2025 series is separately preserved. Original FY2022–2023 units were thousands, FY2024 rupees and FY2025–2026 lakhs; all calculations convert explicitly. Fiscal 2021 is an audited comparative, not a separately retrieved original annual report, and CFO remains ND. No consolidated/standalone or restated/original series is silently spliced. Cash capex, not depreciation, determines reported FCF; interest is classified in financing.

| Vintage issue | Treatment / source |
|---|---|
| FY25 PAT original to IPO restated | Fully disclosed numeric bridge. FY26 annual comparative retains original ₹179.54 lakh, not restated ₹293.01 lakh. Show both growth comparisons. Restated PDF12; Prospectus PDF288 |
| FY24 PAT original to IPO restated | Original and restated values retained; see financial_inputs.json Restated PDF12 |
| FY23 PAT original to IPO restated | Original and restated values retained; see financial_inputs.json Restated PDF12 |
| FY25 expense presentation | Do not compare gross margins across changed cost groupings. EBITDA excluding all other income reconciles to ₹628.79 lakh original versus ₹625.64 lakh restated, not a huge underlying margin step. AR26 PDF69; Prospectus PDF72 |
| FY26 results to annual cash flow | Same closing cash and capex. Annual cash-flow interest of ₹1.79 lakh versus results ₹3.38 lakh and financing classification of the reserve writeoff alter cash-flow groups. There is a ₹0.01 lakh rounding residual. Select latest annual figures and retain original results. Results26 PDF9; AR26 PDF70 |
| FY26 reserves summary inconsistency | Use reconciled balance sheet and notes reserves of ₹2,020.32 lakh. No explicit explanation for the inconsistent profit-panel reserves was located. Results26 PDF6,8; AR26 PDF68 |
| FY24 cash flow original to IPO restated | Group changes preserve the same ₹13.94 lakh cash increase. Restated notes state long-term and short-term financing were grossed and reclassified. Original net borrowing repayment was ₹87.09 lakh versus restated ₹191.58 lakh; original ₹0.26 lakh investment sale is removed. Restatement does not create cash. FY24 PDF15; Restated PDF8 |
| FY25 balance regroupings | ₹4.83 lakh moved between current-asset categories; the total is unchanged. Use granular current annual-report notes. FY25_2025 PDF14; AR26 PDF68 |
| FY25 original copies | Both copies have the same 30 August 2025 signature and UDIN, and the same core statements. The July 2026 upload lacks the earlier 13-page audit section. Preserve the earlier complete audit. FY25_2025 versus FY25_2026 |

FY2025 original PAT₹ 1.7954 crore plus gratuity₹ 0.0748 crore, lower depreciation₹ 1.0884 crore, income-tax₹ 0.0604 crore and deferred-tax−₹ 0.0889 crore yields restated₹ 2.9301 crore. The disclosed bridge resolves that number, not the question whether later statutory useful lives and capital carry-forward fully match the IPO presentation. FY2024 PAT was restated downward and FY2023 turned to a small loss. Keep both sides. FY2026 PAT growth is 116.68% on the original comparator but 32.77% on restated profit. Normalized FY2026 PAT is₹ 3.125175 crore after removing all₹ 0.4092 crore other income and using 25% operating tax; no deferred-tax credit is extrapolated. [Restated PDF 12; AR26 PDF 69,86–88]

Fresh IPO shares increased issued equity from 4,158,400 to 5,658,400, a 36.07% increase. FY2026 reported EPS₹ 8.23 uses weighted-average 4,725,523 shares; current-share reported earnings are approximately₹ 6.88, not₹ 8.23. Comparing restated FY2025 PAT per pre-IPO issued share with FY2026 PAT per current issued share shows roughly flat/slightly lower per-share earnings despite higher company profit. The earlier 1:1 bonus was not economic dilution; preferential and IPO shares were. Potential later claims remain a verification item, not an invented zero. [AR26 PDF 78–79,89,94]

| Vintage/window | Sum CFO / PAT ₹cr | Ratio | After-finance ratio | Capital-creditor sensitivity |
|---|---|---|---|---|
| Original annual statements 2024–2026 | 5.51 / 7.65 | 0.7209× | 0.3810× | 0.6495 |
| Original annual statements 2022–2026 | 10.07 / 7.78 | 1.2952× | 0.6731× | 1.2249 |
| IPO-restated FY23–25 only 2023–2025 | 7.86 / 4.43 | 1.7756× | 1.1259× | ND / NS |

FY2026 cash quality deteriorated: receivables₹ 6.7425 crore, inventory₹ 5.7447 crore, supplier advances₹ 2.7364 crore and government balances₹ 1.3353 crore absorbed funds. Finished goods rose to₹ 4.6449 crore. Receivables older than one year total₹ 0.7107 crore, including₹ 0.5961 crore aged two to three years; disclosed doubtful balances are zero, not proof every old balance will collect. Approximately₹ 0.4840 crore payables are older than a year. These require subsequent receipts/stock-ageing and settlement checks. [AR26 PDF 82–85]

| FY | AR / inventory / AP ₹cr | Average AR days | Cost-proxy inventory / AP days | Funding ROIC / ROCE / ROE |
|---|---|---|---|---|
| 2021 | 3.59 / 4.65 / 3.06 | ND / NS | ND / NS / ND / NS | NS / NS / NS |
| 2022 | 4.89 / 3.90 / 3.07 | 153.67 | 190.88 / 136.75 | 6.86% / 9.15% / 2.12% |
| 2023 | 3.79 / 3.53 / 4.07 | 153.47 | 159.83 / 153.58 | 6.88% / 9.17% / 3.04% |
| 2024 | 2.38 / 2.99 / 2.02 | 106.88 | 187.91 / 175.84 | 22.52% / 30.03% / 55.82% |
| 2025 | 5.11 / 3.80 / 1.33 | 92.77 | 146.73 / 72.45 | 20.65% / 27.53% / 28.75% |
| 2026 | 6.74 / 5.74 / 1.52 | 118.23 | 149.94 / 44.87 | 15.60% / 20.80% / 22.99% |

The all-period day series uses total revenue for credit-sales and revenue minus core EBITDA (including cash operating costs) for inventory/payables. The supplementary current-year calculation uses material/direct cost and purchases instead. Those are labelled proxies, not contradictory audited CCC figures.

Reported CFO₹ 1.0287 crore includes₹ 0.5464 crore additional capital creditors within other-liability cash movement while the investing line uses full additions. Reclassifying that amount gives operating-CFO sensitivity₹ 0.4823 crore and cash-capex₹ 11.5228 crore, leaving FCF exactly−₹ 11.0405 crore. This is not exhaustively normalized CFO: capital-goods FX gain₹ 0.2830 crore and gratuity reversal₹ 0.0846 crore lack separately labelled cash-flow reversals and may be reflected in asset/liability movements. Do not subtract them twice. Cash capex explains weak FCF, not weak CFO. [AR26 PDF 70,80,86]

| Window | ΔNOPAT / Δfunding IC ₹cr | Incremental proxy | Capex − D&A +Δbasic ONWC | Residual ₹cr |
|---|---|---|---|---|
| 2023–2026 | 2.93 / 20.67 | 14.17% | 16.44 − 4.87 + 7.72 = 19.29 | 1.38 |
| 2021–2026 | 2.83 / 18.65 | 15.17% | 16.99 − 6.30 + 5.79 = 16.48 | 2.17 |

Core defined ONWC increased₹ 4.4931 crore; committed operating capital including advances rose₹ 14.8951 crore. Average-core-capital FY2026 ROIC proxy is 15.90%, but the one-year incremental proxy against the original profit base is only 5.94%, with a newly deployed cohort not mature. The broad 3 Y/5 Y financing proxies above include DTA within net assets and deduct only available cash; the financial supplement also shows 14.76%/15.89% using all cash and excluding DTA. Definitions, not a new economic conclusion, explain the difference. Neither is a project IRR. A reasoned 13–19% nominal INR capital-cost sensitivity brackets material cyclicality, scale and funding uncertainty; it is not automatically the 15% equity hurdle. [financial_inputs; financial_metrics; metrics]

March gross debt₹ 6.2960 crore is bank term₹ 3.1570 crore, working capital₹ 2.8312 crore and unsecured₹ 0.3078 crore. The₹ 1.7244 crore current-maturity classification does not reconcile to printed instalments totaling₹ 0.0438611 crore per month. Historical Canara CC sanction₹ 5 crore and July 2026 CRISIL rated CC₹ 3.7 crore are not live available-headroom confirmations. CRISIL B/Stable Issuer Not Cooperating reflects information limitations and excludes a forward-looking component; it is not a default rating. Proposed₹ 4.3 crore facilities are not cash. Auditors reported no bank default or material one-year solvency uncertainty at March 2026. [AR26 PDF 79; ST-CRISIL 26; Prospectus bank table]

IPO gross proceeds₹ 17.10 crore were allocated to machinery₹ 9.0653 crore, WC₹ 3.85 crore, general corporate₹ 2.4847 crore and IPO expenses₹ 1.70 crore. Used₹ 16.9217 crore leaves₹ 0.1783 crore restricted to machinery. The cash-flow net-equity line₹ 13.9822 crore also reflects₹ 1.4052 crore other capital expenses and₹ 0.0126 crore reserve writeoff; that is a classification bridge, not evidence all deductions were cash. Expenditure versus the₹ 1.70 crore original IPO-expense allocation remains worth clarifying. Cash on balance sheet₹ 0.2836 crore is not all free cash. [Deviation PDF 2–3; AR26 PDF 70,79,95]

## 10. Valuation & Market Expectations

| Metric | Qualified result |
|---|---|
| Market cap / EV with March bridge | ₹101.85 crore / ₹108.04 crore |
| Reported / normalized P/E | 26.18× / 32.59× |
| EV/core EBITDA / P/B | 16.18× / 3.94× |
| Reported FCF yield | -10.84% |
| Whole-lot reference | 2 lots / 2400 shares / ₹432,000.00 |
| Primary 20/60-session liquidity | ND; L remainsNS |
| 17 observed secondary sessions, not full sample | Mean ₹4,344,144.00; median ₹3,058,260.00 |
| Partial-sample theoretical exit at 2/5/10% | 8.17 days / 3.27 days / 1.63 days; not L-scoring basis |

These are qualified market-reference calculations, not live execution prices. March debt/cash are deliberately dated rather than falsely current. Historical Indian-GAAP lease/rental economics remain in operating costs; no undisclosed lease liability or off-balance-sheet debt is assumed. Equity claims, later subsidiary perimeter and actual current bank balances need confirmation. The normalized-PAT tax rate 25% differs slightly from the model's explicit 25.168% cash-tax assumption; neither extrapolates FY2026 deferred-tax benefits.

| Strict conditional case | Volume / EBITDA margin | First reserve failure | Ordinary return |
|---|---|---|---|
| bear_5y | 0.00% / 24.00% | 1 | Suppressed |
| base_5y | 15.00% / 32.00% | 1 | Suppressed |
| bull_5y | 25.00% / 36.00% | 1 | Suppressed |
| bear_10y | 0.00% / 24.00% | 1 | Suppressed |
| base_10y | 15.00% / 32.00% | 1 | Suppressed |
| bull_10y | 25.00% / 36.00% | 1 | Suppressed |

The strict cases reuse March balance anchors as conditional October opening and do not assume unverified new funding. Their reserve shortfalls are therefore scenario diagnostics, not actual defaults. Month-one failure is not a forecast that the company would fail in November. The missing intervening cash bridge makes all paths source-ineligible. Ordinary IRRs/terminal prices are suppressed after failure rather than presented as if a rescue were assured.

| Conditional funding case | Exit sales / capex ₹cr | Final shares | Exit price / IRR | 12/15/18% entry ₹ |
|---|---|---|---|---|
| funded_reference_5y | 37.60 / 7.54 | 5662240 | 124.45 / -7.49% | 69.22 / 60.65 / 53.32 |
| funded_rating_limit_5y | 37.60 / 7.54 | 5767321 | 125.35 / -7.35% | 69.72 / 61.09 / 53.71 |
| funded_reference_10y | 81.71 / 36.40 | 5662240 | 330.89 / 6.07% | 104.43 / 80.17 / 61.97 |
| funded_rating_limit_10y | 81.71 / 36.40 | 5767321 | 329.01 / 6.00% | 103.83 / 79.71 / 61.62 |

Funded references explicitly assume access to historical CC headroom and, where required, a discounted whole-share raise within the stated authorization. The rating-table ceiling variant, no-equity/no-renewal alternatives, printed-maturity policy, delayed commissioning and higher equipment cost remain separate trials. A source-ineligible path that mathematically funds is not the supported base case used by R. Entry ranges at 12/15/18% are only assumption-dependent outputs and are not buy limits.

| Reference | Next NOPAT / D&A | Replacement / growth investment | FCFF | Cash / funding reserve / operating reserve | Cash financial asset / debt / claims | 10× EBITDA crosscheck ₹ |
|---|---|---|---|---|---|---|
| funded_reference_5y | 9.64 / 1.97 | 1.97 / 2.41 | 7.23 | 16.18 / 0.50 / 0.50 | 15.68 / 5.00 / 0.45 | 268.91 |
| funded_reference_10y | 22.86 / 4.15 | 4.15 / 5.71 | 17.14 | 51.38 / 1.48 / 1.44 | 49.94 / 5.00 / 0.45 | 666.37 |

Terminal FCFF is earned after cash tax, replacement, physical/working-capital investment and the economic-reinvestment floor. Another 12 monthly cash periods must fund without new borrowing/equity rescue. Funding reserve includes debt service; operating reserve separately removes financing/claim payments already deducted in EV-to-equity, avoiding double subtraction of debt-backed cash. Cash above the operating reserve enters the equity bridge; only cash above the full funding reserve could be distributed immediately. Restricted proceeds remain excluded. Detailed monthly debt, fees, maturities, whole shares, assets, pipeline, reserves and claims are reproducible in the full path file.

Conditional funded reference 5-year terminal price, ₹:

| WACC / growth | 2% | 4% | 6% |
|---|---|---|---|
| 13.00% | 150.05 | 159.91 | 170.60 |
| 16.00% | 121.77 | 124.45 | 124.26 |
| 19.00% | 103.46 | 103.17 | 99.30 |

Conditional funded 5-year new-tool growth / margin grid, investor IRR or failed path:

| New-tool volume CAGR | 24% margin | 30% margin | 36% margin |
|---|---|---|---|
| 0.00% | -24.56% | -19.35% | -15.22% |
| 10.00% | -15.22% | -11.08% | -7.59% |
| 20.00% | Failed month 51 | -6.34% | -2.83% |
| 30.00% | Failed month 37 | Failed month 49 | Failed month 51 |
| 40.00% | Failed month 25 | Failed month 27 | Failed month 37 |

Conditional funded reference 10-year terminal price, ₹:

| WACC / growth | 2% | 4% | 6% |
|---|---|---|---|
| 13.00% | 394.21 | 414.99 | 446.55 |
| 16.00% | 326.73 | 330.89 | 335.92 |
| 19.00% | 283.07 | 280.43 | 276.34 |

Conditional funded 10-year new-tool growth / margin grid, investor IRR or failed path:

| New-tool volume CAGR | 24% margin | 30% margin | 36% margin |
|---|---|---|---|
| 0.00% | -7.19% | -4.64% | -2.60% |
| 10.00% | 0.49% | 2.42% | 4.06% |
| 20.00% | Failed month 51 | Failed month 132 | Failed month 132 |
| 30.00% | Failed month 37 | Failed month 49 | Failed month 51 |
| 40.00% | Failed month 25 | Failed month 27 | Failed month 37 |

The 1% entry and 1% exit implementation costs are illustrative, not measured spread/impact. Five-/ten-year returns are nominal before investor taxes and no dividend is counted twice. WACC and growth are separate from the equity hurdle. A terminal EBITDA-multiple cross-check uses the same equity bridge rather than hiding senior claims. The paths describe what assumptions require; they do not establish current fair value or a probability-weighted forecast.

## 11. Bear Case & Permanent-Loss Path

The strongest bear case is that product/mix growth and the IPO capacity story outrun collections. A large customer's loss lowers grinder utilization and spreads fixed expense over less revenue; old receivables and finished goods fail to release cash; supplier advances and GST balances stay locked; promised new equipment requires installation/qualification or further working capital; and banks do not offer the historical headroom. Shareholders then face expensive debt, discounted issuance or forgone orders. At a 32.6× normalized-earnings reference, slow growth can also compress the valuation without any insolvency.

The key falsification variable is collected operating cash relative to committed capital, not a single quarterly profit headline. Evidence against the bear interpretation is important: five-year original cash conversion is positive, the earlier restated three-year ratio is strong, rent removal improved real costs, IPO proceeds funded assets, leverage relative to core EBITDA is below 1×, and auditors found no default. Those facts prevent calling the business distressed on current evidence. They do not verify present cash availability or mature project returns.

Capital impairment risk is High at the qualified price because the cash/capacity/funding variables fail together and market execution may be lumpy. Modeled downside is conditional; no liquidation recovery from book PPE, advances or inventory is promised. Research should move from Hold only after funding, capacity and implementation questions close. A narrow control flaw alone is not proof of fraud, and a price decline alone is not a change in BQS/GQS.

## 12. 5× / 10× Feasibility

| Horizon / net target | Funded grid crossings | Least-growth tested crossing | Best tested funded net multiple |
|---|---|---|---|
| 5y / 1.12 (annual return hurdle) | 0 | None | 1.62×; expanded_multibagger_5y_g.60_m.42 |
| 5y / 1.15 (annual return hurdle) | 0 | None | 1.62×; expanded_multibagger_5y_g.60_m.42 |
| 5y / 1.18 (annual return hurdle) | 0 | None | 1.62×; expanded_multibagger_5y_g.60_m.42 |
| 5y / 5 (net investor multiple) | 0 | None | 1.62×; expanded_multibagger_5y_g.60_m.42 |
| 5y / 10 (net investor multiple) | 0 | None | 1.62×; expanded_multibagger_5y_g.60_m.42 |
| 10y / 1.12 (annual return hurdle) | 8 | expanded_multibagger_10y_g.20_m.42 | 5.81×; expanded_multibagger_10y_g.30_m.42 |
| 10y / 1.15 (annual return hurdle) | 3 | expanded_multibagger_10y_g.30_m.36 | 5.81×; expanded_multibagger_10y_g.30_m.42 |
| 10y / 1.18 (annual return hurdle) | 1 | expanded_multibagger_10y_g.30_m.42 | 5.81×; expanded_multibagger_10y_g.30_m.42 |
| 10y / 5 (net investor multiple) | 1 | expanded_multibagger_10y_g.30_m.42 | 5.81×; expanded_multibagger_10y_g.30_m.42 |
| 10y / 10 (net investor multiple) | 0 | None | 5.81×; expanded_multibagger_10y_g.30_m.42 |

Financing and physical requirements of selected crossing or best-tested paths (not forecasts):

| Path | Exit sales ₹cr / new-tool volume-demand CAGR / margin | Machines at exit → after transition / horizon capex ₹cr | Equity raised ₹cr / final shares | Exit debt / claims / FCFF ₹cr | Net investor multiple |
|---|---|---|---|---|---|
| expanded_multibagger_10y_g.20_m.42 | 134.16 / 20.00% / 42.00% | 39 → 40 / 61.69 | 0.00 / 5658400 | 5.00 / 0.45 / 33.41 | 3.41× |
| expanded_multibagger_10y_g.30_m.36 | 278.49 / 30.00% / 36.00% | 76 → 81 / 131.35 | 22.12 / 7414079 | 5.00 / 0.45 / 64.78 | 4.38× |
| expanded_multibagger_10y_g.30_m.42 | 278.49 / 30.00% / 42.00% | 76 → 81 / 131.35 | 5.76 / 6115171 | 6.48 / 0.45 / 69.96 | 5.81× |
| expanded_multibagger_5y_g.60_m.42 | 161.21 / 60.00% / 42.00% | 50 → 51 / 71.52 | 75.78 / 11673063 | 10.00 / 0.45 / 39.46 | 1.62× |

Accessible-market share is ND: no reliable segment denominator supports these large-volume cases. Every selected path assumes funded additional capacity, customer access and financing terms, not merely a higher terminal multiple. The EBITDA cross-check and lower terminal-growth/higher-WACC grids are separate downward valuation tests.

The five-/ten-year tests are net investor wealth after the same execution costs, not revenue or enterprise-value multiples. For context,5× needs 37.97% annualized over 5 years or 17.46% over 10;10× needs 58.49% or 25.89%. The grids retain every attempted demand/margin/financing combination, including those failing before the terminal year. A missing crossing is bounded to these tested assumptions, not a mathematical impossibility.

The bounded envelope respects the stated share-authorization ceiling and a 30-machine physical cap; the expanded envelope explicitly assumes new share authorization, up to 100 machines, additional debt and a much wider customer base. Whole shares, issue discounts/fees, debt interest/maturity, growing working capital and terminal reinvestment dilute any stock return. High 42% EBITDA-margin cases and large expansion are ambitious assumptions against peer economics and Shining's current commissioning evidence. A funded 5× path, if present, is still speculative; no supported 10× claim is made. All 5×/10× conclusions are Speculative / unsupported until capacity access, unit economics and funding are evidenced.

## 13. Monitoring Plan

| KPI / baseline | Evidence/milestone | Warning / thesis-break investigation |
|---|---|---|
| Operating cash: FY26 CFO ₹1.0287 crore; cap-creditor sensitivity ₹0.4823 crore | Next comparable CFO and receipts afterMarch | Further profitable sales without collections; distinguish reinvestment from accrual loss |
| Old receivables ₹0.7107 crore≥1year | Customer receipts/age migration | Two-to-three-year balance ₹0.5961 crore worsens or becomes irrecoverable |
| Stock:₹5.7447 crore; FG ₹4.6449 crore | Quantities, age, realizations and write-downs | Stock grows faster than sold output; discounting undermines margin |
| Capacity:5machines certified;11planned | Installed/qualified machines and product output | Do not recognize planned capacity; verify causes of further delays |
| Core committed capital ₹31.0696 crore | Mature cohort cash earnings and returns | Returns remain below capital cost after an evidenced ramp period |
| Bank maturities ₹1.7244 crore current | Current sanction/headroom and loan schedule | Missed obligations or unavailable essential funding, not a stale model failure |
| Restricted proceeds ₹0.1783 crore | Object-specific bank/use certificate | Unauthorized diversion would changeG1; delay alone needs explanation |
| Audit/compliance | Database audit trail and timely filings | Repeat material control obstruction or unexplained accounting changes |
| Order ₹1.70 crore net,12 May 2026 | Delivery/receipt within stated six-month window | Past-due nonpayment once actual deadline passed; no premature default claim |
| Implementation 1,200share lot | Primary 20/60-session BSE, depth/spreads/restrictions | One-sided circuits or lot exit infeasibility; updateG4/L |

These are company-specific research checkpoints, not automatically created reminders. A threshold prompts investigation; only a verified severe governance, survival or permanent earning-power failure should automatically change the relevant gate. Current shareholder notices must be checked for subsidiary obligations, management changes, new funding and potential dilution before interpreting the next results.

## 14. Final Classification & Conditional Action

Classification: Hold — unresolved funding, incremental returns and implementation evidence. Action category: Research priority / watchlist pending evidence, not eligible for an affirmative new-purchase conclusion. BQS/GQS/IAS remain separately NS. The numeric classification matrix cannot be applied to missing aggregates; no low-NS record is placed at the bottom of a ranking as if it were proven poor. The compounder criteria are not met, and no portfolio allocation, exit instruction or trade is implied.

Closing the current cash/bank/maturity bridge, confirming installed and saleable throughput, proving incremental project cash returns and collecting primary 20/60-session execution data would allow reassessment. A lower quote alone would not cure CAP/BAL/L missingness or demonstrate governance improvement. Fresh information after 20 October 2026 is excluded from this record except for retrieving sources that were already public by the cutoff.

## 15. Sources, Assumptions & Open Questions

| ID / record | Date / exact original URL | Original hash / limitation |
|---|---|---|
| FY22 / FY22 primary disclosure | 2022-07-19 / [FY22 primary disclosure](https://www.tixnatools.com/wp-content/uploads/2025/01/FY-2021-22.pdf) | 7779e5dd6ba3455389735072080a213453184f2aaa5dda1f85a0d76102d93a81 |
| FY23 / FY23 primary disclosure | 2023-09-01 / [FY23 primary disclosure](https://www.tixnatools.com/wp-content/uploads/2025/01/FY-2022-23.pdf) | 93682855dbef5dddad3dce7fb00a1f8d44e39037636fafae605208d1886bd5eb |
| FY24 / FY24 primary disclosure | 2024-09-02 / [FY24 primary disclosure](https://www.tixnatools.com/wp-content/uploads/2025/01/FY-2023-24.pdf) | 87791daf8def1c51ef23f834375e8fd1b219db0b65f6a0a428a22a7f77ce7bea |
| FY25_2025 / FY25_2025 primary disclosure | 2025-08-30 / [FY25_2025 primary disclosure](https://www.tixnatools.com/wp-content/uploads/2025/11/AY-24-25-audit-report-in-lakhs-STL-signed.pdf) | a0e90e2a050dca700a990ffcafca2006cf53293ecc7046ec67b5f1b4c7cccbfb |
| FY25_2026 / FY25_2026 primary disclosure | 2025-08-30 / [FY25_2026 primary disclosure](https://www.tixnatools.com/wp-content/uploads/2026/07/FY-2024-25.pdf) | cabb39d498b2c42b618a73f7125da5085f64dab99c63640bc3394087fd17f6c1 |
| AR26 / AR26 primary disclosure | 2026-09-08 / [AR26 primary disclosure](https://www.tixnatools.com/wp-content/uploads/2026/09/Annual-report-FY-2025-26.pdf) | 9974f004799f87be1bf5929e9ecff2dcc131a085cb2896fae08fdab88da47070 |
| Prospectus / Prospectus primary disclosure | 2025-10-31 / [Prospectus primary disclosure](https://www.tixnatools.com/wp-content/uploads/2025/11/PROSPECTUS.pdf) | 5c3e0aed4b41ce92cdf341e8b4c1595d975be5dbebff0ac0bad02b8a0c17c810 |
| Restated / Restated primary disclosure | 2025-08-30 / [Restated primary disclosure](https://www.tixnatools.com/wp-content/uploads/2025/11/RFS-Signed-with-Stub-31-7-25_.pdf) | 9ff2850b46a1487924862ebf8664bb6dbd4616f761400c74ef43d4dabeaf81f3 |
| Deviation / Deviation primary disclosure | 2026-05-30 / [Deviation primary disclosure](https://www.tixnatools.com/wp-content/uploads/2026/07/Intimation-regarding-statement-of-deviation-31-03-2026.pdf) | b1c6e79fba0fe23fcc01ee8fe875c0dac9bb44f30148c4f5a18e9ee0c36d5cdc |
| Results26 / Results26 primary disclosure | 2026-05-30 / [Results26 primary disclosure](https://www.tixnatools.com/wp-content/uploads/2026/07/Audited-financial-results-2025-26.pdf) | d211e6242dae03694cc67824db9910077593b9e921d593ac85ef94f2b7198248 |
| ST-PROS / Shining Tools final prospectus | 2025-10-31 / [Shining Tools final prospectus](https://www.tixnatools.com/wp-content/uploads/2025/11/PROSPECTUS.pdf) | 5c3e0aed4b41ce92cdf341e8b4c1595d975be5dbebff0ac0bad02b8a0c17c810 |
| ST-CE / Chartered engineer certificate, inspection 10 May 2025 | 2025-05-10 / [Chartered engineer certificate, inspection 10 May 2025](https://www.tixnatools.com/wp-content/uploads/2025/06/CE-Report_Final_14-6-25.pdf) | 8761d60512b0f77a3ede24af1316e231ef3c5ec8a1466ca7757528a84857b9aa |
| ST-AR26 / 13th Annual Report FY2025-26 | 2026-09-08 / [13th Annual Report FY2025-26](https://www.tixnatools.com/wp-content/uploads/2026/09/Annual-report-FY-2025-26.pdf) | 9974f004799f87be1bf5929e9ecff2dcc131a085cb2896fae08fdab88da47070 |
| ST-ORDER-MAY / Order from Chandan Process | 2026-05-12 / [Order from Chandan Process](https://www.tixnatools.com/wp-content/uploads/2026/07/Intimation-regarding-Award-of-Order.pdf) | dbac707d5f70a57bd08c54d7c521f6e986362df9d55a060c51d2583bc2ffb3d5 |
| ST-CRISIL26 / CRISIL rating rationale | 2026-07-08 / [CRISIL rating rationale](https://www.crisil.com/mnt/winshare/Ratings/RatingList/RatingDocs/ShiningToolsLimited_July%2008_%202026_RR_398546.html) | 804f3ad51d69f6d9e09cccb8a00c0b603879055abfedda58b326b96c0d6e5f41 |
| MKT_IIFL / IIFL dated historical market table, Shining Tools | See period in input / [IIFL dated historical market table, Shining Tools](https://www.indiainfoline.com/company/shining-tools-ltd-historical-data) | 32efef2a5560a4cdd1f91a788cf83c9c269147f0e604fd60d26513d59e87f182 |
| MKT_BLINKX / BlinkX historical price cross-check | See period in input / [BlinkX historical price cross-check](https://blinkx.in/insights/results/shining-tools-ltd-quarterly-result) | 8a078cbb14b2e54796970b9f9a66144ab8504704e4048a5641dad8c57b7a9d13 |
| MKT_INTEROP / Official 19 Oct 2026 NSE interoperability security master | See period in input / [Official 19 Oct 2026 NSE interoperability security master](https://nsearchives.nseindia.com/content/cm/interop/NSE_CM_security_19102026.csv.gz) | d3665d120c8b0379df3483321ad45f8230535c7124b9759de5c29961df326898 |
| PEER-KENN26 / Kennametal India Limited FY2026 results | 2026-08-13 / [Kennametal India Limited FY2026 results](https://in.investors.kennametal.com/static-files/f15f9897-0e93-493d-926d-ec63c9d8d545) | edb6c066d55061851ea6906168ccdb87e501eafdd7cc2af06fbdf624d83bf675 |
| PEER-FORBES26 / Forbes Precision Tools and Machine Parts Limited FY2026 results | 2026-07 / [Forbes Precision Tools and Machine Parts Limited FY2026 results](https://forbesprecision.co.in/wp-content/uploads/2026/07/Annual-Report-2025-2026.pdf) | 4461cf1ae81aa61cb8f38d5af550eddaa5b61927040f9faa2caf2eccfa339ba9 |
| PEER-BIRLA26 / Birla Precision Technologies Limited FY2026 results | 2026-05-29 / [Birla Precision Technologies Limited FY2026 results](https://www.birlaprecision.com/documents/investor/Financial%20Results/ANNUAL%20REPORTS/AR-25-26.pdf?v=1) | 8db9909e377284b565a041174499b80945eceda921a2b7793677a6e0332f4acd |
| PEER-WENDT26 / Wendt (India) Limited FY2026 results | 2026-04-24 / [Wendt (India) Limited FY2026 results](https://wendtindia.com/wp-content/uploads/2026/07/Wendt-AR-2026-Hires.pdf) | 0dfd2f2f4690f9eeaec755f5ff128c5e261e8015ccd5b313d298b7539657a5f7 |
| BSE_LIST / BSE confirms Shining Tools SME listing | 2025-11-14 / [BSE confirms Shining Tools SME listing](https://www.bseindia.com/Downloads/MediaRelease/PR14112025a_20251411.pdf) | Primary BSE web-readable release inspected; original PDF direct HTTP403, no original byte hash asserted. |

Material evidence classes: verified disclosures are original annuals, audited results, restated accounts, official offer document, engineer certificate, issuer order and rating rationale. Calculations are growth, cash ratios, return proxies, multiples and physical checks. Management statements include forecasts, utilization and intended commissioning. Analyst assumptions include every monthly forward demand, collection, margin, capex, refinancing, equity and terminal choice. Secondary historical prices and inaccessible-original corporate leads remain explicitly labelled, not upgraded to primary facts.

Open questions: loan-wise maturities and current sanctioned/drawn headroom; April–October cash and capital deployment; exact useful-life/carry-forward alignment between statutory and IPO-restated accounts; current commissioned machines and product-specific throughput; remaining purchase/qualification commitments; recovery of old receivables, business advances and GST assets; explanation of capital-raising expenses; source clarification for supplier-table maximum inconsistencies; subsidiary contribution/claims; updated ownership/encumbrance and primary market depth/restrictions. Missingness does not itself prove adverse conduct.

| Research version | Change | Effect |
|---|---|---|
| v 1 initial 164 paths | First complete conditional paths retained before exact source-price and terminal cash-reserve refinements. | Superseded. Slight rounded unit proxies; precision 28; debt-service cash and debt both deducted, conservatively understating equity. |
| v 1.2 current 166 paths | Exact FY25 proxy prices; Decimal 40; separate operating/funding reserves; added ₹3.7 crore rated-CC ceiling sensitivity. | Every original path preserved; all current paths remain source-ineligible. No claim that credit-rating quantum is committed funding. |
| Source/reader reconciliation | Original/restated profits, paid section 185 compounding, audit improvement and adverse cash trends reconciled. EXEC5 for mixed delivery, not 4 from missing proof. | G1/G2 conditional;G3/G4 held. BQS/GQS/IAS remainNS; no overrides or fraud/default finding. |

| Required check | Status | Evidence |
|---|---|---|
| 1. Identity, scope and dates | PASS_DISCLOSURE | Original null symbol retained; BSE SHTL/544607 resolved, standalone historical scope; secondary quote explicitly qualified. |
| 2. Primary material sources | PASS_DISCLOSURE | Original annual/IPO/engineer/rating/order/peer disclosures read; secondary corporate leads segregated. |
| 3. Audit, related parties, funding and dilution | PASS_DISCLOSURE | Unmodified main/IFC distinguished from observations; resolved loans/compounding and current funding gaps retained. |
| 4. Comparable units and periods | PASS_DISCLOSURE | Thousands/rupees/lakhs converted; original and restated separately preserved; no fabricated TTM or interim CFO. |
| 5. Revenue drivers | PASS_DISCLOSURE | Five-year selected window; production/services, price/mix and rent conversion distinguished. |
| 6. Cash ratio of sums | PASS_DISCLOSURE | Three/five-year original and separate restated ratios; capital-creditor recast paired with capex. |
| 7. Incremental returns | PASS_DISCLOSURE | Numerator/denominator/timing/residuals and alternative definitions disclosed; CAP stays NS. |
| 8. Normalization and claims | PASS_DISCLOSURE | Other income/tax/leases/current shares, restricted cash and claims consistent within each valuation basis. |
| 9. Linked monthly funding and terminal | PASS_DISCLOSURE | Two outputs, equipment pipeline, debt maturities/fees, whole shares, restricted uses, replacement and transition reserves reconcile. |
| 10. Canonical weights | PASS_DISCLOSURE | 13 factors; Decimal exact weights total 1; EARN not added separately to BQS. |
| 11. Missingness and confidence | PASS_DISCLOSURE | NS, coverage, bounds and weakest-area confidence retained without renormalization. |
| 12. Raw/final scores and overrides | PASS_DISCLOSURE | No unsupported low neutral score or override; failed model return suppression. |
| 13. Classification | PASS_DISCLOSURE | Hold and no compounder designation; no numerical incomplete ranking. |
| 14. Liquidity position | PASS_DISCLOSURE | ₹5 lakh reference, lot 1200; incomplete secondary sample not presented as primary 20/60 history; no missing-as-zero. |
| 15. Bear case | PASS_DISCLOSURE | Linked customer, collection, capacity, refinancing and dilution permanent-loss mechanism with positive counterevidence. |
| 16. Version and completion | PASS_DISCLOSURE | Exact v 3.0 SHA; all 166 current and 164 original trials retained; publication not implied. |

The archive includes authored inputs/code/outputs and both producer and independent attestations. It excludes source PDFs, OCR, raw pages, private helpers and secrets. The exact framework SHA, actual report SHA, company-record SHA and authored-input aggregate SHA are different roles and must not be substituted. Independent cold recovery from the current saved versions is a separate acceptance step. Mechanical PASS does not resolve the expressly disclosed investment-evidence gaps.
