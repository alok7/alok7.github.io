"""Shining Tools: Decimal monthly product/service capacity and cash model. Scenario-only.
Inputs, not this program, determine funding permission. Monetary amounts are INR crore.
"""
from decimal import Decimal as D, ROUND_CEILING
from copy import deepcopy
from collections import defaultdict
Z=D(0); O=D(1); CR=D(10000000)
def d(x):
 if isinstance(x,float):raise TypeError('Use exact decimal strings')
 return x if isinstance(x,D) else D(str(x))
def date(m):
 n=2026*12+10+m-1
 return f'{n//12:04d}-{n%12+1:02d}'
def run(i,s,years,path_id):
 s=deepcopy(s); o={k:d(v) for k,v in i['opening'].items()}; n=years*12
 cash=o['cash'];restricted=o['restricted_ipo'];shares=int(i['issued_shares']);auth=int(s['expanded_authorized_shares']) if s['authorization_gate'] else int(i['authorized_shares'])
 ar=o['receivables'];inv=o['inventory'];ap=o['trade_payables'];opa=o['other_operating_assets'];ppe=o['ppe'];pipelineasset=o['capital_advances'];otherclaim=o['other_current_liabilities'];taxclaim=o['tax_provisions'];capcredit=o['capital_creditors'];gratuity=o['gratuity'];wc=o['working_capital_debt'];term=o['bank_term_debt'];unsecured=o['unsecured_debt'];newdebt=Z;receipts=defaultdict(lambda:Z);payments=defaultdict(lambda:Z);debts=[];pipeline=[];machines=int(s['initial_machines']);pending=int(s['pending_ipo_machines']);added=defaultdict(int)
 for k in range(1,int(s['opening_ar_months'])+1):receipts[k]+=ar*d(s['opening_ar_recovery'])/int(s['opening_ar_months'])
 for k in range(1,int(s['opening_ap_months'])+1):payments[k]+=ap/int(s['opening_ap_months'])
 base_new=o['product_sales']/d(s['new_tool_price']);base_service=o['service_sales']/d(s['service_price']);rows=[];failure=None;exitrow=None;totalgross=Z;cumdraw=Z;eqreject=0
 for m in range(1,n+13):
  y=(m-1)//12;opening=dict(cash=cash,restricted=restricted,ar=ar,inventory=inv,ap=ap,opa=opa,ppe=ppe,pipelineasset=pipelineasset,debt=wc+term+unsecured+newdebt,shares=shares)
  commission=sum(c['machines'] for c in pipeline if c['ready']==m);commissioncost=sum((c['cost'] for c in pipeline if c['ready']==m),Z);pipeline=[c for c in pipeline if c['ready']!=m];machines+=commission;pipelineasset-=commissioncost;ppe+=commissioncost;ipo_commission=0;ipo_payment=Z;ipo_release=Z;capital_credit_payment=Z
  if m==int(s['ipo_commission_month']):
   ipo_commission=pending;machines+=pending;pending=0;ppe+=o['capital_advances'];pipelineasset-=o['capital_advances'];ipo_payment=o['remaining_ipo_capex'];ipo_release=min(restricted,ipo_payment);restricted-=ipo_release;ppe+=ipo_payment;capital_credit_payment=capcredit;capcredit=Z
  if m<=n:
   newdemand=base_new*(O+d(s['new_volume_growth']))**(y+1)*(O-d(s['customer_loss']));servdemand=base_service*(O+d(s['service_volume_growth']))**(y+1)*(O-d(s['customer_loss']));newprice=d(s['new_tool_price'])*(O+d(s['price_growth']))**(y+1);servprice=d(s['service_price'])*(O+d(s['price_growth']))**(y+1)
  else:
   newdemand=terminal_basis['new_units']*(O+d(s['terminal_growth']));servdemand=terminal_basis['service_units']*(O+d(s['terminal_growth']));newprice=terminal_basis['new_price'];servprice=terminal_basis['service_price']
  newcap=d(i['machine_capacity']['new_tools'])*machines;servcap=d(i['machine_capacity']['service_jobs'])*machines;newunits=min(newdemand/12,newcap/12);servunits=min(servdemand/12,servcap/12);lost_new=max(Z,newdemand/12-newunits);lost_service=max(Z,servdemand/12-servunits);sales=newunits*newprice+servunits*servprice
  # Capacity is bought as a whole dual-allocation grinding-machine block, not fractional capital.
  target=max(newdemand/d(i['machine_capacity']['new_tools']),servdemand/d(i['machine_capacity']['service_jobs']))*d(s['capacity_buffer']);needed=max(0,int(target.to_integral_value(rounding=ROUND_CEILING))-machines-pending-sum(c['machines']for c in pipeline));block=min(needed,max(0,int(s['max_machines'])-machines-pending-sum(c['machines']for c in pipeline)),max(0,int(s['annual_machine_limit'])-added[y])) if s['expansion_gate'] else 0
  growthcapex=d(block)*d(i['machine_capex'])*d(s['machine_capex_scale']);added[y]+=block;pipelineasset+=growthcapex
  if block:pipeline.append({'machines':block,'cost':growthcapex,'ready':m+int(s['lead_months'])})
  mat=sales*d(s['material_ratio']);impairment=inv*d(s['inventory_impairment'])if m==int(s['inventory_impairment_month']) else Z;inv-=impairment
  desired=max(Z,(newdemand*newprice+servdemand*servprice)*d(s['material_ratio'])*d(s['inventory_days'])/365);purchases=max(Z,mat+desired-inv);inv+=purchases-mat
  payments[m+int(s['supplier_delay'])]+=purchases;suppliercash=payments.pop(m,Z);ap+=purchases-suppliercash
  receipts[m+int(s['collection_delay'])]+=sales;collections=receipts.pop(m,Z);ar+=sales-collections;writeoff=o['receivables']*(O-d(s['opening_ar_recovery']))if m==int(s['opening_ar_months'])else Z;ar-=writeoff
  opexratio=O-d(s['material_ratio'])-d(s['ebitda_margin']);assert opexratio>=0
  opex=opexratio*(d(s['fixed_cost_fraction'])*o['annual_sales']/12+(O-d(s['fixed_cost_fraction']))*sales)
  maintenance=max(sales*d(s['maintenance_ratio']),ppe*d(s['replacement_rate'])/12 if m>n else Z);ppe+=maintenance;da=min(ppe,o['annual_da']/12+max(Z,ppe-o['ppe'])*d(s['new_da_rate'])/12);ppe-=da;ebitda=sales-mat-opex;ebit=ebitda-da-writeoff-impairment
  interest=(wc*d(s['wc_rate'])+term*d(s['term_rate'])+unsecured*d(s['unsecured_rate'])+newdebt*d(s['new_debt_rate']))/12
  if s['maturity_policy']=='reported_current':principal=min(term,o['current_bank_maturities']/12 if m<=12 else o['long_bank_debt']/36)
  else:principal=min(term,d(s['printed_instalment_monthly']))
  term-=principal;principal_unsecured=unsecured if m==int(s['unsecured_repayment_month'])else Z;unsecured-=principal_unsecured;principal_wc=wc if not s['wc_renewal'] and m==int(s['wc_call_month'])else Z;wc-=principal_wc
  principal_new=Z;renewfees=Z;kept=[]
  for c in debts:
   if c['due']==m:
    if s['new_debt_renewal_gate']:renewfees+=c['amount']*d(s['renewal_fee']);kept.append({'amount':c['amount'],'due':m+int(s['new_debt_tenor'])})
    else:principal_new+=c['amount']
   else:kept.append(c)
  debts=kept;newdebt-=principal_new
  taxes=max(Z,ebit-interest)*d(s['tax_rate']);taxpayment=taxclaim if m==int(s['tax_settlement_month'])else Z;taxclaim-=taxpayment;otherpayment=min(otherclaim,o['other_current_liabilities']/int(s['other_claim_months']))if m<=int(s['other_claim_months'])else Z;otherclaim-=otherpayment
  opa_target=o['other_operating_assets']+max(Z,(newdemand*newprice+servdemand*servprice)-o['annual_sales'])*d(s['other_assets_growth_ratio']);opamovement=opa_target-opa;opa=opa_target
  fees=d(s['annual_bank_fees'])/12+renewfees;reserve=max(d(s['minimum_cash']),(mat+opex)*d(s['reserve_cost_months']));capex=growthcapex+maintenance+ipo_payment
  pre=cash+collections+ipo_release-suppliercash-opex-interest-taxes-taxpayment-otherpayment-fees-capex-capital_credit_payment-principal-principal_unsecured-principal_wc-principal_new-opamovement
  need=max(Z,reserve-pre);wcdraw=Z;draw=Z;drawfee=Z
  if m<=n and s['existing_headroom_gate'] and s['wc_renewal']:
   wcdraw=min(need,max(Z,d(s['wc_limit'])-wc));wc+=wcdraw;pre+=wcdraw;need=max(Z,reserve-pre)
  if m<=n and s['new_debt_gate'] and need>0:
   draw=min(need/(O-d(s['draw_fee'])),max(Z,d(s['new_debt_limit'])-newdebt),max(Z,d(s['cumulative_debt_limit'])-cumdraw));drawfee=draw*d(s['draw_fee']);newdebt+=draw;cumdraw+=draw
   if draw:debts.append({'amount':draw,'due':m+int(s['new_debt_tenor'])})
  pre+=draw-drawfee;need=max(Z,reserve-pre);issued=0;gross=Z;eqfee=Z;issueprice=d(i['entry_price'])*(O-d(s['equity_discount']));forced=int(s.get('forced_equity_shares',0))if m==int(s.get('forced_equity_month',1))else 0
  if m<=n and s['equity_gate'] and m<=int(s['equity_last_month']) and(need>0 or forced>0):
   wanted=max(forced,int((need*CR/(issueprice*(O-d(s['equity_fee'])))).to_integral_value(rounding=ROUND_CEILING)));issued=min(wanted,max(0,auth-shares));eqreject+=int(issued<wanted);shares+=issued;gross=d(issued)*issueprice/CR;eqfee=gross*d(s['equity_fee']);totalgross+=gross
  cash=pre+gross-eqfee;shortfall=max(Z,reserve-cash)
  row={'month':m,'date':date(m),'year':y+1,'phase':'horizon'if m<=n else'terminal_transition','cash_open':opening['cash'],'cash_close':cash,'cash_reserve':reserve,'cash_shortfall':shortfall,'restricted_open':opening['restricted'],'restricted_close':restricted,'ipo_release':ipo_release,'ipo_capex':ipo_payment,'capital_credit_payment':capital_credit_payment,'capital_credit_claim':capcredit,'ar_open':opening['ar'],'ar_close':ar,'inventory_open':opening['inventory'],'inventory_close':inv,'ap_open':opening['ap'],'ap_close':ap,'opa_open':opening['opa'],'opa_close':opa,'opa_movement':opamovement,'ppe_open':opening['ppe'],'ppe_close':ppe,'pipeline_asset_open':opening['pipelineasset'],'pipeline_asset_close':pipelineasset,'machines':machines,'ipo_machines_commissioned':ipo_commission,'machines_commissioned':commission,'machines_ordered':block,'new_units':newunits,'service_units':servunits,'new_units_lost':lost_new,'service_units_lost':lost_service,'new_price':newprice,'service_price':servprice,'sales':sales,'material_cost':mat,'purchases':purchases,'supplier_cash':suppliercash,'collections':collections,'inventory_impairment':impairment,'receivable_writeoff':writeoff,'opex':opex,'ebitda':ebitda,'da':da,'ebit':ebit,'tax':taxes,'tax_claim_payment':taxpayment,'tax_claim_close':taxclaim,'other_claim_payment':otherpayment,'other_claim_close':otherclaim,'interest':interest,'bank_fees':fees,'maintenance_capex':maintenance,'growth_capex':growthcapex,'capex':capex,'debt_open':opening['debt'],'debt_close':wc+term+unsecured+newdebt,'wc_close':wc,'term_close':term,'unsecured_close':unsecured,'new_debt_close':newdebt,'term_principal':principal,'unsecured_principal':principal_unsecured,'wc_principal':principal_wc,'new_principal':principal_new,'wc_draw':wcdraw,'new_draw':draw,'draw_fee':drawfee,'shares_open':opening['shares'],'shares_close':shares,'issued_shares':issued,'issue_price':issueprice,'equity_gross':gross,'equity_fee':eqfee,'pre_equity_cash':pre,'failure':shortfall>D('1e-22')};rows.append(row)
  if m==n:
   exitrow=deepcopy(row);last12=rows[-12:];terminal_basis={'new_units':sum(x['new_units']for x in last12),'service_units':sum(x['service_units']for x in last12),'sales':sum(x['sales']for x in last12),'ebitda':sum(x['ebitda']for x in last12),'new_price':newprice,'service_price':servprice}
  if row['failure']:
   failure={'month':m,'date':date(m),'shortfall':shortfall,'negative_cash':cash<0,'reason':'Scenario reserve/funding shortfall, not observed company default'};break
 terminal=None;attempt=None
 if failure is None:
  trans=rows[n:];end=exitrow;g=d(s['terminal_growth']);w=d(s['wacc']);assert w>g
  nopat=sum(max(Z,x['ebit'])*(O-d(s['tax_rate']))for x in trans);dda=sum(x['da']for x in trans);replacement=max(sum(x['maintenance_capex']for x in trans),dda);physical=sum(x['growth_capex']+x['ipo_capex']for x in trans);last=trans[-1];onwc0=end['ar_close']+end['inventory_close']+end['opa_close']-end['ap_close'];onwc1=last['ar_close']+last['inventory_close']+last['opa_close']-last['ap_close'];wcneed=max(Z,onwc1-onwc0);economic=nopat*g/d(s['terminal_roic']);reinvestment=max(physical+wcneed,economic);extra=reinvestment-physical-wcneed+replacement-sum(x['maintenance_capex']for x in trans);fcff=nopat+dda-replacement-reinvestment
  # Exit cash distributes only amounts not needed to fund every transition-month trough.
  required=max([end['cash_reserve']]+[x['cash_reserve']-(x['cash_close']-end['cash_close'])+extra*d(k+1)/12 for k,x in enumerate(trans)]);required=max(Z,required);excess=max(Z,end['cash_close']-required);lost=sum(x['new_units_lost']+x['service_units_lost']for x in trans);funded=end['cash_close']+D('1e-18')>=required and lost<=D('1e-18')
  claim=d(s['tax_dispute_claim'])+gratuity+end['other_claim_close']+end['tax_claim_close']+end['capital_credit_claim']
  attempt={'next_sales':sum(x['sales']for x in trans),'next_nopat':nopat,'next_da':dda,'replacement_capex':replacement,'physical_growth_capex':physical,'working_capital_reinvestment':wcneed,'economic_reinvestment_floor':economic,'growth_reinvestment':reinvestment,'extra_terminal_cash_need':extra,'fcff':fcff,'reserve':required,'cash_at_exit':end['cash_close'],'excess_cash':excess,'restricted_cash_excluded':end['restricted_close'],'debt':end['debt_close'],'senior_claims':claim,'shares':end['shares_close'],'lost_units':lost,'funded':funded,'transition':[{'month':k+1,'cash_after_excess':x['cash_close']-excess-extra*d(k+1)/12,'reserve':x['cash_reserve'],'new_finance':x['wc_draw']+x['new_draw']+x['equity_gross']}for k,x in enumerate(trans)]}
  if funded:
   ev=max(Z,fcff/(w-g));equity=max(Z,ev+excess-end['debt_close']-claim);price=equity*CR/end['shares_close'];exitnet=price*(O-d(s['exit_cost']));entry=d(i['entry_price'])*(O+d(s['entry_cost']));irr=(exitnet/entry)**(O/years)-O if exitnet>0 else D(-1);cross=max(Z,terminal_basis['ebitda']*d(s['exit_multiple'])+excess-end['debt_close']-claim)*CR/end['shares_close'];terminal=dict(attempt,enterprise_value=ev,equity_value=equity,price=price,irr=irr,multiple_crosscheck_price=cross,hurdle_entries={str(h):exitnet/((O+h)**years*(O+d(s['entry_cost'])))for h in[D('.12'),D('.15'),D('.18')]})
  else:failure={'month':n+12,'date':date(n+12),'shortfall':max(Z,required-end['cash_close']),'negative_cash':False,'reason':'Terminal replacement/reinvestment reserve or physical-capacity gate failure; no rescue assumed'}
 annual=[]
 for y in range(1,years+1):
  a=[x for x in rows if x['year']==y and x['phase']=='horizon']
  if not a:continue
  sums=['sales','new_units','service_units','ebitda','ebit','da','tax','interest','capex','growth_capex','maintenance_capex','collections','supplier_cash','equity_gross','issued_shares','wc_draw','new_draw'];v={k:sum((x[k]for x in a),Z)for k in sums};v.update(year=y,months=len(a),cash_close=a[-1]['cash_close'],debt_close=a[-1]['debt_close'],shares_close=a[-1]['shares_close'],machines=a[-1]['machines']);annual.append(v)
 summary={'path_id':path_id,'years':years,'source_eligible':False,'failure_month':failure['month']if failure else None,'failure_reason':failure['reason']if failure else None,'irr':None if failure else terminal['irr'],'terminal_price':None if failure else terminal['price'],'terminal_sales':None if not exitrow else terminal_basis['sales'],'hurdle_entries':None if failure else terminal['hurdle_entries'],'total_capex':sum(x['capex']for x in rows if x['phase']=='horizon'),'equity_gross':totalgross,'final_shares':rows[-1]['shares_close'],'equity_authorization_rejections':eqreject,'last_machines':rows[-1]['machines'],'new_volume_growth':s['new_volume_growth'],'margin':s['ebitda_margin'],'funded_terminal':terminal is not None,'multiple_return':None if failure else terminal['price']/d(i['entry_price']),'label':s['label']}
 return {'path_id':path_id,'years':years,'spec':s,'source_eligible':False,'source_limit':i['source_eligibility_limit'],'monthly':rows,'annual':annual,'failure':failure,'terminal_attempt':attempt,'terminal':terminal,'summary':summary}
