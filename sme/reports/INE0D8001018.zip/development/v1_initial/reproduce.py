from pathlib import Path
import json,gzip,hashlib
import model
P=Path(__file__).resolve().parent
i=json.loads((P/'model_inputs.json').read_text());specs=json.loads((P/'scenario_inputs.json').read_text())['specifications']
with (P/'canonical_paths.json.gz').open('wb')as f:
 with gzip.GzipFile(filename='',fileobj=f,mode='wb',mtime=0,compresslevel=9)as z:
  z.write(b'{')
  for k,q in enumerate(specs):
   r=model.run(i,q['spec'],q['years'],q['path_id']);z.write(((','if k else'')+json.dumps(q['path_id'])+':'+json.dumps(r,default=str,sort_keys=True,separators=(',',':'))).encode())
  z.write(b'}')
h=hashlib.sha256((P/'canonical_paths.json.gz').read_bytes()).hexdigest();expected=json.loads((P/'expected_output_hashes.json').read_text())['canonical_paths.json.gz'];assert h==expected;print('PASS',len(specs),h)
