"""Independent verifier: raw JSON inputs -> monthly ledgers, with no producer imports.

This deliberately uses separate event schedules and state ledgers. It compares every
saved monthly field after constructing all months from inputs. Decimal differences
below 1e-18 crore are rounding-order noise, never a material tolerance.
"""
from decimal import Decimal, ROUND_CEILING
from pathlib import Path
import json, hashlib, sys

D = Decimal
ZERO = D(0)
ONE = D(1)
CR = D(10000000)
TOL = D('1e-18')

def number(value):
    if isinstance(value, float):
        raise ValueError('Binary float input is forbidden')
    return D(str(value))

def total(items):
    return sum(items, ZERO)

def ceil(value):
    return int(value.to_integral_value(rounding=ROUND_CEILING))

def replay_months(raw, case):
    spec = case['spec']
    s = lambda key: number(spec[key])
    initial = {k: number(v) for k, v in raw['opening'].items()}
    balance = dict(initial)
    balance.update(new_debt=ZERO, shares=raw['issued_shares'])
    newtool_capacity = number(raw['machine_capacity']['new_tools'])
    service_capacity = number(raw['machine_capacity']['service_jobs'])
    machine_count = int(spec['initial_machines'])
    ipo_remaining = int(spec['pending_ipo_machines'])
    authority = int(spec['expanded_authorized_shares'] if spec['authorization_gate'] else raw['authorized_shares'])
    num_months = case['years'] * 12
    capacity_orders, borrowings, invoices, creditors = [], [], {}, {}
    ordered_by_year = {}
    def event(book, month, amount):
        book[month] = book.get(month, ZERO) + amount
    for month in range(1, int(spec['opening_ar_months']) + 1):
        event(invoices, month, initial['receivables'] * s('opening_ar_recovery') / spec['opening_ar_months'])
    for month in range(1, int(spec['opening_ap_months']) + 1):
        event(creditors, month, initial['trade_payables'] / spec['opening_ap_months'])
    cumulative_draw = ZERO
    cumulative_equity = ZERO
    rejected_issues = 0
    rows = []
    failure = None
    for month in range(1, num_months + 13):
        yr = (month - 1) // 12
        old = balance.copy()
        debt_open = total(balance[k] for k in ('working_capital_debt', 'bank_term_debt', 'unsecured_debt', 'new_debt'))
        completed_orders = [v for v in capacity_orders if v['month'] == month]
        capacity_orders = [v for v in capacity_orders if v['month'] != month]
        commissioned = sum(v['count'] for v in completed_orders)
        commissioned_value = total(v['cost'] for v in completed_orders)
        machine_count += commissioned
        balance['capital_advances'] -= commissioned_value
        balance['ppe'] += commissioned_value
        ipo_new, ipo_cash, ipo_draw, capital_payment = 0, ZERO, ZERO, ZERO
        if month == spec['ipo_commission_month']:
            ipo_new = ipo_remaining
            machine_count += ipo_new
            ipo_remaining = 0
            balance['ppe'] += initial['capital_advances']
            balance['capital_advances'] -= initial['capital_advances']
            ipo_cash = initial['remaining_ipo_capex']
            ipo_draw = min(balance['restricted_ipo'], ipo_cash)
            balance['restricted_ipo'] -= ipo_draw
            balance['ppe'] += ipo_cash
            capital_payment = balance['capital_creditors']
            balance['capital_creditors'] = ZERO
        if month <= num_months:
            new_demand = initial['product_sales'] / s('new_tool_price') * (ONE+s('new_volume_growth')) ** (yr+1) * (ONE-s('customer_loss'))
            service_demand = initial['service_sales'] / s('service_price') * (ONE+s('service_volume_growth')) ** (yr+1) * (ONE-s('customer_loss'))
            new_price = s('new_tool_price') * (ONE+s('price_growth')) ** (yr+1)
            service_price = s('service_price') * (ONE+s('price_growth')) ** (yr+1)
        else:
            new_demand = terminal_base['new_units'] * (ONE+s('terminal_growth'))
            service_demand = terminal_base['service_units'] * (ONE+s('terminal_growth'))
            new_price = terminal_base['new_price']
            service_price = terminal_base['service_price']
        new_units = min(new_demand, newtool_capacity*machine_count)/12
        service_units = min(service_demand, service_capacity*machine_count)/12
        new_lost = max(ZERO, new_demand/12-new_units)
        service_lost = max(ZERO, service_demand/12-service_units)
        sales = new_units*new_price + service_units*service_price
        already_ordered = sum(v['count'] for v in capacity_orders)
        needed_count = max(0, ceil(max(new_demand/newtool_capacity, service_demand/service_capacity) * s('capacity_buffer')) - machine_count - ipo_remaining - already_ordered)
        purchase_count = min(needed_count, max(0, spec['max_machines']-machine_count-ipo_remaining-already_ordered), max(0, spec['annual_machine_limit']-ordered_by_year.get(yr,0))) if spec['expansion_gate'] else 0
        ordered_by_year[yr] = ordered_by_year.get(yr,0)+purchase_count
        growth_capex = purchase_count*number(raw['machine_capex'])*s('machine_capex_scale')
        balance['capital_advances'] += growth_capex
        if purchase_count:
            capacity_orders.append(dict(month=month+spec['lead_months'], count=purchase_count, cost=growth_capex))
        material = sales*s('material_ratio')
        inventory_writeoff = balance['inventory']*s('inventory_impairment') if month == spec['inventory_impairment_month'] else ZERO
        balance['inventory'] -= inventory_writeoff
        inventory_target = max(ZERO, (new_demand*new_price+service_demand*service_price)*s('material_ratio')*s('inventory_days')/365)
        purchases = max(ZERO, material+inventory_target-balance['inventory'])
        balance['inventory'] += purchases-material
        event(creditors,month+spec['supplier_delay'],purchases)
        supplier_cash = creditors.pop(month,ZERO)
        balance['trade_payables'] += purchases-supplier_cash
        event(invoices,month+spec['collection_delay'],sales)
        customer_cash = invoices.pop(month,ZERO)
        ar_writeoff = initial['receivables']*(ONE-s('opening_ar_recovery')) if month == spec['opening_ar_months'] else ZERO
        balance['receivables'] += sales-customer_cash-ar_writeoff
        operating_cost = (ONE-s('material_ratio')-s('ebitda_margin'))*(s('fixed_cost_fraction')*initial['annual_sales']/12+(ONE-s('fixed_cost_fraction'))*sales)
        maintenance = max(sales*s('maintenance_ratio'), balance['ppe']*s('replacement_rate')/12 if month > num_months else ZERO)
        balance['ppe'] += maintenance
        depreciation = min(balance['ppe'], initial['annual_da']/12+max(ZERO,balance['ppe']-initial['ppe'])*s('new_da_rate')/12)
        balance['ppe'] -= depreciation
        ebitda = sales-material-operating_cost
        ebit = ebitda-depreciation-ar_writeoff-inventory_writeoff
        interest = (balance['working_capital_debt']*s('wc_rate')+balance['bank_term_debt']*s('term_rate')+balance['unsecured_debt']*s('unsecured_rate')+balance['new_debt']*s('new_debt_rate'))/12
        scheduled = (initial['current_bank_maturities']/12 if month <=12 else initial['long_bank_debt']/36) if spec['maturity_policy']=='reported_current' else s('printed_instalment_monthly')
        term_payment = min(balance['bank_term_debt'],scheduled)
        balance['bank_term_debt'] -= term_payment
        unsecured_payment = balance['unsecured_debt'] if month==spec['unsecured_repayment_month'] else ZERO
        balance['unsecured_debt'] -= unsecured_payment
        wc_payment = balance['working_capital_debt'] if not spec['wc_renewal'] and month==spec['wc_call_month'] else ZERO
        balance['working_capital_debt'] -= wc_payment
        new_payment, rollover_fee = ZERO, ZERO
        next_borrowings = []
        for obligation in borrowings:
            if obligation['due'] != month:
                next_borrowings.append(obligation)
            elif spec['new_debt_renewal_gate']:
                rollover_fee += obligation['amount']*s('renewal_fee')
                next_borrowings.append(dict(amount=obligation['amount'], due=month+spec['new_debt_tenor']))
            else:
                new_payment += obligation['amount']
        borrowings = next_borrowings
        balance['new_debt'] -= new_payment
        cash_tax = max(ZERO,ebit-interest)*s('tax_rate')
        tax_settlement = balance['tax_provisions'] if month==spec['tax_settlement_month'] else ZERO
        balance['tax_provisions'] -= tax_settlement
        other_settlement = min(balance['other_current_liabilities'],initial['other_current_liabilities']/spec['other_claim_months']) if month <= spec['other_claim_months'] else ZERO
        balance['other_current_liabilities'] -= other_settlement
        other_assets = initial['other_operating_assets']+max(ZERO,new_demand*new_price+service_demand*service_price-initial['annual_sales'])*s('other_assets_growth_ratio')
        additional_assets = other_assets-balance['other_operating_assets']
        balance['other_operating_assets'] = other_assets
        bank_fees = s('annual_bank_fees')/12+rollover_fee
        required_cash = max(s('minimum_cash'),(material+operating_cost)*s('reserve_cost_months'))
        capex = growth_capex+maintenance+ipo_cash
        cash_before_funding = balance['cash']+customer_cash+ipo_draw-supplier_cash-operating_cost-interest-cash_tax-tax_settlement-other_settlement-bank_fees-capex-capital_payment-term_payment-unsecured_payment-wc_payment-new_payment-additional_assets
        need = max(ZERO,required_cash-cash_before_funding)
        headroom_draw = ZERO
        if month <= num_months and spec['existing_headroom_gate'] and spec['wc_renewal']:
            headroom_draw = min(need,max(ZERO,s('wc_limit')-balance['working_capital_debt']))
            balance['working_capital_debt'] += headroom_draw
            cash_before_funding += headroom_draw
            need = max(ZERO,required_cash-cash_before_funding)
        fresh_draw = ZERO
        if month <= num_months and spec['new_debt_gate'] and need>0:
            fresh_draw = min(need/(ONE-s('draw_fee')),max(ZERO,s('new_debt_limit')-balance['new_debt']),max(ZERO,s('cumulative_debt_limit')-cumulative_draw))
            balance['new_debt'] += fresh_draw
            cumulative_draw += fresh_draw
            if fresh_draw:
                borrowings.append(dict(amount=fresh_draw,due=month+spec['new_debt_tenor']))
        debt_fee = fresh_draw*s('draw_fee')
        cash_before_funding += fresh_draw-debt_fee
        need = max(ZERO,required_cash-cash_before_funding)
        issue_price = number(raw['entry_price'])*(ONE-s('equity_discount'))
        forced = int(spec.get('forced_equity_shares',0)) if month==int(spec.get('forced_equity_month',1)) else 0
        issued = 0
        if month<=num_months and spec['equity_gate'] and month<=spec['equity_last_month'] and (need>0 or forced>0):
            requested = max(forced,ceil(need*CR/(issue_price*(ONE-s('equity_fee')))))
            issued = min(requested,max(0,authority-balance['shares']))
            rejected_issues += issued<requested
        gross = issued*issue_price/CR
        equity_fee = gross*s('equity_fee')
        balance['shares'] += issued
        cumulative_equity += gross
        balance['cash'] = cash_before_funding+gross-equity_fee
        shortfall = max(ZERO,required_cash-balance['cash'])
        calendar_index = 2026*12+10+month-1
        row = dict(month=month,date=f'{calendar_index//12:04d}-{calendar_index%12+1:02d}',year=yr+1,phase='horizon' if month<=num_months else 'terminal_transition',cash_open=old['cash'],cash_close=balance['cash'],cash_reserve=required_cash,cash_shortfall=shortfall,restricted_open=old['restricted_ipo'],restricted_close=balance['restricted_ipo'],ipo_release=ipo_draw,ipo_capex=ipo_cash,capital_credit_payment=capital_payment,capital_credit_claim=balance['capital_creditors'],ar_open=old['receivables'],ar_close=balance['receivables'],inventory_open=old['inventory'],inventory_close=balance['inventory'],ap_open=old['trade_payables'],ap_close=balance['trade_payables'],opa_open=old['other_operating_assets'],opa_close=balance['other_operating_assets'],opa_movement=additional_assets,ppe_open=old['ppe'],ppe_close=balance['ppe'],pipeline_asset_open=old['capital_advances'],pipeline_asset_close=balance['capital_advances'],machines=machine_count,ipo_machines_commissioned=ipo_new,machines_commissioned=commissioned,machines_ordered=purchase_count,new_units=new_units,service_units=service_units,new_units_lost=new_lost,service_units_lost=service_lost,new_price=new_price,service_price=service_price,sales=sales,material_cost=material,purchases=purchases,supplier_cash=supplier_cash,collections=customer_cash,inventory_impairment=inventory_writeoff,receivable_writeoff=ar_writeoff,opex=operating_cost,ebitda=ebitda,da=depreciation,ebit=ebit,tax=cash_tax,tax_claim_payment=tax_settlement,tax_claim_close=balance['tax_provisions'],other_claim_payment=other_settlement,other_claim_close=balance['other_current_liabilities'],interest=interest,bank_fees=bank_fees,maintenance_capex=maintenance,growth_capex=growth_capex,capex=capex,debt_open=debt_open,debt_close=total(balance[k] for k in ('working_capital_debt','bank_term_debt','unsecured_debt','new_debt')),wc_close=balance['working_capital_debt'],term_close=balance['bank_term_debt'],unsecured_close=balance['unsecured_debt'],new_debt_close=balance['new_debt'],term_principal=term_payment,unsecured_principal=unsecured_payment,wc_principal=wc_payment,new_principal=new_payment,wc_draw=headroom_draw,new_draw=fresh_draw,draw_fee=debt_fee,shares_open=old['shares'],shares_close=balance['shares'],issued_shares=issued,issue_price=issue_price,equity_gross=gross,equity_fee=equity_fee,pre_equity_cash=cash_before_funding,failure=shortfall>D('1e-22'))
        row['commissioned_cost'] = commissioned_value
        row['ipo_advanced_asset_commissioned'] = initial['capital_advances'] if month==spec['ipo_commission_month'] else ZERO
        rows.append(row)
        if month==num_months:
            last_year=rows[-12:]
            terminal_base=dict(new_units=total(v['new_units'] for v in last_year),service_units=total(v['service_units'] for v in last_year),sales=total(v['sales'] for v in last_year),ebitda=total(v['ebitda'] for v in last_year),new_price=new_price,service_price=service_price)
        if row['failure']:
            failure=dict(month=month,shortfall=shortfall)
            break
    return dict(monthly=rows,monthly_failure=failure,cumulative_equity=cumulative_equity,rejected_issues=rejected_issues,terminal_base=locals().get('terminal_base'))

def replay_terminal(raw,case,own,legacy=False):
    """Value only a complete, independently cash-funded transition year."""
    if own['monthly_failure']:
        return None, None
    n=case['years']*12
    s=lambda k:number(case['spec'][k])
    ending=own['monthly'][n-1]
    transition=own['monthly'][n:]
    nopat=total(max(ZERO,r['ebit'])*(ONE-s('tax_rate')) for r in transition)
    depreciation=total(r['da'] for r in transition)
    maintenance_cash=total(r['maintenance_capex'] for r in transition)
    replacement=max(maintenance_cash,depreciation)
    physical=total(r['growth_capex']+r['ipo_capex'] for r in transition)
    def onwc(r):
        return r['ar_close']+r['inventory_close']+r['opa_close']-r['ap_close']
    working_investment=max(ZERO,onwc(transition[-1])-onwc(ending))
    economic_floor=nopat*s('terminal_growth')/s('terminal_roic')
    growth_investment=max(physical+working_investment,economic_floor)
    extra_cash=growth_investment-physical-working_investment+replacement-maintenance_cash
    fcff=nopat+depreciation-replacement-growth_investment
    closing_cash=ending['cash_close']
    full_cash_requirements=[ending['cash_reserve']]
    unlevered_requirements=[ending['cash_reserve']]
    finance_addback=ZERO
    unlevered=[]
    for index,row in enumerate(transition,1):
        full_cash_requirements.append(row['cash_reserve']-(row['cash_close']-closing_cash)+extra_cash*index/12)
        tax_difference=max(ZERO,row['ebit'])*s('tax_rate')-row['tax']
        principal=total(row[k] for k in ('term_principal','unsecured_principal','wc_principal','new_principal'))
        claims_paid=total(row[k] for k in ('tax_claim_payment','other_claim_payment','capital_credit_payment'))
        finance_addback+=principal+row['interest']-tax_difference+row['bank_fees']+claims_paid
        cash_without_financing=row['cash_close']+finance_addback
        unlevered_requirements.append(row['cash_reserve']-(cash_without_financing-closing_cash)+extra_cash*index/12)
        unlevered.append(dict(month=index,cumulative_financing_claim_addback=finance_addback,unlevered_cash=cash_without_financing,tax_shield_removed=tax_difference))
    funding_reserve=max(ZERO,max(full_cash_requirements))
    operating_reserve=max(ZERO,max(unlevered_requirements))
    distributable=max(ZERO,closing_cash-funding_reserve)
    cash_asset=max(ZERO,closing_cash-operating_reserve)
    units_not_served=total(r['new_units_lost']+r['service_units_lost'] for r in transition)
    funded=closing_cash+TOL>=funding_reserve and units_not_served<=TOL
    senior=s('tax_dispute_claim')+number(raw['opening']['gratuity'])+ending['other_claim_close']+ending['tax_claim_close']+ending['capital_credit_claim']
    attempt=dict(next_sales=total(r['sales'] for r in transition),next_nopat=nopat,next_da=depreciation,replacement_capex=replacement,physical_growth_capex=physical,working_capital_reinvestment=working_investment,economic_reinvestment_floor=economic_floor,growth_reinvestment=growth_investment,extra_terminal_cash_need=extra_cash,fcff=fcff,reserve=funding_reserve,funding_reserve=funding_reserve,operating_reserve=operating_reserve,cash_for_equity_bridge=cash_asset,debt_service_earmarked_cash=max(ZERO,cash_asset-distributable),unlevered_transition=unlevered,cash_at_exit=closing_cash,excess_cash=distributable,restricted_cash_excluded=ending['restricted_close'],debt=ending['debt_close'],senior_claims=senior,shares=ending['shares_close'],lost_units=units_not_served,funded=funded,transition=[dict(month=index,cash_after_excess=row['cash_close']-distributable-extra_cash*index/12,reserve=row['cash_reserve'],new_finance=row['wc_draw']+row['new_draw']+row['equity_gross']) for index,row in enumerate(transition,1)])
    if legacy:
        cash_asset=distributable
        for key in ('funding_reserve','operating_reserve','cash_for_equity_bridge','debt_service_earmarked_cash','unlevered_transition'):
            attempt.pop(key)
    if not funded:
        return attempt,None
    enterprise=max(ZERO,fcff/(s('wacc')-s('terminal_growth')))
    equity=max(ZERO,enterprise+cash_asset-ending['debt_close']-senior)
    price=equity*CR/ending['shares_close']
    proceeds=price*(ONE-s('exit_cost'))
    investment=number(raw['entry_price'])*(ONE+s('entry_cost'))
    terminal=dict(attempt,enterprise_value=enterprise,equity_value=equity,price=price,irr=(proceeds/investment)**(ONE/case['years'])-ONE if proceeds>0 else D(-1),multiple_crosscheck_price=max(ZERO,own['terminal_base']['ebitda']*s('exit_multiple')+cash_asset-ending['debt_close']-senior)*CR/ending['shares_close'],hurdle_entries={str(h):proceeds/((ONE+h)**case['years']*(ONE+s('entry_cost'))) for h in [D('.12'),D('.15'),D('.18')]})
    return attempt,terminal

def compare_tree(actual,expected,prefix=''):
    errors=[]
    checked=0
    if isinstance(expected,dict):
        if not isinstance(actual,dict):
            return 1,[{'field':prefix,'actual':actual,'expected':'object'}]
        for key,value in expected.items():
            if key not in actual:
                errors.append({'field':prefix+'.'+key,'actual':'MISSING','expected':str(value)})
            else:
                n,e=compare_tree(actual[key],value,prefix+'.'+key)
                checked+=n;errors+=e
    elif isinstance(expected,list):
        if not isinstance(actual,list):
            return 1,[{'field':prefix,'actual':actual,'expected':'list'}]
        if len(actual)!=len(expected):
            errors.append({'field':prefix+'.length','actual':len(actual),'expected':len(expected)})
        for index,(a,e) in enumerate(zip(actual,expected)):
            n,err=compare_tree(a,e,prefix+f'[{index}]');checked+=n;errors+=err
    else:
        checked+=1
        if not numeric_equal(actual,expected):
            errors.append({'field':prefix,'actual':actual,'expected':str(expected)})
    return checked,errors

def numeric_equal(actual, expected):
    if isinstance(expected,bool) or expected is None or isinstance(expected,str):
        return actual==expected
    try:
        return abs(number(actual)-number(expected))<=TOL
    except Exception:
        return False

def compare_months(raw,case,producer,legacy=False):
    own = replay_months(raw,case)
    mismatches=[]
    if len(own['monthly'])!=len(producer['monthly']):
        mismatches.append({'field':'monthly_count','actual':len(producer['monthly']),'expected':len(own['monthly'])})
    checked=0
    for ours,theirs in zip(own['monthly'],producer['monthly']):
        for field,expected in ours.items():
            if legacy and field in ('commissioned_cost','ipo_advanced_asset_commissioned'):
                continue
            checked+=1
            if field not in theirs or not numeric_equal(theirs[field],expected):
                mismatches.append({'month':ours['month'],'field':field,'actual':theirs.get(field),'expected':str(expected)})
    return own,checked,mismatches

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def independent_annual(own,years):
    annual=[]
    fields=('sales','new_units','service_units','ebitda','ebit','da','tax','interest','capex','growth_capex','maintenance_capex','collections','supplier_cash','equity_gross','issued_shares','wc_draw','new_draw')
    for year in range(1,years+1):
        rows=[r for r in own['monthly'] if r['year']==year and r['phase']=='horizon']
        if not rows:
            continue
        record={field:total(row[field] for row in rows) for field in fields}
        record.update(year=year,months=len(rows),cash_close=rows[-1]['cash_close'],debt_close=rows[-1]['debt_close'],shares_close=rows[-1]['shares_close'],machines=rows[-1]['machines'])
        annual.append(record)
    return annual

def expected_summary(raw,case,own,attempt,terminal):
    if own['monthly_failure']:
        failure_month=own['monthly_failure']['month']
        reason='Scenario reserve/funding shortfall, not observed company default'
    elif terminal is None:
        failure_month=case['years']*12+12
        reason='Terminal replacement/reinvestment reserve or physical-capacity gate failure; no rescue assumed'
    else:
        failure_month=None;reason=None
    return dict(path_id=case['path_id'],years=case['years'],source_eligible=False,failure_month=failure_month,failure_reason=reason,irr=terminal['irr'] if terminal else None,terminal_price=terminal['price'] if terminal else None,terminal_sales=own['terminal_base']['sales'] if own['terminal_base'] else None,hurdle_entries=terminal['hurdle_entries'] if terminal else None,total_capex=total(r['capex'] for r in own['monthly'] if r['phase']=='horizon'),equity_gross=own['cumulative_equity'],final_shares=own['monthly'][-1]['shares_close'],equity_authorization_rejections=own['rejected_issues'],last_machines=own['monthly'][-1]['machines'],new_volume_growth=case['spec']['new_volume_growth'],margin=case['spec']['ebitda_margin'],funded_terminal=terminal is not None,multiple_return=terminal['price']/number(raw['entry_price']) if terminal else None,label=case['spec']['label'])

def verify_paths(folder,legacy=False):
    import gzip
    raw=json.loads((folder/'model_inputs.json').read_text())
    cases=json.loads((folder/'scenario_inputs.json').read_text())['specifications']
    with gzip.open(folder/'canonical_paths.json.gz','rt') as handle:
        saved=json.load(handle)
    if isinstance(saved,list):
        saved={v['path_id']:v for v in saved}
    checked=0;errors=[];records=[];summaries=[]
    ids=[case['path_id'] for case in cases]
    if len(ids)!=len(set(ids)) or set(ids)!=set(saved):
        errors.append({'field':'path_universe','actual':sorted(saved),'expected':sorted(ids)})
    for case in cases:
        producer=saved[case['path_id']]
        own,count,mismatches=compare_months(raw,case,producer,legacy=legacy)
        monthly_checks=count
        checked+=count
        attempt,terminal=replay_terminal(raw,case,own,legacy=legacy)
        for key,expected in [('terminal_attempt',attempt),('terminal',terminal),('annual',independent_annual(own,case['years']))]:
            count,more=compare_tree(producer.get(key),expected,key)
            checked+=count;mismatches+=more
        summary=expected_summary(raw,case,own,attempt,terminal)
        summary['kind']=case['kind']
        count,more=compare_tree(producer['summary'],{k:v for k,v in summary.items() if k!='kind'},'summary')
        checked+=count;mismatches+=more
        if producer.get('source_eligible') is not False:
            mismatches.append({'field':'source_eligible','actual':producer.get('source_eligible'),'expected':False})
        if terminal is None:
            if producer.get('terminal') is not None or any(producer['summary'].get(k) is not None for k in ['irr','terminal_price','hurdle_entries','multiple_return']):
                mismatches.append({'field':'failed_path_return_suppression','actual':'A failed path retained an ordinary return','expected':'All ordinary returns null'})
        else:
            for row in terminal['transition']:
                if row['cash_after_excess']+TOL<row['reserve'] or row['new_finance']!=0:
                    mismatches.append({'field':'terminal_survival','actual':str(row),'expected':'No rescue, no reserve breach'})
        for e in mismatches:
            errors.append(dict(path_id=case['path_id'],**e))
        records.append({'path_id':case['path_id'],'months':len(own['monthly']),'monthly_checks':monthly_checks,'failure_month':summary['failure_month'],'source_eligible':False,'funded_terminal':terminal is not None,'status':'FAIL' if mismatches else 'PASS'})
        summaries.append(summary)
    return {'path_count':len(cases),'monthly_rows':sum(r['months'] for r in records),'checks':checked,'funded_count':sum(r['funded_terminal'] for r in records),'source_eligible_count':0,'errors':errors,'paths':records},summaries

def verify_targets(summaries):
    output=[]
    for years in [5,10]:
        candidates=[r for r in summaries if r['years']==years and r['kind'] in ('reverse_hurdle','multibagger') and r['multiple_return'] is not None]
        for target in ['1.12','1.15','1.18','5','10']:
            required=number(target)**years if number(target)<2 else number(target)
            crossings=[r for r in candidates if r['multiple_return']*D('.99')/D('1.01')>=required]
            highest=max(candidates,key=lambda r:r['multiple_return']) if candidates else None
            smallest=min(crossings,key=lambda r:(number(r['new_volume_growth']),number(r['margin']))) if crossings else None
            output.append(dict(years=years,target=target,required_net_multiple=required,tested_funded_crossings=len(crossings),least_growth_crossing=smallest['path_id'] if smallest else None,best_funded_path=highest['path_id'] if highest else None,best_funded_net_multiple=highest['multiple_return']*D('.99')/D('1.01') if highest else None))
    return output

def main():
    import argparse
    from decimal import localcontext
    from verifier_metrics import financials,peers,scores
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--inputs',default='.')
    parser.add_argument('--output',default='independent_replay_results.json')
    parser.add_argument('--compare',action='store_true',help='Require comparison to saved producer outputs')
    args=parser.parse_args()
    root=Path(args.inputs)
    with localcontext() as ctx:
        ctx.prec=40
        paths,summaries=verify_paths(root)
        failures=list(paths.pop('errors'))
        legacy_path=root/'development/v1_initial'
        legacy_results=None
        if (legacy_path/'canonical_paths.json.gz').exists():
            with localcontext() as old_context:
                old_context.prec=28
                legacy_results,_=verify_paths(legacy_path,legacy=True)
            legacy_errors=legacy_results.pop('errors')
            failures.extend(dict(vintage='superseded_v1',**e) for e in legacy_errors)
            legacy_results['status']='FAIL' if legacy_errors else 'PASS'
            legacy_results['precision']=28
            legacy_results['role']='Superseded model retained for provenance, not used for current conclusions'
        f=json.loads((root/'financial_inputs.json').read_text())
        fm=json.loads((root/'financial_metrics.json').read_text())
        fchecks,ferrors=compare_tree(fm,financials(f),'financial_metrics')
        failures+=ferrors
        p=json.loads((root/'peer_inputs.json').read_text())
        pchecks=0
        for actual,expected in zip(p['peers'],peers(p)):
            n,e=compare_tree(actual,expected,'peer.'+actual['company']);pchecks+=n;failures+=e
        j=json.loads((root/'judgments.json').read_text())
        sc=json.loads((root/'scores.json').read_text())
        schecks,serrors=compare_tree(sc['composites'],scores(j),'score_audit.composites')
        failures+=serrors
        targets=verify_targets(summaries)
        target_checks=0
        for filename in ['model_summary.json','target_search.json','reverse_targets.json','target_results.json']:
            if (root/filename).exists():
                actual=json.loads((root/filename).read_text())
                if isinstance(actual,dict):
                    actual=actual.get('targets',actual.get('results',actual))
                n,e=compare_tree(actual,targets,'target_search');target_checks+=n;failures+=e
                break
        required=['model_inputs.json','scenario_inputs.json','financial_inputs.json','financial_metrics.json','peer_inputs.json','judgments.json','scores.json','canonical_paths.json.gz','framework.md','verifier_replay.py','verifier_metrics.py']
        hashes={name:sha(root/name) for name in required}
        if legacy_results:
            for name in ('model_inputs.json','scenario_inputs.json','canonical_paths.json.gz'):
                hashes['development/v1_initial/'+name]=sha(legacy_path/name)
        result={'status':'FAIL' if failures else 'PASS','scope':'Independent raw-input monthly/event/annual/terminal replay plus exact score, historical and peer calculations; no producer imports','precision':40,'absolute_numeric_tolerance_crore':str(TOL),'paths':paths,'superseded_v1':legacy_results,'financial_checks':fchecks,'peer_checks':pchecks,'score_checks':schecks,'target_checks':target_checks,'targets':targets,'all_current_paths_source_ineligible':True,'input_and_compared_output_sha256':hashes,'failures':failures,'limitations':['Passing arithmetic does not verify current commissioning, bank availability, a primary executable quote or liquidity.','Historical and peer calculations use authored raw inputs; original source inspection and hashes are separately attested.','No precise success probabilities assigned; unsuccessful paths retain null ordinary returns.']}
        destination=Path(args.output)
        destination.write_text(json.dumps(result,ensure_ascii=False,indent=2,sort_keys=True,default=str)+'\n')
        print(json.dumps({'status':result['status'],'paths':paths['path_count'],'monthly_rows':paths['monthly_rows'],'checks':paths['checks']+fchecks+pchecks+schecks+target_checks,'failures':len(failures)},sort_keys=True))
        return 0 if not failures else 1

if __name__=='__main__':
    exit_status=main()
    if exit_status:
        raise SystemExit(exit_status)

