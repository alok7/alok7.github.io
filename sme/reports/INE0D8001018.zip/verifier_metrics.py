"""Independent score, historical-input and peer-calculation audit. No producer imports."""
from decimal import Decimal as D, ROUND_HALF_UP, localcontext

WEIGHTS={
 'BQS':{'GOV':'0.20','MOAT':'0.20','REV':'0.12','DUR':'0.10','CAP':'0.12','CASH':'0.10','BAL':'0.08','EXEC':'0.08'},
 'GQS':{'REV':'0.40','DUR':'0.20','EARN':'0.15','CAP':'0.15','CASH':'0.10'},
 'IAS':{'BQS':'0.25','R':'0.35','D':'0.20','P':'0.10','L':'0.10'}}

def scores(j):
    results={}
    for label,weights in WEIGHTS.items():
        values={key:results['BQS']['final'] if key=='BQS' else j['factors'][key]['score'] for key in weights}
        covered=sum((D(weights[key]) for key in weights if values[key] is not None),D(0))
        known=sum((D(weights[key])*D(values[key]) for key in weights if values[key] is not None),D(0))
        cap=None
        if label in ('BQS','IAS') and ((j['factors']['GOV']['score'] is not None and j['factors']['GOV']['score']<=3) or j['gates']['G1']['status']=='Fail — evidenced'):
            cap=D(3)
        if label=='IAS' and j['gates']['G3']['status']=='Fail — evidenced':
            cap=D(3)
        if label=='GQS' and j['persistent_growth_override']:
            cap=D(5)
        raw=known if covered==1 else None
        final=min(raw,cap) if raw is not None and cap is not None else raw
        if label=='IAS' and any(j['gates'][gate]['status'].startswith(('Hold','Fail')) for gate in ('G2','G4')):
            final=None
        bound=[known+(1-covered),known+10*(1-covered)]
        results[label]={'coverage':covered,'known_contribution':known,'raw':raw,'final':final,'cap':cap,'mathematical_bound':bound,'capped_bound':[min(v,cap) for v in bound] if cap is not None else bound,'display':'NS' if final is None else str(final.quantize(D('.1'),rounding=ROUND_HALF_UP)),'contributions':{key:None if values[key] is None else D(weights[key])*D(values[key]) for key in weights}}
    b=results['BQS'];ias=results['IAS']
    if b['final'] is None:
        other_missing=sum((D(weight) for key,weight in WEIGHTS['IAS'].items() if key!='BQS' and j['factors'][key]['score'] is None),D(0))
        ias['dependency_aware_bound']=[ias['known_contribution']+D('.25')*b['capped_bound'][0]+other_missing,ias['known_contribution']+D('.25')*b['capped_bound'][1]+10*other_missing]
    else:
        ias['dependency_aware_bound']=ias['mathematical_bound']
    return results

def financials(f):
    annual={r['year']:r for r in f['financial_years']}
    restated={r['year']:r for r in f['restated_years']}
    v=lambda y,key:D(annual[y][key])
    out={}
    out['revenue_cagr_5y']=(v(2026,'revenue')/v(2021,'revenue'))**(D(1)/5)-1
    out['revenue_cagr_3y']=(v(2026,'revenue')/v(2023,'revenue'))**(D(1)/3)-1
    out['annual_revenue_additions']={str(year):v(year,'revenue')-v(year-1,'revenue') for year in range(2022,2027)}
    out['annual_revenue_yoy']={str(year):v(year,'revenue')/v(year-1,'revenue')-1 for year in range(2022,2027)}
    for label,records in [('original',annual),('restated',restated)]:
        out[label+'_ebit']={str(year):D(r['pbt'])+D(r['finance'])-D(r['other_income']) for year,r in records.items()}
        out[label+'_ebitda']={str(year):out[label+'_ebit'][str(year)]+D(r['da']) for year,r in records.items()}
    out['cash_conversion']={}
    for label,records,years in [('original_3y_FY24_FY26',annual,[2024,2025,2026]),('original_5y_FY22_FY26',annual,[2022,2023,2024,2025,2026]),('original_latest2y',annual,[2025,2026]),('restated_3y_FY23_FY25',restated,[2023,2024,2025])]:
        cfo=sum(D(records[year]['cfo']) for year in years)
        pat=sum(D(records[year]['pat_total']) for year in years)
        out['cash_conversion'][label]={'cfo_sum':cfo,'pat_sum':pat,'ratio':cfo/pat}
    out['fy26_cfo_pat']=v(2026,'cfo')/v(2026,'pat_total')
    out['fy26_fcf_reported']=v(2026,'cfo')-v(2026,'capex_cash_gross')
    out['fy26_cash_after_capex_and_finance']=out['fy26_fcf_reported']-v(2026,'finance')
    out['fy26_operating_margin']=out['original_ebit']['2026']/v(2026,'revenue')
    out['fy26_ebitda_margin']=out['original_ebitda']['2026']/v(2026,'revenue')
    out['fy25_restated_ebitda_margin']=out['restated_ebitda']['2025']/D(restated[2025]['revenue'])
    out['fy26_ebit_growth_vs_fy25_original']=out['original_ebit']['2026']/out['original_ebit']['2025']-1
    out['fy26_ebit_growth_vs_fy25_restated']=out['original_ebit']['2026']/out['restated_ebit']['2025']-1
    out['fy26_pat_growth_vs_fy25_original']=v(2026,'pat_total')/v(2025,'pat_total')-1
    out['fy26_pat_growth_vs_fy25_restated']=v(2026,'pat_total')/D(restated[2025]['pat_total'])-1
    out['fy26_normalized_pat_25pct_tax']=(out['original_ebit']['2026']-v(2026,'finance'))*D('.75')
    out['fy26_effective_book_tax_rate']=(v(2026,'pbt')-v(2026,'pat_total'))/v(2026,'pbt')
    out['receivable_days_total_sales_proxy']={str(year):(v(year,'ar')+v(year-1,'ar'))/2/v(year,'revenue')*365 for year in range(2022,2027)}
    out['fy26_roe_average_book']=v(2026,'pat_total')/((v(2026,'equity')+v(2025,'equity'))/2)
    out['fy26_reported_pat_per_current_share']=v(2026,'pat_total')*100000/D(5658400)
    out['fy26_normalized_pat_per_current_share']=out['fy26_normalized_pat_25pct_tax']*100000/D(5658400)
    return out

def peers(p):
    results=[]
    for record in p['peers']:
        c={key:D(value)/D(record['divisor_to_crore']) for key,value in record['raw'].items()}
        eb=c['PBT']+c['finance_cost']+c['DA']-c['other_income']
        prior_eb=c['prior_PBT']+c['prior_finance_cost']+c['prior_DA']-c['prior_other_income']
        calc={'revenue_yoy_pct':(c['revenue']/c['prior_revenue']-1)*100,'PAT_yoy_pct':(c['PAT']/c['prior_PAT']-1)*100,'operating_EBITDA_crore':eb,'prior_operating_EBITDA_crore':prior_eb,'operating_EBITDA_margin_pct':eb/c['revenue']*100,'prior_operating_EBITDA_margin_pct':prior_eb/c['prior_revenue']*100,'CFO_PAT_latest':c['CFO']/c['PAT'],'CFO_PAT_2Y_ratio_of_sums':(c['CFO']+c['prior_CFO'])/(c['PAT']+c['prior_PAT']),'reported_FCF_proxy_crore':c['CFO']-c['cash_capex']}
        if 'closing_receivables' in c:
            calc['average_receivable_days_sales_proxy']=(c['closing_receivables']+c['opening_receivables'])/2/c['revenue']*365
        elif 'receivables_turnover' in record.get('reported_ratios',{}):
            calc['average_receivable_days_from_reported_turnover']=365/D(record['reported_ratios']['receivables_turnover'])
        results.append({'company':record['company'],'crore':c,'derived':calc})
    return results
