"""Explicit source-safe allowlist. Creates only local archives, never uploads or publishes."""
from pathlib import Path
import json,hashlib,zipfile
import build
P=Path(__file__).resolve().parent
EXTRAS=['producer_attestation.json','independent_replay_results.json','recovery_attestation.json','independent_review.md','independent_attestation.json','package.py','PACKAGING.md','verification/independent_audit_source_review.json','verification/source_hash_review.json','verification/review_issues.json','verification/reader_structure_review.json']
def sha(b):return hashlib.sha256(b).hexdigest()
def main():
 names=sorted(set(build.INPUTS+build.OUTPUTS+EXTRAS))
 for n in names:
  assert(P/n).is_file(),n
  assert not any(t in n for t in ['__pycache__','financial_research/','business_research/','sources/','library_','fetch_'])
  assert not n.endswith(('.pdf','.png','.jpg','.txt','.pyc','.html.raw'))
 manifest={'format':'source-safe authored research archive v1','company':'Shining Tools Limited','sequence':365,'file_count':len(names),'files':{n:{'sha256':sha((P/n).read_bytes()),'bytes':(P/n).stat().st_size}for n in names},'policy':'Both archives contain identical authored inputs, outputs, retained trials and independent/producer attestations. No raw PDFs, OCR, screenshots, raw website pages, private helpers or secrets. Exact original URLs and hashes retained.'}
 (P/'archive_manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,sort_keys=True,indent=2)+'\n');out=[]
 for kind,method in [('compact',zipfile.ZIP_DEFLATED),('full',zipfile.ZIP_STORED)]:
  path=P/f'SME_365_Shining_Tools_20261020_source_safe_{kind}.zip'
  with zipfile.ZipFile(path,'w',compression=method,compresslevel=9 if method==zipfile.ZIP_DEFLATED else None)as z:
   for n in sorted(names+['archive_manifest.json']):
    info=zipfile.ZipInfo('shining_tools/'+n,(2026,10,20,0,0,0));info.compress_type=method;info.external_attr=0o100644<<16;z.writestr(info,(P/n).read_bytes(),compresslevel=9 if method==zipfile.ZIP_DEFLATED else None)
  with zipfile.ZipFile(path)as z:
   assert z.testzip()is None
   for n in names:assert sha(z.read('shining_tools/'+n))==manifest['files'][n]['sha256']
  out.append({'kind':kind,'filename':path.name,'bytes':path.stat().st_size,'sha256':sha(path.read_bytes()),'entries':len(names)+1})
 (P/'archive_identities.json').write_text(json.dumps(out,sort_keys=True,indent=2)+'\n');print(json.dumps(out,indent=2))
if __name__=='__main__':main()
