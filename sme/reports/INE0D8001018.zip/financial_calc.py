"""Reproduce authored financial diagnostics. Decimal inputs are INR lakh, not crore."""
import json
from pathlib import Path
from decimal import Decimal as D, getcontext
getcontext().prec=40
p=Path(__file__).resolve().parent
f=json.loads((p/'financial_inputs.json').read_text())
y={r['year']:r for r in f['financial_years']}; r={x['year']:x for x in f['restated_years']}
v=lambda row,k:D(row[k])
s=lambda n:format(n,'f')
a={}
a['revenue_cagr_5y']=s((v(y[2026],'revenue')/v(y[2021],'revenue'))**(D(1)/5)-1)
a['revenue_cagr_3y']=s((v(y[2026],'revenue')/v(y[2023],'revenue'))**(D(1)/3)-1)
a['annual_revenue_additions']={str(t):s(v(y[t],'revenue')-v(y[t-1],'revenue')) for t in range(2022,2027)}
a['annual_revenue_yoy']={str(t):s(v(y[t],'revenue')/v(y[t-1],'revenue')-1) for t in range(2022,2027)}
a['original_ebit']={str(t):s(v(z,'pbt')+v(z,'finance')-v(z,'other_income')) for t,z in y.items()}
a['original_ebitda']={str(t):s(D(a['original_ebit'][str(t)])+v(z,'da')) for t,z in y.items()}
a['restated_ebit']={str(t):s(v(z,'pbt')+v(z,'finance')-v(z,'other_income')) for t,z in r.items()}
a['restated_ebitda']={str(t):s(D(a['restated_ebit'][str(t)])+v(z,'da')) for t,z in r.items()}
a['fy26_operating_margin']=s(D(a['original_ebit']['2026'])/v(y[2026],'revenue'))
a['fy26_ebitda_margin']=s(D(a['original_ebitda']['2026'])/v(y[2026],'revenue'))
a['fy25_restated_ebitda_margin']=s(D(a['restated_ebitda']['2025'])/v(r[2025],'revenue'))
a['fy26_ebit_growth_vs_fy25_original']=s(D(a['original_ebit']['2026'])/D(a['original_ebit']['2025'])-1)
a['fy26_ebit_growth_vs_fy25_restated']=s(D(a['original_ebit']['2026'])/D(a['restated_ebit']['2025'])-1)
a['fy26_pat_growth_vs_fy25_original']=s(v(y[2026],'pat_total')/v(y[2025],'pat_total')-1)
a['fy26_pat_growth_vs_fy25_restated']=s(v(y[2026],'pat_total')/v(r[2025],'pat_total')-1)
a['cash_conversion']={}
for name,data,years in [('original_3y_FY24_FY26',y,range(2024,2027)),('original_5y_FY22_FY26',y,range(2022,2027)),('original_latest2y',y,range(2025,2027)),('restated_3y_FY23_FY25',r,range(2023,2026))]:
 c=sum(v(data[t],'cfo') for t in years);q=sum(v(data[t],'pat_total') for t in years);a['cash_conversion'][name]={'cfo_sum':s(c),'pat_sum':s(q),'ratio':s(c/q),'limitation':'Original versus restated flow groupings differ; never mix the vintages without explicit bridge. Prior tiny profits inflate five-year ratio.'}
a['fy26_cfo_pat']=s(v(y[2026],'cfo')/v(y[2026],'pat_total'))
a['fy26_fcf_reported']=s(v(y[2026],'cfo')-v(y[2026],'capex_cash_gross'))
a['fy26_cash_after_capex_and_finance']=s(v(y[2026],'cfo')-v(y[2026],'capex_cash_gross')-v(y[2026],'finance'))
a['fy26_net_debt_available_cash']=s(D('629.60')-D('10.53'))
a['fy26_net_debt_ebitda']=s(D(a['fy26_net_debt_available_cash'])/D(a['original_ebitda']['2026']))
a['fy26_ebit_finance_coverage']=s(D(a['original_ebit']['2026'])/v(y[2026],'finance'))
a['fy26_effective_book_tax_rate']=s((v(y[2026],'pbt')-v(y[2026],'pat_total'))/v(y[2026],'pbt'))
a['fy26_normalized_pat_25pct_tax']=s((D(a['original_ebit']['2026'])-v(y[2026],'finance'))*D('.75'))
a['receivable_days_total_sales_proxy']={str(t):s((v(y[t],'ar')+v(y[t-1],'ar'))/2/v(y[t],'revenue')*365) for t in range(2022,2027)}
a['fy26_receivables_over6months_share']=s((D('64.44')+D('11.46')+D('59.61'))/D('674.25'))
a['fy26_receivables_over1year_share']=s((D('11.46')+D('59.61'))/D('674.25'))
a['fy26_payables_over1year_share']=s((D('43.39')+D('5.01'))/D('152.41'))
# Compatible current annual cost of production proxy; includes material and direct consumables net of FG change.
cost26=D('1019.93')-D('187.98');cost25=D('642.13')-D('53.93')
a['fy26_inventory_days_cost_proxy']=s((D('574.47')+D('380.10'))/2/cost26*365)
a['fy25_inventory_days_cost_proxy']=s((D('380.10')+D('298.53579'))/2/cost25*365)
a['fy26_payable_days_purchases_proxy']=s((D('152.41')+D('133.21'))/2/(D('621.23')+D('405.10'))*365)
a['fy26_cash_conversion_cycle_proxy']=s(D(a['receivable_days_total_sales_proxy']['2026'])+D(a['fy26_inventory_days_cost_proxy'])-D(a['fy26_payable_days_purchases_proxy']))
a['day_proxy_caveat']='Total sales proxy for credit revenue; inventory cost denominator excludes staff/other indirect expenses, payables purchases plus direct consumables are not proven all credit purchases. Never present as audited CCC.'
a['fy26_core_onwc_increase']=s(D('1354.81')-D('905.50'))
a['fy26_core_ic_increase']=s(D('3106.96')-D('1617.45'))
a['fy26_core_roic_25pcttax']=s(D(a['original_ebit']['2026'])*D('.75')/((D('3106.96')+D('1617.45'))/2))
a['fy26_incremental_core_ic_proxy_originalbase']=s((D(a['original_ebit']['2026'])-D(a['original_ebit']['2025']))*D('.75')/D(a['fy26_core_ic_increase']))
a['fy26_incremental_core_ic_proxy_restatedearnings_only_sensitivity']=s((D(a['original_ebit']['2026'])-D(a['restated_ebit']['2025']))*D('.75')/D(a['fy26_core_ic_increase']))
a['incremental_ic_caveat']='One-year early deployment proxy, not project IRR; FY25 restated sensitivity changes earnings only and is explicitly not a fully restated capital cohort. Full 3Y/5Y project-comparable IC cannot be certified due historical grouping, supplier/business advance differences and new capacity timing.'
# Broad financing-side invested-capital proxies retain heterogeneous operating assets.
a['financing_ic_proxy']={str(t):s(v(z,'equity')+v(z,'debt_long')+v(z,'debt_short')-v(z,'cash')-v(z,'dta')-v(z,'investments')) for t,z in y.items()}
a['incremental_financing_ic_proxy']={}
for start in (2021,2023):
    numerator=(D(a['original_ebit']['2026'])-D(a['original_ebit'][str(start)]))*D('.75')
    denominator=D(a['financing_ic_proxy']['2026'])-D(a['financing_ic_proxy'][str(start)])
    a['incremental_financing_ic_proxy'][str(2026-start)+'y']={'start':start,'end':2026,'delta_nopat_lakh':s(numerator),'delta_ic_lakh':s(denominator),'ratio':s(numerator/denominator),'limitations':'Broad financing-side proxy using equity plus interest-bearing debt less cash, deferred tax assets and disclosed investments. Includes unclassified advances; supplier-credit and operating-liability classifications require reconciliation. Rent-to-ownership changes and IPO asset timing mean this is not the return on new machines.'}
a['fy26_roe_average_book']=s(v(y[2026],'pat_total')/((v(y[2026],'equity')+v(y[2025],'equity'))/2))
a['h2fy26_revenue_yoy']=s(D('1028.93')/D('939.48')-1)
a['h1fy26_revenue_yoy_implied_base']=s(D('800.56')/D('533.40')-1)
a['h2fy26_pbt_yoy']=s(D('205.14')/D('246.73')-1)
a['fy26_reported_pat_per_current_share']=s(v(y[2026],'pat_total')*100000/D('5658400'))
a['fy26_normalized_pat_per_current_share']=s(D(a['fy26_normalized_pat_25pct_tax'])*100000/D('5658400'))
a['fy26_promoter_percent']=s(D(3998498)/D(5658400)*100)
(p/'financial_metrics.json').write_text(json.dumps(a,indent=2)+'\n')
print(json.dumps(a,indent=2))
