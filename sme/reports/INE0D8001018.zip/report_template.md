# Shining Tools Limited | SME research 365

Information cutoff: 20 October 2026. Market reference: 19 October 2026. Master Prompt v3.0. INR crore unless noted. GQS means Growth Quality Score.

## 1. Executive Verdict

Shining Tools manufactures TIXNA solid-carbide cutting tools and reconditions used tools. The useful strength is real industrial revenue expansion, with five-year audited operating-revenue CAGR of 18.12%, technical customization and an IPO-funded equipment program. The decisive uncertainty is whether that new capital can turn into collected, per-share earnings: current commissioned throughput is not established, working capital absorbed cash, original and IPO-restated profits require different comparisons, and current bank availability is unverified. At the secondary-corroborated ₹ 180 close, the business is approximately 32.6× normalized earnings, not an obvious cash-supported bargain. This is a small industrial reinvestment/special-situation research watch, not an evidence-backed compounder. BQS, GQS and IAS remain NS for specified missing factors, not a disguised low score. Reconciled commissioning, capital returns, current funding and executable market data could change that conclusion. No observed default or fraud is established. [AR26 PDF 68–70,85–95; Prospectus PDF 108–109,134–135,288; MKT_IIFL]

## 2. Research Header, Gates and Data Confidence

{{HEADER}}

The original list had “Shining Tools”, ISIN INE0D8001018 and a null symbol with listing verification pending. Those fields are preserved unchanged. The issuer's May 2026 BSE filing names SHTL / 544607; BSE's 14 November 2025 release confirms SME listing. The official 19 October interoperability master is metadata for the BSE-only security, not evidence of an NSE listing or a trade. Its SHTL$ symbol must not replace the BSE symbol silently. [Results26 PDF 1; AR26 PDF 2,22; MKT_INTEROP]

Historical audited scope is standalone Indian GAAP Accounting Standards, not Ind AS. September 2026 subsidiary and August management-change leads are separately qualified in the business supplement; no subsidiary profit, cash or NCI is invented. Fiscal 2026 is the latest verified full year. September 2026 results were not located by the information cutoff, and no later TTM or quarterly CFO has been manufactured. The April–July 2025 IPO stub is four months despite occasional document wording of five; it is not annualized. [AR26 policies; Results26; Prospectus]

{{GATES}}

{{CONFIDENCE}}

“Clear” would mean no obstacle found, not a guarantee. Here current funding and implementation are unresolved. The historical financial disclosures are usable with explicit bridges; neither a clean main audit nor a resolved legal contravention erases other weaknesses. Overall confidence in a current investment conclusion is Low because its weakest material inputs are current funding/capital returns and execution data.

## 3. Scorecard and Calculation Audit

{{SCORES}}

{{FACTORS}}

Factors are integer judgments assigned once and reused. Exact Decimal arithmetic, original weights and half-up one-decimal display are used; missing weights are not redistributed. Bounds are mathematical missing-data bounds, not confidence intervals or ranked estimates. BQS uses GOV 20%, MOAT 20%, REV 12%, DUR 10%, CAP 12%, CASH 10%, BAL 8%, EXEC 8%. GQS uses REV 40%, DUR 20%, EARN 15%, CAP 15%, CASH 10%. IAS uses final BQS25%, R 35%, D 20%, P 10%, L 10%. No disclosed override is triggered: current severe governance failure, evidenced funding failure or persistent CAP/CASH≤3 are not established. NS remains NS.

The preselected growth window is the available six-observation FY2021–FY2026 series, not whichever CAGR scores best. The 18.12% CAGR starts REV at 7, without a trajectory uplift. Moving uncertain GOV and CASH by one point changes BQS's known contribution by up to 0.30 and GQS by 0.10, but does not cure missing CAP/BAL. Nearby scores would not justify spurious ranking precision.

## 4. Business Overview

The company operates a Rajkot-region manufacturing unit making end mills, drills, ballnose, thread mills, reamers and customized solid-carbide tools; it also regrinds, sharpens and recoats used tools. Custom orders depend on drawings, application knowledge and approval. The prospectus describes standard-tool delivery around 8–10 days and custom-tool lead time around 1–3 weeks, not long-duration committed backlog. Coating is outsourced to named specialist vendors rather than owned in-house. Goods revenue is recognized on transfer of risks/rewards and service income upon completion. Collections, not dispatch alone, ultimately fund growth. [ST-PROS printed 164–167/PDF 169–172; AR26 policy PDF 73]

FY2026 product revenue was₹ 15.4717 crore and service revenue₹ 2.8232 crore, compared with₹ 11.8372 crore/₹ 2.8916 crore in FY2025. Products supplied all of the net revenue increase: +₹ 3.6345 crore less₹ 0.0684 crore lower services. The recurring service stream is useful but declined 2.37%; it is not automatically a growing installed-base annuity. Gujarat contributed 92.68% of FY2025 revenue. Named aerospace, defence, automotive, medical and other end markets are claimed application categories, not a disclosed sales-mix allocation. [AR26 PDF 85; ST-PROS PDF 166–167]

## 5. Moat / Industry Position

Mechanism → evidence → durability → failure: custom design/application knowledge and repeat sharpening can reduce a customer's incentive to switch; the company has actual product/service sales and technical process experience. But no verified switching-cost duration, protected market share or broad price premium is disclosed. Customers can switch to larger specialist suppliers or rival local vendors, and the company's 92.68% Gujarat concentration limits proof of national distribution. The top customer represented 19.85% and top 10 56.91% of FY2025 operating revenue; no long-term agreements guarantee retention. These percentages use total operations despite a misleading “product sales” footnote. [ST-PROS customer table and business chapter]

Selected invoice samples show price increases between FY2023 and FY2025, and the purchase of previously rented machinery removed approximately₹ 1.55 crore annual rent. Both support real improvement. Selected invoices do not establish market-wide pricing power, while rent-to-ownership substitutes depreciation/capital commitments for operating rent. A capex decision cannot be counted once as a moat and again as unexplained organic profit growth. [ST-PROS printed 244–245/PDF 249–250; audit supplement]

{{PEERS}}

The peer comparison uses economically relevant carbide/cutting-tool, high-speed-tool and superabrasive businesses, not unrelated companies containing “Tools” in their names. Kennametal has superior scale/technology access but weak latest cash realization from inventory growth; Forbes Precision/TOTEM is a closer cutting-tool benchmark; Birla Precision illustrates weaker margins and normalization complexity; Wendt offers a specialist precision/superabrasive comparison with a different mix. Fiscal dates, scope, leases and other income are explicit in peer_inputs.json and peer_research.md. Two-year cash conversion is a ratio of sums, not an average of ratios. No same-date peer valuation premium is invented.

## 6. Revenue Growth & Scale

{{CAGR}}

{{GROWTH}}

Ten-year CAGR is ND because eleven comparable observations were not located. Five-year growth is real but includes pandemic-base context, product mix and pricing. The FY2023–2025 disclosed physical record shows new-tool production 33,245→29,510→39,346 and reconditioning 61,394→56,956→72,825. Production is not verified sold volume, so revenue/production is only a mixed-product realization proxy. The sequence demonstrates a FY2024 volume dip despite broadly flat revenue, then a FY2025 recovery; it is not uniform volume compounding. [ST-PROS PDF 134–135,167]

H1 FY2026 operating revenue₹ 8.0056 crore compares with an implied prior H1₹ 5.3340 crore (+50.09%); H2₹ 10.2893 crore compares with₹ 9.3948 crore (+9.52%). H2 PBT fell 16.86%, while PAT benefited from net tax credits. H2 is audited annual minus unaudited first-half balancing data, not an independently complete new annual period. This slows the case for extrapolating the 24.21% full-year growth rate. No positive REV trajectory adjustment is warranted. [Results26 PDF 6]

## 7. Growth Quality & Reinvestment Runway

The certified base is five grinding machines, annual allocation 45,000 new tools and 80,000 reconditioning jobs. The IPO plan buys six machines plus auxiliaries, adding 54,000 tools and 96,000 jobs, for 99,000/176,000 at eleven machines. It is incorrect to call all 275,000 “new tools”, or to begin with eleven machines and add six again. New tools and reconditioning share machinery time; quoted category capacities are not independent guarantees at every product mix. [ST-CE PDF 4, visually checked; ST-PROS PDF 108–109]

Holding FY2025 proxy realizations constant, full use of old allocated capacity gives₹ 16.7147 crore annual revenue and the complete proposed plan₹ 36.7723 crore. This is a physical consistency check, not a sales forecast. FY2026 revenue exceeding the old proxy ceiling can reflect mix/prices or new machines; it cannot prove exact commissioning. Management says utilization exceeds 90% without a current denominator. The report describes two imported-machine purchases; capitalization and₹ 8.8870 crore machinery-object spending do not prove all six machines were revenue-generating. Actual FY2026 output by product remains ND. [AR26 PDF 43–48; ST-PROS; business supplement]

The quoted six-machine program is₹ 9.0653 crore, with imported ANCA equipment and auxiliaries, exposed to exchange rate, installation, qualification and customer demand. Capital advances₹ 3.93 crore remain at March 2026. Repeated expansion in the model must pay whole machine blocks, sustain working capital, observe lead times and retain replacement capital. Margin expansion from old rented assets cannot establish the return on new machines. CAP is NS until a commissioned cohort and investment/cash bridge exist; therefore GQS cannot be a numeric growth endorsement.

## 8. Management, Governance & Execution

Five Ghonia-family promoters held approximately 70.66% after IPO; concentration is control evidence, not automatically alignment or abuse. The company disclosed related-party purchases, repayments and remuneration. FY2026 purchases from Shree Industries₹ 0.8487 crore, outstanding₹ 0.1683 crore, director remuneration₹ 0.2400 crore, sitting fees₹ 0.1370 crore and additional CFO-director salary₹ 0.0598 crore should be assessed against PAT and cash, without assuming that every commercial related-party transaction leaks cash. Market terms were not independently benchmarked. [AR26 PDF 78–79,90–92]

Historical section 185 loans were a real compliance breach. The annual report says₹ 4.1569415 crore was fully recovered by 31 March 2024. The prospectus describes a 13 May 2025 penalty/compounding order; the annual report distinguishes an interim direction on 13 May and a final 17 June 2025 order. The₹ 30 lakh total was₹ 6 lakh each for the company and four applicants, not₹ 30 lakh company expense. Preserve the chronology discrepancy while recognizing repayment and paid compounding. No outstanding diversion is inferred from a settled historical matter. [Prospectus PDF 45–46; AR26 PDF 37–38; FY23/FY24 CARO]

The main statutory opinions and IFC opinions are unmodified/clean. Separate CARO and statutory observations include irregular statutory dues and audit-trail issues. FY2024–2025 application-level operation was deficient; FY2026 application logs reportedly operated throughout, but database-layer assurance remains unavailable. The board calls these observations “qualifications”, although the main opinion is unmodified. Late MGT-14, MSME-I, MGT-7 and AOC-4 filings are disclosed as completed; they should not be presented as still pending. The earlier auditor resignation said no concerns. These are mixed stewardship findings, not a categorical clean bill or an allegation of fraud. [Original audit vintages; AR26 PDF 33–35,44,54–67]

{{EXECUTION}}

Execution is scored 5, mixed. The sales forecast miss is documented, but absence of commissioning detail is a gap, not another proven missed deadline. Positive actual growth and substantially deployed/no-deviation IPO proceeds are contrary evidence. Latest management/subsidiary/export leads and their access limitations are recorded in the business supplement, not silently omitted or treated as verified cash flows.

## 9. Financial Forensics

{{HISTORY}}

The main history uses each original annual vintage; the IPO-restated FY2023–2025 series is separately preserved. Original FY2022–2023 units were thousands, FY2024 rupees and FY2025–2026 lakhs; all calculations convert explicitly. Fiscal 2021 is an audited comparative, not a separately retrieved original annual report, and CFO remains ND. No consolidated/standalone or restated/original series is silently spliced. Cash capex, not depreciation, determines reported FCF; interest is classified in financing.

{{RECONCILIATIONS}}

FY2025 original PAT₹ 1.7954 crore plus gratuity₹ 0.0748 crore, lower depreciation₹ 1.0884 crore, income-tax₹ 0.0604 crore and deferred-tax−₹ 0.0889 crore yields restated₹ 2.9301 crore. The disclosed bridge resolves that number, not the question whether later statutory useful lives and capital carry-forward fully match the IPO presentation. FY2024 PAT was restated downward and FY2023 turned to a small loss. Keep both sides. FY2026 PAT growth is 116.68% on the original comparator but 32.77% on restated profit. Normalized FY2026 PAT is₹ 3.125175 crore after removing all₹ 0.4092 crore other income and using 25% operating tax; no deferred-tax credit is extrapolated. [Restated PDF 12; AR26 PDF 69,86–88]

Fresh IPO shares increased issued equity from 4,158,400 to 5,658,400, a 36.07% increase. FY2026 reported EPS₹ 8.23 uses weighted-average 4,725,523 shares; current-share reported earnings are approximately₹ 6.88, not₹ 8.23. Comparing restated FY2025 PAT per pre-IPO issued share with FY2026 PAT per current issued share shows roughly flat/slightly lower per-share earnings despite higher company profit. The earlier 1:1 bonus was not economic dilution; preferential and IPO shares were. Potential later claims remain a verification item, not an invented zero. [AR26 PDF 78–79,89,94]

{{CASH}}

FY2026 cash quality deteriorated: receivables₹ 6.7425 crore, inventory₹ 5.7447 crore, supplier advances₹ 2.7364 crore and government balances₹ 1.3353 crore absorbed funds. Finished goods rose to₹ 4.6449 crore. Receivables older than one year total₹ 0.7107 crore, including₹ 0.5961 crore aged two to three years; disclosed doubtful balances are zero, not proof every old balance will collect. Approximately₹ 0.4840 crore payables are older than a year. These require subsequent receipts/stock-ageing and settlement checks. [AR26 PDF 82–85]

{{WORKING}}

Reported CFO₹ 1.0287 crore includes₹ 0.5464 crore additional capital creditors within other-liability cash movement while the investing line uses full additions. Reclassifying that amount gives operating-CFO sensitivity₹ 0.4823 crore and cash-capex₹ 11.5228 crore, leaving FCF exactly−₹ 11.0405 crore. This is not exhaustively normalized CFO: capital-goods FX gain₹ 0.2830 crore and gratuity reversal₹ 0.0846 crore lack separately labelled cash-flow reversals and may be reflected in asset/liability movements. Do not subtract them twice. Cash capex explains weak FCF, not weak CFO. [AR26 PDF 70,80,86]

{{RETURNS}}

Core defined ONWC increased₹ 4.4931 crore; committed operating capital including advances rose₹ 14.8951 crore. Average-core-capital FY2026 ROIC proxy is 15.90%, but the one-year incremental proxy against the original profit base is only 5.94%, with a newly deployed cohort not mature. The broad 3 Y/5 Y financing proxies above include DTA within net assets and deduct only available cash; the financial supplement also shows 14.76%/15.89% using all cash and excluding DTA. Definitions, not a new economic conclusion, explain the difference. Neither is a project IRR. A reasoned 13–19% nominal INR capital-cost sensitivity brackets material cyclicality, scale and funding uncertainty; it is not automatically the 15% equity hurdle. [financial_inputs; financial_metrics; metrics]

March gross debt₹ 6.2960 crore is bank term₹ 3.1570 crore, working capital₹ 2.8312 crore and unsecured₹ 0.3078 crore. The₹ 1.7244 crore current-maturity classification does not reconcile to printed instalments totaling₹ 0.0438611 crore per month. Historical Canara CC sanction₹ 5 crore and July 2026 CRISIL rated CC₹ 3.7 crore are not live available-headroom confirmations. CRISIL B/Stable Issuer Not Cooperating reflects information limitations and excludes a forward-looking component; it is not a default rating. Proposed₹ 4.3 crore facilities are not cash. Auditors reported no bank default or material one-year solvency uncertainty at March 2026. [AR26 PDF 79; ST-CRISIL 26; Prospectus bank table]

IPO gross proceeds₹ 17.10 crore were allocated to machinery₹ 9.0653 crore, WC₹ 3.85 crore, general corporate₹ 2.4847 crore and IPO expenses₹ 1.70 crore. Used₹ 16.9217 crore leaves₹ 0.1783 crore restricted to machinery. The cash-flow net-equity line₹ 13.9822 crore also reflects₹ 1.4052 crore other capital expenses and₹ 0.0126 crore reserve writeoff; that is a classification bridge, not evidence all deductions were cash. Expenditure versus the₹ 1.70 crore original IPO-expense allocation remains worth clarifying. Cash on balance sheet₹ 0.2836 crore is not all free cash. [Deviation PDF 2–3; AR26 PDF 70,79,95]

## 10. Valuation & Market Expectations

{{MULTIPLES}}

These are qualified market-reference calculations, not live execution prices. March debt/cash are deliberately dated rather than falsely current. Historical Indian-GAAP lease/rental economics remain in operating costs; no undisclosed lease liability or off-balance-sheet debt is assumed. Equity claims, later subsidiary perimeter and actual current bank balances need confirmation. The normalized-PAT tax rate 25% differs slightly from the model's explicit 25.168% cash-tax assumption; neither extrapolates FY2026 deferred-tax benefits.

{{MAIN_CASES}}

The strict cases reuse March balance anchors as conditional October opening and do not assume unverified new funding. Their reserve shortfalls are therefore scenario diagnostics, not actual defaults. Month-one failure is not a forecast that the company would fail in November. The missing intervening cash bridge makes all paths source-ineligible. Ordinary IRRs/terminal prices are suppressed after failure rather than presented as if a rescue were assured.

{{FUNDED}}

Funded references explicitly assume access to historical CC headroom and, where required, a discounted whole-share raise within the stated authorization. The rating-table ceiling variant, no-equity/no-renewal alternatives, printed-maturity policy, delayed commissioning and higher equipment cost remain separate trials. A source-ineligible path that mathematically funds is not the supported base case used by R. Entry ranges at 12/15/18% are only assumption-dependent outputs and are not buy limits.

{{TERMINAL}}

Terminal FCFF is earned after cash tax, replacement, physical/working-capital investment and the economic-reinvestment floor. Another 12 monthly cash periods must fund without new borrowing/equity rescue. Funding reserve includes debt service; operating reserve separately removes financing/claim payments already deducted in EV-to-equity, avoiding double subtraction of debt-backed cash. Cash above the operating reserve enters the equity bridge; only cash above the full funding reserve could be distributed immediately. Restricted proceeds remain excluded. Detailed monthly debt, fees, maturities, whole shares, assets, pipeline, reserves and claims are reproducible in the full path file.

{{SENSITIVITY}}

The 1% entry and 1% exit implementation costs are illustrative, not measured spread/impact. Five-/ten-year returns are nominal before investor taxes and no dividend is counted twice. WACC and growth are separate from the equity hurdle. A terminal EBITDA-multiple cross-check uses the same equity bridge rather than hiding senior claims. The paths describe what assumptions require; they do not establish current fair value or a probability-weighted forecast.

## 11. Bear Case & Permanent-Loss Path

The strongest bear case is that product/mix growth and the IPO capacity story outrun collections. A large customer's loss lowers grinder utilization and spreads fixed expense over less revenue; old receivables and finished goods fail to release cash; supplier advances and GST balances stay locked; promised new equipment requires installation/qualification or further working capital; and banks do not offer the historical headroom. Shareholders then face expensive debt, discounted issuance or forgone orders. At a 32.6× normalized-earnings reference, slow growth can also compress the valuation without any insolvency.

The key falsification variable is collected operating cash relative to committed capital, not a single quarterly profit headline. Evidence against the bear interpretation is important: five-year original cash conversion is positive, the earlier restated three-year ratio is strong, rent removal improved real costs, IPO proceeds funded assets, leverage relative to core EBITDA is below 1×, and auditors found no default. Those facts prevent calling the business distressed on current evidence. They do not verify present cash availability or mature project returns.

Capital impairment risk is High at the qualified price because the cash/capacity/funding variables fail together and market execution may be lumpy. Modeled downside is conditional; no liquidation recovery from book PPE, advances or inventory is promised. Research should move from Hold only after funding, capacity and implementation questions close. A narrow control flaw alone is not proof of fraud, and a price decline alone is not a change in BQS/GQS.

## 12. 5× / 10× Feasibility

{{TARGETS}}

The five-/ten-year tests are net investor wealth after the same execution costs, not revenue or enterprise-value multiples. For context,5× needs 37.97% annualized over 5 years or 17.46% over 10;10× needs 58.49% or 25.89%. The grids retain every attempted demand/margin/financing combination, including those failing before the terminal year. A missing crossing is bounded to these tested assumptions, not a mathematical impossibility.

The bounded envelope respects the stated share-authorization ceiling and a 30-machine physical cap; the expanded envelope explicitly assumes new share authorization, up to 100 machines, additional debt and a much wider customer base. Whole shares, issue discounts/fees, debt interest/maturity, growing working capital and terminal reinvestment dilute any stock return. High 42% EBITDA-margin cases and large expansion are ambitious assumptions against peer economics and Shining's current commissioning evidence. A funded 5× path, if present, is still speculative; no supported 10× claim is made. All 5×/10× conclusions are Speculative / unsupported until capacity access, unit economics and funding are evidenced.

## 13. Monitoring Plan

{{MONITORING}}

These are company-specific research checkpoints, not automatically created reminders. A threshold prompts investigation; only a verified severe governance, survival or permanent earning-power failure should automatically change the relevant gate. Current shareholder notices must be checked for subsidiary obligations, management changes, new funding and potential dilution before interpreting the next results.

## 14. Final Classification & Conditional Action

Classification: Hold — unresolved funding, incremental returns and implementation evidence. Action category: Research priority / watchlist pending evidence, not eligible for an affirmative new-purchase conclusion. BQS/GQS/IAS remain separately NS. The numeric classification matrix cannot be applied to missing aggregates; no low-NS record is placed at the bottom of a ranking as if it were proven poor. The compounder criteria are not met, and no portfolio allocation, exit instruction or trade is implied.

Closing the current cash/bank/maturity bridge, confirming installed and saleable throughput, proving incremental project cash returns and collecting primary 20/60-session execution data would allow reassessment. A lower quote alone would not cure CAP/BAL/L missingness or demonstrate governance improvement. Fresh information after 20 October 2026 is excluded from this record except for retrieving sources that were already public by the cutoff.

## 15. Sources, Assumptions & Open Questions

{{SOURCE_LEDGER}}

Material evidence classes: verified disclosures are original annuals, audited results, restated accounts, official offer document, engineer certificate, issuer order and rating rationale. Calculations are growth, cash ratios, return proxies, multiples and physical checks. Management statements include forecasts, utilization and intended commissioning. Analyst assumptions include every monthly forward demand, collection, margin, capex, refinancing, equity and terminal choice. Secondary historical prices and inaccessible-original corporate leads remain explicitly labelled, not upgraded to primary facts.

Open questions: loan-wise maturities and current sanctioned/drawn headroom; April–October cash and capital deployment; exact useful-life/carry-forward alignment between statutory and IPO-restated accounts; current commissioned machines and product-specific throughput; remaining purchase/qualification commitments; recovery of old receivables, business advances and GST assets; explanation of capital-raising expenses; source clarification for supplier-table maximum inconsistencies; subsidiary contribution/claims; updated ownership/encumbrance and primary market depth/restrictions. Missingness does not itself prove adverse conduct.

{{UPDATES}}

{{QUALITY}}

The archive includes authored inputs/code/outputs and both producer and independent attestations. It excludes source PDFs, OCR, raw pages, private helpers and secrets. The exact framework SHA, actual report SHA, company-record SHA and authored-input aggregate SHA are different roles and must not be substituted. Independent cold recovery from the current saved versions is a separate acceptance step. Mechanical PASS does not resolve the expressly disclosed investment-evidence gaps.
