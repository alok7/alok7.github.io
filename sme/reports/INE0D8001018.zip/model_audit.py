"""Producer algebraic audit. Independent replay is separately authored."""
from decimal import Decimal as D
Z=D(0)
def audit(x,i):
 checks=0
 def same(a,b,label):
  nonlocal checks
  if abs(D(a)-D(b))>D('1e-18')*max(D(1),abs(D(a)),abs(D(b))):raise AssertionError((x['path_id'],label,a,b))
  checks+=1
 s=x['spec'];prev=None
 for r in x['monthly']:
  same(r['cash_close'],r['cash_open']+r['collections']+r['ipo_release']-r['supplier_cash']-r['opex']-r['interest']-r['tax']-r['tax_claim_payment']-r['other_claim_payment']-r['bank_fees']-r['capex']-r['capital_credit_payment']-r['term_principal']-r['unsecured_principal']-r['wc_principal']-r['new_principal']-r['opa_movement']+r['wc_draw']+r['new_draw']-r['draw_fee']+r['equity_gross']-r['equity_fee'],'cash bridge')
  same(r['restricted_close'],r['restricted_open']-r['ipo_release'],'restricted cash bridge');assert r['ipo_release']<=r['ipo_capex'];checks+=1
  same(r['ar_close'],r['ar_open']+r['sales']-r['collections']-r['receivable_writeoff'],'receivables')
  same(r['inventory_close'],r['inventory_open']-r['inventory_impairment']+r['purchases']-r['material_cost'],'inventory')
  same(r['ap_close'],r['ap_open']+r['purchases']-r['supplier_cash'],'payables')
  same(r['opa_close'],r['opa_open']+r['opa_movement'],'other operating assets')
  same(r['ppe_close'],r['ppe_open']+r['commissioned_cost']+r['ipo_advanced_asset_commissioned']+r['ipo_capex']+r['maintenance_capex']-r['da'],'PPE bridge')
  same(r['pipeline_asset_close'],r['pipeline_asset_open']+r['growth_capex']-r['commissioned_cost']-r['ipo_advanced_asset_commissioned'],'paid pipeline bridge')
  same(r['debt_close'],r['debt_open']+r['wc_draw']+r['new_draw']-r['term_principal']-r['unsecured_principal']-r['wc_principal']-r['new_principal'],'debt bridge')
  same(r['shares_close'],r['shares_open']+r['issued_shares'],'share bridge');assert isinstance(r['issued_shares'],int)and r['issued_shares']>=0;checks+=1
  auth=int(s['expanded_authorized_shares'])if s['authorization_gate']else int(i['authorized_shares']);assert r['shares_close']<=auth;checks+=1
  same(r['equity_gross'],D(r['issued_shares'])*r['issue_price']/10000000,'gross share proceeds');same(r['equity_fee'],r['equity_gross']*D(s['equity_fee']),'equity fees')
  assert r['new_units']<=D(i['machine_capacity']['new_tools'])*r['machines']/12+D('1e-18');assert r['service_units']<=D(i['machine_capacity']['service_jobs'])*r['machines']/12+D('1e-18');checks+=2
  same(r['sales'],r['new_units']*r['new_price']+r['service_units']*r['service_price'],'physical revenue')
  same(r['ebitda'],r['sales']-r['material_cost']-r['opex'],'EBITDA');same(r['ebit'],r['ebitda']-r['da']-r['inventory_impairment']-r['receivable_writeoff'],'EBIT')
  if r['phase']=='terminal_transition':assert r['issued_shares']==0 and r['new_draw']==0 and r['wc_draw']==0;checks+=1
  if prev:
   same(r['cash_open'],prev['cash_close'],'cash continuity');same(r['debt_open'],prev['debt_close'],'debt continuity');same(r['shares_open'],prev['shares_close'],'shares continuity')
  prev=r
 if x['failure']:
  assert x['terminal']is None and x['summary']['irr']is None and x['summary']['terminal_price']is None and x['summary']['hurdle_entries']is None;checks+=1
 else:
  t=x['terminal'];same(t['fcff'],t['next_nopat']+t['next_da']-t['replacement_capex']-t['growth_reinvestment'],'earned terminal FCFF');assert t['replacement_capex']+D('1e-18')>=t['next_da'];checks+=1
  same(t['enterprise_value'],max(Z,t['fcff']/(D(s['wacc'])-D(s['terminal_growth']))),'terminal EV');same(t['equity_value'],max(Z,t['enterprise_value']+t['cash_for_equity_bridge']-t['debt']-t['senior_claims']),'equity bridge');same(t['price'],t['equity_value']*10000000/t['shares'],'terminal price')
  for a in t['transition']:assert a['cash_after_excess']+D('1e-18')>=a['reserve']and a['new_finance']==0;checks+=1
 return {'path_id':x['path_id'],'status':'PASS','checks':checks,'scope':'Producer algebra, not independent judgment or source eligibility'}
