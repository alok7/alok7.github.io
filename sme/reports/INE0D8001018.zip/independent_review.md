# Independent review: Shining Tools Limited, SME 365

The research is acceptable as a completed, evidence-limited dossier, not an affirmative investment recommendation. BQS, GQS and IAS remain NS. Current funding and implementation are unresolved, while original historical records remain usable with explicit vintage and accounting qualifications. No actual default or severe current diversion is established.

## Independent work

- Read the actual v3.0 framework and verified its required SHA256.
- Reviewed original audit, CARO, internal-control, restatement, annual-report, prospectus, capacity, rating and peer evidence. Nineteen original-file hashes match their authored source records. Selected critical source pages were visually inspected, including the prospectus capacity table and the original restatement bridge.
- Independently reconstructed all 166 current paths from raw model/scenario JSON, without importing the producer's model, scenario, score or metrics functions: 12,910 monthly rows, 1,098,508 monthly/annual/terminal/summary comparisons, plus 62 historical financial, 129 peer, 50 score and 70 hurdle/target comparisons. No mismatch remains.
- Separately reconstructed the retained initial 164 paths at their original Decimal precision: 12,706 monthly rows and 1,044,877 comparisons. They remain superseded, not support for current conclusions.
- Current modeling uses a declared Decimal precision of 40, whole-share issues, separately scheduled collection and payment cohorts, restricted-purpose cash, instrument-specific debt service, machine blocks and lead times, and a further cash-funded terminal transition. All 166 current paths remain source-ineligible; 102 are conditionally funded and 64 fail. Failed ordinary returns are suppressed.
- Independently checked the exact NS arithmetic: BQS coverage 80%, bound 4.54–6.34; GQS coverage 85%, bound 5.40–6.75; IAS coverage 30%, bound 1.90–8.20, with a dependency-aware bound of 2.785–7.285. Bounds are not point scores or confidence intervals.

## Material refinements retained

1. Terminal operating reserve and full financing-survival reserve are separate. Cash earmarked for debt service is no longer excluded and then deducted again through exit debt. Exact cash-tax differences are used in the unlevered bridge, and survival still requires no terminal rescue.
2. Product and service realization proxies now derive from exact cited FY25 revenue/production inputs. Their limited meaning as production-based proxies remains explicit.
3. Process-level Decimal dependence was removed. The initial precision-28 code and paths remain available rather than being overwritten.
4. Execution moved from 4 to 5: one sales forecast miss and unknown commissioning do not constitute two proven delivery failures. Positive growth and no-deviation deployment evidence are retained.
5. The IPO-restated FY25 profit bridge is explained, while FY26's use of the original comparative and capital carry-forward still limits comparability. These are different questions.
6. Compounding chronology distinguishes the annual report's 13 May interim direction and 17 June final order from the prospectus wording. The ₹30 lakh aggregate is not portrayed as entirely the company's cost.
7. The ₹0.4823 crore operating-CFO figure is a capital-creditor classification sensitivity, paired with the same capex adjustment. It is not exhaustively normalized CFO.
8. Prior 1.7756× restated cash conversion, unmodified main/IFC opinions, recovered old loans and improved application audit trails remain genuine contrary evidence.
9. Reader text corruption and a split ISIN were corrected. Volume-demand growth and post-transition machine counts are distinguished from realized revenue CAGR and horizon-exit capacity.
10. The replay CLI was corrected so successful invocation does not exit before the recovery guard writes its attestation. The earlier incomplete recovery attempt is not claimed as successful.

## Review limits

The final HTML passed structural checks for fifteen sections, consistent table columns, public source-link shape, intact identifiers and absence of unresolved template markers. Browser-rendered visual QA was not completed: Cloud Chromium failed at launch with a socket permission error and crashpad error, and produced no final-reader screenshot. Structural verification is not a substitute for desktop/mobile pixel review. Selected source-PDF visual checks do not establish full-document visual QA.

A primary executable BSE quote, complete 20/60-session liquidity history, current bank headroom, actual commissioning, mature project returns and complete subsequent subsidiary claims remain unavailable. These are expressly disclosed investment-evidence gaps, not arithmetic failures. The secondary ₹180 reference and conditional return grids must not be promoted to live investment recommendations.

The accompanying hash-bound attestation identifies the exact report, company record, canonical model, authored-input aggregate and replay receipt separately. Final archive acceptance additionally requires independently recovering the current saved compact and full versions into fresh inputs-only clones and reproducing all declared outputs. No publication is implied by this review.
