"""Scenario design and target selection. All variants are saved, never silently discarded."""
from decimal import Decimal as D
from copy import deepcopy
def base():
 return {'label':'Conditional core-business scenario; not a supported forecast','initial_machines':7,'pending_ipo_machines':4,'ipo_commission_month':6,'new_tool_price':'.0003008488791745031261119300564','service_price':'.00003970614486783384826639203570','new_volume_growth':'.15','service_volume_growth':'.05','price_growth':'.02','customer_loss':'0','capacity_buffer':'1.1','machine_capex_scale':'1','expansion_gate':True,'max_machines':30,'annual_machine_limit':4,'lead_months':6,'material_ratio':'.455','ebitda_margin':'.32','fixed_cost_fraction':'.5','inventory_days':'200','inventory_impairment':'0','inventory_impairment_month':3,'supplier_delay':2,'collection_delay':4,'opening_ar_months':6,'opening_ar_recovery':'1','opening_ap_months':3,'other_assets_growth_ratio':'.15','maintenance_ratio':'.03','replacement_rate':'.10','new_da_rate':'.15','tax_rate':'.25168','tax_settlement_month':12,'other_claim_months':3,'wc_rate':'.116','term_rate':'.105','unsecured_rate':'.12','new_debt_rate':'.14','maturity_policy':'reported_current','printed_instalment_monthly':'.0438611','unsecured_repayment_month':12,'wc_renewal':True,'wc_call_month':12,'annual_bank_fees':'.1238','minimum_cash':'.10','reserve_cost_months':'.25','existing_headroom_gate':False,'wc_limit':'5','new_debt_gate':False,'new_debt_limit':'0','cumulative_debt_limit':'0','new_debt_tenor':36,'new_debt_renewal_gate':False,'renewal_fee':'.01','draw_fee':'.015','equity_gate':False,'authorization_gate':False,'expanded_authorized_shares':10000000,'equity_last_month':48,'equity_discount':'.30','equity_fee':'.025','forced_equity_shares':0,'forced_equity_month':1,'tax_dispute_claim':'.3369','wacc':'.16','terminal_growth':'.04','terminal_roic':'.16','exit_multiple':'10','entry_cost':'.01','exit_cost':'.01'}
def specifications():
 out=[]
 def add(name,years,kind,**changes):
  s=base();s.update(changes);out.append({'path_id':name,'years':years,'kind':kind,'spec':s})
 for y in [5,10]:
  add(f'bear_{y}y',y,'main',label='Linked customer, ageing, margins and refinancing stress',new_volume_growth='0',service_volume_growth='-.05',customer_loss='.20',ebitda_margin='.24',inventory_days='250',collection_delay=6,opening_ar_recovery='.85',inventory_impairment='.10',initial_machines=5,pending_ipo_machines=6,ipo_commission_month=12,wc_renewal=False)
  add(f'base_{y}y',y,'main')
  add(f'bull_{y}y',y,'main',new_volume_growth='.25',service_volume_growth='.12',ebitda_margin='.36',inventory_days='160',collection_delay=3,initial_machines=11,pending_ipo_machines=0,ipo_commission_month=1)
  funded={'existing_headroom_gate':True,'equity_gate':True,'label':'Conditional funded reference: stale CC headroom and whole-share raise assumed; not authorization or source-eligible forecast'}
  add(f'funded_reference_{y}y',y,'funded_reference',**funded)
  add(f'funded_rating_limit_{y}y',y,'funding',**dict(funded,wc_limit='3.7',label='Conditional July2026 rating-table CC ceiling3.7cr, not sanctioned headroom; still funding-ineligible'))
  add(f'funded_printed_maturities_{y}y',y,'funding',**dict(funded,maturity_policy='printed_instalments'))
  add(f'funded_no_equity_{y}y',y,'funding',**dict(funded,equity_gate=False))
  add(f'funded_delayed_ipo_{y}y',y,'funding',**dict(funded,initial_machines=5,pending_ipo_machines=6,ipo_commission_month=12))
  add(f'funded_capex_inflation_{y}y',y,'funding',**dict(funded,machine_capex_scale='1.5'))
  add(f'funded_no_wc_renewal_{y}y',y,'funding',**dict(funded,wc_renewal=False,existing_headroom_gate=False))
  for w in ['.13','.16','.19']:
   for g in ['.02','.04','.06']:add(f'terminal_{y}y_w{w}_g{g}',y,'wacc_growth',**dict(funded,wacc=w,terminal_growth=g))
  for g in ['0','.10','.20','.30','.40']:
   for mar in ['.24','.30','.36']:add(f'growth_margin_{y}y_g{g}_m{mar}',y,'growth_margin',**dict(funded,new_volume_growth=g,ebitda_margin=mar))
  # A saved grid, not a falsely precise continuous threshold. All failed points remain retained.
  for pct in range(0,61,5):
   g=str(D(pct)/100);add(f'reverse_{y}y_g{g}',y,'reverse_hurdle',**dict(funded,new_volume_growth=g,service_volume_growth=g,max_machines=60,annual_machine_limit=8,authorization_gate=True,expanded_authorized_shares=12000000,equity_last_month=96))
  for fam,ceiling,auth,annual in [('bounded',30,6500000,4),('expanded',100,16000000,12)]:
   for g in ['.10','.20','.30','.40','.60','.80']:
    for mar in ['.30','.36','.42']:
     add(f'{fam}_multibagger_{y}y_g{g}_m{mar}',y,'multibagger',**dict(funded,label=f'{fam} funded multibagger stress envelope, no probability or forecast',new_volume_growth=g,service_volume_growth=g,ebitda_margin=mar,max_machines=ceiling,annual_machine_limit=annual,authorization_gate=fam=='expanded',expanded_authorized_shares=auth,equity_last_month=120,existing_headroom_gate=True,new_debt_gate=fam=='expanded',new_debt_limit='5',cumulative_debt_limit='10',new_debt_renewal_gate=False))
 return out

def targets(rows):
 out=[]
 for years in[5,10]:
  for target in['1.12','1.15','1.18','5','10']:
   hurdle=D(target)**years if D(target)<2 else D(target);candidates=[r for r in rows if r['years']==years and r['kind'] in ['reverse_hurdle','multibagger']and r['multiple_return']is not None];success=[r for r in candidates if D(r['multiple_return'])*D('.99')/D('1.01')>=hurdle];best=max(candidates,key=lambda x:D(x['multiple_return']))if candidates else None
   out.append({'years':years,'target':target,'interpretation':'annual return hurdle'if D(target)<2 else'net investor multiple','required_net_multiple':str(hurdle),'tested_funded_crossings':len(success),'least_growth_crossing':min(success,key=lambda x:(D(x['new_volume_growth']),D(x['margin'])))['path_id']if success else None,'best_funded_path':best['path_id']if best else None,'best_funded_net_multiple':D(best['multiple_return'])*D('.99')/D('1.01')if best else None,'status':'Scenario grid only; no source-eligible probability or expected return'})
 return out
