# Simca Advertising Limited — research dossier

Position **380** · ISIN **INE1K4J01018** · NSE Emerge **SIMCA** · Framework v3.0
Information cutoff **20 October 2026**; market reference **19 October 2026**. Research assembled 25 October using only cutoff-eligible evidence. INR crore unless specified. Not an instruction to trade.

## 1. Executive Verdict

**Hold — unresolved financial comparability; not an evidence-backed compounder.** Simca sells outdoor advertising space and execution, increasingly digital slots, mainly in Maharashtra. Rising digital inventory, repeat clients, new location rights and a largely equity-funded expansion are credible positives. They do not yet establish owned infrastructure economics or durable per-share cash compounding. The decisive issue is reconciling IPO-restated service-rendered revenue and equity with subsequent statutory accounts: ₹4.953 crore of FY25 equity difference is not explicitly bridged to FY26. At ₹421.05, the security capitalizes statutory FY26 earnings at about30.3x after IPO dilution; an illustrative modest-growth path produces well below the15% hurdle, but is not reliable enough for a numerical IAS. Financial-history reconciliation, collection evidence and commissioned-unit cash returns—not a higher asset-count press release—would change this assessment. Thesis type: early listed regional advertising expansion, with cyclical demand and execution risk. [S01 F13; S02; S03 PDFpp71,76,86; S10/S11]

## 2. Research Header, Gates and Data Confidence

Legal identity is Simca Advertising Limited, incorporated17June2022; do not transplant the older promoter enterprise's1970 brand legacy into audited corporate history. NSE security master confirms11,971,600 shares and600-share lot; traded19October close₹421.05, market capitalization₹504.0642 crore. Actual trading series isST. Some company letters sayEQ, which does not override exchange security/transaction evidence. Quote is not stale, but is not an executable offer. [S01 history; S03 p25; S10/S11]

Scope is **standalone Indian GAAP / Accounting Standards under Companies (Accounting Standards) Rules2021**, not Ind AS; no subsidiary/associate/JV at31March2026. FY26 audited results approved29May; July clarification fixes XBRL denomination, prescribed format and notes. Half-year reporting does not authorize invented quarterly cash flow. September2026 results released23October are **excluded**, along with current aggregator TTM/price data. Five-year scenarios20October2026–20October2031; nominal INR,15% investor hurdle before personal tax; independent discount sensitivities12/15/18%; illustrative₹5 lakh position. [S02 notes; S03 p25]

|Gate|Status|Evidence and release requirement|
|---|---|---|
|G1 integrity/minority protection|Conditional|Promoter site leases, filing delays and inconsistent RPT presentation require scrutiny; no substantiated severe diversion or minority abuse established. Obtain matched lease/arm's-length and AOC2 reconciliations.|
|G2 financial reliability|Hold — unresolved|RHP restated FY25 versus statutory FY26 opening/comparative equity and income differ materially. Need full AS5/recognition reconciliation, not just a generic regrouping note. IAS NS; quality ranking excluded while this affects critical factors.|
|G3 funding/survival|Conditional|Low statutory borrowings, IPO funds and positive CFO are counterevidence to distress. Actual October unrestricted cash and license obligations not reconciled; model gaps do not prove default.|
|G4 tradability|Conditional|60 sampled sessions traded;600-share lot andST trading impose implementation risk. No bid-depth/impact proof. Not suspended or proven effectively untradeable.|

Confidence: High on identity and dated trades; Medium on individual primary financial statements and reported operating inventory; Low on inter-vintage comparability, organic/real growth and normalized incremental returns; Low on October unrestricted liquidity/valuation anchor. Overall confidence for an investment conclusion is Low, not an average of those subjects.

## 3. Scorecard and Calculation Audit

{{SCORES}}

{{FACTORS}}

BQS weights: GOV20%, MOAT20%, REV12%, DUR10%, CAP12%, CASH10%, BAL8%, EXEC8%. GQS: REV40%, DUR20%, EARN15%, CAP15%, CASH10%. IAS: BQS25%, R35%, D20%, P10%, L10%. All weights sum100%; canonical shared factors are reused. Mathematical missing-data bounds assign missing factors1–10, never midpoint/renormalized score; IAS propagates BQS bounds. GOV/DUR together±1 shifts known BQS by±0.30, GQS±0.20 and IAS quality contribution±0.075; aggregate scores remain NS. No governance/funding override is asserted. CASH4 does not trigger the≤3 persistent-cash cap. Scores are policy judgments, not calibrated fraud/default probabilities. [scores.json; framework§8–10]

## 4. Business Overview

Space-selling was99.46% of restated FY25 revenue and99.58% in9M FY26; mounting/dismounting is a small remainder. The company arranges outdoor campaign locations, purchases media availability and sells advertiser campaigns; “mediatech” does not establish proprietary software or SaaS economics. Maharashtra contributed88.56% ofFY25/81.17% of9M FY26; advertising agencies63.27%/58.63%, real estate24.21%/27.32%. Typical campaigns last14days (7–21); agency credit30–60days and direct-client credit0–30days are stated commercial terms, not observed collection performance. [S01 pp164–167; B10,B13,B14]

Reported media inventory at December2025 was150 units:78 static plus72 digital units. **Each physical LED was counted as six advertising units**, implying12 LEDs under that convention—not150 owned sites. The company does not own the underlying media structures identified in the prospectus; promoter subleases cover29 physical sites represented by59 slot units. The July2025 promoter arrangement is₹0.90 crore/month. Site permits, renewal, location access and content slots are economically distinct from hardware ownership. Later reports call222 units “sites,” without reconciling the unit definition. [S01 pp29–30,164; S07; B11,B15]

## 5. Moat / Industry Position

Local advertiser/agency relationships and high-visibility locations can reduce sourcing friction; conversion to digital lets multiple campaigns share a screen. But short campaigns, substitutes, nontransferable site leases, renewals and larger rivals limit proven pricing power. Top10 customers were51.61% FY25 revenue and top10 vendors72.54% hoarding purchases. Unnamed customer identities limit relatedness verification; they do not prove connected sales. Physical inventory, sold slot-hours, realized price, rights duration and collections—not total advertising budgets—are the economic moat tests. [S01 risks/business; B13–B16]

|Peer and economic role|Primary comparison|Limits/counterevidence|
|---|---|---|
|Bright Outdoor Media, closest listed Mumbai OOH/DOOH benchmark|FY25 revenue₹126.7455, PAT₹19.0749; equity₹163.7436 from capital+reserves|Real-estate segment complicates margin comparison. RHP's₹6.09 equity/313.3%ROE contradict Bright's own filing and are rejected.|
|Signpost India, larger concession/network comparator|FY25 consolidated revenue₹453.2241, PAT₹33.9035; stated longer5–20year concessions|Debt/depreciation/capital intensity matter. RHP's₹33.7453 PAT is standalone, not same scope. Panel counts not comparable to Simca slots.|
|Alakh Advertising, direct private regional competitor|RHP identifies Mumbai/Nagpur network and agency relationships|FY25 audited financials unavailable; no invented multiple or ranking. Undated current website is only corroboration.|

Additional adjacent firms Minimax and CWM are not independent valuation observations; CWM is also a profit-sharing counterparty. See B24–B27 for exact primary URLs and locators. These peers establish contestable economics, not a justified premium multiple. No cross-company stock-price comparison is manufactured.

## 6. Revenue Growth & Scale

{{GROWTH}}

The3/5/10year CAGR requests are NS/ND rather than filled with misleading series: FY23 is a roughly9.5month incorporation stub; onlyFY24/FY25 are comparable full years within the RHP restatement; FY26 has an unresolved recognition bridge. FY24's₹37.3493 crore increase over the stub is disclosed but not called full-year organic growth. A single nominal CAGR would blend billing/service timing and different capital histories. [S01 F6–F13; S02]

DOOH mix rose23.00% FY25 to36.01% nine-monthFY26; the remainder was mostly traditional outdoor. Reported occupancy77.25%/77.96% is actual-sales/potential-sales—not physical utilization. Slot inventory rose, but price/volume/like-for-like yield, organic acquisitions and gross-versus-net agency procurement effects are not separately quantified. Gross billing includes media procurement costs; accounting policy and observed revenues do not prove every rupee is value-added activity. Underlying audience, impressions, physical screen counts and net take rate remain ND. [S01 p164; B11–B14]

July corrigendum reports approximate total Q1FY27 revenue₹42.6443 versus₹26.6792,59.84% growth. This is management's business update, not audited operating revenue or a basis to annualize one quarter. Original₹24.67 comparator is superseded. No Q1PAT/CFO is invented, and no post-cutoff September half is included. [S06]

## 7. Growth Quality & Reinvestment Runway

IPO objects were seven LED installations₹12.7188, CWM balance₹5, incremental working capital₹23.5 and GCP. Gross raise₹58.04 versus issue costs₹8.41 leaves₹49.63 net: a material14.5% gross-cost burden. ByJune30,₹0.45 LED and₹0.1545 GCP had been used, with₹49.03 reported unutilized; no deviation and no overdue FY27 completion milestone were reported. This supports funds being available **then**, not current surplus cash or attractive returns. [S01 pp89–98; S04 pp7–17]

CWM rights cost₹7.5 over20 screens/10years, with50% of **net profits after direct expenses**, not50% of gross revenue or ownership of screens. ₹2.5 already paid per offer/monitor evidence versus₹1.5 March project-right asset creates an interim bridge inference: model adds₹1 right and subtracts₹1 cash, not a verified October transaction ledger. ₹5 remaining is separately modeled as investment/amortization, not hidden in LED capex. June₹0.45 LED spend is excluded from future residual capex but conservatively not credited to opening March PPE without commissioning evidence. [S01 pp97–98; S04; S03 PDFp84]

A bottom-up path requires seven commissioned screens, priced sold slots, sustained collections, renewal economics and CWM receipts. Rising unit counts alone cannot substantiate the base case. Short-cycle discretionary ad budgets and agency customers limit demonstrated duration. GQS therefore remains NS on REV/EARN/CAP; positive sales momentum does not fill missing evidence.

## 8. Management, Governance & Execution

Promoter control remains concentrated: the IPO mechanically reduces original share block to73.51% of issued equity before subsequent trades; that is not a substitute for a verified latest shareholding/pledge pattern. Latest cutoff-date promoter encumbrance history is ND in this dossier. Exchange share disclosures confirm acquisitions occurred, but individual unnecessary identifiers are excluded. No promoter integrity conclusion is inferred from high ownership alone. [S01/S03/S10]

RHP discloses13 delayed RoC filings, some up to508days, plus tax/EPF delays; late fees paid and no show-cause as prospectus date. Issuer direct-tax demand about₹0.1024 including interest is distinct from promoter GST disputes₹19.3458 across14matters: promoter liabilities are not automatically issuer debt. No adjudicated fraud is inferred. AR narrative says no material RPTs while AOC2 labels promoter space/office rent arrangements material (₹9/₹0.396); financial-period wording is also stale. Commercial necessity is plausible, but matched-period approval/arm's-length and lease economics are unresolved. [S01 pp41–44; S03 pp32,47; B18–B20]

Unmodified FY26 audit and no-deviation monitoring are meaningful counterevidence, not proof that every accounting bridge or lease arrangement is immaterial. The independent-director resignation alone is not misconduct. [S02; S04]

|Promise/vintage|Subsequent evidence before cutoff|Assessment|
|---|---|---|
|IPO:7 LED installations inFY27|June₹0.45 spend; July partial conversions/additions|Partial execution, not full commissioning proof|
|CWM₹7.5 rights/20screens|₹2.5 paid;₹5 IPO object unusedJune|Cash receipts/profit statement ND|
|July₹10 BFSI order and prior₹15.26 mandate|Management announcements|Do not add to sales without execution/collection; customer concentration remains|
|September6Bandra rights|Three-year rights, underlying structures excluded|Real access expansion, consideration/yield undisclosed|
|OctoberShirdi rights|₹5lakh/month+tax,24months, contract being executed|Likely license cost, not booked advertiser revenue|

## 9. Financial Forensics

{{HISTORY}}

Additional historical operating bridge (Indian GAAP; source S01 F7 and S02; ₹ crore):

|Measure|FY23 stub restated|FY24 restated|FY25 restated|FY25 statutory|FY26 statutory|
|---|---|---|---|---|---|
|Operating revenue|11.9557|49.3050|74.9446|72.832594|127.218100|
|Hoarding expense / procurement|9.0782|38.1843|53.3527|55.045593|92.202935|
|Operating EBITDA excluding other income|2.1148|7.7228|13.4889|10.114583|22.927896|
|Operating EBIT excluding other income|2.1148|7.7193|13.3611|9.986758|22.178433|
|Depreciation/amortization|0|0.0035|0.1278|0.127825|0.749463|
|Finance cost|0|0|0.0176|0.017591|0.020959|
|Cash FCF proxy|0.0466|2.2109|2.5702|2.570170|5.615294|
|Inventory|0|0|0|0|0|
|Current investments|0|0|0|0|0|
|Contract/unbilled receivables|1.1848|3.7249|6.4862|0|3.014215|
|Basic/diluted EPS as filed, ₹|2.26|6.56|11.34|8.38|18.88|

FY23 covers incorporation 17 June 2022 to 31 March 2023; other annual rows cover 1 April–31 March. Restated EPS uses retrospective bonus weighting and cannot be compared to raw pre-bonus statutory EPS. No NCI/owner split applies to standalone profits. Gross profit is not separately reported: revenue less hoarding procurement is a contribution proxy, not a complete gross margin after labor/other delivery expenses. Full economic invested capital, lease present value and normalized tax-aligned ROIC are NS pending rights/recognition bridges; no invented industrial gross-profit or lease assets. PPE/capex history is in financial_inputs.json; historical noncash useful-life and normalization detail is limited. RHP FY24 unbilled3.7249 is the cumulative FY23/FY24 recognition bridge; FY23 and FY24 quoted EPS are the RHP table values, not recomputed using current shares. The negative statutory FY25 second half is a balancing-period disclosure, not proof of current operational loss or a comparable clean half-year trend.

All figures preserve their own vintage; original/restated FY25 are separate rows, not duplicates to be averaged. Raw PDFs/OCR and personal identifiers are deliberately excluded; structured observations, formulas and source locators remain rebuildable.

**Recognition and equity bridge.** RHPF13 originalFY25PAT7.3763 → restated9.9752: gratuity+0.0182, tax−0.7673, deferred tax−0.0082, provision+0.0019, unbilled+2.7613, discount+0.5929 (rounding). FY25restated equity17.3671 versusoriginal12.4141 differs4.9530; unbilled receivable6.4862 accounts for the receivable uplift. RHP nine-monthFY26 explicitly reverses6.4862 already recognized in preceding years, showing why timing matters. FY26statutory equity12.414150+PAT16.615674=29.029824, and reserves transfer8.75 into bonus capital does not change total equity. Prior-period-item lines are blank in ARPDFpp71,90. [S01F13; S03PDFp76]

ARPDFp86 now recognizes₹3.014215 unbilled within₹39.766352 receivables; FY25statutory comparative shows none. This supports changed service-rendered recognition but is not a complete correction reconciliation. **Hypothesis, not fact:** if the entire₹4.953 equity difference flowed throughFY26 earnings, current-periodPAT would be₹11.662674 and current-shareP/E43.22x; analogous revenue timing adjustment would subtract prior unbilled₹6.4862 to₹120.7319, but other corrections/tax must be reconciled before adopting this as normalized revenue. The margin sensitivity deducts5.33pp from base EBITDA as an approximate pretax earnings-timing stress, not a restated audited account. G2 remains a hold rather than asserting fraud or an arbitrary valuation haircut.

FY26 PBT22.774829 +finance0.020959 −other income0.617355 =operatingEBIT22.178433. Adding back labor-code0.007841 and investment-sale loss0.112977 yields tentative operatingEBIT22.299251 and EBITDA23.048714; these identified noncore addbacks do **not** solve the larger recognition issue. Reported statutoryPAT16.615674 versus addback-only16.703871 at27% assumed tax is kept separate. Reported CFO10.516185/cashcapex4.900891 givesFCFproxy5.615294. Interest is financing cash flow; rights₹1.5 are in operating adjustments and short advances₹1.58 in investing, so FCFproxy is not clean FCFF. The model treats rights as investment explicitly. [S02cashflow]

CumulativeCFO/PAT is32.24% overRHPFY23stub–FY25, versus57.62% over statutoryFY25–FY26; never combine the twoPAT series or average annual ratios. FY26alone63.29% is improving counterevidence. Receivables rose₹25.0218 crore while payables rose₹13.8839; working capital remains the cash consumer. Average statutory receivable days78.20 versus closing114.09; closing payable days107.93 uses hoarding-cost proxy. No inventory, so inventorydaysNA; contract/unbilled assets are included in receivables, not double-added. Comparable credit-purchase/receivable ageing limits prevent a precise canonical CCC. [S01/S02/S03PDFp86]

Receivable ageing: unbilled3.014215; billed<6months35.149272;6–12months1.186283;1–2years0.158032;2–3years0.258550. All classified undisputed/considered good by management; that is not subsequent cash verification. Annual-report cash9.608902 includes4.391085 deposits with original maturity>12months and4.99 shorter deposits, leaving0.227818 bank/cash. Restriction/early-withdrawal terms for March deposits are ND. By contrastJuneIPO43.97 deposits are expressly sweep-in; total unutilized49.03 includes5.06 current-account balances. No bank-account numbers retained. [S03PDFpp86–87; S04pp14–15]

Mechanical statutory ROE80.18%; net-financing-capitalROCE164.79%; incremental after-taxEBIT/change(net equity+debt−cash)74.28%. Formula inputs and exact numbers in financial_metrics.json. These are **not** supported economic ROIC: leased-site commitments omitted, netting all term deposits distorts denominators, IPO capital arrives later, and restatement changesFY25capital. CAP remainsNS. Gross debt0.087822, versus reportedcash9.608902 does not prove immediate cash coverage. Warrants=zero inFY26filing; current undisclosed convertibles/options remain an evidence gap, not an invented fully diluted claim. Bonus175:1 is not economic dilution; IPO31,71,600newshares is. HistoricalEPS₹18.88 used0.88crore weighted shares; current-shareEPS₹13.879 uses1.19716crore. [S02/S03/S10]

## 10. Valuation & Market Expectations

At₹421.05: marketcap₹504.0642; statutorycurrent-shareP/E30.34x. March reported-cash EV₹494.5431 /tentatively normalizedEBITDA₹23.0487 ≈21.46x; using unavailable term deposits as cash can understate economicEV. March bookP/B17.36x is **pre-IPO and stale**, not a current balance-sheet multiple. FCFproxyyield1.11% likewise historical and not normalized FCFE. Post-IPO proceeds cannot be added gross after deducting deployment or credited to earnings twice. [S02/S04/S10/S11]

**Conditional model, not a forecast or price target:**60monthly steps from20October2026, FY26 operating scale as anchor. Opening liquidity upper proxy=Marchreportedcash9.608902+JuneunutilizedIPO49.03−inferredCWMpayment1=57.638902. It omits unknown interveningCFO/deployment, explicitly not Octobercash. Constrained variant uses onlyMarchbank/cash+JuneIPO−1=48.257818; other cash boundaries9.608902/34.608902/58.638902 test funds already used. These are analytical states, not equally probable estimates. Debt0.087822 repaidmonth1; no committed new debt assumed;1crore buffer is an analyst assumption.

Annualized run-rate growth sequences—not reported-year growth—are bear−15/0/5/5/5%, base25/20/18/15/12%, bull40/30/25/20/15%. Monthly compounding smooths these rates; last12months define terminal revenue/earnings. EBITDAmargins bear8→10%, base15%, bull17.5%. Collections160/115/100days, payables65/100/110days at72.5%procurement-cost proxy; other operating assets4%/liabilities2.7%of sales. InitialONWC14.24311 is built from disclosed operating balances and migrated over6months. Maintenance/growthcashcapex2.5/3.5/4.5%of sales plus residualLED12.2688 andCWM5 over6months. Assets depreciate20%annualWDV and rights over10years as analytical assumptions; wages/rent/media costs remain expensed. No IndASlease-debt addback is mixed with IndianGAAPEBITDA. No dividends or interest income are credited; retainedcash appears only once in terminal equity.

{{VALUATION}}

DCFcross-check discounts monthlyFCFF=EBIT−positive operatingtax+D&A−capex−rightsinvestment−ΔONWC. TerminalNOPAT grows2/4/5% with25%assumed marginalROIC; terminalreinvestment=g/ROIC, not growth without funding. Rates12/15/18% are separate sensitivity assumptions, not automatically equated to hurdle. Terminal multipleEV converts to equity by adding terminalcash and subtracting remainingdebt; current cash is not added again. Rescue counterfactual issues discounted equity at60%of entry, dilutes current holders and is **not evidence funds are available**. ItsDCF is enterprise/pre-financing diagnostic, not dilutedholdervalue. Anyunfunded path's later cash/terminal value is diagnostic continuation only; no validgoing-concernreturn is claimed.

{{SENSITIVITY}}

Executioncost sensitivity: a2% higher effectiveentry plus2%exit cost lowers thebase illustrativeIRR; it does not assume a spread quote or executable block. No probabilities assigned. Conditional hurdle-entry prices do not authorize purchase whileG2 unresolved.

## 11. Bear Case & Permanent-Loss Path

The thesis-break variable is **cash yield after media-right renewals and advertiser collections**, not headline portfolio size. Loss of an agency/BFSI advertiser or site-right access reduces sold slots; fixed rent and vendor commitments compress margins; agencies slow payments while media vendors shorten credit; LED/CWM spending continues before yields mature. Existing term deposits may be unavailable andIPOcash committed. This linked path is modeled with−40% first-yearrun-rate growth,−2%margin,240receivable/35payabledays, capex stillrequired and no assumed new financing. Funding-floor breach is reported explicitly, not concealed by zeroingcash. Failure is conditional and does not establish companydefault/fraud. [S01risk disclosures; model_outputs.json]

Strongest counterevidence: FY26positiveCFO, lowborrowings, IPOcash then verified, increasingdigitalmix and actualnewrights. A prompt conversion of unbilledbalances to cash and reconciledfinancialhistory could improve this conclusion. Conversely a lowerquotedprice cannot resolve missingreliability evidence. Material valuation downside can arise even without insolvency: bear lowergrowth/margin and7xterminalEBITDA produce substantial equityvalue loss. Recoverableassets include cash, collectibleadvertiserbalances and transferableeconomicrights—but rights are not freely saleable ownedproperty. No unsupported liquidationrecovery is claimed.

## 12. 5× / 10× Feasibility

Speculative/unsupported as a durable investment thesis. Five-year5x requires37.97%annualpricegrowth and10x58.49%; with unchangedmultiple/margin and nofurtherdilution, earnings/revenue must scale comparably. Starting fromcurrent-shareEPS₹13.879,5x/10xprice at30.34x would requireEPS₹69.40/₹138.79 (PAT≈₹83.08/₹166.16crore), before defending the highmultiple. At15xterminalP/E, requiredPATroughly₹168.02/₹336.04crore. This outstrips the conditionalbullpath and requires accessiblephysicalinventory, collections andfunding not yet demonstrated. Exactsuccessprobabilities or multibaggertargets are unwarranted.

## 13. Monitoring Plan

|KPI / baseline|Milestone or alert|Thesis-break/review condition|Timing/source|
|---|---|---|---|
|FY25equitydifference₹4.953crore|Matched FY25→FY26AS5/revenue/tax reconciliation|Continued material unreconciledfinancialseries maintainsG2Hold, not automaticfraud|Nextauditedfiling; S01/S03|
|FY26unbilled₹3.0142; closingAR114days|Invoice/collectioncohort and currentageing|Rising>160days alongsideweakmargin triggers linkedfundingreview|Half-yearresults; S03|
|IPOJuneunutilized₹49.03|Bank-to-object-to-assetreconciliation, no doublecount|Unexplainedmaterialdeviation requiresG1/G2review|Quarterlymonitor; S04|
|SevenLEDplan;₹0.45spentJune|Commissioningdates, physicalscreens, soldslots/yield|Renewal-adjustedcashreturns belowcapitalcost refuteCAPthesis|FY27deadline; S01/S04|
|CWMtotal₹7.5/20screens/50%netprofits|₹2.5paidbridge,₹5balanceandactualprofitremittances|Noenforceablerights/receipts afterdeploymentperiod require impairmentreview|Nextresults; S01/S04|
|222reportedunits=80static+142digital|Physicalboard/slotdenominatorreconciled|Countgrowthwithoutcashyield cannot justifygrowthrating|Operationalupdates; S07|
|Promoterleases /₹0.90monthlyreference|Matchedperiodrent, approvals, renewals|Loss of criticalrights or evidencedabuse changesG1/DUR|Annualreport/renewal; S01/S03|
|₹5lakhmonthlyShirdiconsideration|Executedagreement, advertiserbookings andnetmargin|Persistentnegativeyield afterlaunch triggers allocationreview|Firstoperatingyear; S08|
|600-sharelot;20sessionADV30,510|Actualbiddepth/lotexecution before allocation|Repeatedno-bid sessions canmoveG4toHold|Atproposedtrade; S10/S11|

Thresholds are scenario-linked alerts, not universal rules or automatictrades. No reminders/automations created.

## 14. Final Classification & Conditional Action

**Hold — unresolved; research-priority reconciliation, not eligible for investment consideration.** BQS/GQS/IAS remainNS, outside ranked numeric tables. Specific missingcriticalfactors: REV,CAP,EARN andsupportedR; G2 restricts qualityrankings because financialcomparability is central. Knownfactors remain separately scored and auditable. There is no overallblendedscore and no governanceavoid/defaultlabel. Even if accounts reconcile, conditionalbase returns at₹421.05 are weak; any futureIAS must be recomputed with verifiedcurrentcash, normalizedearnings and investableexecution. New evidence matters before price. No globalregistry, Git, Libraryupload or publication occurs in this producerwork; separate review required.

## 15. Sources, Assumptions & Open Questions

{{SOURCES}}

Detailed businessclaims B10–B31, peerprimarylinks and conflicts are retained in business_notes.md; financial_inputs.json preserves exactperiod/vintage and financial_metrics.json formulas are rebuilt by analyze.py. market_rows.json contains onlyissuerrows over60datedsessions; market_provenance.json preserves official source/hash lineage. Modelinputs, allmonthlypaths, conditionalfundingfailures, sensitivities, reverseexpectations and exact original unpublished internal draft summaries are retained without raw source files. Historical full code/input/monthly snapshots were not frozen, so those summaries are incomplete and not claimed historically replayable. The current46-path model is complete; no reconstructed outputs are presented as original history. Source-safe archives contain noPDF/OCR, bankaccounts, personalIDs or privatefilesystempaths.

Openquestions: exactAS5/recognitionbridge; subsequentcashrealization; actualOctober unrestrictedcash andIPOdeployment; debt/leasecommitments; sourceof₹1croreCWMpaidbridge; commissioninganduseful-life confirmation; directcontractrenewals; latestpledge/fullydilutedclaims; gross/netprincipalagentpolicy andphysicalvolume/yield. Sourcefailures are not silently filled: companyIRpage404; callPDFtextblank; initialPythonrequestslibraryunavailable (curlworked); BrightoldURLHTML/screenshotverificationfailed but alternativeprimarycomparativeread. NoChromiumlaunched, no deniedactionbypassed. PrimaryFY26financialpageswerevisuallyread; extractedOCRisprivateprocessingonlyandnotarchived. Informationretrievedaftercutoff is onlyusedwhere documentdate precedescutoff; post-cutoffresults/quotesexcluded.
