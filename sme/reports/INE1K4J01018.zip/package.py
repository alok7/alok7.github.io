from pathlib import Path
import hashlib,json,zipfile
P=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
excluded={'private','__pycache__'};external={'archive_manifest.json','build_manifest.json','producer_handoff.json','cold_rebuild_proof.json'}
files=[x for x in sorted(P.rglob('*'))if x.is_file()and not excluded.intersection(x.relative_to(P).parts)and x.suffix not in ['.zip','.pyc']and x.name not in external]
generated=['source_ledger.json','financial_inputs.json','market_metrics.json','model_inputs.json','model_outputs.json','model_main_monthly.csv','financial_metrics.json','scores.json','model_vintages/v1_pre_ipo_cash_anchor.json','model_vintages/update_log.json','report.md','report.html','model_proof.json','market_provenance.json','company_record.json','verification.json']
manifest={'schema':'source_safe_build_v1','position':380,'isin':'INE1K4J01018','generated_outputs':generated,'hash_order':['inputs/code','derived data/model/report/proof','record role hashes','build manifest','archives','external archive manifest/cold proof/handoff'],'files':{str(x.relative_to(P)):{'sha256':sha(x),'bytes':x.stat().st_size}for x in files},'source_safe':True,'excluded_classes':['raw PDF','OCR/source extraction','personal identifiers','private processing paths','browser caches']}
(P/'build_manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');files.append(P/'build_manifest.json');archives=[]
for role in ['full','compact']:
 chosen=[x for x in files if not(role=='compact'and x.name in ['model_outputs.json','model_main_monthly.csv'])]
 name=f'SME_380_Simca_Advertising_20261020_source_safe_{role}.zip';zp=P/name
 with zipfile.ZipFile(zp,'w',zipfile.ZIP_DEFLATED,compresslevel=9)as z:
  for x in chosen:
   zi=zipfile.ZipInfo('Simca_Advertising_380/'+str(x.relative_to(P)),date_time=(2026,10,20,0,0,0));zi.compress_type=zipfile.ZIP_DEFLATED;zi.external_attr=0o100644<<16;z.writestr(zi,x.read_bytes())
 archives.append({'role':role,'filename':name,'sha256':sha(zp),'bytes':zp.stat().st_size,'members':{str(x.relative_to(P)):sha(x)for x in chosen},'omitted_reconstructible':[str(x.relative_to(P))for x in files if x not in chosen]})
(P/'archive_manifest.json').write_text(json.dumps({'position':380,'isin':'INE1K4J01018','non_circular':True,'build_manifest_sha256':sha(P/'build_manifest.json'),'record_sha256':sha(P/'company_record.json'),'archives':archives},indent=2)+'\n')
print([(x['role'],x['bytes'])for x in archives])
