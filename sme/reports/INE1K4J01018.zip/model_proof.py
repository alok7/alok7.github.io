"""Independent, offline algebra audit. Does not import or execute producer model."""
import json, math, hashlib
from pathlib import Path
P=Path(__file__).resolve().parent
I=json.loads((P/'model_inputs.json').read_text()); O=json.loads((P/'model_outputs.json').read_text()); F=json.loads((P/'financial_inputs.json').read_text())['fy26']
checks=0; failures=[]
def ck(label, got, want):
 global checks
 checks+=1
 if isinstance(want,bool):ok=got==want
 elif want is None:ok=got is None
 else:ok=math.isclose(got,want,rel_tol=2e-9,abs_tol=2e-8)
 if not ok: failures.append(dict(check=label,actual=got,expected=want))
ck('input_version_matches',O['inputs_version']==I['version'],True)
ck('rights_contract_total',I['initial_rights']+5,7.5)
ck('synthetic_cash_bridge',I['initial_cash'],F['cash']+49.03-1)
paths=O['paths']+O['sensitivity_paths']; results=[]
for ix,p in enumerate(paths):
 a=p['assumptions']; s=I['scenarios'][p['name']]; initcash=a['initial_cash']; cash=initcash; wc=I['initial_wc']; ppe=I['initial_ppe']; rights=I['initial_rights']; debt=I['initial_debt']; shares=I['initial_shares_crore']; raised=0; maxgap=0; first=None; fails=[]; totals={k:0. for k in ['cfo','capex','rights_capex','debt_repayment','equity_raise']}
 ck(f'{ix}:length',len(p['rows']),60)
 for r in p['rows']:
  m=r['month']; y=(m-1)//12; remaining=(m-1)%12+1
  runrev=F['revenue']
  for z in range(y): runrev*=max(.05,1+s['growth'][z]+a['growth_shift'])
  runrev*=max(.05,1+s['growth'][y]+a['growth_shift'])**(remaining/12)
  revenue=runrev/12; ebitda=revenue*(s['margin'][y]+a['margin_shift']); da=ppe*(1-.8**(1/12)); amort=min(rights,(I['initial_rights']+(5 if m>a['delay_months']+6 else 0))/120)
  ebit=ebitda-da-amort; interest=debt*.01; tax=.27*max(0,ebit-interest); pat=ebit-interest-tax
  target=runrev*((s['days']+a['days_shift'])/365+.04-.725*s['paydays']/365-.027)
  nwc=((6-m)*wc+target)/(7-m) if m<=6 else target; dwc=nwc-wc
  project=(a['delay_months']<m<=a['delay_months']+6); capex=revenue*s['capex_ratio']+(12.2688/6 if project else 0); rights_capex=5/6 if project else 0
  cfo=pat+da+amort-dwc; repay=debt if m==1 else 0; precash=cash+cfo-capex-rights_capex-repay; gap=max(0,1-precash)
  if gap>1e-9:
   if first is None:first=m
   if not a['rescue']:fails.append((m,gap,precash<0));maxgap=max(maxgap,gap)
  eq=gap if a['rescue'] and gap>1e-9 else 0; newshares=eq/(I['entry']*.6)
  # Independent levered-to-unlevered bridge: add back interest and replace tax on EBT with tax on EBIT.
  fcff=cfo+interest+tax-max(0,ebit)*.27-capex-rights_capex
  expected={'year':y+1,'revenue':revenue,'ebitda':ebitda,'da':da,'amortization':amort,'ebit':ebit,'interest':interest,'tax':tax,'pat':pat,'opening_cash':cash,'cfo':cfo,'capex':capex,'rights_capex':rights_capex,'delta_wc':dwc,'wc':nwc,'fcff':fcff,'debt_repayment':repay,'equity_raise':eq,'new_shares_crore':newshares,'shares_crore':shares+newshares,'closing_cash':precash+eq,'ppe':ppe+capex-da,'rights':rights+rights_capex-amort,'debt':debt-repay,'shortfall':gap}
  for k,v in expected.items():ck(f'{ix}:{m}:{k}',r[k],v)
  for k in totals:totals[k]+=expected[k]
  ck(f'{ix}:{m}:cumulative_cash',r['closing_cash'],initcash+totals['cfo']-totals['capex']-totals['rights_capex']-totals['debt_repayment']+totals['equity_raise'])
  cash=precash+eq;wc=nwc;ppe+=capex-da;rights+=rights_capex-amort;debt-=repay;shares+=newshares;raised+=eq
 S=p['summary'];last=p['rows'][-12:];ebitda=sum(r['ebitda']for r in last);ev=max(0,ebitda*a['multiple']);equity=max(0,ev+cash-debt);exitprice=equity/shares;irr=(exitprice/I['entry'])**.2-1 if exitprice else -1
 values={'terminal_revenue':sum(r['revenue']for r in last),'terminal_ebitda':ebitda,'terminal_ev':ev,'terminal_cash':cash,'terminal_debt':debt,'terminal_equity':equity,'exit_price':exitprice,'illustrative_irr':irr,'valid_going_concern_return':not fails,'first_funding_gap_month':first,'minimum_cash':min(r['closing_cash']for r in p['rows']),'maximum_unfunded_gap':maxgap,'total_equity_raise':raised,'terminal_shares_crore':shares,'dilution':shares/I['initial_shares_crore']-1}
 for k,v in values.items():ck(f'{ix}:summary:{k}',S[k],v)
 for hurdle in [.12,.15,.18]:ck(f'{ix}:entry:{hurdle}',S[f'required_entry_{int(hurdle*100)}pct'],exitprice/(1+hurdle)**5)
 ck(f'{ix}:failure_count',len(p['failure_path']),len(fails))
 if fails:ck(f'{ix}:failed_path_label','Diagnostic' in S['valuation_status'],True)
 if a['rescue']:ck(f'{ix}:rescue_dcf_label','NOT rescue holder value' in S['dcf_scope'],True)
 for f,(month,gap,negative)in zip(p['failure_path'],fails):
  ck(f'{ix}:fail:month',f['month'],month);ck(f'{ix}:fail:gap',f['shortfall_to_floor'],gap);ck(f'{ix}:fail:negative',f['negative_cash'],negative)
 nopat=sum(r['ebit']for r in last)*.73
 for d in S['dcf_grid']:
  rate=d['rate'];g=d['g'];terminal=max(0,nopat*(1+g)*(1-g/.25))/(rate-g);opv=sum(r['fcff']*math.exp(-math.log1p(rate)*r['month']/12)for r in p['rows']);tpv=terminal/(1+rate)**5;dev=opv+tpv;dequity=max(0,dev+initcash-I['initial_debt'])
  ck(f'{ix}:dcf:{rate}:{g}:price',d['price'],dequity/I['initial_shares_crore']);ck(f'{ix}:dcf:{rate}:{g}:tv_fraction',d['terminal_fraction'],tpv/dev if dev>0 else None)
 results.append({'path_index':ix,'scenario':p['name'],'months':60,'rescue_assumed':a['rescue'],'unfunded':bool(fails)})
# The reverse solver reports values but does not retain its monthly paths; check target tolerance, not fabricated path coverage.
for x in O['reverse_expectations']:ck('reverse_return_target',x['model_return'],.15)
notes=[
 'Arithmetic tests are not source authentication or economic validation. Initial cash remains a synthetic March plus June-proceeds bridge, not observed October unrestricted liquidity.',
 'Failed unfinanced paths retain diagnostic terminal values; neither those values nor their DCF can support a going-concern investment return.',
 'Rescue path exit price reflects discounted issue dilution; DCF is pre-financing enterprise valuation per original shares and does not measure rescue-shareholder wealth transfer.',
 'Growth assumptions are annualized run-rate changes; monthly interpolation makes annual aggregate growth different.',
 'v3 reconciles contractual7.5 rights using assumed2.5 opening rights plus5 future payment; cash reduced1.0 versus v2. Intervening1.0 payment is an analyst inference, not verified October balances. Historical project-right presentation remains uncertain.',
 'Cash is added once at entry in enterprise DCF; terminal cash is added once only in exit-multiple valuation. No dividends are additionally distributed. These are alternative valuations, not amounts to sum.'
]
receipt={'status':'PASS'if not failures else'FAIL','scope':'Independent algebra and units audit of all retained monthly paths; substantive caveats remain','checks':checks,'paths':len(paths),'monthly_rows':sum(len(p['rows'])for p in paths),'failures':failures,'path_results':results,'observations':notes,'sha256':{n:hashlib.sha256((P/n).read_bytes()).hexdigest()for n in ['model.py','model_inputs.json','model_outputs.json','financial_inputs.json','model_proof.py']}}
(P/'model_proof.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({k:receipt[k]for k in ['status','checks','paths','monthly_rows']}));raise SystemExit(bool(failures))
