# Simca Advertising Limited — research dossier

Position **380** · ISIN **INE1K4J01018** · NSE Emerge **SIMCA** · Framework v3.0
Information cutoff **20 October 2026**; market reference **19 October 2026**. Research assembled 25 October using only cutoff-eligible evidence. INR crore unless specified. Not an instruction to trade.

## 1. Executive Verdict

**Hold — unresolved financial comparability; not an evidence-backed compounder.** Simca sells outdoor advertising space and execution, increasingly digital slots, mainly in Maharashtra. Rising digital inventory, repeat clients, new location rights and a largely equity-funded expansion are credible positives. They do not yet establish owned infrastructure economics or durable per-share cash compounding. The decisive issue is reconciling IPO-restated service-rendered revenue and equity with subsequent statutory accounts: ₹4.953 crore of FY25 equity difference is not explicitly bridged to FY26. At ₹421.05, the security capitalizes statutory FY26 earnings at about 30.3 x after IPO dilution; an illustrative modest-growth path produces well below the 15% hurdle, but is not reliable enough for a numerical IAS. Financial-history reconciliation, collection evidence and commissioned-unit cash returns—not a higher asset-count press release—would change this assessment. Thesis type: early listed regional advertising expansion, with cyclical demand and execution risk. [S01 F13; S02; S03 PDF pp 71,76,86; S10/S11]

## 2. Research Header, Gates and Data Confidence

Legal identity is Simca Advertising Limited, incorporated 17 June 2022; do not transplant the older promoter enterprise's 1970 brand legacy into audited corporate history. NSE security master confirms 11,971,600 shares and 600-share lot; traded 19 October close ₹421.05, market capitalization ₹504.0642 crore. Actual trading series is ST. Some company letters say EQ, which does not override exchange security/transaction evidence. Quote is not stale, but is not an executable offer. [S01 history; S03 p 25; S10/S11]

Scope is **standalone Indian GAAP / Accounting Standards under Companies (Accounting Standards) Rules 2021**, not Ind AS; no subsidiary/associate/JV at 31 March 2026. FY26 audited results approved 29 May; July clarification fixes XBRL denomination, prescribed format and notes. Half-year reporting does not authorize invented quarterly cash flow. September 2026 results released 23 October are **excluded**, along with current aggregator TTM/price data. Five-year scenarios 20 October 2026–20 October 2031; nominal INR,15% investor hurdle before personal tax; independent discount sensitivities 12/15/18%; illustrative ₹5 lakh position. [S02 notes; S03 p 25]

|Gate|Status|Evidence and release requirement|
|---|---|---|
|G1 integrity/minority protection|Conditional|Promoter site leases, filing delays and inconsistent RPT presentation require scrutiny; no substantiated severe diversion or minority abuse established. Obtain matched lease/arm's-length and AOC 2 reconciliations.|
|G2 financial reliability|Hold — unresolved|RHP restated FY25 versus statutory FY26 opening/comparative equity and income differ materially. Need full AS 5/recognition reconciliation, not just a generic regrouping note. IAS NS; quality ranking excluded while this affects critical factors.|
|G3 funding/survival|Conditional|Low statutory borrowings, IPO funds and positive CFO are counterevidence to distress. Actual October unrestricted cash and license obligations not reconciled; model gaps do not prove default.|
|G4 tradability|Conditional|60 sampled sessions traded;600-share lot and ST trading impose implementation risk. No bid-depth/impact proof. Not suspended or proven effectively untradeable.|

Confidence: High on identity and dated trades; Medium on individual primary financial statements and reported operating inventory; Low on inter-vintage comparability, organic/real growth and normalized incremental returns; Low on October unrestricted liquidity/valuation anchor. Overall confidence for an investment conclusion is Low, not an average of those subjects.

## 3. Scorecard and Calculation Audit

|Score|Raw/final|Coverage|Missing factors|Mathematical bound|Eligibility|
|---|---|---|---|---|---|
|BQS|NS / NS|76%|REV, CAP|3.820–5.980|Not ranking eligible|
|GQS|NS / NS|30%|REV, EARN, CAP|2.100–8.400|Not ranking eligible|
|IAS|NS / NS|40%|BQS, R|2.605–6.295|Not ranking eligible|

|Factor|Score|Evidence/reason|
|---|---|---|
|GOV|5|S01 risks pp 39–44; S03 AOC 2; reporting delays and promoter reliance balanced by no adjudicated minority diversion located. G2 financial reconciliation is separate.|
|MOAT|4|B10–B16: local access and repeat advertisers; leased rights, short campaigns and customer/vendor concentration constrain pricing power.|
|REV|NS|S01 F13/S02: statutory versus restated recognition unresolved; nominal expansion clear, comparable real growth not established.|
|DUR|5|B11–B16 and S05/S07/S08: DOOH opportunity and new licenses, but short campaigns and renewal concentration.|
|CAP|NS|S01/S02 incompatible capital vintages; leased sites and new IPO deployment have not proved incremental cash returns.|
|CASH|4|S01/S02: weak cumulative conversion in each separate vintage; FY26 recovery to 63.3% is positive, insufficient to call persistent high cash conversion.|
|BAL|6|S02/S04: very low debt and unutilized IPO funds, offset restricted deployment purpose and unverified current cash/lease commitments.|
|EXEC|5|S05/S07 conversions/site rights show execution; collection, commissioning and post-IPO return evidence not yet established.|
|EARN|NS|S01 F13: timing corrections and FY26 normalization not reconciled.|
|R|NS|All return paths are conditional because accounting and October liquidity anchor unresolved; do not score synthetic base as forecast.|
|D|3|Conditional severe loss/funding stress with limited listed liquidity; not a default assertion.|
|P|3|30.3 x statutory trailing current-share P/E; base needs more growth/margin/multiple than modest assumptions deliver.|
|L|4|S10/S11:600-share lot≈₹2.53 lakh; traded daily, but trade-for-trade/one-sided exits and concentrated float.|

BQS weights: GOV 20%, MOAT 20%, REV 12%, DUR 10%, CAP 12%, CASH 10%, BAL 8%, EXEC 8%. GQS: REV 40%, DUR 20%, EARN 15%, CAP 15%, CASH 10%. IAS: BQS 25%, R 35%, D 20%, P 10%, L 10%. All weights sum 100%; canonical shared factors are reused. Mathematical missing-data bounds assign missing factors 1–10, never midpoint/renormalized score; IAS propagates BQS bounds. GOV/DUR together±1 shifts known BQS by±0.30, GQS±0.20 and IAS quality contribution±0.075; aggregate scores remain NS. No governance/funding override is asserted. CASH 4 does not trigger the≤3 persistent-cash cap. Scores are policy judgments, not calibrated fraud/default probabilities. [scores.json; framework§8–10]

## 4. Business Overview

Space-selling was 99.46% of restated FY25 revenue and 99.58% in 9 M FY26; mounting/dismounting is a small remainder. The company arranges outdoor campaign locations, purchases media availability and sells advertiser campaigns; “mediatech” does not establish proprietary software or Saa S economics. Maharashtra contributed 88.56% of FY25/81.17% of 9 M FY26; advertising agencies 63.27%/58.63%, real estate 24.21%/27.32%. Typical campaigns last 14 days (7–21); agency credit 30–60 days and direct-client credit 0–30 days are stated commercial terms, not observed collection performance. [S01 pp 164–167; B10,B13,B14]

Reported media inventory at December 2025 was 150 units:78 static plus 72 digital units. **Each physical LED was counted as six advertising units**, implying 12 LEDs under that convention—not 150 owned sites. The company does not own the underlying media structures identified in the prospectus; promoter subleases cover 29 physical sites represented by 59 slot units. The July 2025 promoter arrangement is ₹0.90 crore/month. Site permits, renewal, location access and content slots are economically distinct from hardware ownership. Later reports call 222 units “sites,” without reconciling the unit definition. [S01 pp 29–30,164; S07; B11,B15]

## 5. Moat / Industry Position

Local advertiser/agency relationships and high-visibility locations can reduce sourcing friction; conversion to digital lets multiple campaigns share a screen. But short campaigns, substitutes, nontransferable site leases, renewals and larger rivals limit proven pricing power. Top 10 customers were 51.61% FY25 revenue and top 10 vendors 72.54% hoarding purchases. Unnamed customer identities limit relatedness verification; they do not prove connected sales. Physical inventory, sold slot-hours, realized price, rights duration and collections—not total advertising budgets—are the economic moat tests. [S01 risks/business; B13–B16]

|Peer and economic role|Primary comparison|Limits/counterevidence|
|---|---|---|
|Bright Outdoor Media, closest listed Mumbai OOH/DOOH benchmark|FY25 revenue ₹126.7455, PAT ₹19.0749; equity ₹163.7436 from capital+reserves|Real-estate segment complicates margin comparison. RHP's ₹6.09 equity/313.3% ROE contradict Bright's own filing and are rejected.|
|Signpost India, larger concession/network comparator|FY25 consolidated revenue ₹453.2241, PAT ₹33.9035; stated longer 5–20 year concessions|Debt/depreciation/capital intensity matter. RHP's ₹33.7453 PAT is standalone, not same scope. Panel counts not comparable to Simca slots.|
|Alakh Advertising, direct private regional competitor|RHP identifies Mumbai/Nagpur network and agency relationships|FY25 audited financials unavailable; no invented multiple or ranking. Undated current website is only corroboration.|

Additional adjacent firms Minimax and CWM are not independent valuation observations; CWM is also a profit-sharing counterparty. See B24–B27 for exact primary URLs and locators. These peers establish contestable economics, not a justified premium multiple. No cross-company stock-price comparison is manufactured.

## 6. Revenue Growth & Scale

|Comparable series|Endpoints|Annual addition|Growth / caveat|
|---|---|---|---|
|RHP FY24→FY25|49.3050→74.9446|25.6396|52.00%, one full-year interval|
|Statutory FY25→FY26|72.832594→127.218100|54.385506|74.67%, statutory comparison; no claim reconciled to RHP|
|FY23 stub→FY24 RHP|11.9557→49.3050|37.3493|NM as equal-full-year organic comparison|

The 3/5/10 year CAGR requests are NS/ND rather than filled with misleading series: FY23 is a roughly 9.5 month incorporation stub; only FY24/FY25 are comparable full years within the RHP restatement; FY26 has an unresolved recognition bridge. FY24's ₹37.3493 crore increase over the stub is disclosed but not called full-year organic growth. A single nominal CAGR would blend billing/service timing and different capital histories. [S01 F6–F13; S02]

DOOH mix rose 23.00% FY25 to 36.01% nine-month FY26; the remainder was mostly traditional outdoor. Reported occupancy 77.25%/77.96% is actual-sales/potential-sales—not physical utilization. Slot inventory rose, but price/volume/like-for-like yield, organic acquisitions and gross-versus-net agency procurement effects are not separately quantified. Gross billing includes media procurement costs; accounting policy and observed revenues do not prove every rupee is value-added activity. Underlying audience, impressions, physical screen counts and net take rate remain ND. [S01 p 164; B11–B14]

July corrigendum reports approximate total Q1 FY27 revenue ₹42.6443 versus ₹26.6792,59.84% growth. This is management's business update, not audited operating revenue or a basis to annualize one quarter. Original ₹24.67 comparator is superseded. No Q1 PAT/CFO is invented, and no post-cutoff September half is included. [S06]

## 7. Growth Quality & Reinvestment Runway

IPO objects were seven LED installations ₹12.7188, CWM balance ₹5, incremental working capital ₹23.5 and GCP. Gross raise ₹58.04 versus issue costs ₹8.41 leaves ₹49.63 net: a material 14.5% gross-cost burden. By June 30,₹0.45 LED and ₹0.1545 GCP had been used, with ₹49.03 reported unutilized; no deviation and no overdue FY27 completion milestone were reported. This supports funds being available **then**, not current surplus cash or attractive returns. [S01 pp 89–98; S04 pp 7–17]

CWM rights cost ₹7.5 over 20 screens/10 years, with 50% of **net profits after direct expenses**, not 50% of gross revenue or ownership of screens. ₹2.5 already paid per offer/monitor evidence versus ₹1.5 March project-right asset creates an interim bridge inference: model adds ₹1 right and subtracts ₹1 cash, not a verified October transaction ledger. ₹5 remaining is separately modeled as investment/amortization, not hidden in LED capex. June ₹0.45 LED spend is excluded from future residual capex but conservatively not credited to opening March PPE without commissioning evidence. [S01 pp 97–98; S04; S03 PDFp 84]

A bottom-up path requires seven commissioned screens, priced sold slots, sustained collections, renewal economics and CWM receipts. Rising unit counts alone cannot substantiate the base case. Short-cycle discretionary ad budgets and agency customers limit demonstrated duration. GQS therefore remains NS on REV/EARN/CAP; positive sales momentum does not fill missing evidence.

## 8. Management, Governance & Execution

Promoter control remains concentrated: the IPO mechanically reduces original share block to 73.51% of issued equity before subsequent trades; that is not a substitute for a verified latest shareholding/pledge pattern. Latest cutoff-date promoter encumbrance history is ND in this dossier. Exchange share disclosures confirm acquisitions occurred, but individual unnecessary identifiers are excluded. No promoter integrity conclusion is infer red from high ownership alone. [S01/S03/S10]

RHP discloses 13 delayed Ro C filings, some up to 508 days, plus tax/EPF delays; late fees paid and no show-cause as prospectus date. Issuer direct-tax demand about ₹0.1024 including interest is distinct from promoter GST disputes ₹19.3458 across 14 matters: promoter liabilities are not automatically issuer debt. No adjudicated fraud is infer red. AR narrative says no material RPTs while AOC 2 labels promoter space/office rent arrangements material (₹9/₹0.396); financial-period wording is also stale. Commercial necessity is plausible, but matched-period approval/arm's-length and lease economics are unresolved. [S01 pp 41–44; S03 pp 32,47; B18–B20]

Unmodified FY26 audit and no-deviation monitoring are meaningful counterevidence, not proof that every accounting bridge or lease arrangement is immaterial. The independent-director resignation alone is not misconduct. [S02; S04]

|Promise/vintage|Subsequent evidence before cutoff|Assessment|
|---|---|---|
|IPO:7 LED installations in FY27|June ₹0.45 spend; July partial conversions/additions|Partial execution, not full commissioning proof|
|CWM ₹7.5 rights/20 screens|₹2.5 paid;₹5 IPO object unused June|Cash receipts/profit statement ND|
|July ₹10 BFSI order and prior ₹15.26 mandate|Management announcements|Do not add to sales without execution/collection; customer concentration remains|
|September 6 Bandra rights|Three-year rights, underlying structures excluded|Real access expansion, consideration/yield undisclosed|
|October Shirdi rights|₹5 lakh/month+tax,24 months, contract being executed|Likely license cost, not booked advertiser revenue|

## 9. Financial Forensics

|Period / vintage|Revenue|PAT|CFO|Capex|Equity|AR|AP|Cash|Debt|
|---|---|---|---|---|---|---|---|---|---|
|FY23 stub / RHP restated|11.9557|1.5661|0.0466|0.0000|1.6161|5.5085|2.5502|0.1410|0.0443|
|FY24 / RHP restated|49.3050|5.7758|2.2278|0.0169|7.3919|15.6957|8.6482|2.3075|0.0000|
|FY25 / RHP restated|74.9446|9.9752|3.3091|0.7389|17.3671|21.2307|13.3805|5.2878|0.2819|
|FY25 / FY26 statutory comparative|72.8326|7.3763|3.3091|0.7389|12.4141|14.7445|13.3806|5.2878|0.2819|
|FY26 / FY26 statutory|127.2181|16.6157|10.5162|4.9009|29.0298|39.7664|27.2644|9.6089|0.0878|

Additional historical operating bridge (Indian GAAP; source S01 F7 and S02; ₹ crore):

|Measure|FY23 stub restated|FY24 restated|FY25 restated|FY25 statutory|FY26 statutory|
|---|---|---|---|---|---|
|Operating revenue|11.9557|49.3050|74.9446|72.832594|127.218100|
|Hoarding expense / procurement|9.0782|38.1843|53.3527|55.045593|92.202935|
|Operating EBITDA excluding other income|2.1148|7.7228|13.4889|10.114583|22.927896|
|Operating EBIT excluding other income|2.1148|7.7193|13.3611|9.986758|22.178433|
|Depreciation/amortization|0|0.0035|0.1278|0.127825|0.749463|
|Finance cost|0|0|0.0176|0.017591|0.020959|
|Cash FCF proxy|0.0466|2.2109|2.5702|2.570170|5.615294|
|Inventory|0|0|0|0|0|
|Current investments|0|0|0|0|0|
|Contract/unbilled receivables|1.1848|3.7249|6.4862|0|3.014215|
|Basic/diluted EPS as filed, ₹|2.26|6.56|11.34|8.38|18.88|

FY23 covers incorporation 17 June 2022 to 31 March 2023; other annual rows cover 1 April–31 March. Restated EPS uses retrospective bonus weighting and cannot be compared to raw pre-bonus statutory EPS. No NCI/owner split applies to standalone profits. Gross profit is not separately reported: revenue less hoarding procurement is a contribution proxy, not a complete gross margin after labor/other delivery expenses. Full economic invested capital, lease present value and normalized tax-aligned ROIC are NS pending rights/recognition bridges; no invented industrial gross-profit or lease assets. PPE/capex history is in financial_inputs.json; historical non cash useful-life and normalization detail is limited. RHP FY24 unbilled 3.7249 is the cumulative FY23/FY24 recognition bridge; FY23 and FY24 quoted EPS are the RHP table values, not recomputed using current shares. The negative statutory FY25 second half is a balancing-period disclosure, not proof of current operational loss or a comparable clean half-year trend.

All figures preserve their own vintage; original/restated FY25 are separate rows, not duplicates to be averaged. Raw PDFs/OCR and personal identifiers are deliberately excluded; structured observations, formulas and source locators remain rebuildable.

**Recognition and equity bridge.** RHPF 13 original FY25 PAT 7.3763 → restated 9.9752: gratuity+0.0182, tax−0.7673, deferred tax−0.0082, provision+0.0019, unbilled+2.7613, discount+0.5929 (rounding). FY25 restated equity 17.3671 versus original 12.4141 differs 4.9530; unbilled receivable 6.4862 accounts for the receivable uplift. RHP nine-month FY26 explicitly reverses 6.4862 already recognized in preceding years, showing why timing matters. FY26 statutory equity 12.414150+PAT 16.615674=29.029824, and reserves transfer 8.75 into bonus capital does not change total equity. Prior-period-item lines are blank in ARPDF pp 71,90. [S01 F13; S03 PDFp 76]

ARPDFp 86 now recognizes ₹3.014215 unbilled within ₹39.766352 receivables; FY25 statutory comparative shows none. This supports changed service-rendered recognition but is not a complete correction reconciliation. **Hypothesis, not fact:** if the entire ₹4.953 equity difference flowed through FY26 earnings, current-period PAT would be ₹11.662674 and current-share P/E 43.22 x; analogous revenue timing adjustment would subtract prior unbilled ₹6.4862 to ₹120.7319, but other corrections/tax must be reconciled before adopting this as normalized revenue. The margin sensitivity deducts 5.33 pp from base EBITDA as an approximate pretax earnings-timing stress, not a restated audited account. G2 remains a hold rather than asserting fraud or an arbitrary valuation haircut.

FY26 PBT 22.774829 +finance 0.020959 −other income 0.617355 =operating EBIT 22.178433. Adding back labor-code 0.007841 and investment-sale loss 0.112977 yields tentative operating EBIT 22.299251 and EBITDA 23.048714; these identified non core addbacks do **not** solve the larger recognition issue. Reported statutory PAT 16.615674 versus addback-only 16.703871 at 27% assumed tax is kept separate. Reported CFO 10.516185/cash capex 4.900891 gives Fcf proxy 5.615294. Interest is financing cash flow; rights ₹1.5 are in operating adjustments and short advances ₹1.58 in investing, so Fcf proxy is not clean FCFF. The model treats rights as investment explicitly. [S02 cash flow]

Cumulative CFO/PAT is 32.24% over RHPFY 23 stub–FY25, versus 57.62% over statutory FY25–FY26; never combine the two PAT series or average annual ratios. FY26 alone 63.29% is improving counterevidence. Receivables rose ₹25.0218 crore while payables rose ₹13.8839; working capital remains the cash consumer. Average statutory receivable days 78.20 versus closing 114.09; closing payable days 107.93 uses hoarding-cost proxy. No inventory, so inventory days NA; contract/unbilled assets are included in receivables, not double-added. Comparable credit-purchase/receivable ageing limits prevent a precise canonical CCC. [S01/S02/S03 PDFp 86]

Receivable ageing: unbilled 3.014215; billed<6 months 35.149272;6–12 months 1.186283;1–2 years 0.158032;2–3 years 0.258550. All classified undisputed/considered good by management; that is not subsequent cash verification. Annual-report cash 9.608902 includes 4.391085 deposits with original maturity>12 months and 4.99 shorter deposits, leaving 0.227818 bank/cash. Restriction/early-withdrawal terms for March deposits are ND. By contrast June IPO 43.97 deposits are expressly sweep-in; total unutilized 49.03 includes 5.06 current-account balances. No bank-account numbers retained. [S03 PDF pp 86–87; S04 pp 14–15]

Mechanical statutory ROE 80.18%; net-financing-capital ROCE 164.79%; incremental after-tax EBIT/change(net equity+debt−cash)74.28%. Formula inputs and exact numbers in financial_metrics.json. These are **not** supported economic ROIC: leased-site commitments omitted, netting all term deposits distorts denominators, IPO capital arrives later, and restatement changes FY25 capital. CAP remains NS. Gross debt 0.087822, versus reported cash 9.608902 does not prove immediate cash coverage. Warrants=zero in FY26 filing; current undisclosed convertibles/options remain an evidence gap, not an invented fully diluted claim. Bonus 175:1 is not economic dilution; IPO 31,71,600 new shares is. Historical EPS ₹18.88 used 0.88 crore weighted shares; current-share EPS ₹13.879 uses 1.19716 crore. [S02/S03/S10]

## 10. Valuation & Market Expectations

At ₹421.05: market cap ₹504.0642; statutory current-share P/E 30.34 x. March reported-cash EV ₹494.5431 /tentatively normalized EBITDA ₹23.0487 ≈21.46 x; using unavailable term deposits as cash can under state economic EV. March book P/B17.36 x is **pre-IPO and stale**, not a current balance-sheet multiple. Fcf proxy yield 1.11% likewise historical and not normalized FCFE. Post-IPO proceeds cannot be added gross after deducting deployment or credited to earnings twice. [S02/S04/S10/S11]

**Conditional model, not a forecast or price target:**60 monthly steps from 20 October 2026, FY26 operating scale as anchor. Opening liquidity upper proxy=March reported cash 9.608902+June unutilized IPO 49.03−infer red CWM payment 1=57.638902. It omits unknown intervening CFO/deployment, explicitly not October cash. Constrained variant uses only March bank/cash+June IPO−1=48.257818; other cash boundaries 9.608902/34.608902/58.638902 test funds already used. These are analytical states, not equally probable estimates. Debt 0.087822 repaid month 1; no committed new debt assumed;1 crore buffer is an analyst assumption.

Annualized run-rate growth sequences—not reported-year growth—are bear−15/0/5/5/5%, base 25/20/18/15/12%, bull 40/30/25/20/15%. Monthly compounding smooths these rates; last 12 months define terminal revenue/earnings. Ebitda margins bear 8→10%, base 15%, bull 17.5%. Collections 160/115/100 days, payables 65/100/110 days at 72.5% procurement-cost proxy; other operating assets 4%/liabilities 2.7% of sales. Initial ONWC 14.24311 is built from disclosed operating balances and migrated over 6 months. Maintenance/growth cash capex 2.5/3.5/4.5% of sales plus residual LED 12.2688 and CWM 5 over 6 months. Assets depreciate 20% annual WDV and rights over 10 years as analytical assumptions; wages/rent/media costs remain expensed. No Ind ASlease-debt addback is mixed with Indian GAAP EBITDA. No dividends or interest income are credited; retained cash appears only once in terminal equity.

|Path|Terminal revenue|EBITDA|Cash|Exit price|Illustrative IRR|Funding floor breach|
|---|---|---|---|---|---|---|
|bear|122.42|12.24|44.75|108.96|-23.69%|None in model|
|base|275.49|41.32|102.41|499.76|3.49%|None in model|
|bull|374.92|65.61|145.36|998.31|18.85%|None in model|
|linked_failure|71.90|4.31|11.01|27.22|-42.18%|5|

Dcf cross-check discounts monthly FCFF=EBIT−positive operating tax+D&A−capex−rights investment−ΔONWC. Terminal NOPAT grows 2/4/5% with 25% assumed marginal ROIC; terminal reinvestment=g/ROIC, not growth without funding. Rates 12/15/18% are separate sensitivity assumptions, not automatically equated to hurdle. Terminal multiple EV converts to equity by adding terminal cash and subtracting remaining debt; current cash is not added again. Rescue counterfactual issues discounted equity at 60% of entry, dilutes current holders and is **not evidence funds are available**. Its DCF is enterprise/pre-financing diagnostic, not diluted holder value. Any unfunded path's later cash/terminal value is diagnostic continuation only; no valid going-concern return is claimed.

|Discount rate|Terminal growth|Conditional DCF price|Terminal EV PV share|
|---|---|---|---|
|12%|2%|182.97|82.8%|
|12%|4%|201.27|84.9%|
|12%|5%|214.13|86.1%|
|15%|2%|143.97|78.5%|
|15%|4%|151.52|80.1%|
|15%|5%|156.30|81.0%|
|18%|2%|120.17|74.6%|
|18%|4%|123.61|75.8%|
|18%|5%|125.64|76.4%|

Base exit-price hurdle entry sensitivity: 12% hurdle → ₹283.58, 15% hurdle → ₹248.47, 18% hurdle → ₹218.45.

|Annual run-rate growth shift|EBITDA margin shift|Exit multiple|Conditional IRR|
|---|---|---|---|
|-10%|-3%|8|-12.56%|
|-10%|-3%|12|-7.24%|
|-10%|-3%|16|-2.92%|
|-10%|+0%|8|-8.69%|
|-10%|+0%|12|-3.10%|
|-10%|+0%|16|1.43%|
|-10%|+3%|8|-5.39%|
|-10%|+3%|12|0.43%|
|-10%|+3%|16|5.15%|
|+0%|-3%|8|-7.36%|
|+0%|-3%|12|-1.13%|
|+0%|-3%|16|3.83%|
|+0%|+0%|8|-2.99%|
|+0%|+0%|12|3.49%|
|+0%|+0%|16|8.66%|
|+0%|+3%|8|0.70%|
|+0%|+3%|12|7.40%|
|+0%|+3%|16|12.76%|
|+10%|-3%|8|-1.88%|
|+10%|-3%|12|5.21%|
|+10%|-3%|16|10.78%|
|+10%|+0%|8|2.96%|
|+10%|+0%|12|10.28%|
|+10%|+0%|16|16.06%|
|+10%|+3%|8|7.03%|
|+10%|+3%|12|14.56%|
|+10%|+3%|16|20.52%|

Reverse expectations for a 15% return: 8 x exit EBITDA needs a +29.5% annual growth-rate shift over the base path; 12 x exit EBITDA needs a +16.8% annual growth-rate shift over the base path; 16 x exit EBITDA needs a +8.6% annual growth-rate shift over the base path. All are conditional, not probabilities.

Base execution-cost illustration (2% entry uplift and 2% exit deduction): 2.66% IRR.


Execution cost sensitivity: a 2% higher effective entry plus 2% exit cost lowers the base illustrative IRR; it does not assume a spread quote or executable block. No probabilities assigned. Conditional hurdle-entry prices do not authorize purchase while G2 unresolved.

## 11. Bear Case & Permanent-Loss Path

The thesis-break variable is **cash yield after media-right renewals and advertiser collections**, not headline portfolio size. Loss of an agency/BFSI advertiser or site-right access reduces sold slots; fixed rent and vendor commitments compress margins; agencies slow payments while media vendors shorten credit; LED/CWM spending continues before yields mature. Existing term deposits may be unavailable and Ipo cash committed. This linked path is modeled with−40% first-year run-rate growth,−2% margin,240 receivable/35 payable days, capex still required and no assumed new financing. Funding-floor breach is reported explicitly, not concealed by zeroing cash. Failure is conditional and does not establish company default/fraud. [S01 risk disclosures; model_outputs.json]

Strongest counterevidence: FY26 positive CFO, low borrowings, Ipo cash then verified, increasing digital mix and actual new rights. A prompt conversion of unbilled balances to cash and reconciled financial history could improve this conclusion. Conversely a lower quoted price cannot resolve missing reliability evidence. Material valuation downside can arise even without insolvency: bear lower growth/margin and 7 x terminal EBITDA produce substantial equity value loss. Recoverable assets include cash, collectible advertiser balances and transferable economic rights—but rights are not freely saleable owned property. No unsupported liquidation recovery is claimed.

## 12. 5× / 10× Feasibility

Speculative/unsupported as a durable investment thesis. Five-year 5 x requires 37.97% annual price growth and 10 x 58.49%; with unchanged multiple/margin and no further dilution, earnings/revenue must scale comparably. Starting from current-share EPS ₹13.879,5 x/10 xprice at 30.34 x would require EPS ₹69.40/₹138.79 (PAT≈₹83.08/₹166.16 crore), before defending the high multiple. At 15 x terminal P/E, required Pat roughly ₹168.02/₹336.04 crore. This outstrips the conditional bull path and requires accessible physical inventory, collections and funding not yet demonstrated. Exact success probabilities or multibagger targets are unwarranted.

## 13. Monitoring Plan

|KPI / baseline|Milestone or alert|Thesis-break/review condition|Timing/source|
|---|---|---|---|
|FY25 equity difference ₹4.953 crore|Matched FY25→FY26 AS 5/revenue/tax reconciliation|Continued material unreconciled financial series maintains G2 Hold, not automatic fraud|Next audited filing; S01/S03|
|FY26 unbilled ₹3.0142; closing AR 114 days|Invoice/collection cohort and current ageing|Rising>160 days alongside weak margin triggers linked funding review|Half-year results; S03|
|Ipo june unutilized ₹49.03|Bank-to-object-to-asset reconciliation, no double count|Unexplained material deviation requires G1/G2 review|Quarterly monitor; S04|
|Seven Led plan;₹0.45 spent June|Commissioning dates, physical screens, sold slots/yield|Renewal-adjusted cash returns below capital cost refute Cap thesis|FY27 deadline; S01/S04|
|CWMtotal ₹7.5/20 screens/50% net profits|₹2.5 paid bridge,₹5 balance and actual profit remittances|No enforceable rights/receipts after deployment period require impairment review|Next results; S01/S04|
|222 reported units=80 static+142 digital|Physical board/slot denominator reconciled|Count growth without cash yield cannot justify growth rating|Operational updates; S07|
|Promoter leases /₹0.90 monthly reference|Matched period rent, approvals, renewals|Loss of critical rights or evidenced abuse changes G1/DUR|Annual report/renewal; S01/S03|
|₹5 lakh monthly Shirdi consideration|Executed agreement, advertiser bookings and net margin|Persistent negative yield after launch triggers allocation review|First operating year; S08|
|600-share lot;20 session ADV 30,510|Actual bid depth/lot execution before allocation|Repeated no-bid sessions can move G4 to Hold|At proposed trade; S10/S11|

Thresholds are scenario-linked alerts, not universal rules or automatic trades. No reminders/automations created.

## 14. Final Classification & Conditional Action

**Hold — unresolved; research-priority reconciliation, not eligible for investment consideration.** BQS/GQS/IAS remain NS, outside ranked numeric tables. Specific missing critical factors: REV,CAP,EARN and supported R; G2 restricts quality rankings because financial comparability is central. Known factors remain separately scored and auditable. There is no overall blended score and no governance avoid/default label. Even if accounts reconcile, conditional base returns at ₹421.05 are weak; any future IAS must be recomputed with verified current cash, normalized earnings and investable execution. New evidence matters before price. No global registry, Git, Library upload or publication occurs in this producer work; separate review required.

## 15. Sources, Assumptions & Open Questions

- **S01** [RHP, approved 1 May 2026; restated examination 2 April 2026](https://nsearchives.nseindia.com/emerge/corporates/content/SimcaAdvertisingLimited_RHP.pdf); retrieved 2026-10-25.
- **S02** [FY26 results and July18 clarification, filed July20 2026](https://nsearchives.nseindia.com/corporate/SIMCA_20072026165250_NSE_Intimation_Clarification_on_H2_Financials.pdf); retrieved 2026-10-25.
- **S03** [FY26 annual report, filed September22 2026](https://archives.nseindia.com/annual_reports/SME_AR_32069_SIMCA_2025_2026_A_12030332_22092026144744.pdf); retrieved 2026-10-25.
- **S04** [June30 IPO monitoring report, August27 2026](https://nsearchives.nseindia.com/corporate/SIMCA_27082026151947_NSE_Intimation_Monitoring_Agency_Report.pdf); retrieved 2026-10-25.
- **S05** [July14 2026 business update](https://nsearchives.nseindia.com/corporate/SIMCA_14072026155928_NSE_Intimation_Q1_Business_Update.pdf); retrieved 2026-10-25.
- **S06** [July14 corrected approximate Q1 revenue](https://nsearchives.nseindia.com/corporate/SIMCA_14072026144648_NSE_Corrigendum_to_Update.pdf); retrieved 2026-10-25.
- **S07** [September8 new media rights](https://nsearchives.nseindia.com/corporate/SIMCA_08092026161446_NSE_Intimation_Acquisition_of_New_Media_Sites_07092026.pdf); retrieved 2026-10-25.
- **S08** [October15 Shirdi license award](https://nsearchives.nseindia.com/corporate/SIMCA_15102026151853_Intimation_to_exchnage_for_Advertising_Rights_of_Shirdi_Airport_151026.pdf); retrieved 2026-10-25.
- **S09** [June8 conference call filed June12](https://nsearchives.nseindia.com/corporate/SIMCA_12062026194222_NSE_Intimation_-_Transcript.pdf); retrieved 2026-10-25.
- **S10** [19 October official security master](https://nsearchives.nseindia.com/content/cm/interop/NSE_CM_security_19102026.csv.gz); retrieved 2026-10-25.
- **S11** [Official daily bhavcopies, 60 sessions July24–October19](https://nsearchives.nseindia.com/content/cm/BhavCopy_NSE_CM_0_0_0_20261019_F_0000.csv.zip); retrieved 2026-10-25.
- **S12** [FY26 integrated filing, July18 corrected denomination](https://nsearchives.nseindia.com/corporate/ixbrl/INTEGRATED_FILING_NONINDAS_175715_18072026142127_iXBRL_WEB.html); retrieved 2026-10-25.

Detailed business claims B10–B31, peer primary links and conflicts are retained in business_notes.md; financial_inputs.json preserves exact period/vintage and financial_metrics.json formulas are rebuilt by analyze.py. market_rows.json contains only issuer rows over 60 dated sessions; market_provenance.json preserves official source/hash line age. Model inputs, all monthly paths, conditional funding failures, sensitivities, reverse expectations and exact original unpublished internal draft summaries are retained without raw source files. Historical full code/input/monthly snapshots were not frozen, so those summaries are incomplete and not claimed historically replayable. The current 46-path model is complete; no reconstructed outputs are presented as original history. Source-safe archives contain no PDF/OCR, bank accounts, personal IDs or private filesystem paths.

Open questions: exact AS 5/recognition bridge; subsequent cash realization; actual October unrestricted cash and Ipo deployment; debt/lease commitments; source of ₹1 crore CWM paid bridge; commissioning and useful-life confirmation; direct contract renewals; latest pledge/fully diluted claims; gross/net principal-agent policy and physical volume/yield. Source failures are not silently filled: company IRpage 404; call Pdf text blank; initial Python requests library unavailable (curl worked); Bright old URLHTML/screenshot verification failed but alternative primary comparative read. No Chromium launched, no denied action bypassed. Primary FY26 financial pages were visually read; extracted OCR is private processing only and not archived. Information retrieved after cutoff is only used where document date precedes cutoff; post-cutoff results/quotes excluded.
