from pathlib import Path
import json,re,html,hashlib
P=Path(__file__).resolve().parent
load=lambda n:json.loads((P/n).read_text())
S=load('scores.json');F=load('financial_inputs.json');M=load('financial_metrics.json');O=load('model_outputs.json');market=load('market_metrics.json')
def table(headers,rows):return '|'+ '|'.join(headers)+'|\n|'+'|'.join(['---']*len(headers))+'|\n'+'\n'.join('|'+'|'.join(str(c)for c in r)+'|'for r in rows)
scores=table(['Score','Raw/final','Coverage','Missing factors','Mathematical bound','Eligibility'],[[k,'NS / NS',f"{s['coverage']:.0%}",', '.join(s['missingness']),f"{s['bounds'][0]:.3f}–{s['bounds'][1]:.3f}",'Not ranking eligible']for k,s in S['scores'].items()])
factors=table(['Factor','Score','Evidence/reason'],[[k,v['score'],v['rationale']]for k,v in S['factors'].items()])
history=table(['Period / vintage','Revenue','PAT','CFO','Capex','Equity','AR','AP','Cash','Debt'],[[r['period']+' / '+r['vintage']]+[f'{r[x]:.4f}'for x in ['revenue','pat','cfo','capex','equity','ar','ap','cash','debt']]for r in F['rows']])
growth=table(['Comparable series','Endpoints','Annual addition','Growth / caveat'],[['RHP FY24→FY25','49.3050→74.9446','25.6396','52.00%, one full-year interval'],['Statutory FY25→FY26','72.832594→127.218100','54.385506','74.67%, statutory comparison; no claim reconciled to RHP'],['FY23 stub→FY24 RHP','11.9557→49.3050','37.3493','NM as equal-full-year organic comparison']])
val=table(['Path','Terminal revenue','EBITDA','Cash','Exit price','Illustrative IRR','Funding floor breach'],[[p['name']]+[f"{p['summary'][x]:.2f}"for x in ['terminal_revenue','terminal_ebitda','terminal_cash','exit_price']]+[f"{p['summary']['illustrative_irr']:.2%}",p['summary']['first_funding_gap_month']or'None in model']for p in O['paths'][:4]])
b=O['paths'][1]['summary'];grid=table(['Discount rate','Terminal growth','Conditional DCF price','Terminal EV PV share'],[[f"{d['rate']:.0%}",f"{d['g']:.0%}",f"{d['price']:.2f}",f"{d['terminal_fraction']:.1%}"]for d in b['dcf_grid']])
grid+='\n\nBase exit-price hurdle entry sensitivity: '+', '.join(f"{h}% hurdle → ₹{b[f'required_entry_{h}pct']:.2f}"for h in [12,15,18])+'.\n\n'
grid+=table(['Annual run-rate growth shift','EBITDA margin shift','Exit multiple','Conditional IRR'],[[f"{p['assumptions']['growth_shift']:+.0%}",f"{p['assumptions']['margin_shift']:+.0%}",p['assumptions']['multiple'],f"{p['summary']['illustrative_irr']:.2%}"]for p in O['sensitivity_paths']])
grid+='\n\nReverse expectations for a 15% return: '+ '; '.join(f"{r['multiple']}x exit EBITDA needs a {r['annual_growth_shift']:+.1%} annual growth-rate shift over the base path"for r in O['reverse_expectations'])+'. All are conditional, not probabilities.\n\n'
grid+=f"Base execution-cost illustration (2% entry uplift and 2% exit deduction): {((b['exit_price']*.98/(421.05*1.02))**.2-1):.2%} IRR.\n"
sources='\n'.join(f"- **{s['id']}** [{s['title']}]({s['url']}); retrieved {s['accessed']}."for s in load('source_ledger.json'))
s=(P/'report_sections.md').read_text()
for k,v in dict(SCORES=scores,FACTORS=factors,HISTORY=history,GROWTH=growth,VALUATION=val,SENSITIVITY=grid,SOURCES=sources).items():s=s.replace('{{'+k+'}}',v)
# Repair compact editorial token joins without changing numbers, identifiers, URLs or formulas.
words=['cash','flow','equity','income','period','financial','statement','revenue','growth','price','value','return','capital','rights','margin','model','current','reported','statutory','unrestricted','operating','normalized','terminal','initial','funding','unbilled','receivable','payable','year','month','share','hurdle','entry','exit','base','bull','bear','conditional','evidence','source','company','primary','cutoff','average','closing','annual','monthly','interim','dated','actual','positive','negative','gross','net','tax','debt','low','high','new','old','total','original','restated','digital','physical','audited','prior','quarterly','permanent','strongest','no','before','after','with','without','not','and','or','of','to','in','the','for']
repls={'currentcash':'current cash','receivablebalances':'receivable balances','cashrealization':'cash realization','growthrating':'growth rating','cashyield':'cash yield','financialhistory':'financial history','reportedcash':'reported cash','netfinancing':'net financing','per-share':'per-share','unfunded':'unfunded','unmodified':'unmodified','cashflows':'cash flows','cashflow':'cash flow','shareholding':'shareholding','yearrun':'year run','cashgeneration':'cash generation','normalization-margin':'normalization margin','fiveyear':'five year','sourceof':'source of','source-safe':'source-safe','fullydilutedclaims':'fully diluted claims','latestpledge':'latest pledge','newfinancing':'new financing','noenforceable':'no enforceable','commissioningdates':'commissioning dates','soldslots':'sold slots','automatically':'automatically','one-sided':'one-sided','performance':'performance','sourcefailures':'source failures','sameperiod':'same period','cross-check':'cross-check','comparability':'comparability'}
# Apply only prose, not links/URLs. Digit boundaries improve financial readability.
joins={a+b:a+' '+b for a in words for b in words}
lines=[]
for line in s.splitlines():
 if 'https://' not in line:
  line=re.sub(r'(?<=[a-zA-Z%])(?=[₹0-9])|(?<=[0-9%])(?=[A-Za-z₹])',' ',line)
  line=re.sub(r'(?<=[a-z])(?=[A-Z])',' ',line)
  for a,b2 in repls.items():line=line.replace(a,b2)
  # Most joins are exact domain phrase combinations; split common words only when full suffix is recognizable.

 lines.append(line)
# Dictionary segmentation applies only to unknown conjoined prose tokens.
from functools import lru_cache
dictionary=set(re.findall(r"[A-Za-z]+",(P/'framework.md').read_text().lower()))
dictionary.update("advertiser advertisers bank accounts cashflow unutilized June October July September February commissioning cohort physical occupancy static digital purported issuer annualisation aligned inferences normalization normalized unbilled loan loans sweep taxpayer before afterward interim corroboration normative effective rights units net profits default current audited filing allocation remuneration invoices inspect all rows paths synthetic python requests library unavailable curl worked HTML launched Chromium subsequent read visually extracted private processing archived trade deposit deposits booked hardware renewed direct fully diluted comparative paperwork total denominator reconciled no linked reported missing capital source safe returns positive negative still report quote quoted locked implied funding interest material matched executed continued unexplained next used where only actual monthly automatic first root signoff peer primary no profit collection verification blank screenshots systematic success probabilities increase increasing cash yield debt outflow terminal enterprise discounted borrower linked credit bank taxes each financial physical inventory qualitative consideration cost actual edited owns thereof unspent unresolved supplemented inspect".lower().split())
@lru_cache(None)
def splitword(word):
 if word in dictionary:return (word,)
 best=None
 for i in range(3,len(word)-2):
  a=word[:i]
  if a not in dictionary:continue
  tail=splitword(word[i:])
  if tail and (best is None or len(tail)+1<len(best)):best=(a,)+tail
 return best
def fixword(match):
 word=match.group();parts=splitword(word.lower())
 if parts and len(parts)>1:
  result=' '.join(parts)
  return result[0].upper()+result[1:] if word[0].isupper() else result
 return word
fixed=[]
for line in lines:
 if 'https://' not in line:
  line=re.sub(r'\b[A-Za-z]{7,}\b',fixword,line)
  line=line.replace('INE 1 K 4 J 01018','INE1K4J01018').replace('v 3.0','v3.0').replace('in to','into')
  line=re.sub(r'\b(S|B|F|G|FY|Q) ([0-9]+)',r'\1\2',line)
  line=line.replace('PDFpp','PDF pp').replace('IPOcash','IPO cash')
 
 for a,b2 in {'Actualbiddepth': 'Actual bid depth', 'Anyunfunded': 'Any unfunded', 'Atproposedtrade': 'At proposed trade', 'Brightold': 'Bright old', 'CWMpaidbridge': 'CWM paid bridge', 'CWMpayment': 'CWM payment', 'Executedagreement': 'Executed agreement', 'GAAPEBITDA': 'GAAP EBITDA', 'Libraryupload': 'Library upload', 'Marchbank': 'March bank', 'Marchreported': 'March reported', 'Matchedperiodrent': 'Matched period rent', 'Noenforceablerights': 'No enforceable rights', 'OCRisprivateprocessingonlyandnotarchived': 'OCR is private processing only and not archived', 'Operationalupdates': 'Operational updates', 'Physicalboard': 'Physical board', 'Recoverableassets': 'Recoverable assets', 'Repeatedno': 'Repeated no', 'Shirdiconsideration': 'Shirdi consideration', 'Unexplainedmaterialdeviation': 'Unexplained material deviation', 'afterlaunch': 'after launch', 'alternativeprimarycomparativeread': 'alternative primary comparative read', 'balanceandactualprofitremittances': 'balance and actual profit remittances', 'collectibleadvertiserbalances': 'collectible advertiser balances', 'datedsessions': 'dated sessions', 'deniedactionbypassed': 'denied action bypassed', 'directcontractrenewals': 'direct contract renewals', 'equitydifference': 'equity difference', 'financialcomparability': 'financial comparability', 'globalregistry': 'global registry', 'lowborrowings': 'low borrowings', 'meaningfulsupersededvintages': 'meaningful superseded vintages', 'netprincipalagentpolicy': 'net principal-agent policy', 'nofurtherdilution': 'no further dilution', 'overallblendedscore': 'overall blended score', 'ownedproperty': 'owned property', 'privatefilesystempaths': 'private filesystem paths', 'producerwork': 'producer work', 'quotesexcluded': 'quotes excluded', 'repaidmonth': 'repaid month', 'screenshotverificationfailed': 'screenshot verification failed', 'slotdenominatorreconciled': 'slot denominator reconciled', 'transferableeconomicrights': 'transferable economic rights', 'unchangedmultiple': 'unchanged multiple', 'unreconciledfinancialseries': 'unreconciled financial series', 'validgoing': 'valid going', 'withoutduplicatingrawsourcefiles': 'without duplicating raw source files', 'xterminal': 'x terminal', 'zeroingcash': 'zeroing cash'}.items():line=line.replace(a,b2)
 fixed.append(line)
lines=fixed
s='\n'.join(lines)+'\n';(P/'report.md').write_text(s)
# Deterministic HTML with semantic tables; no external scripts/assets.
parts=[];in_table=False;in_list=False
for line in s.splitlines():
 if line.startswith('|'):
  if re.match(r'^\|[-|: ]+\|$',line):continue
  if not in_table:parts.append('<table>');in_table=True;tag='th'
  else:tag='td'
  parts.append('<tr>'+''.join(f'<{tag}>'+html.escape(x.strip())+f'</{tag}>'for x in line.strip('|').split('|'))+'</tr>');continue
 if in_table:parts.append('</table>');in_table=False
 if not line.strip():continue
 level=len(line)-len(line.lstrip('#'))
 content=html.escape(line[level:].strip()if level else line)
 content=re.sub(r'\*\*(.*?)\*\*',r'<strong>\1</strong>',content)
 content=re.sub(r'\[([^\]]+)\]\((https?://[^)]+)\)',r'<a href="\2">\1</a>',content)
 parts.append(f'<h{min(level,6)}>{content}</h{min(level,6)}>'if level else '<p>'+content+'</p>')
if in_table:parts.append('</table>')
(P/'report.html').write_text('<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width"><title>Simca Advertising — Position 380</title><style>body{font:16px/1.6 system-ui,sans-serif;max-width:1150px;margin:40px auto;padding:0 24px;color:#18262d;background:#fafbfc}h1,h2{color:#063c53}h2{margin-top:48px;border-bottom:2px solid #bacdd7}table{border-collapse:collapse;width:100%;font-size:13px;display:block;overflow-x:auto;margin:24px 0}td,th{border:1px solid #cbd8df;padding:9px;text-align:left}th{background:#e5eef2}a{color:#006288}strong{color:#064a60}@media print{body{font-size:11px}h2{break-after:avoid}tr{break-inside:avoid}}</style><main>'+''.join(parts)+'</main></html>')
