# Simca Advertising Limited — position 380

Frozen producer dossier for separate independent review, not self-accepted or published.

- Information cutoff: 20 October 2026; actual traded quote: 19 October 2026, ₹421.05.
- Legal identity: Simca Advertising Limited, NSE Emerge SIMCA, INE1K4J01018.
- Conclusions: BQS/GQS/IAS NS; G2 Hold for financial-vintage comparability. Explicitly not a misconduct/default finding.
- `report.md` and `report.html`: all 15 v3.0 sections.
- `financial_inputs.json`, `business_notes.md`, `market_rows.json`: source-safe evidence inputs.
- `model.py`: deterministic 60-month linked financial/funding model; model outputs include failed continuations, sensitivities and rescue dilution. These remain conditional, not supported price forecasts.
- `model_proof.py`: independent algebra verifier; does not import producer model.
- `model_vintages/`: exact original unpublished internal draft summaries, with explicit completeness/provenance limitations in update_log.json. Original full historical code/inputs/monthly outputs were not frozen; these summaries are not claimed replayable. Newly reconstructed compatibility diagnostics are excluded. The current46-path model is complete and independently reproducible.
- `company_record.json`: noncircular role hashes and per-score ranking eligibility.

Run `python rebuild.py` using Python 3.12 standard library only. No network, browser, raw PDFs or OCR needed. Run `python cold_rebuild.py` to prove recovery after deletion of generated files; it uses an isolated temporary copy. `python package.py` builds deterministic full and compact archives. The compact archive omits only large reproducible model-output/CSV expansions; code and source-safe inputs reconstruct them exactly. Manifest and external handoff hashes document this distinction.

Static HTML was checked structurally; no Chromium or visual-browser claim. Raw source processing files are not included in either archive. Separate reviewer acceptance is required before root publication or Library upload.
