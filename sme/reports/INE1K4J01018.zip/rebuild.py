from pathlib import Path
import subprocess,sys,json,hashlib
P=Path(__file__).resolve().parent
for x in ['prepare_inputs.py','model.py','analyze.py','build_report.py','model_proof.py','finalize.py']:
 r=subprocess.run([sys.executable,str(P/x)],cwd=P,capture_output=True,text=True)
 if r.returncode:raise RuntimeError(x+'\n'+r.stdout+r.stderr)
print('Offline rebuild PASS')
