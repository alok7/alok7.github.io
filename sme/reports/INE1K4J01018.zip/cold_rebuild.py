from pathlib import Path
import tempfile,shutil,subprocess,sys,json,hashlib,zipfile
P=Path(__file__).resolve().parent;manifest=json.loads((P/'build_manifest.json').read_text());generated=manifest['generated_outputs'];sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();results=[]
for role in ['full','compact']:
 archive=next(P.glob('*source_safe_'+role+'.zip'))
 with tempfile.TemporaryDirectory(prefix='simca_cold_') as t:
  with zipfile.ZipFile(archive)as z:z.extractall(t)
  root=Path(t)/'Simca_Advertising_380';before=[]
  for name in generated:
   p=root/name
   if p.exists():p.unlink()
   before.append(not p.exists())
  r=subprocess.run([sys.executable,str(root/'rebuild.py')],cwd=root,capture_output=True,text=True)
  if r.returncode:raise RuntimeError(r.stdout+r.stderr)
  mismatches=[n for n in generated if sha(root/n)!=manifest['files'][n]['sha256']]
  if mismatches:raise AssertionError(mismatches)
  results.append({'archive':archive.name,'archive_sha256':sha(archive),'generated_absent_before_rebuild':all(before),'reconstructed':len(generated),'hash_mismatches':mismatches,'network_needed':False})
(P/'cold_rebuild_proof.json').write_text(json.dumps({'status':'PASS','results':results,'manifest_sha256':sha(P/'build_manifest.json')},indent=2)+'\n')
print('Cold full and compact rebuild PASS')
