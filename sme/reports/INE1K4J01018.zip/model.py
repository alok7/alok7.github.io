"""Conditional monthly model, INR crore. No financing availability is presumed."""
import json,math,csv,itertools
from pathlib import Path
P=Path(__file__).resolve().parent
F=json.loads((P/'financial_inputs.json').read_text()); f=F['fy26']; M=json.loads((P/'market_metrics.json').read_text())
SC={'bear':dict(growth=[-.15,0,.05,.05,.05],margin=[.08,.09,.10,.10,.10],days=160,paydays=65,multiple=7,capex_ratio=.025), 'base':dict(growth=[.25,.20,.18,.15,.12],margin=[.15]*5,days=115,paydays=100,multiple=12,capex_ratio=.035), 'bull':dict(growth=[.40,.30,.25,.20,.15],margin=[.175]*5,days=100,paydays=110,multiple=16,capex_ratio=.045),'linked_failure':dict(growth=[-.40,-.10,0,.03,.03],margin=[-.02,.02,.04,.05,.06],days=240,paydays=35,multiple=5,capex_ratio=.025)}
opening_wc=f['ar']+f['operating_deposits']+f['supplier_advance']+f['prepaid']-f['ap']-f['other_operating_liabilities']
inputs={'version':'v3','horizon_start':'2026-10-20','horizon_end':'2031-10-20','months':60,'anchor':'FY26 statutory operating scale; synthetic opening liquidity, NOT October balance sheet or FY27 forecast','tax':.27,'cash_floor':1,'initial_cash':f['cash']+49.03-1.0,'cash_sensitivity':[9.608902,34.608902,58.638902],'initial_wc':opening_wc,'initial_ppe':f['ppe_including_cwip'],'initial_rights':2.5,'initial_debt':f['debt'],'initial_shares_crore':M['shares']/1e7,'entry':M['price'],'minimum_financing_commitment':0,'rights_bridge':'S04 states2.5 paid while March S02 rights asset1.5. Infer1.0 intervening payment: subtract1 from synthetic liquidity and add1 to rights. No assertion of actual October cash.','new_equity_discount':.4,'maintenance_policy':'cash capex scenario ratio plus residual IPO LED12.2688 and CWM5; 6 month deployment unless delayed. Existing asset depreciation20% WDV annual; rights amortization10 years. Not management forecast.','unutilized_cash_caveat':'June30 ring-fenced IPO proceeds are deployment funds, not distributable surplus; never add gross IPO again. S04 rounds 49.03; no Jun-Oct operating or deployment bridge verified.','scenarios':SC}
(P/'model_inputs.json').write_text(json.dumps(inputs,indent=2)+'\n')
def run(name='base',growth_shift=0,margin_shift=0,days_shift=0,multiple=None,cash=None,delay=0,rescue=False):
 s=SC[name];cash=inputs['initial_cash'] if cash is None else cash;initial_cash=cash;wc=opening_wc;ppe=inputs['initial_ppe'];rights=inputs['initial_rights'];debt=f['debt'];shares=inputs['initial_shares_crore'];rev=f['revenue'];rows=[];fails=[];funding=0;cum=0;first=None
 for month in range(1,61):
  year=(month-1)//12;growth=s['growth'][year]+growth_shift;rev*=max(.05,1+growth)**(1/12);revenue=rev/12
  margin=s['margin'][year]+margin_shift;ebitda=revenue*margin
  da=ppe*(1-(1-.20)**(1/12)); amort=min(rights,(inputs['initial_rights']+ (5 if month>delay+6 else 0))/120);ebit=ebitda-da-amort;interest=debt*.12/12;tax=max(0,ebit-interest)*.27;pat=ebit-interest-tax
  days=s['days']+days_shift;ar=rev*days/365;ap=rev*.725*s['paydays']/365;target_wc=ar+rev*.04-ap-rev*.027
  # Gradual six-month migration; stress permanently changes collections/credit terms.
  next_wc=wc+(target_wc-wc)/(7-month) if month<=6 else target_wc;dwc=next_wc-wc
  led=12.2688/6 if delay<month<=delay+6 else 0;newrights=5/6 if delay<month<=delay+6 else 0;capex=revenue*s['capex_ratio']+led
  fcff=ebit-max(0,ebit)*.27+da+amort-dwc-capex-newrights
  cfo=pat+da+amort-dwc;repay=debt if month==1 else 0;before=cash+cfo-capex-newrights-repay;need=max(0,1-before);eq=0;newshares=0
  if need>1e-9:
   if first is None:first=month
   if rescue:eq=need;newshares=eq/(M['price']*.6);shares+=newshares;funding+=eq
   else:fails.append({'month':month,'shortfall_to_floor':need,'negative_cash':before<0})
  close=before+eq;ppe+=capex-da;rights+=newrights-amort;debt-=repay;cum+=pat
  rows.append(dict(month=month,year=year+1,revenue=revenue,ebitda=ebitda,da=da,amortization=amort,ebit=ebit,interest=interest,tax=tax,pat=pat,opening_cash=cash,cfo=cfo,capex=capex,rights_capex=newrights,delta_wc=dwc,wc=next_wc,fcff=fcff,debt_repayment=repay,equity_raise=eq,new_shares_crore=newshares,shares_crore=shares,closing_cash=close,ppe=ppe,rights=rights,debt=debt,shortfall=need))
  cash=close;wc=next_wc
 last12=rows[-12:];terminal_ebitda=sum(r['ebitda'] for r in last12);mult=s['multiple'] if multiple is None else multiple;terminal_ev=max(0,terminal_ebitda*mult);terminal_equity=max(0,terminal_ev+cash-debt);exit_price=terminal_equity/shares;irr=(exit_price/M['price'])**.2-1 if exit_price else -1
 # Terminal FCFF explicitly includes sustainable reinvestment; 4% growth /25% marginal ROIC assumption.
 terminal_nopat=sum(r['ebit'] for r in last12)*.73;terminal_fcff=max(0,terminal_nopat*1.04*(1-.04/.25));dcfs=[]
 for rate,g in itertools.product([.12,.15,.18],[.02,.04,.05]):
  terminal=max(0,terminal_nopat*(1+g)*(1-g/.25))/(rate-g);pv=sum(r['fcff']/((1+rate)**(r['month']/12)) for r in rows);tpv=terminal/(1+rate)**5;ev=pv+tpv;equity=max(0,ev+initial_cash-f['debt']);dcfs.append(dict(rate=rate,g=g,price=equity/inputs['initial_shares_crore'],terminal_fraction=tpv/ev if ev>0 else None))
 return {'name':name,'assumptions':dict(growth_shift=growth_shift,margin_shift=margin_shift,days_shift=days_shift,multiple=mult,initial_cash=initial_cash,delay_months=delay,rescue=rescue),'rows':rows,'summary':dict(valuation_status=('Diagnostic only: unfunded continuation' if fails else 'Conditional, not supported investment forecast'),dcf_scope=('Enterprise/pre-financing DCF only; NOT rescue holder value' if rescue else 'Conditional equity cross-check; invalid as executable value after funding failure'),terminal_revenue=sum(r['revenue'] for r in last12),terminal_ebitda=terminal_ebitda,terminal_ev=terminal_ev,terminal_cash=cash,terminal_debt=debt,terminal_equity=terminal_equity,exit_price=exit_price,illustrative_irr=irr,valid_going_concern_return=not fails,first_funding_gap_month=first,minimum_cash=min(r['closing_cash'] for r in rows),maximum_unfunded_gap=max([x['shortfall_to_floor'] for x in fails]or[0]),total_equity_raise=funding,terminal_shares_crore=shares,dilution=shares/inputs['initial_shares_crore']-1,dcf_grid=dcfs,required_entry_12pct=exit_price/1.12**5,required_entry_15pct=exit_price/1.15**5,required_entry_18pct=exit_price/1.18**5),'failure_path':fails}
if __name__=='__main__':
 paths=[run(n) for n in SC]
 for cash in inputs['cash_sensitivity']:
  for n in ['bear','base','linked_failure']:paths.append(run(n,cash=cash))
 paths+=[run('base',cash=.227818+49.03-1),run('bear',cash=.227818+49.03-1),run('linked_failure',cash=.227818+49.03-1),run('base',margin_shift=-.0533),run('linked_failure',cash=9.608902,rescue=True),run('base',delay=12)]
 sensitivities=[run('base',growth_shift=g,margin_shift=m,multiple=x) for g,m,x in itertools.product([-.10,0,.10],[-.03,0,.03],[8,12,16])]
 reverse=[]
 for mult in [8,12,16]:
  lo,hi=-.2,1
  for _ in range(70):
   mid=(lo+hi)/2;r=run('base',growth_shift=mid,multiple=mult)
   if r['summary']['illustrative_irr']<.15:lo=mid
   else:hi=mid
  reverse.append(dict(multiple=mult,annual_growth_shift=(lo+hi)/2,model_return=run('base',growth_shift=(lo+hi)/2,multiple=mult)['summary']['illustrative_irr'],warning='Conditional, not an investable forecast; must also test financing and asset access'))
 out={'inputs_version':'v3','paths':paths,'sensitivity_paths':sensitivities,'reverse_expectations':reverse}
 (P/'model_outputs.json').write_text(json.dumps(out,indent=2)+'\n')
 with (P/'model_main_monthly.csv').open('w') as f2:
  w=csv.DictWriter(f2,fieldnames=['scenario']+list(paths[0]['rows'][0]));w.writeheader()
  for p in paths[:4]:w.writerows(dict(scenario=p['name'],**r) for r in p['rows'])
 print([(p['name'],round(p['summary']['illustrative_irr']*100,2),p['summary']['first_funding_gap_month']) for p in paths[:4]])
