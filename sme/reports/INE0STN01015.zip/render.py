from pathlib import Path
import html,re
P=Path(__file__).resolve().parent

def inline(s):
 s=html.escape(s,quote=False)
 s=re.sub(r'\[([^\]]+)\]\(([^\s)]+)\)',lambda m:f'<a href="{html.escape(m[2],quote=True)}" rel="noreferrer">{m[1]}</a>',s)
 s=re.sub(r'\*\*(.+?)\*\*',r'<strong>\1</strong>',s);s=re.sub(r'`([^`]+)`',r'<code>\1</code>',s)
 return s

def render(md):
 out=[];para=[];table=[];nav=[]
 def flushp():
  if para:out.append('<p>'+inline(' '.join(para))+'</p>');para.clear()
 def flusht():
  if not table:return
  lines=[x for x in table if not re.match(r'^\|[\s:|\-]+\|$',x)];head=lines[0];out.append('<div class="table-scroll"><table><thead><tr>'+''.join('<th scope="col">'+inline(x.strip())+'</th>' for x in head.strip('|').split('|'))+'</tr></thead><tbody>')
  for row in lines[1:]:out.append('<tr>'+''.join('<td>'+inline(x.strip())+'</td>' for x in row.strip('|').split('|'))+'</tr>')
  out.append('</tbody></table></div>');table.clear()
 for l in md.splitlines():
  if l.startswith('|'):flushp();table.append(l);continue
  flusht()
  if not l.strip():flushp();continue
  if l.startswith('#'):
   flushp();level=len(l)-len(l.lstrip('#'));title=l[level:].strip();match=re.match(r'(\d+)\.',title);anchor='s'+match[1] if level==2 and match else 'title'+str(len(out));out.append(f'<h{level} id="{anchor}">'+inline(title)+f'</h{level}>')
   if level==2 and match:nav.append(f'<a href="#{anchor}">'+inline(title)+'</a>')
  else:para.append(l)
 flushp();flusht()
 css='''body{margin:0;background:#f3f5f8;color:#17212d;font:17px/1.6 system-ui,sans-serif}header{background:#102c41;color:white;padding:2rem}main{max-width:1180px;margin:auto;background:white;padding:2rem}nav{display:flex;flex-wrap:wrap;gap:.5rem;margin:1rem 0}nav a{background:#e8eef3;padding:.3rem .6rem;font-size:.85rem}h2{border-top:2px solid #cfdae3;padding-top:1.3rem;margin-top:2.5rem}a{color:#005f91;overflow-wrap:anywhere}header a{color:white}p{overflow-wrap:anywhere}.table-scroll{overflow-x:auto}table{border-collapse:collapse;width:100%;font-size:.9rem}th,td{padding:.55rem;border:1px solid #d2dce3;text-align:left;vertical-align:top}th{background:#e9f0f5}tbody tr:nth-child(even){background:#fafbfd}code{font-size:.85em;background:#f0f3f5;padding:.15rem}.notice{background:#fff4d8;border-left:5px solid #b98517;padding:1rem}@media(max-width:700px){main{padding:1rem}header{padding:1rem}body{font-size:16px}}@media print{nav{display:none}body{background:white}main{padding:0}h2{break-after:avoid}tr{break-inside:avoid}a{color:inherit}}'''
 return '<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Silkflex Polymers (India) Limited — Wallstrat research</title><style>'+css+'</style></head><body><header><strong>WALLSTRAT · SME RESEARCH · POSITION 378</strong><br>20 October 2026 cutoff · Market reference 19 October</header><main><div class="notice"><strong>Research hold. BQS NS · GQS NS · IAS NS.</strong> Conditional modeling, not a recommendation. Private producer freeze; independent acceptance pending.</div><nav aria-label="Report sections">'+''.join(nav)+'</nav>'+''.join(out)+'</main></body></html>\n'
if __name__=='__main__':(P/'report.html').write_text(render((P/'report.md').read_text()))
