"""Offline deterministic rebuild from source-safe inputs; no network or raw reports."""
from pathlib import Path
import runpy
P=Path(__file__).resolve().parent
for script in ['prepare.py','model.py','scoring.py','build_report.py','render.py','verify.py','record.py']:
 runpy.run_path(str(P/script),run_name='__main__')
