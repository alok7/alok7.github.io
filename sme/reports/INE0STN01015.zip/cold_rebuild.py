"""Cold archive rebuild; source documents/network never needed."""
import json,hashlib,zipfile,tempfile,pathlib,subprocess,sys,os
P=pathlib.Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
am=json.loads((P/'archive_manifest.json').read_text());bm=json.loads((P/'build_manifest.json').read_text());proof=[]
for a in am['archives']:
 with tempfile.TemporaryDirectory(prefix='silkflex-cold-') as td:
  root=pathlib.Path(td)
  with zipfile.ZipFile(P/a['filename']) as z:
   assert z.testzip() is None;z.extractall(root)
  d=root/'Silkflex_Polymers_378'
  assert all(sha(d/p)==h for p,h in a['members'].items())
  for p in bm['generated_outputs']:
   x=d/p
   if x.exists():x.unlink()
  # Rebuild subprocess uses stdlib, source-safe package only. Disable networking and deny file reads outside package except runtime imports.
  runner="""import sys,runpy,pathlib,socket,builtins,os
p=pathlib.Path(sys.argv[1]).resolve();sys.path.insert(0,str(p))
def blocked(*a,**k):raise RuntimeError('network forbidden in cold rebuild')
socket.socket=blocked;socket.create_connection=blocked
allowed=[str(p),sys.base_prefix,sys.prefix,'/usr/lib/']
def audit(event,args):
 if event=='open' and isinstance(args[0],(str,bytes,os.PathLike)):
  q=str(pathlib.Path(args[0]).resolve())
  if not any(q.startswith(v) for v in allowed):raise RuntimeError('outside-package file access blocked')
 if event.startswith('socket.') or event=='subprocess.Popen':raise RuntimeError('network/subprocess forbidden in cold rebuild')
sys.addaudithook(audit)
runpy.run_path(str(p/(sys.argv[2] if len(sys.argv)>2 else 'rebuild.py')),run_name='__main__')
"""
  result=subprocess.run([sys.executable,'-c',runner,str(d)],cwd=d,capture_output=True,text=True)
  if result.returncode:raise RuntimeError(result.stdout+result.stderr)
  matches={p:sha(d/p)==bm['files'][p]['sha256'] for p in bm['generated_outputs']};assert all(matches.values()),matches
  vintages=[]
  for v in ['v1','v2','v3','v4']:
   vd=d/'model_vintages'/v
   expected={n:bm['files'][f'model_vintages/{v}/{n}']['sha256'] for n in ['model_summary.json','model_paths.json.gz']}
   for n in expected:
    if (vd/n).exists():(vd/n).unlink()
   r=subprocess.run([sys.executable,'-c',runner,str(vd),'model.py'],cwd=vd,capture_output=True,text=True);assert r.returncode==0,r.stderr
   vm={n:sha(vd/n)==h for n,h in expected.items()};assert all(vm.values()),vm;vintages.append({'vintage':v,'outputs':vm})
  proof.append({'archive':a['filename'],'archive_sha256':a['sha256'],'CRC_and_members_pass':True,'all_generated_outputs_removed_first':True,'current_outputs_byte_equal':matches,'vintages':vintages,'network_disabled':True,'source_safe_inputs_only':True})
(P/'cold_rebuild_proof.json').write_text(json.dumps({'passed':True,'scope':'producer cold-rebuild proof; independent review pending','results':proof},indent=2)+'\n');print('Cold rebuild: both archives and retained vintages byte-identical.')
