import json,csv,statistics,hashlib
from pathlib import Path
P=Path(__file__).resolve().parent
J=lambda f:json.loads((P/f).read_text())
def put(f,x):(P/f).write_text(json.dumps(x,indent=2)+'\n')
f=J('financial_inputs.json');h=f['history'];m={}
for y,r in h.items():
 r['ebit_operating']=r['pbt']+r['finance_cost']-r['other_income']-r.get('exceptional_gain',0);r['ebitda_operating']=r['ebit_operating']+r['da'];r['normalized_pat']=(r['pbt']-r['other_income']-r.get('exceptional_gain',0))*(1-.255);r['nopat']=r['ebit_operating']*(1-.255)
 r['ebitda_margin']=r['ebitda_operating']/r['revenue'];r['receivable_days_closing']=r['receivables']/r['revenue']*365;r['net_debt']=r['debt']-r['cash'];r['interest_coverage']=r['ebit_operating']/r['finance_cost'];r['capital_employed_financing']=r['equity']+r['debt']-r['cash']-r.get('other_bank_deposits',0)
 if str(int(y)-1) in h:
  prev=h[str(int(y)-1)];r['reported_yoy_unverified_comparability']=r['revenue']/prev['revenue']-1;r['revenue_addition']=r['revenue']-prev['revenue'];r['roe_average']=r['pat']/((r['equity']+prev['equity'])/2);r['roic_financing_proxy']=r['nopat']/((r['capital_employed_financing']+prev['capital_employed_financing'])/2)
# Never overwrite input reports with derived fields.
m['history']=h;m['growth']={'five_year_mixed_vintage_cagr':(h['2026']['revenue']/h['2021']['revenue'])**.2-1,'three_year_mixed_vintage_cagr':(h['2026']['revenue']/h['2023']['revenue'])**(1/3)-1,'two_year_later_comparative_cagr':(h['2026']['revenue']/h['2024']['revenue'])**.5-1,'FY26_same_source_yoy':h['2026']['revenue']/h['2025']['revenue']-1,'warning':'mixed-vintage long-window growth is an illustrative reported calculation, not established comparable organic CAGR; REV remains NS'}
m['cash_bridge']={'2025_reported_cfo_latest':-23.5399,'2025_add_current_capital_advance':10.0489,'2025_add_restricted_deposit_movement':1.7378,'2025_reclassified_operating_cfo':-11.7532,'2026_reported_cfo':29.1465,'2026_remove_current_capital_advance_release':-10.0489,'2026_add_restricted_deposit_movement':.1932,'2026_reclassified_operating_cfo':19.2908,'2024_latest_comparative_cfo':8.582378,'three_year_pat':3.929157+7.0004+12.1533,'three_year_reported_cfo':8.582378-23.5399+29.1465,'three_year_reclassified_cfo':8.582378-11.7532+19.2908,'warning':'Reclassification proxy still reflects tax timing, supplier credit and mixed disclosure vintages. It is not clean FCFF; FY24 restatement adds uncertainty.'}
c=m['cash_bridge'];c['reported_ratio_of_sums']=c['three_year_reported_cfo']/c['three_year_pat'];c['reclassified_ratio_of_sums']=c['three_year_reclassified_cfo']/c['three_year_pat'];c['FY26_operating_investment_cash']=57.4573-8.3038-10.0489;c['FY26_FCF_reclassified']=19.2908-c['FY26_operating_investment_cash'];c['FY25_investment_cash']=6.9656+8.3038+10.0489;c['FY25_FCF_reclassified']=-11.7532-c['FY25_investment_cash']
m['incremental_capital']={'FY25_to_FY26_delta_nopat':h['2026']['nopat']-h['2025']['nopat'],'FY25_to_FY26_delta_capital':h['2026']['capital_employed_financing']-h['2025']['capital_employed_financing'],'definition':'financing IC proxy equity+gross debt-cash-long bank deposits; includes operating assets and all technology/CWIP, not an asset-light trading denominator; prior gratuity reserve affects equity; maturation timing limits interpretation'};x=m['incremental_capital'];x['incremental_ROIC_proxy']=x['FY25_to_FY26_delta_nopat']/x['FY25_to_FY26_delta_capital'];put('financial_metrics.json',m)
rows=J('market_rows.json');clean=[]
for x in rows:
 if 'row' not in x:
  clean.append(x);continue
 r=x['row'];clean.append({'date':x['session'],'close':float(r['ClsPric']) if r else None,'volume':int(r['TtlTradgVol']) if r else 0,'turnover_inr':float(r['TtlTrfVal']) if r else 0,'trades':int(r['TtlNbOfTxsExctd']) if r else 0,'high':float(r['HghPric']) if r else None,'low':float(r['LwPric']) if r else None})
put('market_rows.json',clean)
market={'source_template':'https://nsearchives.nseindia.com/content/cm/BhavCopy_NSE_CM_0_0_0_{YYYYMMDD}_F_0000.csv.zip','security_master_url':'https://nsearchives.nseindia.com/content/cm/interop/NSE_CM_security_19102026.csv.gz','quote':clean[-1],'quote_stale':False,'quote_executable':False,'issued_shares':11607000,'lot':1000,'price':260,'market_cap_crore':301.782,'reference_position_inr':500000,'whole_lots_within_reference':1,'whole_lot_value':260000,'note':'Two lots cost520000, above reference; one lot260000 creates material granularity. No live spread/depth observed.'}
for n in [20,60]:
 a=clean[-n:];t=[x['turnover_inr'] for x in a];con=min(statistics.mean(t),statistics.median(t));market[str(n)+'_sessions']={'count':len(a),'active':sum(x['volume']>0 for x in a),'zero':sum(x['volume']==0 for x in a),'mean_turnover':statistics.mean(t),'median_turnover':statistics.median(t),'conservative_turnover':con,'exit_days':{str(v):500000/(con*v) for v in [.02,.05,.1]},'one_price':sum(x['volume']>0 and x['high']==x['low'] for x in a)}
put('market_metrics.json',market)
