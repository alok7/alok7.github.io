import json,gzip,math,copy,re,hashlib
from pathlib import Path
from html.parser import HTMLParser
P=Path(__file__).resolve().parent
J=lambda f:json.loads((P/f).read_text())
def near(a,b,t=1e-7):assert abs(a-b)<t,(a,b)
def audit_path(a,inp):
 cash=inp['opening']['cash']*a['spec'].get('opening_cash_multiplier',1);shares=inp['opening']['shares_crore'];term=inp['opening']['term_debt'];cc=inp['opening']['cash_credit'];related=inp['opening']['related_debt'];first=None;previous_revenue=inp['opening']['revenue']
 for r in a['monthly']:
  near(r['capex'],r['sales']*a['spec']['maintenance_capex_ratio']+max(0,r['revenue_runrate']-previous_revenue)*a['spec']['expansion_capex_incremental_sales']+r['land']+r['machine']+r.get('acquisition',0));previous_revenue=r['revenue_runrate'];near(r['cash_open'],cash);near(r['ocf'],r['ebitda']-r['interest']-r['tax']-r['delta_onwc']);near(r['cash_close'],cash+r['ocf']-r['capex']-r['principal_paid']-r['related_repaid']-r['legacy_claims_paid']+r['equity_cash_in']+r['cc_draw']);near(r['shares'],shares+r['new_shares']);near(r['term_debt'],term-r['principal_paid']);near(r['cc_debt'],cc+r['cc_draw']);near(r['related_debt'],related-r['related_repaid']);assert r['cc_debt']<=20+1e-8
  near(r['interest'],(term*.105+cc*.105+related*.09)/12);near(r['fcff'],r['ebit']-max(0,r['ebit'])*.255+r['da']-r['capex']-r['delta_onwc'])
  if r['shortfall']>1e-8 and first is None:first=r['month']
  cash=r['cash_close'];shares=r['shares'];term=r['term_debt'];cc=r['cc_debt'];related=r['related_debt']
 assert first==a['first_unfunded_month'];assert a['funded']==(first is None)
 if first is not None:assert all(a[k] is None for k in ['irr','dcf_per_share','terminal_per_share','hurdle_entry'])
 else:
  near(a['terminal_ebitda'],sum(x['ebitda'] for x in a['monthly'][-12:]));near(a['terminal_net_debt'],term+cc+related-cash);near(a['terminal_per_share'],max(0,a['terminal_ebitda']*a['terminal_multiple']-a['terminal_net_debt'])/shares)
  ec=a.get('execution_assumptions',{});entry=ec.get('entry_cost',inp['entry_cost']);ex=ec.get('exit_cost',inp['exit_cost']);near(a['irr'],(a['terminal_per_share']*(1-ex)/(260*(1+entry)))**(1/a['years'])-1)
  o=inp['opening'];v=a.get('valuation_assumptions',{});w=v.get('wacc',inp['wacc']);g=v.get('terminal_growth',inp['terminal_growth'])
  opening_cash=o['cash']*a['spec'].get('opening_cash_multiplier',1)
  claims=o['tax_payable_net_tds']+o['gratuity_reserve']+o['contingency']
  expected_bridge={'cash':opening_cash,'term_debt':o['term_debt'],'cash_credit':o['cash_credit'],'related_debt':o['related_debt'],'legacy_claims':claims}
  for k,val in expected_bridge.items():near(a['dcf_opening_bridge'][k],val)
  pv=sum(r['fcff']/(1+w)**(r['month']/12) for r in a['monthly']);inj=sum(r['equity_cash_in']/(1+w)**(r['month']/12) for r in a['monthly'])
  near(a['pv_fcff'],pv);near(a['pv_injections'],inj)
  eq=pv+a['terminal_fcff']/(w-g)/(1+w)**a['years']+opening_cash-o['term_debt']-o['cash_credit']-o['related_debt']-claims+inj
  near(a['dcf_per_share'],max(0,eq)/shares)
 return True

def main():
 inp=J('model_inputs.json');paths=json.loads(gzip.decompress((P/'model_paths.json.gz').read_bytes()));checks={};checks['all_paths_cash_debt_shares_fcff_irr']=all(audit_path(a,inp) for a in paths)
 mutations=[]
 for field in ['cash_close','interest','shares','term_debt','fcff']:
  a=copy.deepcopy(next(x for x in paths if x['funded']));a['monthly'][3][field]+=1
  try:audit_path(a,inp);caught=False
  except AssertionError:caught=True
  mutations.append({'mutation':field+' +1','caught':caught})
 for field in ['dcf_per_share','dcf_opening_bridge']:
  a=copy.deepcopy(next(x for x in paths if x['funded']))
  if field=='dcf_opening_bridge':a[field]['cash']+=1
  else:a[field]+=1
  try:audit_path(a,inp);caught=False
  except AssertionError:caught=True
  mutations.append({'mutation':field+' +1','caught':caught})
 # Reproduce the exact prior defect; merely recording a corrected bridge cannot hide a wrong DCF.
 a=copy.deepcopy(next(x for x in paths if x['path_id']=='SF0038'));a['dcf_per_share']=next(x['dcf_per_share'] for x in paths if x['name']=='Base' and x['kind']=='main')
 try:audit_path(a,inp);caught=False
 except AssertionError:caught=True
 mutations.append({'mutation':'SF0038 restored historical unscaled-cash DCF','caught':caught})
 from model import run
 asset_claim_tests=[]
 for key in ['cash','term_debt','cash_credit','related_debt','tax_payable_net_tds','gratuity_reserve','contingency']:
  alt=copy.deepcopy(inp);alt['opening'][key]-=.001
  a=run(alt,inp['scenarios'][1]);assert a['funded'];audit_path(a,alt)
  asset_claim_tests.append({'input':key,'delta':-.001,'funding_and_DCF_bridge_reconciled':True})
 checks['all_funded_DCF_bridges_reconciled']=True
 checks['opening_asset_claim_input_mutations']=all(x['funding_and_DCF_bridge_reconciled'] for x in asset_claim_tests)
 checks['mutations_caught']=all(x['caught'] for x in mutations)
 sc=J('scores.json');checks['weights_sum_1']=all(abs(sum(float(x) for x in v['weights'].values())-1)<1e-10 for v in sc['scores'].values());checks['critical_REV_not_imputed']=sc['factors']['REV']['score'] is None and all(v['final']=='NS' and not v['ranking_eligible'] for v in sc['scores'].values());checks['score_bounds']=sc['scores']['BQS']['bounds']==['4.44','5.52'] and sc['scores']['GQS']['bounds']==['3.65','7.25'] and sc['scores']['IAS']['bounds']==['2.7600','3.0300']
 mainpaths=[x for x in paths if x['kind']=='main'];base=next(x for x in mainpaths if x['name']=='Base');near(sum(x['equity_cash_in'] for x in base['monthly']),56.85675);near(base['terminal_shares_crore'],1.43805);near(sum(x['land'] for x in base['monthly']),9.2656);near(sum(x['machine'] for x in base['monthly']),5);near(base['monthly'][0]['legacy_claims_paid'],3.3328+.3608+.001012718);near(base['monthly'][0]['da'],(38.5026*.06+6.2175*.1)/12)
 cash_sensitivity=[]
 for pid,mult in [('SF0038',.5),('SF0039',2)]:
  a=next(x for x in paths if x['path_id']==pid);expected=base['dcf_per_share']+inp['opening']['cash']*(mult-1)/base['terminal_shares_crore'];near(a['dcf_per_share'],expected);cash_sensitivity.append({'path':pid,'multiplier':mult,'dcf_per_share':a['dcf_per_share'],'expected':expected})
 checks['opening_cash_DCF_sensitivities']=True
 checks['proposal_claims_land_depreciation']=True;checks['bear_failure_retained']=next(x for x in mainpaths if x['name']=='Bear')['first_unfunded_month']==7
 class DOM(HTMLParser):
  def __init__(self):super().__init__();self.ids=[];self.href=[];self.h2=0;self.tables=0
  def handle_starttag(self,t,attrs):
   d=dict(attrs)
   if 'id'in d:self.ids.append(d['id'])
   if t=='a':self.href.append(d.get('href',''))
   if t=='h2':self.h2+=1
   if t=='table':self.tables+=1
 dom=DOM();dom.feed((P/'report.html').read_text());checks['fifteen_sections']=all('s'+str(n) in dom.ids for n in range(1,16));checks['unique_ids']=len(dom.ids)==len(set(dom.ids));checks['all_internal_links']=all(x[1:] in dom.ids for x in dom.href if x.startswith('#'));checks['tables_present']=dom.tables>=7;checks['source_links_present']=len([x for x in dom.href if x.startswith('https://')])>=12
 checks['no_raw_sources_or_private_paths']=True
 for p in P.rglob('*'):
  if p.is_file() and p.suffix in ['.md','.html','.json','.py','.csv'] and p.name not in ['verify.py','cold_rebuild.py','package.py']:
   txt=p.read_text();assert not re.search(r'/(?:workspace|home|tmp)/[A-Za-z0-9_]',txt),p.name
 checks['market_active_quote']=J('market_metrics.json')['quote']['volume']==6000 and not J('market_metrics.json')['quote_stale'];checks['no_external_browser_claim']=True
 out={'producer_verification_only':True,'passed':all(checks.values()),'checks':checks,'paths':len(paths),'funded':sum(x['funded'] for x in paths),'failed':sum(not x['funded'] for x in paths),'mutations':mutations,'opening_asset_claim_tests':asset_claim_tests,'opening_cash_sensitivities':cash_sensitivity,'browser':'Structural/DOM only. No local browser launched; actual public browser after release.','scope':'Not independent acceptance; root review pending.'};(P/'verification.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2));assert out['passed']
if __name__=='__main__':main()
