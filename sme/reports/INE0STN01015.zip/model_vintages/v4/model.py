import json,math,gzip,csv,itertools
from pathlib import Path
P=Path(__file__).resolve().parent

def run(inp,spec,years=5):
 o=inp['opening'];f=inp['financing'];pr=inp['proposed'];s=dict(spec)
 cash=o['cash']*s.get('opening_cash_multiplier',1);term=o['term_debt'];cc=o['cash_credit'];related=o['related_debt'];shares=o['shares_crore'];ppe=o['ppe_depreciable'];intang=o['intangible'];onwc=o['onwc'];r=o['revenue'];flows=[];funding=[];failed=None;cumfcff=0;pv_fcff=0;pv_inj=0;netclaims=o['tax_payable_net_tds']+o['gratuity_reserve']+o['contingency'];warrant_deposit=0
 for month in range(1,years*12+1):
  oldr=r;r*= (1+s['growth'])**(1/12);sales=r/12;ebitda=sales*s['margin'];da=(ppe*.06+intang*.10)/12;ebit=ebitda-da
  interest=(term*f['interest_term']+cc*f['interest_cc']+related*f['interest_related'])/12
  tax=max(0,ebit-interest)*f['tax_rate'];nopat=ebit-max(0,ebit)*f['tax_rate']
  target=r*s['receivable_days']/365+r*(1-s['gross_margin'])*(s['inventory_days']-s['payable_days'])/365+r*s['other_onwc_ratio'];newonwc=onwc+(target-onwc)/max(1,13-month) if month<=12 else target;dworking=newonwc-onwc;onwc=newonwc
  maint=sales*s['maintenance_capex_ratio'];growth=max(0,r-oldr)*s['expansion_capex_incremental_sales'];land=o['capital_commitment']/s['land_months'] if month<=s['land_months'] else 0
  eqmonth=s['equity_month'];machine=pr['machine_capex_object']/12 if eqmonth>0 and eqmonth<=month<eqmonth+12 else 0;acquisition=s.get('acquisition_cash',0) if month==s.get('acquisition_month',1) else 0;capex=maint+growth+land+machine+acquisition
  inj=0;newshares=0;extra_amort=0
  if month==eqmonth and eqmonth>0:
   inj+=pr['equity_cash'];newshares+=pr['equity_shares_crore'];extra_amort=pr['debt_repayment_object']
   if s['warrants']:inj+=pr['warrant_deposit'];warrant_deposit=pr['warrant_deposit']
  if s['warrants'] and eqmonth>0 and month==s['warrant_conversion_month'] and month>=eqmonth:
   inj+=pr['warrant_conversion_balance'];newshares+=pr['warrant_shares_crore'];warrant_deposit=0
  amort=min(term,(f['firstyear_term_amortization'] if month<=12 else f['later_annual_term_amortization'])/12+extra_amort);term-=amort
  related_repay=related if month==s.get('related_call_month',0) else 0;related-=related_repay
  legacy=netclaims if month==1 else 0
  cash_before=cash;ocf=ebitda-interest-tax-dworking;cash+=ocf-capex-amort-related_repay-legacy+inj;shares+=newshares
  draw=min(max(0,f['minimum_cash']-cash),max(0,f['cash_credit_limit']-cc));cc+=draw;cash+=draw
  shortfall=max(0,f['minimum_cash']-cash)
  if shortfall>1e-8 and failed is None:failed=month
  # No cash/debt plug on failed paths; subsequent mechanical rows are diagnostic only.
  fcff=nopat+da-capex-dworking;pv_fcff+=fcff/(1+inp['wacc'])**(month/12);pv_inj+=inj/(1+inp['wacc'])**(month/12);cumfcff+=fcff
  ppe+=maint+growth+machine-(ppe*.06/12);intang-=intang*.10/12
  if month==12:ppe+=o['cwip']
  flows.append(dict(month=month,revenue_runrate=r,sales=sales,ebitda=ebitda,da=da,ebit=ebit,interest=interest,tax=tax,ocf=ocf,onwc=onwc,delta_onwc=dworking,capex=capex,land=land,machine=machine,acquisition=acquisition,principal_paid=amort,related_repaid=related_repay,legacy_claims_paid=legacy,equity_cash_in=inj,new_shares=newshares,cc_draw=draw,term_debt=term,cc_debt=cc,related_debt=related,cash_open=cash_before,cash_close=cash,shares=shares,fcff=fcff,shortfall=shortfall,ppe=ppe,intangible=intang))
 terminal_ebitda=sum(x['ebitda'] for x in flows[-12:]);netdebt=term+cc+related-cash;ev=terminal_ebitda*s['multiple'];equity=max(0,ev-netdebt);terminal_price=equity/shares;entry=inp['valuation_price']*(1+inp['entry_cost']);exitnet=terminal_price*(1-inp['exit_cost']);irr=(exitnet/entry)**(1/years)-1 if exitnet>0 else -1
 # steady-state terminal FCFF explicitly finances growth through capex and working capital
 terminal_da=ppe*.06+intang*.10;terminal_nopat=(r*s['margin']-terminal_da)*(1-f['tax_rate']);terminal_fcff=terminal_nopat+terminal_da-r*s['maintenance_capex_ratio']-r*inp['terminal_growth']*s['expansion_capex_incremental_sales']-onwc*inp['terminal_growth'];tv=terminal_fcff/(inp['wacc']-inp['terminal_growth']);dcf_equity=pv_fcff+tv/(1+inp['wacc'])**years-o['term_debt']-o['cash_credit']-o['related_debt']+o['cash']-netclaims+pv_inj;dcf=max(0,dcf_equity)/shares
 out=dict(name=s['name'],years=years,spec=s,funded=failed is None,first_unfunded_month=failed,max_shortfall=max(x['shortfall'] for x in flows),terminal_revenue=sum(x['sales'] for x in flows[-12:]),terminal_revenue_runrate=r,terminal_ebitda=terminal_ebitda,terminal_net_debt=netdebt,terminal_cash=cash,terminal_shares_crore=shares,terminal_per_share=terminal_price if failed is None else None,irr=irr if failed is None else None,dcf_per_share=dcf if failed is None else None,terminal_fcff=terminal_fcff,hurdle_entry=exitnet/(1+inp['hurdle'])**years/(1+inp['entry_cost']) if failed is None else None,pv_fcff=pv_fcff,pv_injections=pv_inj,terminal_multiple=s['multiple'],annual=[flows[i] for i in range(11,len(flows),12)],monthly=flows)
 return out

def build():
 inp=json.loads((P/'model_inputs.json').read_text());specs=[]
 for s in inp['scenarios']:specs.append((s,5,'main'));specs.append((s,10,'long'))
 base=inp['scenarios'][1]
 variations={'growth':[.05,.10,.15,.25,.35],'margin':[.12,.16,.18,.22,.25],'receivable_days':[45,90,120,180],'inventory_days':[100,180,240],'multiple':[4,6,10,12],'equity_month':[0,3,6,12],'land_months':[1,6,24],'related_call_month':[1,6,12],'opening_cash_multiplier':[0,.5,2],'expansion_capex_incremental_sales':[.4,.8,1.2],'maintenance_capex_ratio':[.04,.06],'acquisition_cash':[5,10,20]}
 for k,vals in variations.items():
  for v in vals:specs.append((dict(base,**{k:v,'name':f'{k}={v}'}),5,'one_way'))
 for g,m,d,e in itertools.product([-.20,0,.30],[.08,.14,.23],[90,180],[0,6]):
  specs.append((dict(base,growth=g,margin=m,receivable_days=d,equity_month=e,inventory_days=200,related_call_month=6,name=f'linked g{g} m{m} d{d} e{e}'),5,'linked'))
 for y,g,mult in itertools.product([5,10],[.20,.30,.40,.50],[6,8,12]):specs.append((dict(base,growth=g,multiple=mult,name=f'target{y} g{g} x{mult}'),y,'target'))
 paths=[]
 for i,(s,y,kind) in enumerate(specs):
  a=run(inp,s,y);a['path_id']=f'SF{i:04}';a['kind']=kind;paths.append(a)
 # Discount-rate and terminal-growth sensitivities preserve full paths.
 for w,t in itertools.product([.12,.15,.18],[.02,.04,.06]):
  alt=dict(inp,wacc=w,terminal_growth=t);a=run(alt,dict(base,name=f'DCF w{w} g{t}'));a['path_id']=f'SF{len(paths):04}';a['kind']='discount';a['valuation_assumptions']={'wacc':w,'terminal_growth':t};paths.append(a)
 # No conversion and immediate on-demand related claim branches.
 for warrants in [False]:
  a=run(inp,dict(base,warrants=warrants,name='No warrant conversion'));a['path_id']=f'SF{len(paths):04}';a['kind']='funding';paths.append(a)
 a=run(inp,dict(base,warrant_conversion_month=1000,name='Warrant deposit forfeited; no conversion'));a['path_id']=f'SF{len(paths):04}';a['kind']='funding';paths.append(a)
 for entry,ex in [(0,0),(.03,.05),(.05,.10)]:
  alt=dict(inp,entry_cost=entry,exit_cost=ex);a=run(alt,dict(base,name=f'costs{entry}/{ex}'));a['path_id']=f'SF{len(paths):04}';a['kind']='execution';a['execution_assumptions']={'entry_cost':entry,'exit_cost':ex};paths.append(a)
 for i in range(66):
  a=run(inp,dict(base,growth=i/100,name=f'reverse growth{i}%'));a['path_id']=f'SF{len(paths):04}';a['kind']='reverse';paths.append(a)
 summaries=[{k:v for k,v in a.items() if k!='monthly'} for a in paths];(P/'model_summary.json').write_text(json.dumps(summaries,indent=2)+'\n');raw=json.dumps(paths,sort_keys=True,separators=(',',':')).encode();(P/'model_paths.json.gz').write_bytes(gzip.compress(raw,mtime=0))
 with (P/'model_main_monthly.csv').open('w') as f:
  fields=['scenario']+list(paths[0]['monthly'][0]);w=csv.DictWriter(f,fieldnames=fields);w.writeheader()
  for p in paths:
   if p['kind']=='main':
    for r in p['monthly']:w.writerow({'scenario':p['name'],**r})
 print([(p['name'],p['funded'],p['irr'],p['dcf_per_share'],p['first_unfunded_month']) for p in paths if p['kind']=='main'])
if __name__=='__main__':build()
