import json,hashlib,zipfile
from pathlib import Path
P=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
exclude={'archive_manifest.json','build_manifest.json','producer_handoff.json','cold_rebuild_proof.json','freeze.json'}
files=[p for p in sorted(P.rglob('*')) if p.is_file() and p.suffix not in ['.zip','.pyc'] and '__pycache__' not in p.parts and p.name not in exclude]
manifest={'schema':'source_safe_build_v1','position':378,'isin':'INE0STN01015','framework':'v3.0','scope':'Offline source-safe editorial inputs, derivations, current and retained model vintages; no raw source documents','files':{str(p.relative_to(P)):{'sha256':sha(p),'bytes':p.stat().st_size} for p in files},'generated_outputs':['financial_metrics.json','market_metrics.json','model_summary.json','model_paths.json.gz','model_main_monthly.csv','scores.json','source_ledger.json','report.md','report.html','verification.json','company_record.json'],'hash_order':['inputs/code','derived outputs','company_record roles','build_manifest','archives','external archive_manifest/coldproof/handoff']}
(P/'build_manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');files.append(P/'build_manifest.json')
archives=[]
for style in ['full','compact']:
 selected=[p for p in files if not(style=='compact' and (p.name=='model_paths.json.gz' or (p.name=='model_summary.json' and 'model_vintages' in p.parts)))]
 name=f'SME_378_Silkflex_Polymers_20261020_source_safe_{style}.zip';zpath=P/name
 with zipfile.ZipFile(zpath,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
  for p in selected:
   rel='Silkflex_Polymers_378/'+str(p.relative_to(P));info=zipfile.ZipInfo(rel,date_time=(2026,10,20,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o100644<<16;z.writestr(info,p.read_bytes())
 archives.append({'role':style,'filename':name,'sha256':sha(zpath),'bytes':zpath.stat().st_size,'members':{str(p.relative_to(P)):sha(p) for p in selected},'omitted_reconstructible':[str(p.relative_to(P)) for p in files if p not in selected]})
(P/'archive_manifest.json').write_text(json.dumps({'position':378,'isin':'INE0STN01015','archives':archives,'manifest_sha256':sha(P/'build_manifest.json'),'record_sha256':sha(P/'company_record.json'),'non_circular':True},indent=2)+'\n');print([(x['role'],x['bytes']) for x in archives])
