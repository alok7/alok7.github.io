# Silkflex Polymers (India) Limited

Position 378 · INE0STN01015 · Master Prompt v3.0 · Private research freeze,20 October  2026

## 1. Executive Verdict

**Hold — unresolved historical comparability; not a verified compounder.** Silkflex Polymers (India) Limited is moving from distribution of Malaysian textile inks/wood coatings into local binder, glue and ink manufacturing. Commissioning is real; dependable excess returns and a clean comparable growth history are not yet established. **BQS NS / GQS NS / IAS NS**: material FY23/FY24 revenue revisions lack a full issuer bridge. This is a capital-intensive transition/special-situation research thesis, not a finding of misconduct. At the actual 19 October  2026 traded close ₹260, the conditional fully-funded 20% growth base yields only **0.29%** over five years against 15%; the ordinary bear runs out of modeled funding in month 7. A reliable reporting bridge, current funding proof, royalty economics and markedly stronger returns or lower executable entry are needed. No trade or portfolio allocation is recommended. [F24/F25/F26/P24; model_summary.json]

## 2. Research Header, Gates and Data Confidence

| Input | Treatment |
|---|---|
| Identity | Silkflex Polymers (India) Limited; original label “Silkflex Polymer”; position 378 |
| Security | NSE Emerge, SILKFLEX, SM, INE0STN01015; Indian issuer, not Malaysian supplier |
| Cutoff |20 October  2026 IST; market reference 19 October 2026 |
| Price |₹260 close,6,000 shares and 5 trades; actual dated trade, NOT stale; not an executable quote |
| Equity |11,607,000 issued shares;₹301.782 cr market capitalization; no proposed shares pre-added |
| Accounts |Standalone audited 31 March 2026; Indian GAAP Accounting Standards, not Ind AS; no subsidiaries reported |
| Later results |No later comparable H1FY27 filed account verified at cutoff; no invented TTM |
| Horizon |5 years;10 year demanding extensions retained |
| Hurdle/capital cost |15% nominal INR before investor taxes; separate 15% WACC analyst assumption with 12–18% sensitivity |
| Position |Illustrative ₹5lakh, not recommended size;1,000 share lot ₹2.6lakh; two lots exceed reference |
| Model state |Synthetic opening uses 31 March  audited state at 20 October ; not a verified October liquidity statement |
| Execution costs |1.5% entry/2.5% exit analyst assumptions, not measured spreads |

| Gate | Status | Evidence / condition |
|---|---|---|
|G1|Conditional|No substantiated severe abuse found. On-demand related funding, acquisition terms and dated litigation warrant verification; not allegations represented as facts.|
|G2|Hold — unresolved|Material historical revenue/cash-flow reclassifications lack a quantified full bridge; underlying growth comparability cannot be established. Unmodified audit is retained as counterevidence. Hold is not a finding of fabricated accounts.|
|G3|Conditional|Audited debt and capital commitments leave narrow internally funded headroom; base modeled proposal funds, credible bear/no-finance paths fail. No observed default established.|
|G4|Conditional|Active trading verified19October, but lot granularity and missing executable spread constrain₹5lakh implementation; not effectively untradeable.|

**Confidence:** High on retrieved FY26 reported numbers and dated exchange trade; Medium on business/governance, model arithmetic and funding interpretation; **Low on historical organic growth comparability and present unreported opening cash**. Overall investment confidence is Low, not an average. Forecast uncertainty is separately high. G2 is a research hold over reconciliation, not a claim the unmodified audit is invalid. No gate is declared “Fail — evidenced.” [F26; P24; MK01]

## 3. Scorecard and Calculation Audit

| Measure | Raw / final | Coverage | Missing-data bound | Eligible for ranking? |
|---|---|---:|---|---|
|BQS|NS / NS|88%|4.44–5.52|No|
|GQS|NS / NS|60%|3.65–7.25|No|
|IAS|NS / NS|75%|2.7600–3.0300|No|

| Canonical factor | Score | Evidence and boundary |
|---|---:|---|
|GOV|5|Adequate disclosed stewardship with RPT demand loans, auditor turnover and historical reporting/reclassification concerns; no proved abuse. [F26 notes32/37; P24; B06/B07]|
|MOAT|5|Distribution/service and technology access useful but supplier relationship terminable; no proven price premium. [P24 pp27–29,134–135; CALL26]|
|REV|NS|NS: FY23/FY24 revenue vintages differ materially without quantified issuer reconciliation; current37.73% expansion real but cannot establish comparable three/five-year underlying growth. Do not turn mixed-vintage39.65% into9. [F24,F25,P24,F26]|
|DUR|6|Binder/glue plant and October ink commissioning open adjacent products, bounded by new-process and customer demand risks. [B02/B03; INKOCT]|
|CAP|5|Incremental financing-IC proxy17.92% only modestly exceeds15% assumed WACC; full-year return on new plant/royalty economics not proven. [financial_metrics.json; CALL26 pp10–11]|
|CASH|4|Three-year reported conversion0.615×; classification-adjusted proxy0.698×; FY26 aided by suppliers and capital advance releases; FY21–23 weak. Not proven pervasive value destruction at≤3. [F26 p64; F25 p72; P24 p188]|
|BAL|4|₹62.46cr debt,₹2.09cr cash,9.27cr land commitment and nearly-used CC; base survives only conditional proposal and bear fails. Not observed default. [F26 notes5/9/44; CR26]|
|EXEC|5|Manufacturing/ink commissioning achieved but original construction timetable slipped and royalty/margin claims not fully demonstrated. [P24; CALL26; INKOCT]|
|EARN|6|PAT/EPS grow materially and other income small; new manufacturing and unexplained segment margin arithmetic limit persistence assessment. [F26 p63; CALL26 pp10–11]|
|R|1|Conditional base0.29% nominal after assumed execution costs versus15% hurdle: gap below−10percentage points. Not forecast certainty. [model_summary.json]|
|D|2|Ordinary bear fails funding inmonth7 despite proposed equity, with no assumed rescue; leverage and thin cash permit severe impairment. [model SF0000]|
|P|3|₹260 requires substantially more than20% growth at8× exit and full conditional dilution; base DCF~₹88, not headroom. [model_summary.json]|
|L|6|2.046 theoretical sessions at5% of conservative60-day turnover starts7; deduct1 for₹2.6lakh lot exceeding₹2.4435lakh daily5%budget and absent spread/depth. [market_metrics.json]|

**BQS known contributions:** GOV:1.00 + MOAT:1.00 + REV:NS + DUR:0.60 + CAP:0.60 + CASH:0.40 + BAL:0.32 + EXEC:0.40.

**GQS known contributions:** REV:NS + DUR:1.20 + EARN:0.90 + CAP:0.75 + CASH:0.40.

**IAS known contributions:** BQS:NS + R:0.35 + D:0.40 + P:0.30 + L:0.60.

BQS known subtotal 4.32; missing REV weight 0.12 yields 4.44–5.52. GQS known 3.25; missing 0.40 yields 3.65–7.25. IAS standalone known 1.65; propagate BQS bound through 25% to obtain 2.76–3.03. The broader mechanical IAS bound treating BQS completely unknown is 1.90–4.15; the tighter displayed range uses the known quality evidence. These are mathematical bounds, not confidence intervals or point-score rankings. No renormalization, neutral 5 substitution, arbitrary haircut or midpoint is used. Exact arithmetic and weights remain in scores.json.

**Critical-factor treatment:** GOV 5 does not trigger the≤3 governance cap; CAP 5 and CASH 4 do not trigger the≤3 persistent-destruction GQS cap. Missing REV is not a low score. G2 prevents a favorable investment classification and IAS remains NS even though conditional R/D/P/L can be explored. GOV/MOAT jointly ±1 changes BQS known subtotal ±0.40 and IAS ±0.10; CAP/CASH jointly ±1 changes GQS known±0.25. Small apparent differences are not economically decisive. [framework.md; scores.json]

## 4. Business Overview

Silkflex began as an Indian distributor of Malaysian Silkflex textile printing inks and water-based wood coatings. The exclusive brand/distribution access, local inventory and technical service relationships are useful assets, but exclusivity is contractual rather than proof of an unassailable technology moat. The IPO prospectus describes agreements terminable on 90-day notice for an uncured breach. Replacement supply could require product retraining and customer acceptance. The prospectus also warns of supplier pricing power and supply interruptions. Its Malaysian principal's international footprint is not Silkflex India's export footprint. [P24, printed 27–29,82,134–135]

The transition to manufacturing is real but incomplete. At the April 2026 call management reported an operational Vadodara binder/glue facility with 500 MT monthly nameplate and approximately 60% utilization at that time. This does **not** establish annual average utilization, October utilization or demand at full capacity. FY 26 revenue mix was 75.9% distribution and 24.1% manufacturing. Management said only two products were locally made while 108 products were still imported, explaining why inventory requirements persisted. Full FY 27 utilization and a 50% manufacturing mix were targets, not achieved facts. [CALL26, pp 2–4,8]

The cutoff includes a subsequent, meaningful milestone: the 19 October exchange notice confirms commissioning of two 2 MT vessels and commercial textile garment ink production, at 4 MT/day/shift. September's notice only announced installation subject to trials; October's notice supersedes it. This is an incremental ink process: do not simply add 4 MT/day to 500 MT/month without specifying operating days, shifts and overlapping processes. No post-commissioning sales, contribution margin or utilization record existed by the next-day cutoff. [INKSEP; INKOCT]


The cash cycle starts with imported/locally made stocks, then customer credit, rather than a prepaid subscription. The FY26 audited single-reportable-segment disclosure does not independently certify the call's product profitability split. FY26 reported manufacturing contribution≈₹26.56 cr and distribution≈₹83.64 cr are calculations from management's24.1%/75.9% mix, not separately audited revenue segments. [F26 note 53; CALL26]

## 5. Moat / Industry Position

Local production can capture conversion margin, reduce freight/import exposure and improve availability; it also adds fixed assets, operational execution and working-capital risk. Malaysian technology access has not automatically become proprietary Indian intellectual property. The prospectus says no trading-brand royalty was paid, but manufacturing royalties would become payable following production with percentage mutually decided by volume/cost. A current executed royalty percentage has not been established. Technology-transfer capitalization does not prove there is no ongoing fee. [P24, pp 134–135]

Management's generic 20–25% manufacturing and 12–15% trading EBITDA statements should not become an audited segment model. The call later offers inconsistent explanations of Q 4 margins; the analyst takes the reconciliation offline. The audited company-wide accounts remain the anchor. Likewise descriptions of zero-carbon/zero-discharge operations are management claims, not independently verified lifecycle metrics. [CALL26, pp 4,10–11]

Historical concentration was high: top 10 customers contributed 79.93% of FY 23 sales and 71.88% in 9 MFY 24. These are dated prospectus observations; a current FY 26 concentration figure was not found. FY 26 foreign-exchange earnings were nil, against₹3,962.67 lakh outgo. Textile exporters may transmit global demand and brand sourcing shifts into domestic orders, but this is not demonstrated direct export diversification. Costs remain exposed to raw-material prices, dollar-linked imports and passing increases to customers. [P24,p 29; F26, Directors report]


These are deliberately **FY 25 historical business benchmarks**, not latest valuation comparables. Scope differences prohibit applying their consolidated multiples mechanically.

| Comparator | Primary evidence | Relevance and limits |
|---|---|---|
| Fineotex Chemical | FY 25 report:104,000 MT annual nameplate;470+products; operations income₹533.33 cr; PAT₹109.21 cr; CFO₹69.33 cr. [PEERF,PDF 4–6] | Textile chemicals overlap, but much broader established production and applications; Malaysia subsidiary R&D differs from dependence on an external licensor. Derived CFO/PAT≈0.635 shows why high profit margins alone do not prove cash quality. Not a scale-matched peer. |
| Rossari Biotech | FY 25 textile division revenue₹374.6 cr versus₹353.9 cr; stated 5.9% growth;3,000+products and 1,000+customers. [PEERR,pp 16–17] | Broader textile processing chemistry and backward integration compete for customer relationships. This is segment revenue within a diversified group, not group revenue; no synthetic segment profit margin is inferred. |
| Pidilite Industries | FY 25 B 2 B represented 18.4% of company sales and grew 16.1%; industrial adhesives 5.1%, industrial resins/projects 9.2%, pigments 4.1% of sales. [PEERP,segment discussion; official digital annual report] | Industrial binders/adhesives/coatings overlap. Dominant consumer/bazaar brands and channels make the whole-company franchise and margins unlike Silkflex. Appropriate as an adjacent product benchmark, not direct valuation anchor. |


The selected peer disclosure periods are historical FY25, deliberately not described as current FY26 peer valuations. No recent peer prices were verified, so no current relative-P/E table or claimed cheapness versus a larger diversified company is fabricated. The cross-check uses normalized company operating earnings and explicit 6–10×EV/EBITDA scenario exits; peer scale/product breadth informs why those are assumptions rather than an entitlement. [PEERF/PEERR/PEERP]

## 6. Revenue Growth & Scale

| FY | Revenue ₹cr | Annual addition ₹cr | Mixed-vintage YoY | Source / comparability |
|---|---:|---:|---|---|
|2021|20.7522|NA|NA|P24|
|2022|27.8247|7.0725|34.08%|P24|
|2023|34.2133|6.3886|22.96%|P24|
|2024|50.2729|16.0596|46.94%|F25 comparative|
|2025|80.0113|29.7384|59.15%|F26 comparative|
|2026|110.2033|30.1920|37.73%|F26|

FY21 is the first endpoint; its addition/YoY are NA. Six observed annual endpoints produce a **mixed-vintage** FY21–26 calculation of39.65%; FY23–26 three-year47.68%; later-comparative FY24–26 two-year48.06%. **None is certified organic CAGR.** The comparable latest-report FY26/FY25 revenue gain is 37.73%,₹30.192 cr. One comparable annual interval cannot replace the preferred 3/5 year window. Ten-year CAGR isND; the operating history does not supply eleven annual observations.

**Retained contradictions:** FY23 revenue ₹44.2973 cr in AR24 differs from ₹34.2133 cr prospectus restatement. FY24 originally ₹59.5764 cr becomes ₹50.272908 cr in AR25 comparative. FY25₹80.156242 cr becomes ₹80.0113 cr in AR26; this last movement is traceable to ₹0.144941 cr service/rental revenue moved to other income, leaving total income unchanged. The first two changes lack a quantified bridge in reviewed notes. Do not assume 18% GST explains them: it does not reconcile exactly. Both historical vintages remain in financial_inputs.json. [P24 annexureB/E; F24 p60; F25 p71/82; F26 p63]

The April call reports textile inks ₹104.1 cr and wood coatings ₹6.1 cr, with local manufacturing contributing 24.1% of total. These management business splits help explain direction but do not quantify price/volume, retained/acquired business or net/gross-accounting effects. The 31 August Sylera announcement discloses approval to acquire the entire business undertaking for cash, with completion targeted on or before November 2026. Issuer-reported FY24/FY25/FY26 sales were ₹5.3778155/₹6.812305/₹8.3061147 crore, with approximately 450 MT annual ink sales. Consideration was to be announced later; completion was not established at the cutoff. No acquired revenue is added to the base case. The issuer states that this is not a related-party transaction and that promoters have no interest; these are attributed disclosures, not independent verification. [ACQ26] Real new production supports accessible growth; it does not cure historical comparability. REV remains NS. [CALL26 pp 4,10–11]

## 7. Growth Quality & Reinvestment Runway

The IPO plan expected construction completion byOctober 2024; commercial production was announcedNovember 2025. Construction and commissioning are different milestones, but the gap means delivery should not be described as on-time without a revised schedule and reasons. Commissioning and first manufacturing sales are positive evidence. A brief production history, current capacity ramp and unresolved contribution economics prevent extrapolating a mature manufacturing track record. [P24,pp 83–85; CALL26; INKOCT]

An accessible runway exists through existing textile relationships, imported-product localization and binder applications beyond textiles. Durability is nevertheless bounded by textile/wood demand, supplier technology, input-price competition and the capital needed to serve broader customers. Claimed industry TAM or international brands shifting sourcing to India is not backlog. Monitor repeat local-product orders, product mix, cash collections, inventory turns, contractual royalty economics and capacity utilization before assigning durable excess returns.



**Bottom-up feasibility, not capacity-as-revenue:** at a hypothetical ₹150/kg realization,500 MT/month operated 12 months implies ₹90 cr annual binder/glue nameplate sales. That realization is a call-based illustration, not a verified blended ASP or guaranteed orderbook. The new 4 MT/day/shift ink line requires separate operating-days/shifts/ASP assumptions; at 250 days and ₹150/kg the illustration adds ₹15 cr, not ₹90 cr. Do not multiply utilization or production across incompatible processes.

Base revenue reaches ₹274.22cr annualized run-rate in five years; a 40% manufacturing mix would require≈₹109.69 cr local-product sales and 60% distribution≈₹164.53 cr. The current illustrated ₹105 cr combined nameplate is already close to that requirement, before maintenance/downtime, mix and new products. Model growth capex 20% of incremental annual revenue plus ₹5 cr specified machinery is therefore a **required assumption**, not proof the expansion is commissioned or sufficient. Bull ₹363.85cr demands further product/asset scaling. Lack of precise product throughput and royalty margin data limits CAP/DUR rather than granting unlimited capacity.

GQS is NS, not a growth dismissal: known DUR 6/EARN 6/CAP 5/CASH 4 contribute 3.25 points; unknown REV carries 40%. No ≤3capital/cash override is applied. Good one-year earnings cannot compensate for absent comparable growth proof. [F26; CALL26; INKOCT; model_inputs.json]

## 8. Management, Governance & Execution

The FY 26 report describes a continuing statutory auditor appointed forFY 23–FY 27, an unmodified statutory opinion and no reported fraud. Those are positive controls, not sufficient evidence for a high governance score. Internal and secretarial auditors changed, alongside compliance-officer/director changes. These must not be mislabelled statutory-auditor resignations; the reviewed descriptions do not establish information-denial or audit-scope disputes. [F26, corporate information and auditors section]

Disclosed FY 26 director remuneration totals₹81 lakh, approximately 6.67% of₹1,215.33 lakh PAT. This excludes disclosed related-party interest, salaries and reimbursements and therefore is not total promoter economic extraction. The AGM proposes annual transaction ceilings of₹50 crore for CMD and₹30 crore for WTD unsecured loan transactions, repayable on demand. These ceilings are neither cash received nor unconditional funding commitments. Actual related-party balances and debt stress belong in the reconciled financial model. Borrowing from insiders can support growth but demand repayment and related-party pricing warrant scrutiny. [F26, AGM item 4 and PDF 80]

The revised proposed ₹56.85675 crore equity/warrant programme is a prospective dilution/funding scenario at the cutoff. Later allotments are excluded; treating the proposal as cash at the cutoff would introduce hindsight. The 31 August primary board notice approves the Sylera Inc. undertaking acquisition and local Sylera/Slyvora product launches. Its annexure specifies cash consideration, but no price; completion is targeted on or before November 2026. The issuer states no related-party transaction or promoter interest. Reported target sales are ₹5.3778cr/₹6.8123cr/₹8.3061cr in FY24/FY25/FY26 and around450MT annual ink sales. These are issuer statements about the target, not audited post-acquisition contributions. Approval and wording “taken over/acquired” in the cover do not override the annexure's future completion date. Do not add target sales or assume free acquisition. [ACQ26, pp1–2]

The primary30June2026 shareholding declaration shows promoter8,141,700shares/70.14% and no pledged/NDU encumbrance. These are datedJune facts; no September primary declaration was established, so October zero-pledge is not asserted. [SHPJ26]

Historical legal disclosure is not a finding of guilt. The prospectus records two promoter proceedings: for one the police final report recommended discharge/civil treatment, with a protest petition pending; the other involved a charge sheet and pending adjudication. That is dated 2024 status, not independently verified October 2026 status. No wrongdoing or automatic governance override is inferred. [P24,pp 228–229]

FY 23/FY 24 revenue vintages differ materially. Searching the FY 25 financial notes finds generic regrouping language but not a quantified bridge explaining the entire revenue change. The finance coordinator preserves both versions. This constrains confidence in an organic historical CAGR rather than supporting a misconduct allegation. [F25, financial notes]



| Promise / proposal | Dated evidence | Delivery at cutoff / treatment |
|---|---|---|
|Factory construction by Oct 2024|IPO prospectus pp 83–85|Commercial launch Nov 2025; construction vs commissioning distinguished, no “on-time” label|
|Local binder/glue manufacturing|April 2026call|First manufacturing revenue reported; actual commercial progress, not full utilization proof|
|100% utilization and 50% manufacturing mix FY27|April 2026call|Targets; cutoff actuals ND; no full-year forecast credited as fact|
|Two additional ink vessels|10 Sep  2026installation|19Octcommercial-production notice verified; one day of history by cutoff|
|Debt reduction via internal accruals|April 2026call|No completed debt elimination verified; proposed equity/warrants materially alter funding assumptions|
|Preferential equity/warrants|26Augnotice,11Sepcorrigendum|Revised equity 1,573,500 shares@₹205, warrants 1,200,000@₹205; conditional, not cash|

FY26 issuer states IPO proceeds used for stated objects; gross ₹18.1064 cr IPO less ₹1.7535 cr issue-related deduction leaves ₹16.3529 cr net financing cash in FY25. This is a numerical cash/equity reconciliation, not independent verification of every invoice. No ESOP/convertible other than disclosed proposal established. The June 2026 primary shareholding filing reports 70.14% promoter ownership and no pledge/NDU at that date. September/current encumbrance and exact liquidity restrictions remain explicit gaps; the June disclosure must not become a current “zero pledge” assertion. [F26 note 50; F25 cashflow/equity; EQ26/COR26]

## 9. Financial Forensics

| FY | Operating EBITDA | EBIT | PAT | EPS ₹ | CFO reported | Gross debt | Cash equivalents | Equity | Receivables | Inventory | Payables |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
|2021|1.256|1.203|0.454|0.68|-0.171|6.128|0.054|5.135|2.768|5.219|0.527|
|2022|1.642|1.434|0.686|0.85|-4.285|9.945|0.040|7.380|2.208|11.191|0.558|
|2023|2.387|1.990|0.786|0.97|0.012|12.083|0.038|8.166|2.100|14.635|1.677|
|2024|7.068|6.588|3.929|4.84|8.582|15.162|0.059|12.260|5.842|16.252|8.077|
|2025|11.612|11.229|7.000|6.26|-23.540|36.273|0.090|35.614|10.132|30.132|6.247|
|2026|21.745|19.869|12.153|10.47|29.146|62.460|2.090|47.544|19.556|29.473|14.625|

₹crore unless EPS. P24 FY21–23 are restated pre-IPO accounts; later years use latest comparative where identified. EPS early years is prospectus bonus-adjusted, not raw contemporaneous EPS. Full annual raw/derived metrics, capital, shares and historic versions are retained; gross profit is not treated as an audited segment metric. [financial_inputs.json; financial_metrics.json]

**FY26 income normalization:** reported PBT 16.3232 + finance 4.1317 − other income 0.5664 − exceptional 0.0200  = operating EBIT 19.8685; add D&A 1.8768 gives EBITDA 21.7453 (19.73% revenue). At 25.5% normalized tax, operating NOPAT 14.8020. Normalized PAT excludes non-operating/exceptional income under the same assumed tax rate; no group minority adjustment applies. Reported EPS 10.47, FY25 EPS 6.26; FY26 issued shares unchanged. [F26 p63/77–79]

**CFO is not clean free cash:** FY26 CFO 29.1465 includes 10.0489 release of current capital advances and 0.1932 deposit outflow. Reclassifying both gives 19.2908 operating-cash proxy. FY25 latest comparative CFO−23.5399 +10.0489 capital-advance outflow +1.7378 restricted-deposit movement =−11.7532. Three-year ratio-of-sums reported CFO/PAT=0.615; reclassified proxy=0.698. It is **not** an average of annual ratios and remains subject toFY24 comparability/tax timing. Supplier balances rose ₹8.3778 crFY26, supporting cash while receivables rose ₹9.4243 cr; do not describe all CFO as collected profits. [F26 p64/74–75; F25 p72]

**Capex bridge:** FY26 gross PPE cash-flow line 90.3719 + intangibles 6.4025 − non-cash CWIP transfer 35.1663 − prior intangible reclassification 4.1508 =57.4573. Deduct capital-advance release 8.3038 from investing and 10.0489 from operating to obtain current-period operating investment cash 39.1046, excluding disposal 0.002. Reclassified FCF proxy 19.2908−39.1046=**−19.8138**. FY25 includes 6.9656 gross PPE plus 18.3527 capital advances; reclassified FCF proxy−37.0715. Neither is automatically FCFF because interest is financing-classified, operating tax timing differs, deposits/sales are separate and policy classifications changed. CFO+CFI remains cash-reconcilable despite historical relocation. [F26 p64/76; F25 p72/80–81]

**Capital and returns:** financing IC proxy =equity+debt−cash−long-term bank deposits. FY26₹105.9822cr, FY25₹70.0602cr. Incremental NOPAT ₹6.4363 divided by ΔIC ₹35.9220 =**17.92%**; FY26 NOPAT/average IC=16.82%. These proxies include technology/CWIP, are not mature-cohort returns, and include all-financing-versus-operating reconciliation differences. They are distinct from issuer pre-tax ROCE≈24% and normalized 15% WACC. Recent commissioning and land timing distort simple incremental ratios; no claim of persistent high-return reinvestment. [F26 notes 13/33; financial_metrics.json]

**Funding opening:** gross debt 62.4599, comprising term/bank/NBFC 35.8775,CC 19.6824, related 6.9000. Cash 2.0904 excludes 1.9311>12 month deposits; restricted deposits are not free netting. Current bank/NBFC/car/term maturities 6.0831 are separated from CC rollover.₹20 cr CC sanction leaves only 0.3176 headroom; model assumes no unseen additional facility. CRISIL BBB−/Stable on ₹50 cr facilities in March 2026 cited 91% average utilization through January and 3.6–5.25crmedium-term term obligations; audited current maturities take priority for year 1, later 3.6 is a disclosed modeling assumption. Related loans remain callable, separately stressed. [F26 notes 5/9; CR26]

₹9.2656 cr unprovided land commitment is added to future capex;₹7 cr already advanced is not charged again. Net legacy tax ₹3.3328 cr(current tax 3.7532−TDS assets 0.4204), full gratuity 0.3608 and tax contingency 0.001012718 are explicitly reserved at model start. No hidden tax benefit is used in loss months.₹0.2765 cr disputed >3 year receivables remains treated as good in accounts; no expected-credit-loss cover was located. Model opening cash / receivable-stress branches expose uncertainty, rather than treating aged balances as immediately collectible. [F26 notes 18/21/44/52]

The reported prior gratuity charge ₹0.2993 cr through reserves less deferred tax ₹0.0753 cr explains equity growth below PAT. Leases follow AS operating-rental treatment in operating expenses; no Ind AS 116 ROU/debt invented. No quantified remaining operating-lease commitment located:ND, not zero. [F26 policies,notes 4/52]

## 10. Valuation & Market Expectations

₹260×1.1607 crore shares =₹301.782 cr market cap. Using latest audited state, EV=market cap+62.4599−2.0904=₹362.1515 cr; EV / normalized EBITDA≈16.65×; reported P/E≈24.83×; P/B≈6.35×. These combine an October price and March balance, not a contemporaneously verified enterprise value. FCF yield is negative and not a cheapness signal. No proposed proceeds or shares enter current market cap. [MK01;F26]

| Case | Growth / EBITDA margin | Terminal revenue | Funding | Terminal ₹/share | 5y IRR | DCF ₹ | 15% hurdle entry ₹ |
|---|---|---:|---|---:|---:|---:|---:|
|Bear|3% / 14%|126.04|Fails month 7|NS — funding failure|NS — funding failure%|NS — funding failure|NS — funding failure|
|Base|20% / 20%|252.58|Funded conditional|274.62|0.29%|88.38|131.16|
|Bull|30% / 23%|363.85|Funded conditional|587.27|16.76%|176.29|280.47|

**Every row is conditional analyst modeling, not a forecast.** The base starts with March audited state as a synthetic October opening; actual intervening cash, obligations and trading are ND. It requires the revised proposal to close in month 1:₹32.25675 cr equity plus ₹6.15 cr warrant deposit, with ₹18.45 cr conversion cash and 0.12 crore shares in month 18. Equity adds 0.15735 crore shares; fully diluted total 1.43805 crore. Bear assumes equity only; bull full conversion month 12. No equity cash without corresponding dilution; a no-warrant branch retains funded deposit only where contractually assumed. Realized post-cutoff allotments are not backfilled.

Opening commitment 9.2656 is spent over 12 months;₹5 cr proposed machinery budget is incremental to maintenance 2.5% of sales and expansion 20% of incremental sales(base). Capex and working capital grow with sales. Base closing receivable days 65,inventory 140 cost days, payables 65 cost days,32% gross-margin assumption,other ONWC 2.7% of sales; bear 90/170/50 days and 14% EBITDA squeezes cash. Positive operating tax 25.5%, no unusable tax assets. Debt interest 10.5% bank/9% related.₹12.5 cr proposal object repays term debt without being expensed. Remaining first-year maturities and later 3.6/year amortization are paid;CC may roll within ₹20 cr only. Related demand recall is separately modeled. All surplus cash remains in terminal equity: no simultaneous dividend double count. [model_inputs.json;model_main_monthly.csv]

**DCF:** monthly FCFF=NOPAT+D&A−cash capex−ΔONWC; discount at 15%, terminal g4% and required terminal growth capital. Terminal EV is not just EBITDA×perpetuity. From PV operating value subtract opening debt/legacy claims, add opening cash and PV conditional capital injections, then divide by terminal diluted shares. This is a fully-diluted conditional allocation convention with no interim dividends; it is not a clean historical-share intrinsic value unaffected by financing timing. WACC 12/15/18 and terminal g2/4/6% full paths retained. Terminal steady FCFF must pay maintenance, expansion and working capital, not assume zero reinvestment. Land excluded from depreciation in current v5; initial v1 retained and rebuildable.

**Return model cross-check:** exit EV = trailing EBITDA×6/8/10; subtract ending debt and add ending cash; divide by actual modeled terminal shares; apply 2.5% exit cost / 1.5% entry cost. IRR is `(netexit/(260×1.015))^(1/5)−1` because no dividends. Base 15% hurdle entry≈₹131.16, but it does **not** clear G2 or authorize purchase. Holding 20% growth, margins and financing constant requires 15.68× exit EBITDA, solved from target equity proceeds plus ending net debt; exact model multiple paths retained. No sampled funded point in the retained 0–65% annual-growth grid, at one-percentage-point resolution, clears the 15% hurdle while holding the base 20% margin, 8× exit, working-capital terms and funding dates/amounts constant. The highest sampled funded return is about1.50% at22% growth. Higher demand can exhaust working-capital funding rather than monotonically improve investor return. This grid does not prove that every unsampled continuous point fails, nor establish a continuous solved threshold; no sampled funded hurdle-crossing bracket was found. Terminal capacity and reinvestment would require rechecking before treating any high-growth price-implied case as feasible.

There are188retained paths, 61funded and127failed, spanning delayed/no issuance, demand/margin/collection/inventory, land timing, related recall, opening cash, exit multiple, WACC/g and 5/10 year return targets. Design frequencies are not probabilities. Failed paths preserve cash shortfall and first failure, but no ordinary terminal price/DCF/IRR. Subsequent failed-path rows are diagnostics, not implied rescue. [model_summary.json;model_paths.json.gz]

## 11. Bear Case & Permanent-Loss Path

The strongest counterargument is that the apparent transformation is expensive localization of a contract-dependent distributor, not a protected chemical franchise. Input/supplier disruption or textile-order weakness lowers utilization; margin falls while customers pay later and inventory cannot clear; capex, land and debt remain payable; cash credit already near its limit leaves dependence on new capital. At bear 3% growth/14% margin/90 day collections and equity funding only, financing fails in month7. An assumed promoter rescue would conceal the failure, so none is added. Collateralized land or technology book value does not establish liquidation recovery.

**Thesis-break variable:** cash collection and funding during manufacturing scale-up, not the headline capacity figure. FY26 receivables grow 93.02% while sales grow 37.73%; actual receipt evidence and credit terms matter. Latest CFO recovery is partial counterevidence to an inescapable default story, but is inflated by capital-advance release and supplier credit. Audited profit and CRISIL BBB− are counterevidence to an assertion of proven fraud/default, not a guarantee against stress. The model's failure is hypothetical; actual failure is not claimed. [F26;CR26;modelinputs]

Unresolved revenue bridges can reflect legitimate reclassification. Nonetheless, investing before knowing the underlying growth basis would confuse absence of explanation with proof. G2research hold requires issuer line-by-line reconciliation and collection/funding evidence. A lower price cannot fix missing financial comparability. [F24/F25/P24]

## 12. 5× / 10× Feasibility

Tenfold price growth requires 58.49% annualized over 5 years or 25.89% over 10 years; fivefold requires 37.97% or 17.46%. This must be per-share after dilution, not company revenue multiplication. Full proposal shares / starting shares=1.239; at unchanged margin / P/E multiple,10× price would require about 12.39× revenue(₹1,365crfromFY26base), before considering debt, working capital and capacity. The manufacturing transition may change margins, but that must be earned rather than assumed.

The retained target grid covers 5/10 years,20/30/40/50% growth and 6/8/12× exit. 0of24designed paths mechanically reach 10×if funded; none is assigned a success probability. Base 5 year terminal price is1.06×entry before costs. Large growth paths are conditional capacity relaxations, not validated plant plans. Lower 6× exit trials prevent relying only on rerating. Given unreconciled historical growth, new manufacturing and capital needs, **10×is Speculative/unsupported**, not a commitment or target. [modeltargetpaths;F26;CALL26]

## 13. Monitoring Plan

| KPI/event | Baseline | Warning | Thesis-break / required action | Source / cadence |
|---|---|---|---|---|
|Comparable revenue|FY24 ₹59.5764 vs ₹50.2729 cr|Further unexplained comparative changes|No line-by-line bridge: maintain G2 hold|Issuer audited notes, next report|
|Customer collections|FY26 receivables ₹19.5561 cr;64.77closing days|>90 days with flat orders|>120 days and funding shortfall requires G3 review|Half-year cash / ageing|
|Inventory|₹29.4728 crFY26|Cost days >170 with slow output|Obsolescence / lender drawing-power loss|Audited stock / bank statements|
|Funding proposal|₹32.25675 cr equity+₹24.6 cr warrants conditional|Delay >3 months or revised price/uses|Cannot meet committed cash without unauthorized rescue|Exchange allotment and bank proof|
|Cash-credit  headroom|₹19.6824/20 cr used 31 Mar|Limit fully used with land due|Payment default or unsupported rollover|Bank / current accounts|
|Land commitment|₹9.2656 cr unprovided|Acceleration without funding|Cash shortfall / asset recoverability|Contract / payment filings|
|Local manufacturing|500 MT/month;April utilization~60%;new ink 4 MT/day/shift|Production above orders or unexplained margin mix|Repeated negative unit cash margin|Half-year operations / royalty terms|
|Supplier/royalty|Terminable contract; current percentage ND|Adverse pricing or renewal terms|Loss without qualified economic replacement|Material exchange agreements|
|Promoter loans/RPT|₹6.9 cr actual;₹80 cr transaction ceilings, not cash|Demand recall or unexplained connected transfers|Evidenced abuse would trigger G1, not ordinary borrowing|RPT notes / AGM|
|Tradability|1,000 lot;2zero-trade sessions/60|Persistent zero trades / wider one-sided markets|Effectively untradeable: IAS NS for new purchase|NSE sessions / security master|

Thresholds are analyst investigation triggers derived from modeled stress, not universal rules or automatic sell orders. Review next applicable filings; no recurring task, reminder or trade has been created.

## 14. Final Classification & Conditional Action

**Hold — unresolved / insufficient comparable growth evidence.** All three aggregates are NS, not zero and not assigned bottom ranks. Keep this company in Pending evidence; the financial-reliability research hold also bars favorable investment classification. No governance/funding numeric cap is asserted because an actual severe failure has not been established. No evidence-backed compounder designation: quality, runway and current funding requirements are not satisfied.

**Action category: research priority, not eligible for investment consideration yet.** First obtain material revenue/comparative bridges, current cash/debt/proceeds and royalty unit economics. Then refresh the model and per-score eligibility. Conditional ₹131 hurdle entry does not waive the hold; a price change alone cannot fix BQS/GQS. For an existing holding, no exit instruction is given without position, taxes and execution depth. Independent producer review and batch acceptance are pending; this dossier is not self-accepted and nothing is saved to public Git/Library here.

## 15. Sources, Assumptions & Open Questions

| ID | Source/date | Locator/use |
|---|---|---|
|P24|[IPO prospectus](https://silkflexindia.in/wp-content/uploads/prospectus_silkflex-polymers-india-limited_01.05.2024.pdf) — 2024-05-01|printed27–29,82–85,134–135,228–229; financial evidence: printed 186–188,196–197; annexures A/B/C/E|
|F26|[FY2026 annual report](https://silkflexindia.in/wp-content/uploads/Annual-Report-2025-2026.pdf) — 2026-08-19|Corporate information; AGM explanatory statement item4; Directors report; PDF80 related parties; financial evidence: PDF62–83, audited25April2026|
|F25|[FY2025 annual report](https://silkflexindia.in/wp-content/uploads/SPIL_Annual-Report_2024-25_Final.pdf) — 2025-08-30|financial notes; generic regrouping clause; financial evidence: printed70–82 and notes26–40|
|CALL26|[FY2026 earnings call, held28April, filed6May](https://nsearchives.nseindia.com/corporate/SILKFLEX_06052026183658_Letter.pdf) — 2026-05-06|printed2–4,6,8,10–11|
|INKSEP|[Ink vessel installation notice](https://silkflexindia.in/wp-content/uploads/Letter-10-09-2026.pdf) — 2026-09-10|p1|
|INKOCT|[Ink commercial production commencement](https://nsearchives.nseindia.com/corporate/SILKFLEX_19102026154705_Letter.pdf) — 2026-10-19|p1|
|PEERF|[Fineotex FY2025 annual report](https://fineotex.com/wp-content/uploads/2021/07/22nd-Annual-Report-2024-2025.pdf) — FY25 historical report; exact publication date ND|PDF4–6 Chairman statement and business profile|
|PEERR|[Rossari FY2025 annual report](https://www.rossari.com/wp-content/uploads/2025/06/Annual-Report-2024-25.pdf) — FY25 historical report; exact publication date ND|printed16–17 textile specialty chemicals|
|PEERP|[Pidilite FY2025 annual report](https://www.pidilite.com/content/dam/pidilitecorporatewebsite/financial/annual-reports/annual-report-2024-25.pdf) — FY25 historical report; exact publication date ND|BRSR business segments; segment commentary|
|ACQ26|[Sylera acquisition and product launch board notice](https://nsearchives.nseindia.com/corporate/SILKFLEX_31082026204833_Letter.pdf) — 2026-08-31|p1 andannexurep2|
|SHPJ26|[Shareholding pattern30June2026](https://silkflexindia.in/wp-content/uploads/Shareholding-Pattern-for-the-quarter-June-30-2026.pdf) — 2026-06-30|declarationtable andpromoteraggregate|
|F24|[F24 audited financial source](https://silkflexindia.in/wp-content/uploads/spil-annual-report-2023-24.pdf) — 2024-05-31|printed 59–61, notes18–20|
|EQ26|[EGM preferential issue notice](https://silkflexindia.in/wp-content/uploads/Notice-of-EGM-3.pdf) — 2026-08-26|items 2/3, objects and warrant payment terms|
|COR26|[Preferential issue corrigendum](https://silkflexindia.in/wp-content/uploads/Notice-Corrigendum-1.pdf) — 2026-09-11|revised issue 1,573,500 shares andobjects|
|CR26|[CRISIL rating rationale](https://www.crisilratings.com/mnt/winshare/Ratings/RatingList/RatingDocs/SilkflexPolymersIndiaLimited_March%2031_%202026_RR_391895.html) — 2026-03-31|standalone ₹50 cr facilities; liquidity; supplier concentration|
|MK01|[NSE19 October  bhavcopy](https://nsearchives.nseindia.com/content/cm/BhavCopy_NSE_CM_0_0_0_20261019_F_0000.csv.zip) — 2026-10-19|INE0STN01015 SM row; issuer-only 60-session extract|
|MK02|[NSE19 October  security master](https://nsearchives.nseindia.com/content/cm/interop/NSE_CM_security_19102026.csv.gz) — 2026-10-19|SM issuer row,11,607,000 shares/1,000 lot|

**Evidence types:** V=verified disclosed historical number/filing; C=reproducible calculation; M=attributed management statement; A=analyst assumption. `financial_inputs.json` stores V / vintage contradictions; `financial_metrics.json` and`market_metrics.json` store C; business claim IDsB01–B08 identify M/V and locators; `model_inputs.json` is A except identified audited openings and proposal terms. `evidence_ledger.json` links material claims, confidence and consequences. Raw PDF/OCR, private paths, account numbers, signatures and unnecessary personal identifiers are excluded.

**Priority open questions:** exact FY23/FY24 gross/net/reclassification bridge; actual October funding/cash and proposal timing; Sylera acquisition price, completion, funding and integration economics (the issuer disclosed no related-party status or promoter interest); current royalty agreement; reconciled product margins; current customer concentration/receipts; bank deposit restrictions; post-cutoff results must not be used as if known on 20 October; current pledge, surveillance, spread and remaining lease commitments. The 60-session price extract includes 11 observed ST-series sessions from 24 July through 7 August, followed by observed SM rows; current 19 October SM is verified. Historical series changes do not establish unrestricted execution. No absence is inferred as zero.

**Definitions:** operating EBIT=PBT+ finance − other income − exceptional; EBITDA=EBIT+D&A; NOPAT=EBIT×(1−25.5%); CFO/PAT=ratio of sums; financing IC=equity+debt−cash−long bank deposits; incremental return=ΔNOPAT/ΔIC with timing limits. Model ONWC=receivables+inventory+operating advances / tax credits / prepaids−trade payables−other operating current liabilities−customer security deposits. Tax balances, capital advances and financing are separate. Lease rent is in margin; future tax is paid currently for conservatism. No overlapping TTM, no fabricated quarterly cash flow.

**Reproducibility:** `rebuild.py` derives metrics, scoring, the retained monthly paths, report and HTML from source-safe inputs. Current v5 and meaningful v1/v2/v3/v4 retain separate inputs/code/outputs; the compact archive can rebuild omitted raw paths. Historical v4 has a retained opening-cash DCF bridge defect: its 0.5× and 2× cash sensitivities incorrectly retained base DCF. Current v5 corrects these to ₹87.65363798 and ₹89.83409068 respectively (base ₹88.38045555 unchanged), using scaled opening cash in both funding and DCF. Earlier vintages remain historical, not current validated sensitivity outputs. Full DCF reconciliation and opening asset/claim mutation checks are required. Cold-rebuild proof compares frozen bytes; artifact role hashes are non-circular. HTML structural/DOM checks are static, not actual browser QA. No local Chromium launch; public browser review only after authorized release. Producer checks are not independent acceptance.
