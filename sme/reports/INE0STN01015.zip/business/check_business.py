import json,pathlib,hashlib
D=pathlib.Path(__file__).parent
b=json.loads((D/'business_inputs.json').read_text());sr=json.loads((D/'source_register.json').read_text());ids={s['id'] for s in sr}
checks={}
checks['three_distinct_peers']=len({p['company'] for p in b['peers']})==3
checks['all_claim_sources_resolve']=all(c['source'] in ids for c in b['claims'])
checks['no_post_cutoff_funding']=b['cutoff_controls']['realized_from_postcutoff_allotments_crore']==0
checks['cutoff_dates']=all(s['date'] is None or s['date']<=b['cutoff'] for s in sr)
checks['no_raw_source_files']=not any(p.suffix.lower() in ['.pdf','.png','.jpg'] for p in D.rglob('*'))
checks['hashes_present']=all(s['sha256'] and len(s['sha256'])==64 for s in sr)
checks['manufacturing_mix_sums_100']=abs(b['claims'][0]['value']['distribution_pct']+b['claims'][0]['value']['manufacturing_pct']-100)<1e-8
checks['separate_capacity_units']=b['claims'][2]['value']['mt_per_day_per_shift']==4 and b['claims'][1]['value']['annualized_nameplate_mt']==6000
checks['remuneration_math']=abs(b['claims'][6]['value']['PAT_pct']-81/1215.33*100)<1e-9
checks['no_unsupported_numeric_REV']=b['factors']['REV']['suggested'] is None
out={'passed':all(checks.values()),'checks':checks,'scope':'Business companion only; not global acceptance or valuation validation','limitations':['Primary peer reports are FY25 operating benchmarks, not latest peer valuation','Exact peer filing dates not independently captured; annual reports predate cutoff','Open evidence gaps retained in business_inputs.json']}
(D/'checks.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2));assert out['passed']
