import json
from pathlib import Path
from decimal import Decimal,ROUND_HALF_UP
P=Path(__file__).resolve().parent
factors={
'GOV':(5,'Adequate disclosed stewardship with RPT demand loans, auditor turnover and historical reporting/reclassification concerns; no proved abuse. [F26 notes32/37; P24; B06/B07]'),
'MOAT':(5,'Distribution/service and technology access useful but supplier relationship terminable; no proven price premium. [P24 pp27–29,134–135; CALL26]'),
'REV':(None,'NS: FY23/FY24 revenue vintages differ materially without quantified issuer reconciliation; current37.73% expansion real but cannot establish comparable three/five-year underlying growth. Do not turn mixed-vintage39.65% into9. [F24,F25,P24,F26]'),
'DUR':(6,'Binder/glue plant and October ink commissioning open adjacent products, bounded by new-process and customer demand risks. [B02/B03; INKOCT]'),
'CAP':(5,'Incremental financing-IC proxy17.92% only modestly exceeds15% assumed WACC; full-year return on new plant/royalty economics not proven. [financial_metrics.json; CALL26 pp10–11]'),
'CASH':(4,'Three-year reported conversion0.615×; classification-adjusted proxy0.698×; FY26 aided by suppliers and capital advance releases; FY21–23 weak. Not proven pervasive value destruction at≤3. [F26 p64; F25 p72; P24 p188]'),
'BAL':(4,'₹62.46cr debt,₹2.09cr cash,9.27cr land commitment and nearly-used CC; base survives only conditional proposal and bear fails. Not observed default. [F26 notes5/9/44; CR26]'),
'EXEC':(5,'Manufacturing/ink commissioning achieved but original construction timetable slipped and royalty/margin claims not fully demonstrated. [P24; CALL26; INKOCT]'),
'EARN':(6,'PAT/EPS grow materially and other income small; new manufacturing and unexplained segment margin arithmetic limit persistence assessment. [F26 p63; CALL26 pp10–11]'),
'R':(1,'Conditional base0.29% nominal after assumed execution costs versus15% hurdle: gap below−10percentage points. Not forecast certainty. [model_summary.json]'),
'D':(2,'Ordinary bear fails funding inmonth7 despite proposed equity, with no assumed rescue; leverage and thin cash permit severe impairment. [model SF0000]'),
'P':(3,'₹260 requires substantially more than20% growth at8× exit and full conditional dilution; base DCF~₹88, not headroom. [model_summary.json]'),
'L':(6,'2.046 theoretical sessions at5% of conservative60-day turnover starts7; deduct1 for₹2.6lakh lot exceeding₹2.4435lakh daily5%budget and absent spread/depth. [market_metrics.json]')}
weights={'BQS':{'GOV':'.20','MOAT':'.20','REV':'.12','DUR':'.10','CAP':'.12','CASH':'.10','BAL':'.08','EXEC':'.08'},'GQS':{'REV':'.40','DUR':'.20','EARN':'.15','CAP':'.15','CASH':'.10'},'IAS':{'BQS':'.25','R':'.35','D':'.20','P':'.10','L':'.10'}}
res={};vals={k:v[0] for k,v in factors.items()}
for score,ws in weights.items():
 known=sum(Decimal(w)*Decimal(vals[k]) for k,w in ws.items() if vals.get(k) is not None);missing=sum(Decimal(w) for k,w in ws.items() if vals.get(k) is None);raw=None if missing else known;vals[score]=raw
 bounds=[known+missing,known+10*missing]
 if score=='IAS':
  b=res['BQS']['bounds'];bounds=[known+Decimal('.25')*Decimal(b[0]),known+Decimal('.25')*Decimal(b[1])]
 res[score]={'raw':'NS' if raw is None else str(raw),'final':'NS' if raw is None else str(raw),'display':'NS' if raw is None else str(raw.quantize(Decimal('.1'),rounding=ROUND_HALF_UP)),'coverage':str(1-missing),'weights':ws,'contributions':{k:None if vals.get(k) is None else str(Decimal(w)*Decimal(vals[k])) for k,w in ws.items()},'bounds':[str(x) for x in bounds] if missing else None,'bounds_type':'mathematical missing-evidence bounds, not probability interval; IAS propagates BQS bounds','missingness':{k:'NS' for k in ws if vals.get(k) is None},'overrides':[],'confidence':'Low on historical growth comparability; Medium on known factors','ranking_eligible':False,'eligibility_reason':'Critical REV missing; no renormalized point score. IAS also blocked by G2 research hold.'}
gates={'G1':{'status':'Conditional','reason':'No substantiated severe abuse found. On-demand related funding, acquisition terms and dated litigation warrant verification; not allegations represented as facts.'},'G2':{'status':'Hold — unresolved','reason':'Material historical revenue/cash-flow reclassifications lack a quantified full bridge; underlying growth comparability cannot be established. Unmodified audit is retained as counterevidence. Hold is not a finding of fabricated accounts.'},'G3':{'status':'Conditional','reason':'Audited debt and capital commitments leave narrow internally funded headroom; base modeled proposal funds, credible bear/no-finance paths fail. No observed default established.'},'G4':{'status':'Conditional','reason':'Active trading verified19October, but lot granularity and missing executable spread constrain₹5lakh implementation; not effectively untradeable.'}}
out={'framework':'v3.0','factors':{k:{'score':v[0],'status':'NS' if v[0] is None else 'Scored','rationale':v[1]} for k,v in factors.items()},'scores':res,'gates':gates,'classification':'Hold — unresolved / insufficient comparable growth evidence','critical_factors':{'GOV':'Scored5; no≤3 governance override','REV':'NS affects BQS12%/GQS40% and IAS viaBQS; cannot rank missing values','CAP':'Scored5, neither high-return nor persistent-destruction conclusion','CASH':'Scored4, not≤3; no GQS5cap','IAS':'NS because BQS missing andG2hold; R1 is conditional descriptive sensitivity only'},'sensitivity':'GOV/MOAT ±1 changes BQS known contribution±0.40, propagatedIAS±0.10; CAP/CASH±1 changes GQSknown±0.25; missingREV is not imputed.'}
(P/'scores.json').write_text(json.dumps(out,indent=2)+'\n');print(res)
