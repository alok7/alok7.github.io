# Silkflex Polymers (India) Limited — position 378

Private, source-safe research under Master Prompt v3.0. Cutoff: 20 October 2026; market reference: 19 October 2026.

Read `report.html` or `report.md`. All three aggregate scores are **NS**, with explicit missing-evidence bounds, because comparable historical revenue growth remains unresolved. This is not a numerical low-quality ranking or a finding of wrongdoing. Conditional scenarios do not verify completed funding.

## Offline rebuild

Using Python 3 with the standard library only:

1. Run `python rebuild.py` from the extracted company folder.
2. Run `python verify.py` for cash/debt/share/FCFF/IRR equations, mutation tests and static HTML DOM checks.
3. To reconstruct a retained vintage, run its `model.py` inside `model_vintages/v1` or `model_vintages/v2`, or `model_vintages/v3`, or `model_vintages/v4`.

The compact archive omits regenerable monthly compressed paths and retained-vintage summaries. The full archive retains distinct current/historical analytical paths. Source-safe financial, business and market inputs are frozen editorial extractions, not scraped again during rebuild. Exact historical differences are preserved rather than overwritten.

No raw source PDFs, OCR, personal account identifiers, private paths or Library IDs are included. Source URLs and retrieved hashes support provenance without redistributing full documents. No public Git, global registry, Library save, trade, browser launch or self-acceptance is performed here. Independent root review is required; the 374–383 publication batch requires all ten records accepted before publication.

`company_record.json` hashes predecessor artifact roles; `build_manifest.json` binds source/code/generated files including the record; external `archive_manifest.json` binds archive bytes. Hashes are non-circular. Cold rebuild proof is an external producer receipt, not independent acceptance. Browser evidence is structural/DOM only; an actual public browser check belongs after authorized release.

Current model v5 corrects the historical v4 opening-cash DCF sensitivity defect. Exact v4 inputs, model, summary and paths remain retained and rebuildable; historical outputs are not endorsed as current validated sensitivities. Source extractions are unchanged.
