## 1. Executive Verdict
SMR Jewels Limited is an Ahmedabad-based designer and B2B distributor of heritage jewellery, using outsourced artisans rather than an owned manufacturing plant. Reported FY26 sales of ₹432.37 crore and PAT of ₹24.75 crore look strong, but operating cash outflow of ₹16.50 crore, inventory-funded growth, gold-price/mix distortion and unresolved comparative-account changes prevent an evidence-backed compounder designation. **Hold — unresolved; BQS NS, GQS NS and IAS NS.** This is an unproven growth-and-working-capital thesis, not a proven fraud/default case. The ₹139.06 reference close is dated 19 October 2026 and secondary corroborated, not a verified executable BSE quote. A conditional base case clears the return hurdle using an exit multiple, but not the conservative DCF at this price; better valuation cannot cure reliability/funding gaps. Independent inventory assurance, reconciled accounts and actual post-IPO cash/use of funds could change the conclusion. [E01,E04,E06]

## 2. Research Header, Gates and Data Confidence
| Item | Basis |
|---|---|
| Original universe position | 383 of 457; SME publication group374–383 |
| Legal security | SMR Jewels Limited; INE11XK01017; BSE SME numeric code544774. Alpha trading ID ND; not silently substituted with aggregator SMRJ |
| Identity history | Incorporated26 October2018 as SMR Jewels Private Limited; public conversion11 October2024; listed8 June2026 [E01,E04] |
| Cutoff | Information through20 October2026 India time; retrieved25 October. Later results/events excluded |
| Market | Target and actual historical trade19 October2026; ₹139.06; secondary138,000 shares/126 trades; same-day trade, not stale. Primary daily file blocked [E06] |
| Shares/market cap | 18,653,743 post-IPO shares calculated; ₹{{market_cap}}crore reference capitalization. No blanket fully-diluted completeness claim |
| Financial scope | Standalone; Indian GAAP Accounting Standards/AS3, not IndAS. No subsidiaries/JVs/associates per audit. ₹crore unless stated |
| Decision assumptions | Five-year model;15% nominal pretax shareholder hurdle;16% WACC separately assumed; ₹5lakh illustrative liquidity position |

| Gate | Finding | Release condition |
|---|---|---|
| G1 integrity | Conditional, not Fail. Related-party property and loans need oversight; no substantiated severe diversion found | Fair lease terms, proceeds/RPT controls and lender-option status |
| G2 financial reliability | Hold — unresolved. Unmodified opinion is positive, but inventory KAM, confirmations and inconsistent comparative statements are material | Auditor/company reconciliation and independent stock/receivable evidence |
| G3 funding | Hold — unresolved, not evidenced default. IPO provided real capital; cutoff utilization/debt/reserves not known | Monitoring report, bank/loan balances, maturity and committed-headroom reconciliation |
| G4 tradability | Hold — unresolved. One active day does not prove ₹5lakh exit capacity through stress | Primary history, lot/restrictions, median turnover, zero-trade days/spreads |

Confidence: identity High; reported FY26 tables Medium (arithmetic mostly reproducible); economic earnings/reinvestment Low; current funding Low; gold-adjusted growth Low; market close Medium/primary execution Low. Overall conclusion confidence Low in investment attractiveness, High that the missing evidence blocks a favorable ranking. Missing disclosure does not imply misconduct.

## 3. Scorecard and Calculation Audit
{{scoretable}}

{{factortable}}

IAS weights are25%BQS+35%R+20%D+10%P+10%L, all unavailable for a supported current conclusion. No renormalization, neutral scores or unsupported overall blend. The generated audit table gives exact weighted contributions and missing-data bounds; no subtotal is treated as a final score. CASH2 reflects persistent negative reported cash conversion, not the IPO itself. A computable GQS would be capped at5 under the cash-quality override; NS stays NS. GOV4 does not trigger the governance cap. None of these three records is eligible for numeric rankings; use Pending evidence rather than the bottom of a ranked list.

## 4. Business Overview
The company designs jewellery in-house and supplies wholesalers, retailers, boutiques and exhibitions through job workers. Product families include heritage, bridal, Jadtar, Polki and Meenakari. The economic activity is designing, sourcing gold, commissioning skilled work, holding inventory and collecting customer cash—not merely collecting a low-capital royalty. The absence of a factory makes fixed assets small but does not make working capital small. [E01: business150–160]

FY25 sales were74.37% Gujarat, with the largest customer26.39% and top10 customers62.43%. Nine-month December2025 concentration was73.31% Gujarat, top customer14.06%, top10 60.46%; diversification improved at the top but remains narrow. These are different reporting lengths, not proof of sustainable deconcentration. Customer count fell from400 FY24 to229 FY25 even as average billed sales per customer rose; this conflicts with a simple broad-volume expansion story. [E01: KPI128/business160]

FY26 product disclosure shows ₹428.2114crore manufactured/design-led and ₹4.1551crore traded sales. “Manufactured” includes outsourced production; it does not establish an owned plant. Product note totals and separately reported other-operating revenue need minor reconciliation. Design and price/mix changes can grow gross sales without proportional grams. [E04: note17]

## 5. Moat / Industry Position
Relationships with artisans and recurring customers, design refreshes and exhibitions can support a niche. Their defensibility is limited: designs are not registered, no long-term exclusive demand or audited market share was established, and customer concentration creates bargaining risk. Claims of heritage/awards are not a moat score. The proposed studio may improve customer experience, but committing shareholder capital to a promoter-owned site introduces return and governance questions. [E01: risk18/business/objects]

| Primary comparator | Period/evidence | What it tests |
|---|---|---|
| Sky Gold & Diamonds | FY26 consolidated revenue₹6,294.9crore; reported CFO approximately−₹45crore versus−₹272crore FY25 [E07] | Much larger B2B/manufacturing and export network; even scale does not ensure cash conversion. Acquisition/consolidation perimeter differs; no like-for-like multiple imported |
| Shanti Gold International | FY26 revenue₹2,018.709crore; PAT₹140.154crore; CFO−₹260.627crore; jewellery1,747.8kg, volume+15.2% versus sales+82.46% [E08] | Direct evidence that nominal gold-sector revenue can far outrun activity; superior volume disclosure, weaker reported cash conversion; not a claim SMR has identical mix |
| Shringar House of Mangalsutra | FY25 prospectus revenue₹1,429.815crore; EBITDA₹92.612crore; PAT₹61.114crore; top10 39.92% [E09] | Focused product/manufacturing competitor with lower customer concentration in this historical comparison. FY26AR primary403; do not represent FY25 as latestFY26 |

At ₹139.06, ₹5 lakh represents about3,596 shares before lot rounding. Relative to the single verified-secondary traded day138,000 shares, that is2.61% of volume; at a hypothetical10% participation limit it is less than one such day. This is not a60-day liquidity estimate, a lot-valid order, or guaranteed exit; one-day turnover₹1.9028crore may not recur.

These peers are operational comparators, not investment recommendations or ordinal quality rankings. No synchronized primary peer prices were verified, so peer P/E/P/B and relative-valuation percentile are ND. Large branded retailers would be materially different businesses. Competition can be stronger than SMR despite similar headline margins.

## 6. Revenue Growth & Scale
{{growthtable}}

Reported FY21–FY26 five-year CAGR is {{cagr5}}; FY23–FY26 three-year CAGR {{cagr3}}. The earlier original statements and later restated accounts are preserved rather than erasing the FY23 decline. The FY22 original-to-FY23 restated equity bridge is unavailable, limiting capital comparability. Ten-year CAGR is NA for a company incorporated2018; FY19 partial incorporation period is not a full-year CAGR base. Latest full auditedFY26 supersedes the nine-monthDecember2025 stub; no overlapping TTM or annualized quarter is manufactured. [E01–E04]

The RHP describes a mix shift: traded goods share was about34.26%FY24 versus approximately10%FY25, while gold procurement prices rose. Its discussion even uses a June2025 gold peak to explain FY25, a timing limitation. Reported FY25 customer count and average order size support larger tickets, not a quantified weight bridge. Approximately20kg sold at one exhibition for around₹20crore is a management/event-level observation, not annual volume. Thus **REV is NS**, not9 from nominal CAGR. Peer Shanti's weight disclosure demonstrates why subtracting a generic gold index is insufficient: purity, stone content, trade/design mix and making charges differ. Obtain grams, net making revenue, realized gold price and same-customer quantities before scoring underlying growth. [E01,E08]

## 7. Growth Quality & Reinvestment Runway
The growth route is specific: more designs/customer relationships, studio displays, exhibitions and additional gold inventory. IPO objects allocated ₹6.4crore studio, ₹6.5crore debt repayment and ₹30crore long-term working capital, with remaining net funds for general purposes. Fresh gross₹51.2crore less estimated company expenses₹3.2771crore gives₹47.9229crore net; OFS₹12.544crore goes to sellers, not operations. [E01,E04]

The August25 announcement verifies commencement, not completion, spending quantum or return. No verified September/cutoff bank balances allow an assertion that₹47.9229crore remains available. Inventory and receivables, not just studio capex, dominate incremental capital. Equity growth from IPO is not internally financed compounding. The model makes the funding dependency visible and stress-tests lost cash; projected accessible demand remains an assumption. [E05]

{{capitalmetrics}}

The funding-IC proxy differs from operating invested capital by tax/provision/classification balances; this is not an exact asset-based ROIC. Current/previous inventory and reserves changed and confirmation caveats remain. CAP is NS despite attractive reported/proxy returns. DUR5 recognizes an accessible niche without assuming every exhibition converts into collected sales. GQS remains NS, with the CASH override preserved.

## 8. Management, Governance & Execution
The promoter-family organization has business experience and a disclosed related-party structure, but post-listing execution history is short. No automatic penalty is applied for an IPO, a family business or an OFS. The critical question is treatment of minority capital. The proposed25-year studio lease on promoter-owned land runs December2024–November2049, at₹0.12crore annual rent plus₹0.5crore refundable deposit. Long tenure is a counterweight to related-party risk; independent rental/capex ownership and termination compensation evidence is still needed. [E01: objects]

FY26 disclosed related-concern sales₹0.4266crore and purchases₹0.2396crore; director remuneration and loans are disclosed. These relatively small commercial amounts are not evidence of tunnelling. A₹1.5968crore guarantee is a contingent claim, not automatically funded debt. No separately named guarantee-call scenario is modeled; the generic opening-cash haircuts test broad unidentified cash uses, not a verified crystallization or timing of this guarantee. Audit is unmodified; CARO does not establish willful default or reported fraud. Against that, audit text refers incongruously to coal-quality revenue adjustments and states reliance on management for physical verification of raw materials/stores/spares/packing. This is a report-quality concern—not evidence of coal operations or falsification. Raw material inventory is₹17.4188crore; do not extrapolate this specific statement to all₹55.567crore stock. Finished-goods NRV testing is described. [E04: audit50–52,notes24]

| Promise / event | Dated evidence | Delivery status at cutoff |
|---|---|---|
| Studio capex | RHPMay18,2026:₹6.4crore object | August25 commencement; completion/quantumND |
| Debt repayment | ₹6.5crore object | Actual current debt/use reconciliationND; modeled assumption only |
| Working capital | ₹30crore object | No verified monitor breakdown; incremental cash realization must be tested |
| CSR | RHP prior shortfall; FY26AR reports₹0.1922crore spent incl carryover | Positive disclosed resolution; not independent impact verification |
| October orders / price query | October7₹67crore order lead and October19 reply discovered secondarily | Primary attachments inaccessible; no orders added to revenue and no unsupported claim query unanswered |

Historical capital: August2024 loan conversion₹3.7914crore and cash preferential issuance; bonuses400:1 and2:1 do not raise cash. RHP lender-option authorization up to₹7.5crore is not proven outstanding in full; residual authorization is not a recognized security. FY26 CARO reports no new preferential/convertible issue, yet exact closure/terms of the historical option remain open. Basic post-IPO shares are used with a separately labeled conversion sensitivity, not a falsely exact fully diluted cap table. [E01,E04]

## 9. Financial Forensics
{{historytable}}

{{reconciliationtable}}

FY26 CFO bridge is₹34.7908crore pre-WC cash earnings−₹47.0968crore WC movement−₹4.1965crore tax=−₹16.5025crore. The printed “cash generated” subtotal repeats the WC movement instead of the sum; corrected arithmetic is explicitly calculated, not a silently edited reported figure. Opening cash₹10.3027−CFO16.5025−capex0.3952+financing6.6125=₹0.0175crore versus reported0.0174, rounding difference₹0.0001crore. Reported FCF proxy−₹16.8977crore is not FCFF. Interest₹1.9147crore classified financing differs from total finance expense₹2.8871crore; do not blindly add both. [E04:CF67]

CumulativeFY23–FY26 CFO/PAT is {{cashratio}} using ratio of sums, not average yearly ratios; bothFY25 vintages leave it negative. OriginalFY21 CFO begins with PAT rather than PBT and is retained with a warning, excluded from this cumulative test. The apparent FY22 cash release is historical counterevidence to permanently weak conversion, but does not offset the later multi-year funding pattern. No cash quarter is invented.

FY26 inventory₹55.567crore, receivables₹21.4708crore, supplier advances₹7.3877crore and customer advances₹4.0192crore imply narrow ONWC₹74.0934crore (excluding financing/tax). Revenue-based closing receivable/inventory days are {{rec_days}}/{{inv_days}}; inventory days on revenue are explicitly not cost-of-sales DIO. Closing balances obscure within-year peaks. Receivables described as good/unsecured and balances subject confirmation do not establish collection. No loss provision is invented. [E04]

Debt₹17.0926crore includes₹4.6935crore current maturities already in short-term debt; do not add them twice. Loans carry varied rates, including unsecured14–17.5%; no new undrawn committed revolving line was verified. Current cash at March31 is not post-IPO cash. Tax liability₹8.2793crore and guarantee₹1.5968crore matter to liquidity; the model's cash-haircut sensitivity can absorb these, but it is not a tax/payment reconciliation. Borrowings converted noncash inFY25 may be included in share-proceeds cash-flow presentation, which requires issuer reconciliation. [E04]

## 10. Valuation & Market Expectations
Reference market cap₹{{market_cap}}crore divided by FY26PAT gives{{pe}}x. FY26 historical EPS₹16.89 uses pre-IPO shares; post-IPO pro-forma EPS is₹{{eps}}. Using₹16.89 with post-IPO equity value would misstate P/E. No actual cutoff EV is claimed without current net debt. [E04,E06,C01]

The offline model starts from **synthetic** March2026 balances plus IPO net funds minus assumed₹6.5crore repayment: cash₹41.4403crore and debt₹10.5926crore. These are neither observed October balances nor forecasts for a missed historical period. At assumed time0 of the forward five-year exercise, IPO WC cash is counted once, then consumed by modeled ONWC; full remaining₹6.4crore studio funding is reserved and spent over18months. Existing CWIP is sunk, making this conservative versus a net remaining studio budget. Actual tax payments, utilization and operating movements since March are unknown and tested through opening-cash haircuts, not concealed.

Revenue ramps linearly each year to the stated terminal annual run-rate; actual modeled monthly sales sum below that endpoint during growth. Exit EBIT and terminal FCFF use the end-of-year-five annualized run-rate, an explicit forward-normalization assumption, not the sum of year-five sales. Every month links revenue ramp, EBIT,14.5% opening debt interest,26% positive earnings tax (no loss tax credit), D&A0.1% sales, maintenance capex0.15%, ONWC movement, studio spend, contractual-style amortization over36months (analyst assumption, not actual schedule), cash and shares. Minimum operating cash₹2crore plus remaining studio reserve must be met. No uncommitted debt draw rescues a failed path. Rent is included in margins; no invented AS lease liability. All margins/rates and exit multiples below are analyst assumptions, not management guidance.

{{scenariotable}}

Bear assumptions: year1 sales−20%, then2%/5%/5%/5%; EBIT2.5–3.5%, WC22–23%,25% studio overrun,6xexitEBIT. Base:15% annual growth/6.5%EBIT/18%WC/10xexit. Bull:25%growth/8%EBIT/WC18% declining16%/13x. Linked failure: sales−30% then−10%, flat then3%/3%; margin1–2.5%, WC35%,50%capex overrun/4x. Rescue supplies only the calculated funding gap at assumed₹80/share, capped₹20crore; it is not committed or endorsed. Failed-path later arithmetic is diagnostic only; no fictitious IRR or terminal DCF is shown.

DCF uses monthly FCFF=EBIT×(1−tax)+D&A−capex−ΔONWC,16%WACC,4%terminal growth with terminal WC reinvestment and maintenance. Opening net cash is added once; ending cash is not also added to DCF. Exit-multiple IRR instead adds ending cash/subtracts debt and divides by actual modeled diluted shares; there are no dividends. Base DCF₹{{dcf_base}} is below₹139.06 even while10xexit supports {{irr_base}}—this disagreement is material terminal-value risk, not two confirming targets. No live target/entry recommendation follows.

{{sensitivitytable}}

Reverse expectations scan growth from−30% to80% in1pp steps, preserving feasibility and discontinuities; the base margins/WC10xexit assumptions meet15% return in bracket{{reverse_bracket}}. No interpolation jumps across failed funding points. DCF assumptions differ from the exit multiple, so return-clearing growth is not a complete market-implied growth estimate. Canonical monthly paths and the full grid are included offline. Upper growth becomes funding-sensitive; more sales is not monotonically safer. A further modeled conversion of₹3.7086crore at₹80/share tests a hypothetical remainder of historical authorization, not an assertion it is outstanding or priced that way; debt is reduced with shares added, and cash is not raised twice.

## 11. Bear Case & Permanent-Loss Path
The strongest bear case is that apparent growth mainly reflects gold prices, higher-ticket mix and inventory/accounting marks, while saleable stock and collections cannot fund obligations. Customer loss then lower margin, slower stock turnover, delayed supplier recovery and depleted IPO liquidity can require dilutive funding at the worst time. The failed model shows why simply discounting a terminal profit stream is insufficient: survival fails first. [E01,E04,A01]

The strongest counterevidence is equally important: genuine disclosed IPO cash, rising operating earnings, audited unmodified statements, a specific studio commencement event, lower single-customer concentration in the December stub, and prior historical cash releases. These do not establish that the bearish story will happen. The thesis-break variable is independently realizable inventory plus collections relative to cash commitments—not a short-term price fall. Missing monitor access does not prove misuse or default.

The failed-path recovery worksheet discounts opening inventory to60%, receivables70% and supplier advances50%, deducting operating payables/customer advances/debt/tax provisions. Its₹{{recovery}}per-share residual is an illustrative recovery stress, not liquidation value: other claims, enforcement costs, gold price, priority and current cash are unknown. Equity could lose substantially more; no floor is promised.

## 12. 5× / 10× Feasibility
Five-year5x and10x price outcomes require37.97% and58.49% annualized gains. With zero dividends/dilution and unchanged margins/multiple they require similar annual revenue growth; gold gross sales are not equivalent economic value creation. At unchanged current P/E,10x requires PAT about₹247.49crore versus₹24.75crore. Holding a normalized5%net margin would require₹4,949.7crore sales, with18%ONWC approximately₹890.95crore before fixed assets—far beyond current funding and requiring a credible financing bridge. Lower multiple or dilution raises the burden. The modeled bull is not a validated10x case. Classification: **Speculative / unsupported**, not impossible.

## 13. Monitoring Plan
| KPI | Baseline | Evidence milestone / warning | Thesis-break test |
|---|---|---|---|
| Inventory assurance | ₹55.567croreFY26; raw₹17.4188crore | Independent physical/NRV and jobworker reconciliation next audited/interim update | Material unsupported stock undermines reliability |
| Collections | ₹21.4708crore FY26 receivables | Subsequent collections/ageing; investigate further growth faster than bills | Demonstrated nonrecoverability exhausting funding |
| CFO conversion | FY26−₹16.5025crore | Positive rolling cash after tax, not debt/IPO financed cash | Persistent gap plus no financeable remedy |
| Price/volume/mix | AnnualgramsND | Grams/purity/making-charge disclosure | No genuine underlying scale despite capital deployment |
| IPO proceeds | Net₹47.9229crore raised | Read monitoring balances and bank use; investigate deviations | Proven misuse or insufficient essential funding |
| Studio | ₹6.4crore plan; commencedAug25 | Timetable, spend, completion, client activity | Unrecoverable capital on related-party site or severe cost overrun |
| Debt/liabilities | Marchdebt₹17.0926crore; guarantee₹1.5968crore | Actual repayment/maturities/covenants; investigate refinancing dependence | Evidenced payment failure, not mere missing data |
| Accounts | FY25 revisions and subtotal errors | Corrected audited comparative/loan-conversion cash bridge | Material unresolvable misstatement |
| Liquidity | One historical active day | Primary60-session turnover/spread/lot and restrictions | Reference position cannot practically exit |

Review on actual results, proceeds-monitor and material filings. Thresholds are economic warning conditions, not fabricated covenant numbers. No reminder or automatic trade is created.

## 14. Final Classification & Conditional Action
**Hold — unresolved; research priority, not eligible for investment consideration on this record.** Do not use the ordinary numeric classification matrix on NS aggregates. G1 is not failed, so neither “Avoid — governance” nor proven fraud/default is asserted. No evidence-backed compounder label and no overall stock rank are warranted. All three ranking eligibility flags are false, with Pending evidence placement; G2/G3/G4 unresolved are disclosed rather than treated as evidenced gate failures.

A lower price can improve conditional model returns but cannot release missing-evidence gates. To revisit: reconcile accounts and inventory, verify cash/debt/use of proceeds, establish diluted capital and actual tradability, and separate underlying business activity from metal-price/mix growth. An existing holder faces a different liquidity problem; without holdings/cost/tax context there is no unsupported sell instruction or allocation advice.

## 15. Sources, Assumptions & Open Questions
{{sourcetable}}

Evidence type V means a disclosure was read, not that underlying physical facts were independently audited by this research; M means management claim; C means reproducible calculation; A means assumption. Every numerical forecast is A01; calculations are C01 and linked to offline inputs. Secondary prices are labeled separately, not elevated to primary verification. Sources dated after20October are excluded; retrieval25October is not the valuation date.

Key open questions: reconciliation of FY25 stock/PAT/equity/CFO; actual noncash loan conversion in cash-flow proceeds; physical inventory/confirmations; exact cutoff IPO balances and debt; historical lender option closure; annualgrams/net-making-revenue; current shareholding/encumbrance and multi-session liquidity; actual order execution versus leads. Denied primaryBSE files were not bypassed. ShringarFY26 primary403 is explicitly not substituted with aggregator financials. Source URLs and authored extracted data—not raw PDFs/OCR—are packaged.

History policy: this is the first authored internal SMR research located in this task. Genuine originalFY20/FY22 and restatedRHP/FY26 financial vintages are preserved in financial_inputs and source notes; no imaginary prior complete research draft is generated. Rebuild uses Python standard library plus the stated Markdown renderer; manifests distinguish authored-input aggregate, reader bytes and company-record bytes. Independent parent review is pending; producer checks do not self-accept or authorize publication.
