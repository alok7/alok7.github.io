import json
from pathlib import Path
P=Path(__file__).resolve().parent
def put(n,x): (P/n).write_text(json.dumps(x,indent=2)+'\n')
h=[]
def row(y,r,pat,cfo,capex,debt,cash,eq,inv,rec,pay,ebit,da,**kw):
 h.append(dict(year=y,revenue=r,pat=pat,cfo=cfo,capex=capex,debt=debt,cash=cash,equity=eq,inventory=inv,receivables=rec,payables=pay,ebit=ebit,da=da,**kw))
row(2020,40.2413862,.0061931,None,None,None,None,None,None,None,None,None,.0008245,source='E03',basis='Original audited, rupees; CFO ND')
row(2021,47.226462,.055147,-.996047,.044221,3.9978,.115021,.074115,5.190439,5.480568,4.509412,.378223,.005428,source='E02',basis='Original audited thousands; CFO starts from PAT not PBT; preserve reported')
row(2022,75.957333,.015015,4.027562,.064027,.888856,.570084,.08913,4.354581,9.386791,6.725424,.419186,.016738,source='E02',basis='Original audited thousands; not restated comparable opening FY23 equity')
row(2023,67.5278,.9094,-1.3669,.0235,6.3272,.5994,1.0364,12.6862,5.7165,7.9806,1.9344,.0263,source='E01',basis='RHP restated lakhs')
row(2024,124.523,3.8451,-1.0598,.0798,7.6471,.1579,4.8816,9.3336,4.048, .2101,6.1035,.0413,source='E01',basis='RHP restated lakhs')
row(2025,263.2518,10.7654,.2883,.0597,8.5655,10.3027,24.7568,24.012,7.6465,1.2521,15.5839,.054,source='E04',basis='FY26 comparative; unreconciled revisions from RHP',advances=.9704,customer_advances=5.413,other_operating_assets=.1103)
row(2026,432.3666,24.7485,-16.5025,.3952,17.0926,.0174,49.5053,55.567,21.4708,6.3804,35.6989,.0642,source='E04',basis='FY26 audited standalone AS, not Ind AS',advances=7.3877,customer_advances=4.0192,other_operating_assets=.0675)
put('financial_inputs.json',{'unit':'INR crore','scope':'Standalone; no subsidiary/JV/associate per FY26 auditor','history':h,'interim_9m_dec25':{'revenue':308.7201,'pat':18.555,'cfo':-16.0062,'cash':.2008,'debt':16.5392,'source':'E01; not additive to FY26; no comparable 9m24 and no TTM'},'reconciliation':{'FY25_RHP':{'pat':10.4123,'kpi_pat':10.4147,'cfo':1.2538,'inventory':23.185,'equity':24.1379,'interest_financing':.8116},'FY25_AR26':{'pat':10.7654,'cfo':.2883,'inventory':24.012,'equity':24.7568,'interest_financing':.8116},'identified_PBT_bridge':.4718,'identified_tax_bridge':.1188,'remaining_equity_difference_unexplained':.2658,'note':'FY25 stock-change expense -13.2186 vs -12.7468 produces +.4718 PBT and approx+.3530 PAT. Balance inventory +.8270 and reserves+.6189 do not fully follow this bridge; no silent normalization. FY25 CFO change -.9655 offset financing +.9655; cash same. FY25 Note7/8 totals swapped in BS; use itemized customer advance not mislabeled total.'}})
put('model_inputs.json',{'unit':'INR crore except price/shares crore','price':139.06,'shares':1.8653743,'revenue0':432.3666,'cash_FY26':.0174,'debt_FY26':17.0926,'net_fresh_proceeds':47.9229,'assumed_repayment':6.5,'studio_budget':6.4,'onwc0':74.0934,'tax':.26,'rate':.145,'wacc':.16,'terminal_growth':.04,'minimum_cash':2,'equity_hurdle':.15,'assumed_new_equity_price':80,'assumed_new_equity_cap':20,'note':'Synthetic FY26 plus IPO funding bridge, NOT actual 20Oct balance. All proceeds including WC remain cash until modeled spending. Existing studio CWIP is sunk, full incremental6.4 is conservative. No uncommitted debt draw. Debt amortized over36months; GCP cash not spent assumed. Conversion status unresolved so separate sensitivity. Interest expense full modeled; lease rent in EBIT, no lease debt invented.', 'scenarios':{
'bear':{'growth':[-.2,.02,.05,.05,.05],'margin':[.025,.03,.035,.035,.035],'wc':[.23,.23,.22,.22,.22],'multiple':6,'capex_overrun':1.25,'equity':False},
'base':{'growth':[.15]*5,'margin':[.065]*5,'wc':[.18]*5,'multiple':10,'capex_overrun':1,'equity':False},
'bull':{'growth':[.25]*5,'margin':[.08]*5,'wc':[.18,.175,.17,.165,.16],'multiple':13,'capex_overrun':1,'equity':False},
'linked_failure':{'growth':[-.3,-.1,0,.03,.03],'margin':[.01,.015,.02,.025,.025],'wc':[.35]*5,'multiple':4,'capex_overrun':1.5,'equity':False},
'conditional_rescue':{'growth':[-.3,-.1,0,.03,.03],'margin':[.01,.015,.02,.025,.025],'wc':[.35]*5,'multiple':4,'capex_overrun':1.5,'equity':True}}})
