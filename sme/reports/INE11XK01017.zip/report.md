# SMR Jewels Limited — position383

## 1. Executive Verdict
SMR Jewels Limited is an Ahmedabad-based designer and B2B distributor of heritage jewellery, using outsourced artisans rather than an owned manufacturing plant. Reported FY26 sales of ₹432.37 crore and PAT of ₹24.75 crore look strong, but operating cash outflow of ₹16.50 crore, inventory-funded growth, gold-price/mix distortion and unresolved comparative-account changes prevent an evidence-backed compounder designation. **Hold — unresolved; BQS NS, GQS NS and IAS NS.** This is an unproven growth-and-working-capital thesis, not a proven fraud/default case. The ₹139.06 reference close is dated 19 October 2026 and secondary corroborated, not a verified executable BSE quote. A conditional base case clears the return hurdle using an exit multiple, but not the conservative DCF at this price; better valuation cannot cure reliability/funding gaps. Independent inventory assurance, reconciled accounts and actual post-IPO cash/use of funds could change the conclusion. [E01,E04,E06]

## 2. Research Header, Gates and Data Confidence
| Item | Basis |
|---|---|
| Original universe position | 383 of 457; SME publication group374–383 |
| Legal security | SMR Jewels Limited; INE11XK01017; BSE SME numeric code544774. Alpha trading ID ND; not silently substituted with aggregator SMRJ |
| Identity history | Incorporated26 October2018 as SMR Jewels Private Limited; public conversion11 October2024; listed8 June2026 [E01,E04] |
| Cutoff | Information through20 October2026 India time; retrieved25 October. Later results/events excluded |
| Market | Target and actual historical trade19 October2026; ₹139.06; secondary138,000 shares/126 trades; same-day trade, not stale. Primary daily file blocked [E06] |
| Shares/market cap | 18,653,743 post-IPO shares calculated; ₹259.40crore reference capitalization. No blanket fully-diluted completeness claim |
| Financial scope | Standalone; Indian GAAP Accounting Standards/AS3, not IndAS. No subsidiaries/JVs/associates per audit. ₹crore unless stated |
| Decision assumptions | Five-year model;15% nominal pretax shareholder hurdle;16% WACC separately assumed; ₹5lakh illustrative liquidity position |

| Gate | Finding | Release condition |
|---|---|---|
| G1 integrity | Conditional, not Fail. Related-party property and loans need oversight; no substantiated severe diversion found | Fair lease terms, proceeds/RPT controls and lender-option status |
| G2 financial reliability | Hold — unresolved. Unmodified opinion is positive, but inventory KAM, confirmations and inconsistent comparative statements are material | Auditor/company reconciliation and independent stock/receivable evidence |
| G3 funding | Hold — unresolved, not evidenced default. IPO provided real capital; cutoff utilization/debt/reserves not known | Monitoring report, bank/loan balances, maturity and committed-headroom reconciliation |
| G4 tradability | Hold — unresolved. One active day does not prove ₹5lakh exit capacity through stress | Primary history, lot/restrictions, median turnover, zero-trade days/spreads |

Confidence: identity High; reported FY26 tables Medium (arithmetic mostly reproducible); economic earnings/reinvestment Low; current funding Low; gold-adjusted growth Low; market close Medium/primary execution Low. Overall conclusion confidence Low in investment attractiveness, High that the missing evidence blocks a favorable ranking. Missing disclosure does not imply misconduct.

## 3. Scorecard and Calculation Audit

| Score | Raw/final | Coverage | Known contribution | Missing-data bound | Eligibility |
| --- | --- | --- | --- | --- | --- |
| BQS | NS / NS | 68.00% | 2.70 | 3.02–5.90 | False |
| GQS | NS / NS | 30.00% | 1.20 | 1.90–8.20 | False |
| IAS | NS / NS | 0.00% | ND | NS | False |



| Factor | Score | BQScontribution | GQScontribution | Evidence/reason |
| --- | --- | --- | --- | --- |
| GOV | 4 | 0.80 | 0.00 | E01/E04: family-related studio capital and audit-document inconsistencies; no severe misconduct evidenced. |
| MOAT | 4 | 0.80 | 0.00 | E01: design/artisan ties but unregistered designs, concentrated customers and no captive manufacturing. |
| REV | ND | NS | NS | E01/E04/E07: gold/mix pass-through materially obscures growth; no annual grams/making-fee bridge. Reported5yr55.7% is NOT underlying growth score. |
| DUR | 5 | 0.50 | 1.00 | E01/E05: funded studio plus jewellery demand; concentrated region and no quantified delivered pipeline. |
| CAP | ND | NS | NS | E04: inventory/earnings revisions and unconfirmed balances invalidate reliable incremental operating capital economics. |
| CASH | 2 | 0.20 | 0.20 | E01/E04: negative cumulative FY23–26 CFO despite profits; raw reported signal robust under bothFY25 vintages. |
| BAL | ND | NS | NS | E04/E05: IPO helps but actual utilization/current debt and committed headroom not verified. |
| EXEC | 5 | 0.40 | 0.00 | E01/E05: scaled sales and started studio, not evidence completed/returns; limited postIPO record. |
| EARN | ND | NS | NS | E04: earnings mix and inventory adjustments, prior-year restatement unresolved. |


IAS weights are25%BQS+35%R+20%D+10%P+10%L, all unavailable for a supported current conclusion. No renormalization, neutral scores or unsupported overall blend. The generated audit table gives exact weighted contributions and missing-data bounds; no subtotal is treated as a final score. CASH2 reflects persistent negative reported cash conversion, not the IPO itself. A computable GQS would be capped at5 under the cash-quality override; NS stays NS. GOV4 does not trigger the governance cap. None of these three records is eligible for numeric rankings; use Pending evidence rather than the bottom of a ranked list.

## 4. Business Overview
The company designs jewellery in-house and supplies wholesalers, retailers, boutiques and exhibitions through job workers. Product families include heritage, bridal, Jadtar, Polki and Meenakari. The economic activity is designing, sourcing gold, commissioning skilled work, holding inventory and collecting customer cash—not merely collecting a low-capital royalty. The absence of a factory makes fixed assets small but does not make working capital small. [E01: business150–160]

FY25 sales were74.37% Gujarat, with the largest customer26.39% and top10 customers62.43%. Nine-month December2025 concentration was73.31% Gujarat, top customer14.06%, top10 60.46%; diversification improved at the top but remains narrow. These are different reporting lengths, not proof of sustainable deconcentration. Customer count fell from400 FY24 to229 FY25 even as average billed sales per customer rose; this conflicts with a simple broad-volume expansion story. [E01: KPI128/business160]

FY26 product disclosure shows ₹428.2114crore manufactured/design-led and ₹4.1551crore traded sales. “Manufactured” includes outsourced production; it does not establish an owned plant. Product note totals and separately reported other-operating revenue need minor reconciliation. Design and price/mix changes can grow gross sales without proportional grams. [E04: note17]

## 5. Moat / Industry Position
Relationships with artisans and recurring customers, design refreshes and exhibitions can support a niche. Their defensibility is limited: designs are not registered, no long-term exclusive demand or audited market share was established, and customer concentration creates bargaining risk. Claims of heritage/awards are not a moat score. The proposed studio may improve customer experience, but committing shareholder capital to a promoter-owned site introduces return and governance questions. [E01: risk18/business/objects]

| Primary comparator | Period/evidence | What it tests |
|---|---|---|
| Sky Gold & Diamonds | FY26 consolidated revenue₹6,294.9crore; reported CFO approximately−₹45crore versus−₹272crore FY25 [E07] | Much larger B2B/manufacturing and export network; even scale does not ensure cash conversion. Acquisition/consolidation perimeter differs; no like-for-like multiple imported |
| Shanti Gold International | FY26 revenue₹2,018.709crore; PAT₹140.154crore; CFO−₹260.627crore; jewellery1,747.8kg, volume+15.2% versus sales+82.46% [E08] | Direct evidence that nominal gold-sector revenue can far outrun activity; superior volume disclosure, weaker reported cash conversion; not a claim SMR has identical mix |
| Shringar House of Mangalsutra | FY25 prospectus revenue₹1,429.815crore; EBITDA₹92.612crore; PAT₹61.114crore; top10 39.92% [E09] | Focused product/manufacturing competitor with lower customer concentration in this historical comparison. FY26AR primary403; do not represent FY25 as latestFY26 |

At ₹139.06, ₹5 lakh represents about3,596 shares before lot rounding. Relative to the single verified-secondary traded day138,000 shares, that is2.61% of volume; at a hypothetical10% participation limit it is less than one such day. This is not a60-day liquidity estimate, a lot-valid order, or guaranteed exit; one-day turnover₹1.9028crore may not recur.

These peers are operational comparators, not investment recommendations or ordinal quality rankings. No synchronized primary peer prices were verified, so peer P/E/P/B and relative-valuation percentile are ND. Large branded retailers would be materially different businesses. Competition can be stronger than SMR despite similar headline margins.

## 6. Revenue Growth & Scale

| FYendMarch | Revenue₹cr | YoY | Annualaddition₹cr | Basis |
| --- | --- | --- | --- | --- |
| 2020 | 40.2414 | NA | ND | Original audited, rupees; CFO ND [E03] |
| 2021 | 47.2265 | 17.36% | 6.9851 | Original audited thousands; CFO starts from PAT not PBT; preserve reported [E02] |
| 2022 | 75.9573 | 60.84% | 28.7309 | Original audited thousands; not restated comparable opening FY23 equity [E02] |
| 2023 | 67.5278 | -11.10% | -8.4295 | RHP restated lakhs [E01] |
| 2024 | 124.5230 | 84.40% | 56.9952 | RHP restated lakhs [E01] |
| 2025 | 263.2518 | 111.41% | 138.7288 | FY26 comparative; unreconciled revisions from RHP [E04] |
| 2026 | 432.3666 | 64.24% | 169.1148 | FY26 audited standalone AS, not Ind AS [E04] |


Reported FY21–FY26 five-year CAGR is 55.72%; FY23–FY26 three-year CAGR 85.69%. The earlier original statements and later restated accounts are preserved rather than erasing the FY23 decline. The FY22 original-to-FY23 restated equity bridge is unavailable, limiting capital comparability. Ten-year CAGR is NA for a company incorporated2018; FY19 partial incorporation period is not a full-year CAGR base. Latest full auditedFY26 supersedes the nine-monthDecember2025 stub; no overlapping TTM or annualized quarter is manufactured. [E01–E04]

The RHP describes a mix shift: traded goods share was about34.26%FY24 versus approximately10%FY25, while gold procurement prices rose. Its discussion even uses a June2025 gold peak to explain FY25, a timing limitation. Reported FY25 customer count and average order size support larger tickets, not a quantified weight bridge. Approximately20kg sold at one exhibition for around₹20crore is a management/event-level observation, not annual volume. Thus **REV is NS**, not9 from nominal CAGR. Peer Shanti's weight disclosure demonstrates why subtracting a generic gold index is insufficient: purity, stone content, trade/design mix and making charges differ. Obtain grams, net making revenue, realized gold price and same-customer quantities before scoring underlying growth. [E01,E08]

## 7. Growth Quality & Reinvestment Runway
The growth route is specific: more designs/customer relationships, studio displays, exhibitions and additional gold inventory. IPO objects allocated ₹6.4crore studio, ₹6.5crore debt repayment and ₹30crore long-term working capital, with remaining net funds for general purposes. Fresh gross₹51.2crore less estimated company expenses₹3.2771crore gives₹47.9229crore net; OFS₹12.544crore goes to sellers, not operations. [E01,E04]

The August25 announcement verifies commencement, not completion, spending quantum or return. No verified September/cutoff bank balances allow an assertion that₹47.9229crore remains available. Inventory and receivables, not just studio capex, dominate incremental capital. Equity growth from IPO is not internally financed compounding. The model makes the funding dependency visible and stress-tests lost cash; projected accessible demand remains an assumption. [E05]


| Metric | Calculation/result | Limitation |
| --- | --- | --- |
| FY26fundingIC | equity+debt−cash = 66.58 | Includes net nonoperating/tax classifications |
| AveragefundingICROCE | 79.68% | EBIT/averageopeningclosing; not issuerreportedclosingdenominator |
| AveragefundingICROIC | 58.97% | 26%normalizedtax assumption; not verified operatingROIC |
| Incrementalproxy | 34.17% | ΔEBIT×.74/ΔfundingIC; distorted by revisions/IPOtiming; CAPNS |
| NarrowONWC | 74.09 | inventory+receivables+supplieradvances+otherCA−tradepayables−customeradvances |
| OperatingICproxy | 75.07 | addsPPE/CWIP/deposit; tax/provisionbridgegap8.49 |


The funding-IC proxy differs from operating invested capital by tax/provision/classification balances; this is not an exact asset-based ROIC. Current/previous inventory and reserves changed and confirmation caveats remain. CAP is NS despite attractive reported/proxy returns. DUR5 recognizes an accessible niche without assuming every exhibition converts into collected sales. GQS remains NS, with the CASH override preserved.

## 8. Management, Governance & Execution
The promoter-family organization has business experience and a disclosed related-party structure, but post-listing execution history is short. No automatic penalty is applied for an IPO, a family business or an OFS. The critical question is treatment of minority capital. The proposed25-year studio lease on promoter-owned land runs December2024–November2049, at₹0.12crore annual rent plus₹0.5crore refundable deposit. Long tenure is a counterweight to related-party risk; independent rental/capex ownership and termination compensation evidence is still needed. [E01: objects]

FY26 disclosed related-concern sales₹0.4266crore and purchases₹0.2396crore; director remuneration and loans are disclosed. These relatively small commercial amounts are not evidence of tunnelling. A₹1.5968crore guarantee is a contingent claim, not automatically funded debt. No separately named guarantee-call scenario is modeled; the generic opening-cash haircuts test broad unidentified cash uses, not a verified crystallization or timing of this guarantee. Audit is unmodified; CARO does not establish willful default or reported fraud. Against that, audit text refers incongruously to coal-quality revenue adjustments and states reliance on management for physical verification of raw materials/stores/spares/packing. This is a report-quality concern—not evidence of coal operations or falsification. Raw material inventory is₹17.4188crore; do not extrapolate this specific statement to all₹55.567crore stock. Finished-goods NRV testing is described. [E04: audit50–52,notes24]

| Promise / event | Dated evidence | Delivery status at cutoff |
|---|---|---|
| Studio capex | RHPMay18,2026:₹6.4crore object | August25 commencement; completion/quantumND |
| Debt repayment | ₹6.5crore object | Actual current debt/use reconciliationND; modeled assumption only |
| Working capital | ₹30crore object | No verified monitor breakdown; incremental cash realization must be tested |
| CSR | RHP prior shortfall; FY26AR reports₹0.1922crore spent incl carryover | Positive disclosed resolution; not independent impact verification |
| October orders / price query | October7₹67crore order lead and October19 reply discovered secondarily | Primary attachments inaccessible; no orders added to revenue and no unsupported claim query unanswered |

Historical capital: August2024 loan conversion₹3.7914crore and cash preferential issuance; bonuses400:1 and2:1 do not raise cash. RHP lender-option authorization up to₹7.5crore is not proven outstanding in full; residual authorization is not a recognized security. FY26 CARO reports no new preferential/convertible issue, yet exact closure/terms of the historical option remain open. Basic post-IPO shares are used with a separately labeled conversion sensitivity, not a falsely exact fully diluted cap table. [E01,E04]

## 9. Financial Forensics

| FY | Revenue | EBITDA | EBIT | PAT | CFO | Capex | FCF | Debt | Cash | Equity | Inventory | Receivables | Payables |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 2020 | 40.2414 | ND | ND | 0.0062 | ND | ND | ND | ND | ND | ND | ND | ND | ND |
| 2021 | 47.2265 | 0.3837 | 0.3782 | 0.0551 | -0.9960 | 0.0442 | -1.0403 | 3.9978 | 0.1150 | 0.0741 | 5.1904 | 5.4806 | 4.5094 |
| 2022 | 75.9573 | 0.4359 | 0.4192 | 0.0150 | 4.0276 | 0.0640 | 3.9635 | 0.8889 | 0.5701 | 0.0891 | 4.3546 | 9.3868 | 6.7254 |
| 2023 | 67.5278 | 1.9607 | 1.9344 | 0.9094 | -1.3669 | 0.0235 | -1.3904 | 6.3272 | 0.5994 | 1.0364 | 12.6862 | 5.7165 | 7.9806 |
| 2024 | 124.5230 | 6.1448 | 6.1035 | 3.8451 | -1.0598 | 0.0798 | -1.1396 | 7.6471 | 0.1579 | 4.8816 | 9.3336 | 4.0480 | 0.2101 |
| 2025 | 263.2518 | 15.6379 | 15.5839 | 10.7654 | 0.2883 | 0.0597 | 0.2286 | 8.5655 | 10.3027 | 24.7568 | 24.0120 | 7.6465 | 1.2521 |
| 2026 | 432.3666 | 35.7631 | 35.6989 | 24.7485 | -16.5025 | 0.3952 | -16.8977 | 17.0926 | 0.0174 | 49.5053 | 55.5670 | 21.4708 | 6.3804 |



| FY25metric₹cr | RHP | FY26comparative | Treatment |
| --- | --- | --- | --- |
| PAT | 10.4123 | 10.7654 | KPIalso10.4147; +.4718PBT−.1188tax explains~.3530; remainingreservesgapopen |
| CFO | 1.2538 | 0.2883 | Financingoffset.9655; cashsame; use latest comparative with warning |
| Inventory | 23.185 | 24.012 | +.8270notfullyexplained by stockexpense.4718 |
| Equity | 24.1379 | 24.7568 | +.6189; unexplained portion.2658 |
| Prior notes | FY25RHP | FY26notes7/8 | Prior othercurrent/provisionstotalsswapped; itemizedcustomeradvanceused |


FY26 CFO bridge is₹34.7908crore pre-WC cash earnings−₹47.0968crore WC movement−₹4.1965crore tax=−₹16.5025crore. The printed “cash generated” subtotal repeats the WC movement instead of the sum; corrected arithmetic is explicitly calculated, not a silently edited reported figure. Opening cash₹10.3027−CFO16.5025−capex0.3952+financing6.6125=₹0.0175crore versus reported0.0174, rounding difference₹0.0001crore. Reported FCF proxy−₹16.8977crore is not FCFF. Interest₹1.9147crore classified financing differs from total finance expense₹2.8871crore; do not blindly add both. [E04:CF67]

CumulativeFY23–FY26 CFO/PAT is -46.29% using ratio of sums, not average yearly ratios; bothFY25 vintages leave it negative. OriginalFY21 CFO begins with PAT rather than PBT and is retained with a warning, excluded from this cumulative test. The apparent FY22 cash release is historical counterevidence to permanently weak conversion, but does not offset the later multi-year funding pattern. No cash quarter is invented.

FY26 inventory₹55.567crore, receivables₹21.4708crore, supplier advances₹7.3877crore and customer advances₹4.0192crore imply narrow ONWC₹74.0934crore (excluding financing/tax). Revenue-based closing receivable/inventory days are 18.13/46.91; inventory days on revenue are explicitly not cost-of-sales DIO. Closing balances obscure within-year peaks. Receivables described as good/unsecured and balances subject confirmation do not establish collection. No loss provision is invented. [E04]

Debt₹17.0926crore includes₹4.6935crore current maturities already in short-term debt; do not add them twice. Loans carry varied rates, including unsecured14–17.5%; no new undrawn committed revolving line was verified. Current cash at March31 is not post-IPO cash. Tax liability₹8.2793crore and guarantee₹1.5968crore matter to liquidity; the model's cash-haircut sensitivity can absorb these, but it is not a tax/payment reconciliation. Borrowings converted noncash inFY25 may be included in share-proceeds cash-flow presentation, which requires issuer reconciliation. [E04]

## 10. Valuation & Market Expectations
Reference market cap₹259.40crore divided by FY26PAT gives10.48x. FY26 historical EPS₹16.89 uses pre-IPO shares; post-IPO pro-forma EPS is₹13.27. Using₹16.89 with post-IPO equity value would misstate P/E. No actual cutoff EV is claimed without current net debt. [E04,E06,C01]

The offline model starts from **synthetic** March2026 balances plus IPO net funds minus assumed₹6.5crore repayment: cash₹41.4403crore and debt₹10.5926crore. These are neither observed October balances nor forecasts for a missed historical period. At assumed time0 of the forward five-year exercise, IPO WC cash is counted once, then consumed by modeled ONWC; full remaining₹6.4crore studio funding is reserved and spent over18months. Existing CWIP is sunk, making this conservative versus a net remaining studio budget. Actual tax payments, utilization and operating movements since March are unknown and tested through opening-cash haircuts, not concealed.

Revenue ramps linearly each year to the stated terminal annual run-rate; actual modeled monthly sales sum below that endpoint during growth. Exit EBIT and terminal FCFF use the end-of-year-five annualized run-rate, an explicit forward-normalization assumption, not the sum of year-five sales. Every month links revenue ramp, EBIT,14.5% opening debt interest,26% positive earnings tax (no loss tax credit), D&A0.1% sales, maintenance capex0.15%, ONWC movement, studio spend, contractual-style amortization over36months (analyst assumption, not actual schedule), cash and shares. Minimum operating cash₹2crore plus remaining studio reserve must be met. No uncommitted debt draw rescues a failed path. Rent is included in margins; no invented AS lease liability. All margins/rates and exit multiples below are analyst assumptions, not management guidance.


| Case | Funding | Firstfailure | Peakgap₹cr | NewEquity₹cr | Dilution | Terminalannualrunrate₹cr | Exit₹ | IRR | DCF₹ |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| bear | Feasible assumption | NA | 0.00 | 0.00 | 0.00% | 408.42 | 72.18 | -12.29% | 37.95 |
| base | Feasible assumption | NA | 0.00 | 0.00 | 0.00% | 869.64 | 351.44 | 20.37% | 115.53 |
| bull | Feasible assumption | NA | 0.00 | 0.00 | 0.00% | 1,319.48 | 801.14 | 41.94% | 200.37 |
| linked_failure | FAIL | 11 | 3.99 | 0.00 | 0.00% | 288.98 | NS | NS | NS |
| conditional_rescue | Feasible assumption | NA | 0.00 | 3.99 | 2.67% | 288.98 | 23.43 | -29.96% | NS |


Bear assumptions: year1 sales−20%, then2%/5%/5%/5%; EBIT2.5–3.5%, WC22–23%,25% studio overrun,6xexitEBIT. Base:15% annual growth/6.5%EBIT/18%WC/10xexit. Bull:25%growth/8%EBIT/WC18% declining16%/13x. Linked failure: sales−30% then−10%, flat then3%/3%; margin1–2.5%, WC35%,50%capex overrun/4x. Rescue supplies only the calculated funding gap at assumed₹80/share, capped₹20crore; it is not committed or endorsed. Failed-path later arithmetic is diagnostic only; no fictitious IRR or terminal DCF is shown.

DCF uses monthly FCFF=EBIT×(1−tax)+D&A−capex−ΔONWC,16%WACC,4%terminal growth with terminal WC reinvestment and maintenance. Opening net cash is added once; ending cash is not also added to DCF. Exit-multiple IRR instead adds ending cash/subtracts debt and divides by actual modeled diluted shares; there are no dividends. Base DCF₹115.53 is below₹139.06 even while10xexit supports 20.37%—this disagreement is material terminal-value risk, not two confirming targets. No live target/entry recommendation follows.


| Unmodeledpriorcashuse₹cr | WACC | Feasible | Failuremonth | DCF₹ | IRR |
| --- | --- | --- | --- | --- | --- |
| 0 | 14.00% | True | NA | 140.82 | 20.37% |
| 0 | 16.00% | True | NA | 115.53 | 20.37% |
| 0 | 18.00% | True | NA | 97.83 | 20.37% |
| 10 | 14.00% | True | NA | 135.46 | 20.00% |
| 10 | 16.00% | True | NA | 110.17 | 20.00% |
| 10 | 18.00% | True | NA | 92.47 | 20.00% |
| 20 | 14.00% | True | NA | 130.10 | 19.63% |
| 20 | 16.00% | True | NA | 104.81 | 19.63% |
| 20 | 18.00% | True | NA | 87.11 | 19.63% |
| 30 | 14.00% | True | NA | 124.74 | 19.25% |
| 30 | 16.00% | True | NA | 99.45 | 19.25% |
| 30 | 18.00% | True | NA | 81.75 | 19.25% |
| 40 | 14.00% | False | 1 | ND | NS |
| 40 | 16.00% | False | 1 | ND | NS |
| 40 | 18.00% | False | 1 | ND | NS |


Reverse expectations scan growth from−30% to80% in1pp steps, preserving feasibility and discontinuities; the base margins/WC10xexit assumptions meet15% return in bracket[[0.08, 0.09]] annual growth (decimal). No interpolation jumps across failed funding points. DCF assumptions differ from the exit multiple, so return-clearing growth is not a complete market-implied growth estimate. Canonical monthly paths and the full grid are included offline. Upper growth becomes funding-sensitive; more sales is not monotonically safer. A further modeled conversion of₹3.7086crore at₹80/share tests a hypothetical remainder of historical authorization, not an assertion it is outstanding or priced that way; debt is reduced with shares added, and cash is not raised twice.

## 11. Bear Case & Permanent-Loss Path
The strongest bear case is that apparent growth mainly reflects gold prices, higher-ticket mix and inventory/accounting marks, while saleable stock and collections cannot fund obligations. Customer loss then lower margin, slower stock turnover, delayed supplier recovery and depleted IPO liquidity can require dilutive funding at the worst time. The failed model shows why simply discounting a terminal profit stream is insufficient: survival fails first. [E01,E04,A01]

The strongest counterevidence is equally important: genuine disclosed IPO cash, rising operating earnings, audited unmodified statements, a specific studio commencement event, lower single-customer concentration in the December stub, and prior historical cash releases. These do not establish that the bearish story will happen. The thesis-break variable is independently realizable inventory plus collections relative to cash commitments—not a short-term price fall. Missing monitor access does not prove misuse or default.

The failed-path recovery worksheet discounts opening inventory to60%, receivables70% and supplier advances50%, deducting operating payables/customer advances/debt/tax provisions. Its₹8.73per-share residual is an illustrative recovery stress, not liquidation value: other claims, enforcement costs, gold price, priority and current cash are unknown. Equity could lose substantially more; no floor is promised.

## 12. 5× / 10× Feasibility
Five-year5x and10x price outcomes require37.97% and58.49% annualized gains. With zero dividends/dilution and unchanged margins/multiple they require similar annual revenue growth; gold gross sales are not equivalent economic value creation. At unchanged current P/E,10x requires PAT about₹247.49crore versus₹24.75crore. Holding a normalized5%net margin would require₹4,949.7crore sales, with18%ONWC approximately₹890.95crore before fixed assets—far beyond current funding and requiring a credible financing bridge. Lower multiple or dilution raises the burden. The modeled bull is not a validated10x case. Classification: **Speculative / unsupported**, not impossible.

## 13. Monitoring Plan
| KPI | Baseline | Evidence milestone / warning | Thesis-break test |
|---|---|---|---|
| Inventory assurance | ₹55.567croreFY26; raw₹17.4188crore | Independent physical/NRV and jobworker reconciliation next audited/interim update | Material unsupported stock undermines reliability |
| Collections | ₹21.4708crore FY26 receivables | Subsequent collections/ageing; investigate further growth faster than bills | Demonstrated nonrecoverability exhausting funding |
| CFO conversion | FY26−₹16.5025crore | Positive rolling cash after tax, not debt/IPO financed cash | Persistent gap plus no financeable remedy |
| Price/volume/mix | AnnualgramsND | Grams/purity/making-charge disclosure | No genuine underlying scale despite capital deployment |
| IPO proceeds | Net₹47.9229crore raised | Read monitoring balances and bank use; investigate deviations | Proven misuse or insufficient essential funding |
| Studio | ₹6.4crore plan; commencedAug25 | Timetable, spend, completion, client activity | Unrecoverable capital on related-party site or severe cost overrun |
| Debt/liabilities | Marchdebt₹17.0926crore; guarantee₹1.5968crore | Actual repayment/maturities/covenants; investigate refinancing dependence | Evidenced payment failure, not mere missing data |
| Accounts | FY25 revisions and subtotal errors | Corrected audited comparative/loan-conversion cash bridge | Material unresolvable misstatement |
| Liquidity | One historical active day | Primary60-session turnover/spread/lot and restrictions | Reference position cannot practically exit |

Review on actual results, proceeds-monitor and material filings. Thresholds are economic warning conditions, not fabricated covenant numbers. No reminder or automatic trade is created.

## 14. Final Classification & Conditional Action
**Hold — unresolved; research priority, not eligible for investment consideration on this record.** Do not use the ordinary numeric classification matrix on NS aggregates. G1 is not failed, so neither “Avoid — governance” nor proven fraud/default is asserted. No evidence-backed compounder label and no overall stock rank are warranted. All three ranking eligibility flags are false, with Pending evidence placement; G2/G3/G4 unresolved are disclosed rather than treated as evidenced gate failures.

A lower price can improve conditional model returns but cannot release missing-evidence gates. To revisit: reconcile accounts and inventory, verify cash/debt/use of proceeds, establish diluted capital and actual tradability, and separate underlying business activity from metal-price/mix growth. An existing holder faces a different liquidity problem; without holdings/cost/tax context there is no unsupported sell instruction or allocation advice.

## 15. Sources, Assumptions & Open Questions

| ID/type | Document | Link/input | Limitation |
| --- | --- | --- | --- |
| E01/V/M | SMR RHP18May2026; printedbusiness150–160,objects104–120,financials s6–s26 | [E01](https://aibi.org.in/Current_DOC/26270026.pdf) | Identity, historical restated financials, risks and IPO intentions; summary KPI inconsistencies retained |
| E02/V | OriginalFY22 annual report3Sep2022; P&L/CF and FY21comparatives | [E02](https://smrjewels.in/wp-content/uploads/2025/03/Annual-Report-2021-22.pdf) | OriginalthousandINR converted÷10000; not forced into restated equity bridge |
| E03/V | OriginalFY20 annual report24Sep2020; financialhighlights | [E03](https://smrjewels.in/wp-content/uploads/2025/03/Annual-Report-2019-20.pdf) | Rupees÷10million; earlier historical perspective |
| E04/V/M | FY26 annual report29Aug2026; audit25Jun2026; PDF50–52,65–67,72–90 | [E04](https://smrjewels.in/wp-content/uploads/2026/08/submission-of-annual-report-SINGED.pdf) | Audited current financials/notes, IPO subsequent event; presentation/reconciliation caveats |
| E05/M | 25Aug2026studio commencement | [E05](https://smrjewels.in/wp-content/uploads/2026/08/BSE-INTIMATION_25.08.2026.pdf) | Commencement not quantum/completion |
| E06a/Secondary | IIFL historical19Oct2026 | [E06a](https://www.indiainfoline.com/company/smr-jewels-ltd-historical-data) | Close139.06;82,000isdeliverynotvolume |
| E06b/Secondary | Equitypandit historical19Oct2026 | [E06b](https://www.equitypandit.com/share-price/95839) | 138,000traded;126trades;turnover₹19,028,030 |
| E07/V/M | SkyGoldFY26 annual reportSeptember2026; overview/financials | [E07](https://skygold.co.in/wp-content/uploads/2026/09/Annual-Report-FY-2025-26.pdf) | Consolidated largerpeer; CFO roundedmanagementsummary |
| E08/V/M | ShantiGoldFY26 annual reportSeptember2026; printed35,92 | [E08](https://shantigold.in/wp-content/uploads/2026/09/Annual-Report-FY-2025-26.pdf) | MillionINR÷10; activity/pricecounterexample |
| E09/V | Shringar prospectus12Sep2025; printed174–176 | [E09](https://www.sebi.gov.in/sebi_data/attachdocs/sep-2025/1758016761687.pdf) | HistoricalFY25 peer; FY26primary403notread |
| E10/Unreadlead | 14Aug2026IPOmonitor | [E10](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=9f4d1998-49f2-4b91-a76e-81ca4dd07079.pdf) | Accessfailed;notusedasverification |
| C01/C | Offlinefinancial/modelcalculation | [C01](financial_inputs.json) | analyze.py/model.py reproduce definitions |
| A01/A | Conditionalforecastassumptions | [A01](model_inputs.json) | No actual cutoff bank balance; synthetic bridge/haircuts/rescueuncommitted |


Evidence type V means a disclosure was read, not that underlying physical facts were independently audited by this research; M means management claim; C means reproducible calculation; A means assumption. Every numerical forecast is A01; calculations are C01 and linked to offline inputs. Secondary prices are labeled separately, not elevated to primary verification. Sources dated after20October are excluded; retrieval25October is not the valuation date.

Key open questions: reconciliation of FY25 stock/PAT/equity/CFO; actual noncash loan conversion in cash-flow proceeds; physical inventory/confirmations; exact cutoff IPO balances and debt; historical lender option closure; annualgrams/net-making-revenue; current shareholding/encumbrance and multi-session liquidity; actual order execution versus leads. Denied primaryBSE files were not bypassed. ShringarFY26 primary403 is explicitly not substituted with aggregator financials. Source URLs and authored extracted data—not raw PDFs/OCR—are packaged.

History policy: this is the first authored internal SMR research located in this task. Genuine originalFY20/FY22 and restatedRHP/FY26 financial vintages are preserved in financial_inputs and source notes; no imaginary prior complete research draft is generated. Rebuild uses Python standard library plus the stated Markdown renderer; manifests distinguish authored-input aggregate, reader bytes and company-record bytes. Independent parent review is pending; producer checks do not self-accept or authorize publication.
