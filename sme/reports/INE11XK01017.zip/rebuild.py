import subprocess,sys
from pathlib import Path
P=Path(__file__).resolve().parent
for script in ['prepare.py','model.py','analyze.py','build_report.py','verify.py']:
 subprocess.run([sys.executable,str(P/script)],cwd=P,check=True)
