# SMR Jewels research archive
Position 383 • INE11XK01017 • BSE SME • information cutoff 20 October 2026.

Run `python rebuild.py` from the extracted directory. Python 3 standard library only; no network, browser, PDF, OCR or external package required. It regenerates financial inputs, metrics, scores, company record, monthly model, gzip paths, reader and verification from authored scripts/inputs. `source_notes.json` and `report_sections.md` retain authored source-safe research; originals are deliberately excluded.

This is evidence-limited deep research, with BQS/GQS/IAS NS and all ranking eligibility false. The synthetic FY26 plus IPO model is not a claim about actual 20 October cash. Conditional paths and failed paths both survive; failure paths have no actionable IRR. No primary access denial was bypassed.

Only genuine disclosed financial vintages are preserved. No prior complete internal research draft was available. The archive does not invent one. Root independent review remains required before upload or publication.

`archive_manifest.json` is the internal noncircular checksum manifest. `build_manifest.json` distinguishes reader, record and authored-input hashes. The ZIP checksum lives in the external packaging receipt rather than inside itself.
