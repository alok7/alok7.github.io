import json,gzip,math,re,hashlib
from html.parser import HTMLParser
from pathlib import Path
P=Path(__file__).resolve().parent; checks=[]
def check(ok,n):
 assert ok,n
 checks.append(n)
def near(a,b):return abs(a-b)<1e-7
class DOM(HTMLParser):
 def __init__(self):super().__init__();self.h2=[];self.capture=False;self.scripts=0;self.tables=0
 def handle_starttag(self,t,a):
  if t=='h2':self.capture=True;self.h2.append('')
  if t=='script':self.scripts+=1
  if t=='table':self.tables+=1
 def handle_endtag(self,t):
  if t=='h2':self.capture=False
 def handle_data(self,d):
  if self.capture:self.h2[-1]+=d
D=DOM();D.feed((P/'report.html').read_text());check(len(D.h2)==15,'Exactly15H2');check([int(x.split('.')[0]) for x in D.h2]==list(range(1,16)),'H2numbered1to15');check(D.scripts==0,'NoactiveJS');check(D.tables>=12,'Datatablespresent')
for n in ['company_record.json','financial_inputs.json','source_notes.json','scores.json','model_outputs.json']:json.loads((P/n).read_text());check(True,'Parse'+n)
r=json.loads((P/'company_record.json').read_text());check(all(k in r for k in ['position','isin','company','symbol','exchange','information_cutoff']),'Recordidentitycontract')
for k in ['BQS','GQS','IAS']:
 x=r['scores']['composites'][k];check(x['final'] is None and x['display']=='NS' and x['ranking_eligible']==False,'NScorrect'+k);check(near(sum(x['weights'].values()),1),'Weights'+k)
paths=json.loads(gzip.decompress((P/'canonical_paths.json.gz').read_bytes()));outputs=json.loads((P/'model_outputs.json').read_text())
for case,rows in paths.items():
 check(len(rows)==60,'60months'+case)
 prevshares=1.8653743
 for row in rows:
  n=f'{case}_{row["month"]}'
  check(near(row['cash'],row['cash_open']+row['operating_cash']-row['capex']-row['debt_repaid']+row['equity_raised']),'cash'+n)
  check(near(row['pat'],row['ebit']-row['interest']-row['tax']),'pat'+n)
  check(near(row['operating_cash'],row['pat']+row['da']-row['delta_onwc']),'operating'+n)
  check(near(row['shares'],prevshares+row['equity_raised']/80),'shares'+n);prevshares=row['shares']
  check(row['debt']>=-1e-8,'debtnonnegative'+n)
  check(near(row['shortfall'],max(0,2+row['studio_reserve']-row['cash'])),'reserveconstraint'+n)
 out=outputs['scenarios'][case];check(out['feasible']==all(x['shortfall']<=1e-9 for x in rows),'Modelstatusparsed'+case)
 if not out['feasible']:check(out['irr'] is None and out['exit_price'] is None,'NoReturnOnFailure'+case)
check(outputs['scenarios']['linked_failure']['failure_month']==11,'Failureatmonth11')
check(outputs['scenarios']['conditional_rescue']['new_equity']>0,'Conditionalrescueexplicit')
check(any(not x['feasible'] for x in outputs['reverse_growth_grid']),'Reversefundingdiscontinuitytested')
for x in outputs['reverse_growth_grid']:
 if not x['feasible']:check(x['irr'] is None,'ReverseNoFalseIRR')
check('{{' not in (P/'report.md').read_text(),'NoUnfilledPlaceholders')
receipt={'status':'PASS producer structural and arithmetic checks; not independent acceptance','checks':len(checks),'h2':len(D.h2),'tables':D.tables,'scripts':D.scripts,'browser':'Not attempted; structural DOM only per instruction','source_safe':'Archive whitelist excludes raw PDFs/OCR/private paths','known_limitations':['No actual cutoff cash/debt/proceeds verification','Secondary historical close; liquidity unresolved','FY25 reconciliation and inventory verification pending','Model forecasts conditional on synthetic starting balance']}
(P/'verification.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt))
