import json
from pathlib import Path
P=Path(__file__).resolve().parent
D=json.loads((P/'financial_inputs.json').read_text());H=D['history'];by={x['year']:x for x in H}
out={'history_metrics':[],'cagr':{},'normalization':'No invented adjustments. Reported PAT retained with FY25 revisions explicit; operating EBIT=PBT+finance cost. CFO interest classification uses reported1.9147 rather than full finance cost2.8871.'}
for h in H:
 d={'year':h['year'],'growth':None if h['year']==2020 else h['revenue']/by[h['year']-1]['revenue']-1,'addition':None if h['year']==2020 else h['revenue']-by[h['year']-1]['revenue'],'ebitda':None if h['ebit'] is None else h['ebit']+h['da'],'fcf':None if h['cfo'] is None else h['cfo']-h['capex'],'pat_margin':h['pat']/h['revenue'],'funding_IC':None if h['equity'] is None else h['equity']+h['debt']-h['cash']}
 out['history_metrics'].append(d)
for a,b in [(2021,2026),(2023,2026),(2020,2026)]:out['cagr'][f'{a}_{b}']=(by[b]['revenue']/by[a]['revenue'])**(1/(b-a))-1
sub=[by[x] for x in [2023,2024,2025,2026]];out['cumulative_CFO_PAT_FY23_26']=sum(x['cfo'] for x in sub)/sum(x['pat'] for x in sub)
out['FY26_CFO_bridge']={'preWC':34.7908,'WC':-47.0968,'tax_paid':-4.1965,'CFO':-16.5025,'investing':-.3952,'financing':6.6125,'opening_cash':10.3027,'closing_cash':.0174}
old,new=out['history_metrics'][-2:];avg=(old['funding_IC']+new['funding_IC'])/2
out['FY26_ROCE_funding_proxy']=by[2026]['ebit']/avg;out['FY26_ROIC_funding_proxy']=by[2026]['ebit']*.74/avg
out['incremental_return_funding_proxy']=(by[2026]['ebit']-by[2025]['ebit'])*.74/(new['funding_IC']-old['funding_IC'])
out['FY26_ONWC_narrow']=55.567+21.4708+7.3877+.0675-6.3804-4.0192
out['FY26_operating_IC_proxy']=out['FY26_ONWC_narrow']+.502+.1346+.3378
out['IC_bridge_gap']=out['FY26_operating_IC_proxy']-new['funding_IC'];out['IC_bridge_explanation']='Main difference income-tax provision8.2793, other provision/accrual and staff/deposit classifications. Reconciliation incomplete; no exact economic ROIC claim.'
out['FY26_receivable_days']=21.4708/432.3666*365;out['FY26_inventory_revenue_days']=55.567/432.3666*365
out['FY26_P_E_postIPO']=139.06*1.8653743/24.7485;out['market_cap']=139.06*1.8653743
out['FY26_postIPO_proforma_EPS']=24.7485/1.8653743
(P/'financial_metrics.json').write_text(json.dumps(out,indent=2)+'\n')
factors={'GOV':(4,'E01/E04: family-related studio capital and audit-document inconsistencies; no severe misconduct evidenced.'),'MOAT':(4,'E01: design/artisan ties but unregistered designs, concentrated customers and no captive manufacturing.'),'REV':(None,'E01/E04/E07: gold/mix pass-through materially obscures growth; no annual grams/making-fee bridge. Reported5yr55.7% is NOT underlying growth score.'),'DUR':(5,'E01/E05: funded studio plus jewellery demand; concentrated region and no quantified delivered pipeline.'),'CAP':(None,'E04: inventory/earnings revisions and unconfirmed balances invalidate reliable incremental operating capital economics.'),'CASH':(2,'E01/E04: negative cumulative FY23–26 CFO despite profits; raw reported signal robust under bothFY25 vintages.'),'BAL':(None,'E04/E05: IPO helps but actual utilization/current debt and committed headroom not verified.'),'EXEC':(5,'E01/E05: scaled sales and started studio, not evidence completed/returns; limited postIPO record.'),'EARN':(None,'E04: earnings mix and inventory adjustments, prior-year restatement unresolved.')}
weights={'BQS':{'GOV':.2,'MOAT':.2,'REV':.12,'DUR':.1,'CAP':.12,'CASH':.1,'BAL':.08,'EXEC':.08},'GQS':{'REV':.4,'DUR':.2,'EARN':.15,'CAP':.15,'CASH':.1}}
scores={'framework':'3.0','factors':{k:{'score':v[0],'reason':v[1]} for k,v in factors.items()},'composites':{},'IAS_factors':{k:{'score':None,'reason':'No current validated funding/valuation/liquidity basis; conditional model not a score.'} for k in ['R','D','P','L']}}
for name,ws in weights.items():
 covered=sum(w for k,w in ws.items() if factors[k][0] is not None);subtotal=sum(w*factors[k][0] for k,w in ws.items() if factors[k][0] is not None)
 scores['composites'][name]={'raw':None,'final':None,'display':'NS','ranking_eligible':False,'coverage':covered,'known_weighted_contribution':subtotal,'missing_bounds':[subtotal+1-covered,subtotal+10*(1-covered)],'weights':ws,'override':'GQS cap5 for CASH2 applies only if computable; NS remains NS' if name=='GQS' else 'No governance numeric override; G1notFail'}
scores['composites']['IAS']={'raw':None,'final':None,'display':'NS','ranking_eligible':False,'coverage':0,'weights':{'BQS':.25,'R':.35,'D':.2,'P':.1,'L':.1},'override':'G2Hold and missingBQS/R/D/P/L; no favorable investment classification'}
(P/'scores.json').write_text(json.dumps(scores,indent=2)+'\n')
record={'position':383,'isin':'INE11XK01017','company':'SMR Jewels Limited','symbol':'544774','symbol_type':'BSE numeric security code; alpha trading ID not independently verified','exchange':'BSE SME','information_cutoff':'2026-10-20','market_reference':'2026-10-19','actual_trade_date':'2026-10-19','price':139.06,'price_status':'Secondary corroborated dated closing quote, primary unverified; not executable guarantee','scores':scores,'classification':'Hold — unresolved financial reliability and funding evidence; Pending evidence, not low-ranked','gates':{'G1':'Conditional','G2':'Hold — unresolved','G3':'Hold — unresolved','G4':'Hold — unresolved'},'compounder_eligible':False,'ranking_eligibility':{'BQS':False,'GQS':False,'IAS':False},'research_mode':'Deep evidence-limited analysis with conditional model; not favorable investment clearance','source_safe':True,'research_history':'First authored internal research in this task; originals/restated financial vintages preserved. No prior internal draft was located or manufactured.'}
(P/'company_record.json').write_text(json.dumps(record,indent=2)+'\n')
