import json,re,html
from pathlib import Path
P=Path(__file__).resolve().parent
def load(n):return json.loads((P/n).read_text())
M=load('financial_metrics.json');H=load('financial_inputs.json');S=load('scores.json');O=load('model_outputs.json')
def fmt(x,d=2):return 'ND' if x is None else f'{x:,.{d}f}'
def pct(x):return 'NS' if x is None else f'{x*100:.2f}%'
def tab(headers,rows):return '\n'+'| '+' | '.join(headers)+' |\n| '+' | '.join(['---']*len(headers))+' |\n'+''.join('| '+' | '.join(map(str,r))+' |\n' for r in rows)
sources=[
('E01','V/M','SMR RHP18May2026; printedbusiness150–160,objects104–120,financials s6–s26','https://aibi.org.in/Current_DOC/26270026.pdf','Identity, historical restated financials, risks and IPO intentions; summary KPI inconsistencies retained'),
('E02','V','OriginalFY22 annual report3Sep2022; P&L/CF and FY21comparatives','https://smrjewels.in/wp-content/uploads/2025/03/Annual-Report-2021-22.pdf','OriginalthousandINR converted÷10000; not forced into restated equity bridge'),
('E03','V','OriginalFY20 annual report24Sep2020; financialhighlights','https://smrjewels.in/wp-content/uploads/2025/03/Annual-Report-2019-20.pdf','Rupees÷10million; earlier historical perspective'),
('E04','V/M','FY26 annual report29Aug2026; audit25Jun2026; PDF50–52,65–67,72–90','https://smrjewels.in/wp-content/uploads/2026/08/submission-of-annual-report-SINGED.pdf','Audited current financials/notes, IPO subsequent event; presentation/reconciliation caveats'),
('E05','M','25Aug2026studio commencement','https://smrjewels.in/wp-content/uploads/2026/08/BSE-INTIMATION_25.08.2026.pdf','Commencement not quantum/completion'),
('E06a','Secondary','IIFL historical19Oct2026','https://www.indiainfoline.com/company/smr-jewels-ltd-historical-data','Close139.06;82,000isdeliverynotvolume'),
('E06b','Secondary','Equitypandit historical19Oct2026','https://www.equitypandit.com/share-price/95839','138,000traded;126trades;turnover₹19,028,030'),
('E07','V/M','SkyGoldFY26 annual reportSeptember2026; overview/financials','https://skygold.co.in/wp-content/uploads/2026/09/Annual-Report-FY-2025-26.pdf','Consolidated largerpeer; CFO roundedmanagementsummary'),
('E08','V/M','ShantiGoldFY26 annual reportSeptember2026; printed35,92','https://shantigold.in/wp-content/uploads/2026/09/Annual-Report-FY-2025-26.pdf','MillionINR÷10; activity/pricecounterexample'),
('E09','V','Shringar prospectus12Sep2025; printed174–176','https://www.sebi.gov.in/sebi_data/attachdocs/sep-2025/1758016761687.pdf','HistoricalFY25 peer; FY26primary403notread'),
('E10','Unreadlead','14Aug2026IPOmonitor','https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=9f4d1998-49f2-4b91-a76e-81ca4dd07079.pdf','Accessfailed;notusedasverification'),
('C01','C','Offlinefinancial/modelcalculation','financial_inputs.json','analyze.py/model.py reproduce definitions'),
('A01','A','Conditionalforecastassumptions','model_inputs.json','No actual cutoff bank balance; synthetic bridge/haircuts/rescueuncommitted')]
(P/'source_ledger.json').write_text(json.dumps([dict(zip(['id','type','document','url','limitation'],x)) for x in sources],indent=2)+'\n')
v={'market_cap':fmt(M['market_cap']),'cagr5':pct(M['cagr']['2021_2026']),'cagr3':pct(M['cagr']['2023_2026']),'cashratio':pct(M['cumulative_CFO_PAT_FY23_26']),'rec_days':fmt(M['FY26_receivable_days']),'inv_days':fmt(M['FY26_inventory_revenue_days']),'pe':fmt(M['FY26_P_E_postIPO']),'eps':fmt(M['FY26_postIPO_proforma_EPS']),'dcf_base':fmt(O['scenarios']['base']['dcf_per_initial_share']),'irr_base':pct(O['scenarios']['base']['irr']),'recovery':fmt(O['recovery_failed_path']['per_share']),'reverse_bracket':str(O['feasible_hurdle_brackets'])+' annual growth (decimal)'}
v['scoretable']=tab(['Score','Raw/final','Coverage','Known contribution','Missing-data bound','Eligibility'],[[k,'NS / NS',pct(x['coverage']),fmt(x.get('known_weighted_contribution')),'–'.join(fmt(y) for y in x.get('missing_bounds',[])) or 'NS','False'] for k,x in S['composites'].items()])
v['factortable']=tab(['Factor','Score','BQScontribution','GQScontribution','Evidence/reason'],[[k,fmt(x['score'],0),'NS' if x['score'] is None else fmt(x['score']*S['composites']['BQS']['weights'].get(k,0)),'NS' if x['score'] is None else fmt(x['score']*S['composites']['GQS']['weights'].get(k,0)),x['reason']] for k,x in S['factors'].items()])
v['growthtable']=tab(['FYendMarch','Revenue₹cr','YoY','Annualaddition₹cr','Basis'],[[x['year'],fmt(x['revenue'],4),pct(y['growth']) if y['growth'] is not None else 'NA',fmt(y['addition'],4),x['basis']+' ['+x['source']+']'] for x,y in zip(H['history'],M['history_metrics'])])
v['historytable']=tab(['FY','Revenue','EBITDA','EBIT','PAT','CFO','Capex','FCF','Debt','Cash','Equity','Inventory','Receivables','Payables'],[[x['year']]+[fmt(z,4) for z in [x['revenue'],y['ebitda'],x['ebit'],x['pat'],x['cfo'],x['capex'],y['fcf'],x['debt'],x['cash'],x['equity'],x['inventory'],x['receivables'],x['payables']]] for x,y in zip(H['history'],M['history_metrics'])])
v['reconciliationtable']=tab(['FY25metric₹cr','RHP','FY26comparative','Treatment'],[['PAT',10.4123,10.7654,'KPIalso10.4147; +.4718PBT−.1188tax explains~.3530; remainingreservesgapopen'],['CFO',1.2538,.2883,'Financingoffset.9655; cashsame; use latest comparative with warning'],['Inventory',23.185,24.012,'+.8270notfullyexplained by stockexpense.4718'],['Equity',24.1379,24.7568,'+.6189; unexplained portion.2658'],['Prior notes','FY25RHP','FY26notes7/8','Prior othercurrent/provisionstotalsswapped; itemizedcustomeradvanceused']])
v['capitalmetrics']=tab(['Metric','Calculation/result','Limitation'],[['FY26fundingIC','equity+debt−cash = '+fmt(M['history_metrics'][-1]['funding_IC']),'Includes net nonoperating/tax classifications'],['AveragefundingICROCE',pct(M['FY26_ROCE_funding_proxy']),'EBIT/averageopeningclosing; not issuerreportedclosingdenominator'],['AveragefundingICROIC',pct(M['FY26_ROIC_funding_proxy']),'26%normalizedtax assumption; not verified operatingROIC'],['Incrementalproxy',pct(M['incremental_return_funding_proxy']),'ΔEBIT×.74/ΔfundingIC; distorted by revisions/IPOtiming; CAPNS'],['NarrowONWC',fmt(M['FY26_ONWC_narrow']),'inventory+receivables+supplieradvances+otherCA−tradepayables−customeradvances'],['OperatingICproxy',fmt(M['FY26_operating_IC_proxy']),'addsPPE/CWIP/deposit; tax/provisionbridgegap'+fmt(M['IC_bridge_gap'])]])
v['scenariotable']=tab(['Case','Funding','Firstfailure','Peakgap₹cr','NewEquity₹cr','Dilution','Terminalannualrunrate₹cr','Exit₹','IRR','DCF₹'],[[k,'Feasible assumption' if r['feasible'] else 'FAIL',r['failure_month'] or 'NA',fmt(r['max_unfunded_shortfall']),fmt(r['new_equity']),fmt(r['dilution_pct'])+'%',fmt(r['revenue_year5']),fmt(r['exit_price']) if r['exit_price'] is not None else 'NS',pct(r['irr']),fmt(r['dcf_per_initial_share']) if r['dcf_per_initial_share'] is not None else 'NS'] for k,r in O['scenarios'].items()])
v['sensitivitytable']=tab(['Unmodeledpriorcashuse₹cr','WACC','Feasible','Failuremonth','DCF₹','IRR'],[[x['unmodeled_cash_use'],pct(x['wacc']),x['feasible'],x['failure_month'] or 'NA',fmt(x['dcf_per_initial_share']),pct(x['irr'])] for x in O['sensitivity']])
v['sourcetable']=tab(['ID/type','Document','Link/input','Limitation'],[[x[0]+'/'+x[1],x[2],'['+x[0]+']('+x[3]+')',x[4]] for x in sources])
s=(P/'report_sections.md').read_text()
for k,val in v.items():s=s.replace('{{'+k+'}}',str(val))
assert '{{' not in s
(P/'report.md').write_text('# SMR Jewels Limited — position383\n\n'+s)
# Offline standard-library markdown subset; fixed layout, tables and links only.
def inline(s):
 s=html.escape(s);s=re.sub(r'\*\*(.*?)\*\*',r'<strong>\1</strong>',s);s=re.sub(r'\[([^]]+)\]\(([^)]+)\)',r'<a href="\2">\1</a>',s);return s
parts=[];lines=s.splitlines();i=0
while i<len(lines):
 line=lines[i]
 if line.startswith('## '):parts.append('<h2>'+inline(line[3:])+'</h2>')
 elif line.startswith('### '):parts.append('<h3>'+inline(line[4:])+'</h3>')
 elif line.startswith('|'):
  rows=[]
  while i<len(lines) and lines[i].startswith('|'):
   cells=[x.strip() for x in lines[i].strip('|').split('|')]
   if not all(re.fullmatch(r'[-: ]+',x) for x in cells):rows.append(cells)
   i+=1
  parts.append('<div class="table"><table><thead><tr>'+''.join('<th>'+inline(c)+'</th>' for c in rows[0])+'</tr></thead><tbody>'+''.join('<tr>'+''.join('<td>'+inline(c)+'</td>' for c in r)+'</tr>' for r in rows[1:])+'</tbody></table></div>');continue
 elif line.strip():parts.append('<p>'+inline(line)+'</p>')
 i+=1
style='body{font:16px/1.6 system-ui,sans-serif;max-width:1120px;margin:auto;padding:32px;color:#162238;background:#fafbff}h1{font-size:2.4rem}h2{margin-top:3rem;border-top:2px solid #cad7e9;padding-top:1rem}table{border-collapse:collapse;font-size:14px;min-width:600px;width:100%}td,th{border:1px solid #ccd7e4;padding:9px;text-align:left;vertical-align:top}th{background:#e5edf8}.table{overflow-x:auto}a{color:#1658a8}strong{color:#7d2439}footer{margin-top:3rem}'
(P/'report.html').write_text('<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>SMR Jewels | 383 | Wallstrat</title><style>'+style+'</style></head><body><h1>SMR Jewels Limited</h1><p>383 · BSE SME · cutoff20October2026 · evidence-limited deep research</p>'+''.join(parts)+'<footer>Source-safe reader. No recommendation or executable quote. Parent review pending.</footer></body></html>')
