import json,gzip,math,csv
from pathlib import Path
P=Path(__file__).resolve().parent
I=json.loads((P/'model_inputs.json').read_text())
def simulate(s,wacc=None,tg=None,opening_haircut=0,convert=0):
 cash=I['cash_FY26']+I['net_fresh_proceeds']-I['assumed_repayment']-opening_haircut
 debt=I['debt_FY26']-I['assumed_repayment']; shares=I['shares']
 if convert: debt-=convert;shares+=convert/I['assumed_new_equity_price']
 startcash=cash;startdebt=debt;wc=I['onwc0']; rev=I['revenue0']; rows=[];raised=0;failure=None;pv=0
 captotal=I['studio_budget']*s['capex_overrun'];wacc=wacc or I['wacc'];tg=I['terminal_growth'] if tg is None else tg
 mindebt=debt;mincash=cash;minfree=cash-captotal;fcffs=[]
 for year in range(1,6):
  rstart=rev;rfinish=rev*(1+s['growth'][year-1]);targetwc=rfinish*s['wc'][year-1];wstart=wc
  for mo in range(1,13):
   t=(year-1)*12+mo;annual_run=rstart+(rfinish-rstart)*mo/12; sales=annual_run/12
   nw=wstart+(targetwc-wstart)*mo/12;dw=nw-wc;wc=nw
   ebit=sales*s['margin'][year-1];da=sales*.001;capex=sales*.0015+(captotal/18 if t<=18 else 0)
   reserve=max(0,captotal*(1-min(t,18)/18));interest=debt*I['rate']/12
   tax=max(0,ebit-interest)*I['tax'];pat=ebit-interest-tax
   fcff=ebit*(1-I['tax'])+da-capex-dw;fcffs.append(fcff)
   operating=pat+da-dw;repay=min(debt,startdebt/36) if t<=36 else 0
   before=cash;cash+=operating-capex-repay;debt-=repay;equity=0
   need=max(0,I['minimum_cash']+reserve-cash)
   if need>1e-9 and s['equity'] and raised+need<=I['assumed_new_equity_cap']:
    equity=need;raised+=need;shares+=need/I['assumed_new_equity_price'];cash+=need
   short=max(0,I['minimum_cash']+reserve-cash)
   if short>1e-9 and failure is None:failure=t
   mincash=min(mincash,cash);minfree=min(minfree,cash-reserve)
   rows.append(dict(month=t,sales=sales,ebit=ebit,interest=interest,tax=tax,pat=pat,da=da,onwc=wc,delta_onwc=dw,capex=capex,studio_reserve=reserve,operating_cash=operating,debt_repaid=repay,debt=debt,equity_raised=equity,shares=shares,cash_open=before,cash=cash,shortfall=short,fcff=fcff))
   pv+=fcff/(1+wacc)**(t/12)
  rev=rfinish
 terminal_ebit=rev*s['margin'][-1]
 terminal_fcff=terminal_ebit*(1+tg)*(1-I['tax'])+rev*(1+tg)*.001-rev*(1+tg)*.0015-wc*tg
 tv=terminal_fcff/(wacc-tg)
 enterprise=pv+tv/(1+wacc)**5
 terminal_equity=max(0,terminal_ebit*s['multiple']+cash-debt)
 exitprice=terminal_equity/shares
 irr=(exitprice/I['price'])**.2-1 if exitprice>0 else -1
 return {'feasible':failure is None,'failure_month':failure,'max_unfunded_shortfall':max(x['shortfall'] for x in rows),'min_cash':mincash,'min_cash_less_studio_reserve':minfree,'revenue_year5':rev,'terminal_ebit':terminal_ebit,'terminal_cash':cash,'terminal_debt':debt,'new_equity':raised,'shares_final':shares,'dilution_pct':(shares/I['shares']-1)*100,'exit_price':exitprice if failure is None else None,'irr':irr if failure is None else None,'entry_at_hurdle':exitprice/(1+I['equity_hurdle'])**5 if failure is None else None,'dcf_per_initial_share':max(0,enterprise+startcash-startdebt)/I['shares'] if failure is None and raised==0 else None,'dcf_status':'conditional operating DCF, no equity financing double count' if failure is None and raised==0 else 'NS: failed funding or new equity requires a separately priced claim','terminal_fcff':terminal_fcff,'terminal_EV':terminal_ebit*s['multiple'],'rows':rows}
def main():
 cases={k:simulate(v) for k,v in I['scenarios'].items()}
 # Scan growth without assuming monotonicity; retain disjoint feasible brackets and all rejected points.
 grid=[]
 for j in range(-30,81):
  g=j/100;s={**I['scenarios']['base'],'growth':[g]*5};r=simulate(s)
  grid.append({'growth':g,**{k:r[k] for k in ['feasible','failure_month','max_unfunded_shortfall','irr','dcf_per_initial_share']}})
 brackets=[]
 for a,b in zip(grid,grid[1:]):
  if a['feasible'] and b['feasible'] and (a['irr']-.15)*(b['irr']-.15)<=0: brackets.append([a['growth'],b['growth']])
 sens=[]
 for h in [0,10,20,30,40]:
  for w in [.14,.16,.18]:
   r=simulate(I['scenarios']['base'],wacc=w,opening_haircut=h)
   sens.append({'unmodeled_cash_use':h,'wacc':w,**{k:r[k] for k in ['feasible','failure_month','dcf_per_initial_share','irr','max_unfunded_shortfall']}})
 conv=simulate(I['scenarios']['base'],convert=3.7086)
 out={'basis':'All forecast paths are assumptions, synthetic opening bridge not live cutoff balance. Failure triggers stop investment-return interpretation; postfailure continuation is diagnostic arithmetic only. No assumed new debt; rescue equity conditional/uncommitted.','scenarios':{k:{a:b for a,b in r.items() if a!='rows'} for k,r in cases.items()},'reverse_growth_grid':grid,'feasible_hurdle_brackets':brackets,'sensitivity':sens,'unresolved_conversion_sensitivity':{k:v for k,v in conv.items() if k!='rows'},'recovery_failed_path':{'assumptions':'Opening inventory recovery60%, receivables70%, supplier advances50%; subtract operating payables/customer advances/debt and tax provisions. No upside assumed for fixed assets; ignores preference/legal costs so not a liquidation valuation.', 'asset_recovery':55.567*.6+21.4708*.7+7.3877*.5,'claims':6.3804+4.0192+17.0926+8.2793,'per_share':max(0,55.567*.6+21.4708*.7+7.3877*.5-6.3804-4.0192-17.0926-8.2793)/I['shares']}}
 (P/'model_outputs.json').write_text(json.dumps(out,indent=2)+'\n')
 payload=json.dumps({k:r['rows'] for k,r in cases.items()},sort_keys=True,separators=(',',':')).encode()
 (P/'canonical_paths.json.gz').write_bytes(gzip.compress(payload,mtime=0))
 with (P/'model_paths.csv').open('w') as f:
  wr=csv.DictWriter(f,fieldnames=['scenario']+list(next(iter(cases.values()))['rows'][0]));wr.writeheader()
  for k,r in cases.items():
   for row in r['rows']:wr.writerow({'scenario':k,**row})
 return out
if __name__=='__main__': main()
