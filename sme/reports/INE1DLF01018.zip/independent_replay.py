"""Independent ledger/terminal recurrence replay. Does not import production model/scenarios."""
from pathlib import Path
from decimal import Decimal as D,localcontext
import json,gzip,hashlib
P=Path(__file__).resolve().parent;Z=D(0);O=D(1);CR=D(10000000)
def d(v):return D(str(v))
def check_path(p,i):
 count=0
 def eq(a,b,label):
  nonlocal count
  a=d(a);b=d(b);tol=D('1e-20')*max(O,abs(a),abs(b))
  assert abs(a-b)<=tol,(p['path_id'],label,str(a),str(b));count+=1
 def same(a,b,label):
  nonlocal count
  assert a==b,(p['path_id'],label,a,b);count+=1
 s=p['spec'];opening=i['opening'];n=p['years']*12;prior=None;cum_flex=Z;last_capacity=d(i['capacity']['existing'])
 for r in p['monthly']:
  op=r['opening'];m=r['month'];g=lambda key:d(r[key]);a=lambda key:d(op[key]);v=lambda key:d(s[key]);
  if prior:
   pairs={'cash':'cash_close','ipo_cap':'ipo_capex_close','ipo_wc':'ipo_wc_close','ar':'ar_close','inv':'inventory_close','ap':'ap_close','rawadv':'raw_advances_close','other':'other_assets_close','claims':'other_claims_close','taxclaim':'tax_claim_close','ppe':'ppe_close','cwip':'cwip_close','wcdebt':'wc_debt_close','term':'term_debt_close','projectdebt':'project_debt_close','flexdebt':'flex_debt_close','shares':'shares_close','pledged':'pledged_close','ipo_locked':'ipo_fd_locked_close'}
   for k,f in pairs.items():eq(op[k],prior[f],f'continuity {m} {k}')
  expected_collections=d(opening['receivables'])*v('opening_ar_recovery')/v('opening_ar_months') if m<=int(s['opening_ar_months']) else Z
  if m>int(s['collection_delay']):expected_collections+=d(p['monthly'][m-int(s['collection_delay'])-1]['sales'])
  expected_suppliers=d(opening['payables'])/v('opening_ap_months') if m<=int(s['opening_ap_months']) else Z
  if m>int(s['supplier_delay']):expected_suppliers+=d(p['monthly'][m-int(s['supplier_delay'])-1]['net_invoiced'])
  eq(g('collections'),expected_collections,'collection queue');eq(g('supplier_cash'),expected_suppliers,'supplier queue')
  eq(g('raw_advance_application'),min(a('rawadv'),g('purchases')*v('advance_application_fraction')),'advance application limit')
  eq(g('purchases'),max(Z,g('material')+g('target_inventory')-(a('inv')-g('inventory_spoilage'))),'purchase target')
  eq(g('target_inventory'),max(g('material')*v('minimum_inventory_months'),g('seasonal_supply_target')-a('rawadv')*v('advance_inventory_substitution')),'supply buffer netprepaid')
  eq(g('ar_close'),a('ar')+g('sales')-g('collections')-g('receivable_writeoff'),'AR')
  eq(g('inventory_close'),a('inv')-g('inventory_spoilage')+g('purchases')-g('material'),'inventory')
  eq(g('ap_close'),a('ap')+g('net_invoiced')-g('supplier_cash'),'AP')
  eq(g('net_invoiced'),g('purchases')-g('raw_advance_application'),'invoice afterprepay')
  eq(g('raw_advances_close'),a('rawadv')-g('raw_advance_application')+g('raw_advance_topup'),'advances')
  eq(g('other_assets_close'),a('other')+g('other_assets_change'),'otherassets')
  eq(g('other_claims_close'),a('claims')-g('other_claim_payment'),'claims')
  eq(g('tax_claim_close'),a('taxclaim')-g('tax_claim_payment'),'taxclaim')
  eq(g('ipo_capex_close'),a('ipo_cap')-g('restricted_capex_use'),'IPOcapex')
  eq(g('ipo_wc_close'),a('ipo_wc')-g('restricted_wc_use'),'IPOwc')
  eq(g('ipo_fd_locked_close'),a('ipo_locked')-g('ipo_fd_release'),'FDlocked')
  eq(g('pledged_close'),a('pledged')-g('pledge_release'),'pledge')
  eq(g('restricted_capex_use'),min(max(Z,a('ipo_cap')-g('ipo_fd_locked_close')),g('project_capex')),'capexeligibility')
  inc=max(Z,g('ar_close')+g('inventory_close')+g('other_assets_close')+g('raw_advances_close')-g('ap_close')-(a('ar')+a('inv')+a('other')+a('rawadv')-a('ap')))
  eq(g('incremental_wc'),inc,'incrementalWC');eq(g('restricted_wc_use'),min(a('ipo_wc'),inc) if s['ipo_wc_gate'] else Z,'WCeligibility')
  eq(g('term_debt_close'),a('term')-g('term_principal'),'term')
  eq(g('wc_debt_close'),a('wcdebt')-g('wc_principal'),'wcdebt')
  eq(g('project_debt_close'),a('projectdebt')+g('project_draw')-g('project_principal'),'projectdebt')
  eq(g('flex_debt_close'),a('flexdebt')+g('flex_draw')-g('flex_principal'),'flexdebt')
  eq(g('debt_close'),g('term_debt_close')+g('project_debt_close')+g('wc_debt_close')+g('flex_debt_close'),'alldebt')
  eq(g('shares_close'),a('shares')+g('equity_shares'),'shares');assert int(r['shares_close'])<=25000000
  eq(g('equity_cash'),g('equity_shares')*v('equity_issue_price')/CR*(O-v('equity_fee')),'equityproceeds')
  eq(g('ppe_close'),a('ppe')+g('commissioned_value')+g('maintenance_capex')-g('da'),'PPE')
  eq(g('cwip_close'),a('cwip')+g('project_capex')+g('growth_capex')-g('commissioned_value'),'CWIP')
  eq(g('capacity'),last_capacity+g('commissioned_capacity'),'capacity');last_capacity=g('capacity')
  eq(g('sales'),g('units')*g('price'),'sales');eq(g('material'),g('sales')*v('material_ratio')*(O+v('raw_price_shock')),'material')
  eq(g('ebitda'),g('sales')-g('material')-g('opex'),'EBITDA');eq(g('ebit'),g('ebitda')-g('da')-g('inventory_spoilage')-g('receivable_writeoff'),'EBIT')
  interest=(a('term')*v('old_term_rate')+(a('projectdebt')+g('project_draw'))*v('project_rate')+a('wcdebt')*v('wc_rate')+a('flexdebt')*v('flex_rate')+g('flex_draw')*v('flex_rate'))/12
  eq(g('interest'),interest,'interest');eq(g('current_draw_interest'),g('flex_draw')*v('flex_rate')/12,'drawinterest');eq(g('tax'),max(Z,g('ebit')-interest)*v('tax_rate'),'tax')
  eq(g('capex'),g('project_capex')+g('growth_capex')+g('maintenance_capex'),'capex')
  cash=a('cash')+sum((g(k) for k in ['collections','restricted_capex_use','restricted_wc_use','project_draw','subsidy','pledge_release','gst_refund','equity_cash','flex_draw']),Z)-sum((g(k) for k in ['supplier_cash','raw_advance_topup','opex','interest','tax','tax_claim_payment','other_claim_payment','other_assets_change','capex','project_gst_cash','term_principal','project_principal','wc_principal','flex_principal','fees','legal_payment','flex_fee']),Z)
  eq(g('cash_close'),cash,'cash');eq(g('shortfall'),max(Z,g('reserve')-cash),'shortfall');eq(g('reserve'),max(v('cash_floor'),(g('material')+g('opex'))*v('reserve_months')),'reserve')
  eq(g('operating_fcff'),g('collections')-g('supplier_cash')-g('raw_advance_topup')-g('opex')-max(Z,g('ebit'))*v('tax_rate')-g('other_assets_change')-g('capex')-g('project_gst_cash')+g('gst_refund'),'FCFF')
  cum_flex+=g('flex_draw');assert cum_flex<=v('flex_cumulative_limit')+D('1e-20');assert g('flex_debt_close')<=v('flex_limit')+D('1e-20')
  for field in ['ipo_capex_close','ipo_wc_close','ipo_fd_locked_close','pledged_close','inventory_close','raw_advances_close','ap_close','ar_close','project_remaining','debt_close','ppe_close','cwip_close']:
   assert g(field)>=-D('1e-20'),(p['path_id'],field,m,g(field));count+=1
  if m>n:same(g('flex_draw'),Z,'no terminalrescue');same(g('equity_cash'),Z,'no terminalequity')
  prior=r
 for arow in p['annual']:
  rows=[r for r in p['monthly'] if r['year']==arow['year'] and r['phase']=='horizon']
  for key in ['sales','units','ebitda','da','ebit','interest','tax','collections','supplier_cash','capex','project_capex','growth_capex','maintenance_capex','restricted_capex_use','restricted_wc_use','project_draw','flex_draw','equity_cash','operating_fcff']:eq(arow[key],sum((d(r[key]) for r in rows),Z),'annual '+key)
 if p['terminal_attempt']:
  t=p['terminal_attempt'];tr=p['monthly'][n:];first=tr[:12];end=p['monthly'][n-1];v=lambda k:d(s[k]);q=lambda k:d(t[k]);onwc=lambda r:sum(d(r[k]) for k in ['ar_close','inventory_close','other_assets_close','raw_advances_close'])-d(r['ap_close'])
  nopat=sum((d(r['ebit'])-max(Z,d(r['ebit']))*v('tax_rate') for r in first),Z);da=sum((d(r['da']) for r in first),Z);maint=sum((d(r['maintenance_capex']) for r in first),Z);repl=max(maint,da);physical=sum((d(r['project_capex'])+d(r['growth_capex']) for r in first),Z);wc=max(Z,onwc(first[-1])-onwc(end));growth=max(physical+wc,max(Z,nopat)*v('terminal_growth')/v('terminal_roic'));extra=repl-maint+growth-physical-wc;fcff=nopat+da-repl-growth
  for key,val in dict(next_nopat=nopat,next_da=da,replacement_capex=repl,physical_growth_capex=physical,working_reinvestment=wc,growth_reinvestment=growth,extra_cash_requirement=extra,fcff=fcff).items():eq(t[key],val,'terminal '+key)
  ex=Z;extra_cum=[]
  for k in range(len(tr)):ex+=extra*(O+v('terminal_growth'))**(k//12)/12;extra_cum.append(ex);eq(t['extra_cumulative'][k],ex,'extra cashcum')
  funding=max([d(end['reserve'])]+[d(r['reserve'])-d(r['cash_close'])+d(end['cash_close'])+extra_cum[k] for k,r in enumerate(tr)]);funding=max(Z,funding);eq(q('funding_reserve'),funding,'funding reserve')
  fin=Z;opreq=[d(end['reserve'])]
  for k,r in enumerate(tr):
   rd=lambda f:d(r[f]);shield=max(Z,rd('ebit'))*v('tax_rate')-rd('tax');fin+=sum((rd(f) for f in ['term_principal','project_principal','wc_principal','flex_principal','interest','fees','flex_fee','tax_claim_payment','other_claim_payment','legal_payment']),Z)-shield;u=rd('cash_close')+fin;opreq.append(rd('reserve')-u+d(end['cash_close'])+extra_cum[k]);eq(t['unlevered_transition'][k]['unlevered_cash'],u,'unlevered')
  op=max(Z,max(opreq));eq(q('operating_reserve'),op,'operatingreserve');eq(q('cash_bridge'),max(Z,d(end['cash_close'])-op),'cashbridge');eq(q('distributable_cash'),max(Z,d(end['cash_close'])-funding),'distributable')
  if p['terminal']:
   t=p['terminal'];q=lambda k:d(t[k]);ev=max(Z,fcff/(v('wacc')-v('terminal_growth')));eq(q('enterprise_value'),ev,'EV');nonop=sum((d(z) for z in i['nonoperating_assets'].values()),Z)*v('nonoperating_recovery_fraction');eq(q('nonoperating_recovery'),nonop,'nonoperating recoveries');equity=max(Z,ev+q('cash_bridge')+nonop-q('debt')-q('senior_claims'));eq(q('equity_value'),equity,'equity');per=equity*CR/q('shares');eq(q('price_per_share'),per,'price');net=per*(O-v('exit_cost'));entry=d(i['entry_price'])*(O+v('entry_cost'));irr=(net/entry)**(O/d(p['years']))-O if net>0 else D(-1);eq(q('conditional_irr'),irr,'IRR')
   for h,value in t['hurdle_prices'].items():eq(value,net/((O+d(h))**p['years']*(O+v('entry_cost'))),'hurdle')
   same(p['failure'],None,'funded nofailure');assert q('cash_at_exit')+D('1e-18')>=q('funding_reserve');same(q('terminal_lost_units'),Z,'terminalcapacity')
 if p['failure']:same(p['terminal'],None,'failed suppress terminal');same(p['summary']['ordinary_irr'],None,'failed suppress ordinaryIRR')
 same(p['summary']['source_eligible'],i['source_eligible'] and s['source_eligible'],'source gate')
 return count

def main():
 with localcontext() as c:
  c.prec=45
  f=P/'canonical_paths.json.gz';j=json.loads(gzip.decompress(f.read_bytes()));count=sum(check_path(p,j['inputs']) for p in j['paths']);out={'status':'PASS','independent_checks':count,'paths':len(j['paths']),'monthly_rows':sum(len(p['monthly']) for p in j['paths']),'canonical_sha256':hashlib.sha256(f.read_bytes()).hexdigest(),'method':'Independent arithmetic of raw output states and input assumptions; production model not imported.'};(P/'independent_replay_results.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))
if __name__=='__main__':main()
