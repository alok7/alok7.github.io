"""Deterministic financial calculations from separately cited source inputs."""
from decimal import Decimal as D
import json

def dd(x):return None if x is None else D(str(x))
def ratio(a,b):return None if b is None or b<=0 or a is None else a/b

def run(f,m):
 a=[]; tax=D(str(f.get('normalized_tax_assumption', '.2912')))
 for src in f['annual']:
  r={k:dd(v) if isinstance(v,(int,float)) and k!='fy' else v for k,v in src.items()};r['fy']=src['fy']
  r['ebit']=r['pbt']+r['finance_cost']-r['other_income'];r['ebitda']=r['ebit']+r['da'];r['value_added_proxy']=r['revenue']-r['materials']-r['purchases']-r['inventory_change'];r['ebitda_margin']=r['ebitda']/r['revenue'];r['ebit_margin']=r['ebit']/r['revenue'];r['pat_margin']=r['pat']/r['revenue'];r['normalized_nopat']=r['ebit']*(1-tax);r['normalized_pat']=max(D(0),r['ebit']-r['finance_cost'])*(1-tax);r['gross_debt']=r['debt_long']+r['debt_short'];r['core_onwc']=r['inventory']+r['receivables']-r['payables'];r['broad_onwc_proxy']=r['core_onwc']+r['st_advances']+r['other_ca']-r['other_cl'];r['core_ic']=r['ppe']+r['cwip']+r['core_onwc'];r['broad_ic_proxy']=r['ppe']+r['cwip']+r['lt_advances']+r['broad_onwc_proxy'];r['reported_fcf_proxy']=r['cfo']-r['cash_capex'];r['interest_coverage']=ratio(r['ebit'],r['finance_cost']);r['current_share_pat_per_share']=r['pat']*D(10000000)/D(m['issued_shares'])
  if a:
   prev=a[-1];r['revenue_addition']=r['revenue']-prev['revenue'];r['revenue_yoy']=ratio(r['revenue'],prev['revenue'])-1
   r['average_core_roic']=ratio(r['normalized_nopat'],(r['core_ic']+prev['core_ic'])/2);r['average_broad_roic_proxy']=ratio(r['normalized_nopat'],(r['broad_ic_proxy']+prev['broad_ic_proxy'])/2);r['roe']=ratio(r['pat'],(r['equity']+prev['equity'])/2)
   r['receivable_days']=((r['receivables']+prev['receivables'])/2)/r['revenue']*365
   cost=r['materials']+r['purchases']+r['inventory_change'];r['inventory_days_cost_proxy']=((r['inventory']+prev['inventory'])/2)/cost*365;r['payable_days_cost_proxy']=((r['payables']+prev['payables'])/2)/cost*365;r['cash_cycle_cost_proxy']=r['receivable_days']+r['inventory_days_cost_proxy']-r['payable_days_cost_proxy']
   r['ebitda_change']=r['ebitda']-prev['ebitda'];r['ebitda_change_sales_effect']=r['revenue_addition']*(r['ebitda_margin']+prev['ebitda_margin'])/2;r['ebitda_change_margin_effect']=(r['ebitda_margin']-prev['ebitda_margin'])*(r['revenue']+prev['revenue'])/2
  a.append(r)
 by={r['fy']:r for r in a};last=a[-1];cagrs=[]
 for n in [3,5,10]:
  start=by.get(last['fy']-n);cagrs.append({'years':n,'start_year':last['fy']-n,'end_year':last['fy'],'start_revenue':None if start is None else start['revenue'],'end_revenue':last['revenue'],'cagr':None if start is None else (last['revenue']/start['revenue'])**(D(1)/n)-1})
 cash={}
 for n in [3,5]:
  rows=[r for r in a if r['fy']>last['fy']-n]
  if len(rows)==n:
   cfo=sum(r['cfo']for r in rows);pat=sum(r['pat']for r in rows);capex=sum(r['cash_capex']for r in rows);cash[str(n)]={'start':rows[0]['fy'],'end':last['fy'],'cfo':cfo,'pat':pat,'ratio':ratio(cfo,pat),'cash_capex':capex,'reported_fcf_proxy':cfo-capex}
  else:cash[str(n)]={'available':False,'reason':'Insufficient comparable cash-flow years'}
 incremental={}
 for n in [3,5]:
  s=by.get(last['fy']-n)
  if not s:incremental[str(n)]={'available':False};continue
  dno=last['normalized_nopat']-s['normalized_nopat'];dc=last['core_ic']-s['core_ic'];db=last['broad_ic_proxy']-s['broad_ic_proxy'];incremental[str(n)]={'available':True,'start':s['fy'],'end':last['fy'],'nopat_change':dno,'core_ic_change':dc,'broad_ic_change':db,'core_ratio':ratio(dno,dc),'broad_proxy_ratio':ratio(dno,db),'qualification':'Post-tax accounting proxy, not project IRR. Includes CWIP; capital-advance and non-operating classification sensitivity reported separately from this broad proxy.'}
 price=D(m['quote']['close']);market=price*D(m['issued_shares'])/D(10000000)
 return {'annual':a,'cagrs':cagrs,'cash_conversion':cash,'incremental':incremental,'market_cap':market,'price':price,'current_share_pe':market/last['pat'],'price_book':market/last['equity'],'debt_without_cash_netting':last['gross_debt'],'reported_cash_not_all_available':last['cash'],'normalization_tax_assumption':str(tax),'working_capital_denominator_note':'Average balances; total sales substitutes for credit sales, manufacturing cost is only a cost-compatible inventory/payable proxy, not actual credit purchases. Broad ONWC includes mixed advances pending disclosed decomposition.'}
