"""Shivashrit seasonal potato-flake monthly funding model. All inputs are disclosed strings.
Scenarios are conditional experiments, not observed defaults or promised financing.
"""
from decimal import Decimal as D,localcontext
from collections import defaultdict
from copy import deepcopy
Z=D(0);O=D(1);CR=D(10000000)
def d(v):
 if isinstance(v,float):raise TypeError('Binary float not allowed')
 return v if isinstance(v,D) else D(str(v))
def date(m):
 n=2026*12+10+m-1;return f'{n//12:04d}-{n%12+1:02d}'
def run(i,s,years,path_id):
 with localcontext() as c:
  c.prec=34
  return _run(i,deepcopy(s),years,path_id)
def _run(i,s,years,path_id):
 n=years*12;o={k:d(v) for k,v in i['opening'].items()};cash=d(s.get('general_cash_override',o['general_cash']));ipo_cap=o['ipo_capex_cash'];ipo_wc=o['ipo_wc_cash'];ipo_locked=d(s.get('ipo_fd_lock','0'));pledged=o['pledged_cash'];ar=o['receivables'];inv=o['inventory'];ap=o['payables'];other=o['other_operating_assets'];rawadv=o['raw_material_advances'];claims=o['other_claims'];taxclaim=o['tax_claim'];ppe=o['ppe'];cwip=o['cwip'];wcdebt=o['wc_debt'];term=o['term_debt'];projectdebt=Z;flexdebt=Z;shares=int(i['issued_shares']);project_remaining=o['project_remaining'];project_loan_capacity=d(s.get('project_loan_headroom_override',o['project_loan_headroom']));cum_flex=Z;project_paid=Z;cap=d(i['capacity']['existing']);newcap=d(i['capacity']['new']);baseunits=d(i['capacity']['base_units']);baseprice=o['sales']/baseunits;commissioned=False;receipts=defaultdict(lambda:Z);payments=defaultdict(lambda:Z);newloans=[];cap_pipeline=[];rows=[];failure=None;exitrow=None;unitloss=Z
 for k in range(1,int(s['opening_ar_months'])+1):receipts[k]+=ar*d(s['opening_ar_recovery'])/d(s['opening_ar_months'])
 for k in range(1,int(s['opening_ap_months'])+1):payments[k]+=ap/d(s['opening_ap_months'])
 transition_months=max(12,int(s['flex_tenor']),int(s['project_final_month'])-n,int(s['old_term_final_month'])-n)
 for m in range(1,n+transition_months+1):
  y=(m-1)//12;calmonth=int(date(m)[-2:]);opening=dict(cash=cash,ipo_cap=ipo_cap,ipo_wc=ipo_wc,ar=ar,inv=inv,ap=ap,other=other,rawadv=rawadv,claims=claims,taxclaim=taxclaim,ppe=ppe,cwip=cwip,wcdebt=wcdebt,term=term,projectdebt=projectdebt,flexdebt=flexdebt,shares=shares,pledged=pledged,ipo_locked=ipo_locked)
  # Completion requires all remaining budget paid; a calendar target alone never creates productive capacity.
  project_capex=min(project_remaining,o['project_remaining']/d(s['project_spend_months'])) if m<=int(s['project_spend_months']) else Z
  project_capex*=d(s['project_cost_multiplier']);project_remaining=max(Z,project_remaining-project_capex/d(s['project_cost_multiplier']));project_paid+=project_capex;cwip+=project_capex
  project_gst=project_capex*d(s['project_gst_cash_rate']);gst_refund=Z
  if m>int(s['gst_recovery_delay']):gst_refund=rows[m-int(s['gst_recovery_delay'])-1]['project_gst_cash']*d(s['gst_recovery_fraction'])
  lock_release=ipo_locked if s.get('ipo_premature_redemption_gate',False) and m==1 else min(ipo_locked,d(i['ipo_fd_maturity_schedule'].get(str(m),'0')))
  ipo_locked-=lock_release
  cap_use=min(max(Z,ipo_cap-ipo_locked),project_capex);ipo_cap-=cap_use
  project_draw=min(project_loan_capacity,max(Z,project_capex-cap_use)) if s['project_loan_gate'] else Z;project_loan_capacity-=project_draw;projectdebt+=project_draw
  commissioned_value=Z;commissioned_capacity=Z
  if not commissioned and m>=int(s['commission_month']) and project_remaining<D('1e-24'):
   commissioned=True;commissioned_value=cwip;ppe+=cwip;cwip=Z;cap+=newcap;commissioned_capacity=newcap
  for item in cap_pipeline:
   if item['due']==m:cap+=item['units'];ppe+=item['cost'];cwip-=item['cost'];commissioned_value+=item['cost'];commissioned_capacity+=item['units']
  cap_pipeline=[z for z in cap_pipeline if z['due']!=m]
  if m<=n:
   annual_demand=baseunits*(O+d(s['volume_growth']))**(y+1)*(O-d(s['customer_loss']));price=baseprice*(O+d(s['price_growth']))**(y+1)
  else:annual_demand=terminal_basis['units']*(O+d(s['terminal_growth']))**((m-n-1)//12+1);price=terminal_basis['price']
  ramp=O
  if commissioned and m<int(s['commission_month'])+int(s['ramp_months']):ramp=max(Z,min(O,d(m-int(s['commission_month'])+1)/d(s['ramp_months'])))
  productive_capacity=min(cap,d(i['capacity']['existing'])+newcap*ramp+max(Z,cap-d(i['capacity']['existing'])-newcap)) if commissioned else cap
  desired=annual_demand/12;units=min(desired,productive_capacity/12);lost=max(Z,desired-units);unitloss+=lost;sales=units*price
  growth_capex=Z;growth_capacity=Z
  committed_cap=cap+sum((z['units'] for z in cap_pipeline),Z)
  if s['additional_expansion_gate'] and annual_demand*d(s['capacity_buffer'])>committed_cap:
   growth_capacity=max(Z,min(annual_demand*d(s['capacity_buffer'])-committed_cap,d(s['max_capacity'])-committed_cap));growth_capex=growth_capacity*d(s['capex_per_tonne']);cwip+=growth_capex
   if growth_capex:cap_pipeline.append(dict(units=growth_capacity,cost=growth_capex,due=m+int(s['growth_lead_months'])))
  material=sales*d(s['material_ratio'])*(O+d(s['raw_price_shock']));opening_spoil=inv*d(s['inventory_spoilage']) if m==int(s['spoilage_month']) else Z;inv-=opening_spoil
  # Seasonal inventory target is a stated cost-month proxy, not a claim raw potatoes equal all inventory.
  cover=d(s['seasonal_inventory_months'][str(calmonth)]);supply_target=annual_demand*price*d(s['material_ratio'])*(O+d(s['raw_price_shock']))/12*cover
  target_inventory=max(material*d(s['minimum_inventory_months']),supply_target-rawadv*d(s['advance_inventory_substitution']))
  purchases=max(Z,material+target_inventory-inv);inv+=purchases-material
  advance_application=min(rawadv,purchases*d(s['advance_application_fraction']));rawadv-=advance_application
  advance_target=o['raw_material_advances']*(annual_demand*price/o['sales'])*d(s['advance_retention_fraction']);advance_topup=max(Z,advance_target-rawadv);rawadv+=advance_topup
  net_invoiced=purchases-advance_application;payments[m+int(s['supplier_delay'])]+=net_invoiced;supplier_cash=payments.pop(m,Z);ap+=net_invoiced-supplier_cash
  receipts[m+int(s['collection_delay'])]+=sales;collections=receipts.pop(m,Z);ar+=sales-collections;writeoff=o['receivables']*(O-d(s['opening_ar_recovery'])) if m==int(s['opening_ar_months']) else Z;ar-=writeoff
  variable=O-d(s['material_ratio'])-d(s['ebitda_margin']);assert variable>=0
  opex=variable*((O-d(s['fixed_cost_fraction']))*sales+d(s['fixed_cost_fraction'])*o['sales']/12);ebitda=sales-material-opex
  maintenance=max(sales*d(s['maintenance_ratio']),ppe*d(s['terminal_replacement_rate'])/12 if m>n else Z);ppe+=maintenance;da=min(ppe,o['da']/12+max(Z,ppe-o['ppe'])*d(s['new_asset_da_rate'])/12);ppe-=da;ebit=ebitda-da-opening_spoil-writeoff
  # IPO working capital can reimburse only incremental operating investment, never old debt service or ordinary losses.
  other_target=o['other_operating_assets']+max(Z,annual_demand*price-o['sales'])*d(s['other_asset_ratio']);other_change=other_target-other;other=other_target
  incremental_wc=max(Z,(ar+inv+other+rawadv-ap)-(opening['ar']+opening['inv']+opening['other']+opening['rawadv']-opening['ap']));wc_use=min(ipo_wc,incremental_wc) if s['ipo_wc_gate'] else Z;ipo_wc-=wc_use
  term_principal=min(term,o['current_term_maturity']/12) if m<=12 else min(term,o['term_debt']/d(s['old_term_amort_months']))
  if m>=int(s['old_term_final_month']):term_principal=term
  term-=term_principal
  project_principal=min(projectdebt,(d(s.get('project_loan_headroom_override',o['project_loan_headroom'])) if s['project_loan_gate'] else Z)/d(s['project_amort_months'])) if m>=int(s['project_amort_start']) else Z
  if m>=int(s['project_final_month']):project_principal=projectdebt
  projectdebt-=project_principal
  wc_principal=wcdebt if m==int(s['wc_call_month']) and not s['wc_renewal_gate'] else Z;wcdebt-=wc_principal
  flex_principal=Z;renewal_fee=Z;renewed=Z;kept=[]
  for loan in newloans:
   if loan['due']==m:
    if m<=n and s['flex_renewal_gate']:renewed+=loan['amount'];renewal_fee+=loan['amount']*d(s['renewal_fee']);kept.append(dict(amount=loan['amount'],due=m+int(s['flex_tenor'])))
    else:flex_principal+=loan['amount']
   else:kept.append(loan)
  newloans=kept;flexdebt-=flex_principal
  interest=(opening['term']*d(s['old_term_rate'])+(opening['projectdebt']+project_draw)*d(s['project_rate'])+opening['wcdebt']*d(s['wc_rate'])+opening['flexdebt']*d(s['flex_rate']))/12
  tax=max(Z,ebit-interest)*d(s['tax_rate']);tax_pay=taxclaim if m==int(s['tax_claim_month']) else Z;taxclaim-=tax_pay;claim_pay=min(claims,o['other_claims']/d(s['claim_months'])) if m<=int(s['claim_months']) else Z;claims-=claim_pay
  subsidy=d(s['subsidy_cash']) if m==int(s['subsidy_month']) else Z
  # No automatic FD release, subsidy, promoter rescue or IPO double count.
  pledge_release=min(pledged,d(s['pledge_release'])) if m==int(s['pledge_release_month']) and s['pledge_release_gate'] else Z;pledged-=pledge_release
  legal_pay=d(s['legal_payment']) if m==int(s['legal_month']) else Z;fd_penalty=lock_release*d(s.get('ipo_early_redemption_penalty','0')) if s.get('ipo_premature_redemption_gate',False) and m==1 else Z;fees=project_draw*d(s['project_draw_fee'])+renewal_fee+d(s['annual_fees'])/12+fd_penalty;capex=project_capex+growth_capex+maintenance
  reserve=max(d(s['cash_floor']),(material+opex)*d(s['reserve_months']))
  pre=cash+collections+cap_use+wc_use+project_draw+subsidy+pledge_release+gst_refund-supplier_cash-advance_topup-opex-interest-tax-tax_pay-claim_pay-other_change-capex-project_gst-term_principal-project_principal-wc_principal-flex_principal-fees-legal_pay
  equity_shares=int(s['equity_shares']) if m==int(s['equity_month']) else 0;equity_cash=d(equity_shares)*d(s['equity_issue_price'])/CR*(O-d(s['equity_fee']));shares+=equity_shares;pre+=equity_cash
  need=max(Z,reserve-pre);flexdraw=Z;flexfee=Z
  if m<=n and s['flex_gate']:
   r=d(s['flex_rate'])/12;f=d(s['flex_fee']);t=d(s['tax_rate']);taxable=max(Z,ebit-interest);candidate=need/(O-f-r*(O-t))
   if candidate*r>taxable:candidate=(need-taxable*t)/(O-f-r)
   flexdraw=min(max(Z,candidate),max(Z,d(s['flex_limit'])-flexdebt),max(Z,d(s['flex_cumulative_limit'])-cum_flex));flexfee=flexdraw*f;cum_flex+=flexdraw;flexdebt+=flexdraw
   if flexdraw:newloans.append(dict(amount=flexdraw,due=m+int(s['flex_tenor'])))
  drawinterest=flexdraw*d(s['flex_rate'])/12;oldtax=tax;interest+=drawinterest;tax=max(Z,ebit-interest)*d(s['tax_rate']);cash=pre+flexdraw-flexfee-drawinterest+oldtax-tax;shortfall=max(Z,reserve-cash)
  fcff=collections-supplier_cash-advance_topup-opex-max(Z,ebit)*d(s['tax_rate'])-other_change-capex-project_gst+gst_refund
  row=dict(month=m,date=date(m),year=y+1,phase='horizon' if m<=n else 'terminal_transition',opening=opening,cash_close=cash,reserve=reserve,shortfall=shortfall,ipo_capex_close=ipo_cap,ipo_wc_close=ipo_wc,pledged_close=pledged,ar_close=ar,inventory_close=inv,seasonal_supply_target=supply_target,target_inventory=target_inventory,ap_close=ap,other_assets_close=other,raw_advances_close=rawadv,raw_advance_application=advance_application,raw_advance_topup=advance_topup,net_invoiced=net_invoiced,other_claims_close=claims,tax_claim_close=taxclaim,ppe_close=ppe,cwip_close=cwip,wc_debt_close=wcdebt,term_debt_close=term,project_debt_close=projectdebt,flex_debt_close=flexdebt,debt_close=wcdebt+term+projectdebt+flexdebt,shares_close=shares,capacity=cap,productive_capacity=productive_capacity,units=units,lost_units=lost,price=price,sales=sales,material=material,purchases=purchases,supplier_cash=supplier_cash,collections=collections,receivable_writeoff=writeoff,inventory_spoilage=opening_spoil,opex=opex,ebitda=ebitda,da=da,ebit=ebit,interest=interest,current_draw_interest=drawinterest,tax=tax,tax_claim_payment=tax_pay,other_claim_payment=claim_pay,other_assets_change=other_change,project_capex=project_capex,project_gst_cash=project_gst,gst_refund=gst_refund,growth_capex=growth_capex,maintenance_capex=maintenance,capex=capex,project_remaining=project_remaining,project_loan_headroom=project_loan_capacity,project_draw=project_draw,ipo_fd_locked_close=ipo_locked,ipo_fd_release=lock_release,restricted_capex_use=cap_use,restricted_wc_use=wc_use,incremental_wc=incremental_wc,commissioned_value=commissioned_value,commissioned_capacity=commissioned_capacity,term_principal=term_principal,project_principal=project_principal,wc_principal=wc_principal,flex_principal=flex_principal,flex_draw=flexdraw,flex_fee=flexfee,renewed_principal=renewed,fees=fees,ipo_early_redemption_penalty=fd_penalty,subsidy=subsidy,pledge_release=pledge_release,legal_payment=legal_pay,equity_shares=equity_shares,equity_cash=equity_cash,operating_fcff=fcff)
  rows.append(row)
  if m==n:exitrow=deepcopy(row);terminal_basis=dict(units=sum((r['units'] for r in rows[-12:]),Z),price=price,sales=sum((r['sales'] for r in rows[-12:]),Z),ebitda=sum((r['ebitda'] for r in rows[-12:]),Z))
  if shortfall>D('1e-22'):
   failure=dict(month=m,shortfall=shortfall,negative_cash=cash<0,reason='Conditional model liquidity reserve/funding shortfall; not an observed default.');break
 terminal=None;attempt=None
 if failure is None:
  tr=rows[n:];first=tr[:12];end=exitrow;g=d(s['terminal_growth']);w=d(s['wacc']);assert w>g
  nopat=sum((r['ebit']*(O-d(s['tax_rate'])) for r in first),Z);tda=sum((r['da'] for r in first),Z);actualmaint=sum((r['maintenance_capex'] for r in first),Z);replacement=max(actualmaint,tda)
  onwc=lambda r:r['ar_close']+r['inventory_close']+r['other_assets_close']+r['raw_advances_close']-r['ap_close']
  working=max(Z,onwc(first[-1])-onwc(end));physical=sum((r['growth_capex']+r['project_capex'] for r in first),Z);growth=max(physical+working,max(Z,nopat)*g/d(s['terminal_roic']));extra=replacement-actualmaint+growth-physical-working
  fcff=nopat+tda-replacement-growth;extra_cumulative=[];ex=Z
  for k,r in enumerate(tr):
   ex+=extra*(O+g)**(k//12)/12;extra_cumulative.append(ex)
  funding_reserve=max([end['reserve']]+[r['reserve']-(r['cash_close']-end['cash_close'])+extra_cumulative[k] for k,r in enumerate(tr)]);funding_reserve=max(Z,funding_reserve)
  fin=Z;opreq=[end['reserve']];unlevered=[]
  for k,r in enumerate(tr):
   shield=max(Z,r['ebit'])*d(s['tax_rate'])-r['tax'];fin+=r['term_principal']+r['project_principal']+r['wc_principal']+r['flex_principal']+r['interest']-shield+r['fees']+r['flex_fee']+r['tax_claim_payment']+r['other_claim_payment']+r['legal_payment']
   u=r['cash_close']+fin;opreq.append(r['reserve']-(u-end['cash_close'])+extra_cumulative[k]);unlevered.append(dict(month=k+1,financing_addback=fin,unlevered_cash=u))
  operating_reserve=max(Z,max(opreq));cashbridge=max(Z,end['cash_close']-operating_reserve);distributable=max(Z,end['cash_close']-funding_reserve);terminal_lost=sum((r['lost_units'] for r in tr),Z);funded=end['cash_close']+D('1e-20')>=funding_reserve and terminal_lost<D('1e-20') and end['project_remaining']<D('1e-20')
  senior=end['other_claims_close']+end['tax_claim_close']+d(i['employee_claim']);attempt=dict(next_sales=sum((r['sales'] for r in first),Z),next_nopat=nopat,next_da=tda,replacement_capex=replacement,physical_growth_capex=physical,working_reinvestment=working,growth_reinvestment=growth,extra_cash_requirement=extra,fcff=fcff,cash_at_exit=end['cash_close'],funding_reserve=funding_reserve,operating_reserve=operating_reserve,cash_bridge=cashbridge,distributable_cash=distributable,debt=end['debt_close'],senior_claims=senior,shares=end['shares_close'],restricted_cash_excluded=end['ipo_capex_close']+end['ipo_wc_close']+end['pledged_close'],terminal_lost_units=terminal_lost,funded=funded,unlevered_transition=unlevered,extra_cumulative=extra_cumulative,transition_months=transition_months)
  if funded:
   ev=max(Z,fcff/(w-g));equity=max(Z,ev+cashbridge-end['debt_close']-senior);per=equity*CR/end['shares_close'];entry=d(i['entry_price'])*(O+d(s['entry_cost']));net=per*(O-d(s['exit_cost']));irr=(net/entry)**(O/d(years))-O if net>0 else D(-1);mev=terminal_basis['ebitda']*d(s['exit_multiple']);meq=max(Z,mev+cashbridge-end['debt_close']-senior);pv=sum((r['operating_fcff']/(O+w)**(d(r['month'])/12) for r in rows[:n]),Z);tv=ev/(O+w)**years
   terminal=dict(attempt,enterprise_value=ev,equity_value=equity,price_per_share=per,conditional_irr=irr,ordinary_irr=irr if i['source_eligible'] and s['source_eligible'] else None,multiple_equity_value=meq,multiple_price=meq*CR/end['shares_close'],operating_pv=pv,terminal_pv=tv,operating_dcf=pv+tv,conditional_dcf_equity=max(Z,pv+tv+o['general_cash']+o['ipo_capex_cash']+o['ipo_wc_cash']-o['wc_debt']-o['term_debt']-o['other_claims']-o['tax_claim']-d(i['employee_claim'])),terminal_share=tv/(pv+tv) if pv+tv>0 else None,hurdle_prices={str(h):net/((O+h)**years*(O+d(s['entry_cost']))) for h in [D('.12'),D('.15'),D('.18')]})
  else:failure=dict(month=n+transition_months,shortfall=max(Z,funding_reserve-end['cash_close']),negative_cash=False,reason='Terminal physical capacity/replacement/growth cash reserve failure; no rescue assumed.')
 annual=[]
 for y in range(1,years+1):
  a=[r for r in rows if r['year']==y and r['phase']=='horizon']
  if not a:continue
  sums=['sales','units','ebitda','da','ebit','interest','tax','collections','supplier_cash','capex','project_capex','growth_capex','maintenance_capex','restricted_capex_use','restricted_wc_use','project_draw','flex_draw','equity_cash','operating_fcff'];arow={k:sum((r[k] for r in a),Z) for k in sums};arow.update(year=y,months=len(a),cash_close=a[-1]['cash_close'],debt_close=a[-1]['debt_close'],shares_close=a[-1]['shares_close'],capacity=a[-1]['capacity']);annual.append(arow)
 summary=dict(path_id=path_id,years=years,kind=s['kind'],label=s['label'],source_eligible=i['source_eligible'] and s['source_eligible'],funded=terminal is not None,ordinary_irr=None if terminal is None else terminal['ordinary_irr'],conditional_irr=None if terminal is None else terminal['conditional_irr'],terminal_price=None if terminal is None else terminal['price_per_share'],failure_month=None if failure is None else failure['month'],failure_shortfall=None if failure is None else failure['shortfall'],final_shares=shares,terminal_sales=None if exitrow is None else terminal_basis['sales'],gross_flex_draw=cum_flex,total_project_paid=project_paid,volume_growth=s['volume_growth'],ebitda_margin=s['ebitda_margin'])
 return dict(path_id=path_id,years=years,spec=s,source_eligibility_limit=i['source_eligibility_limit'],monthly=rows,annual=annual,terminal_attempt=attempt,terminal=terminal,failure=failure,summary=summary)
