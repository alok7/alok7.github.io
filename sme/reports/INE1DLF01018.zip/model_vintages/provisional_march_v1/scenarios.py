from copy import deepcopy
from decimal import Decimal as D

def scenarios(i):
 base=dict(kind='source_bounded',label='Source-bounded base stress',source_eligible=False,volume_growth='.12',price_growth='.02',customer_loss='0',ebitda_margin='.21',material_ratio='.59',raw_price_shock='0',fixed_cost_fraction='.30',maintenance_ratio='.025',new_asset_da_rate='.065',seasonal_inventory_months={'1':'6','2':'7','3':'8','4':'7','5':'6','6':'5','7':'4','8':'3','9':'2','10':'1.5','11':'1.5','12':'4'},inventory_spoilage='0',spoilage_month=4,collection_delay=2,supplier_delay=1,opening_ar_months=4,opening_ar_recovery='1',opening_ap_months=2,other_asset_ratio='.10',project_spend_months=3,project_cost_multiplier='1',project_gst_cash_rate='0',gst_recovery_delay=6,gst_recovery_fraction='0',commission_month=3,ramp_months=12,project_loan_gate=True,ipo_wc_gate=True,additional_expansion_gate=False,capacity_buffer='1.10',max_capacity='60000',capex_per_tonne='.004',growth_lead_months=18,old_term_amort_months=48,old_term_final_month=48,project_amort_start=6,project_amort_months=72,project_final_month=78,wc_call_month=12,wc_renewal_gate=True,old_term_rate='.10',project_rate='.10',wc_rate='.11',flex_rate='.13',tax_rate='.25',tax_claim_month=6,claim_months=6,subsidy_cash='0',subsidy_month=18,pledge_release_gate=False,pledge_release='0',pledge_release_month=1,legal_payment='0',legal_month=6,project_draw_fee='.01',annual_fees='.10',cash_floor='1',reserve_months='.50',flex_gate=False,flex_limit='0',flex_cumulative_limit='0',flex_tenor=36,flex_renewal_gate=False,flex_fee='.01',renewal_fee='.005',equity_shares=0,equity_month=1,equity_issue_price='80',equity_fee='.03',terminal_growth='.04',terminal_roic='.14',terminal_replacement_rate='.065',wacc='.16',entry_cost='.01',exit_cost='.02',exit_multiple='8')
 result=[]
 def add(pid,years=5,ref=None,**changes):
  s=deepcopy(base if ref is None else ref);s.update(changes);result.append(dict(path_id=pid,years=years,spec=s));return s
 add('source_bear',volume_growth='0',price_growth='0',ebitda_margin='.16',raw_price_shock='.08',customer_loss='.15',collection_delay=3,project_spend_months=9,commission_month=12,project_cost_multiplier='1.15',inventory_spoilage='.05')
 add('source_base')
 add('source_bull',volume_growth='.22',ebitda_margin='.23',collection_delay=1,commission_month=3,ramp_months=6)
 cond=deepcopy(base);cond.update(kind='conditional_reference',label='Conditional verified-funding and renewal assumptions, not confirmed access',project_loan_gate=True,wc_renewal_gate=True,flex_gate=True,flex_limit='80',flex_cumulative_limit='160',flex_renewal_gate=True,additional_expansion_gate=True,project_loan_headroom_override='15.3711')
 add('conditional_base',ref=cond)
 add('conditional_bear',ref=cond,volume_growth='0',price_growth='0',ebitda_margin='.16',raw_price_shock='.08',customer_loss='.15',collection_delay=3,project_spend_months=9,commission_month=12,project_cost_multiplier='1.15',inventory_spoilage='.05')
 add('conditional_bull',ref=cond,volume_growth='.22',ebitda_margin='.23',collection_delay=1,ramp_months=6)
 add('conditional_base_10y',years=10,ref=cond)
 for growth in ['0','.05','.10','.15','.20','.25','.30']:
  for margin in ['.16','.19','.21','.23','.25']:
   add('growth_'+growth+'_margin_'+margin,ref=cond,kind='growth_margin',volume_growth=growth,ebitda_margin=margin)
 for w in ['.13','.14','.16','.18','.20']:
  for g in ['.02','.03','.04','.05']:
   add('wacc_'+w+'_g_'+g,ref=cond,kind='discount_terminal',wacc=w,terminal_growth=g)
 stresses=[('headroom_lower',dict(project_loan_headroom_override='9.2806')),('headroom_upper',dict(project_loan_headroom_override='35')),('cash_zero',dict(general_cash_override='0')),('no_project_loan',dict(project_loan_gate=False)),('no_wc_renewal',dict(wc_renewal_gate=False)),('no_flex',dict(flex_gate=False)),('flex20',dict(flex_limit='20',flex_cumulative_limit='40')),('flex40',dict(flex_limit='40',flex_cumulative_limit='80')),('no_flex_renewal',dict(flex_renewal_gate=False)),('delay6',dict(commission_month=9,project_spend_months=9)),('delay12',dict(commission_month=15,project_spend_months=15)),('overrun15',dict(project_cost_multiplier='1.15')),('overrun30',dict(project_cost_multiplier='1.30')),('raw10',dict(raw_price_shock='.10')),('raw20',dict(raw_price_shock='.20')),('collection3',dict(collection_delay=3)),('collection4',dict(collection_delay=4)),('spoil10',dict(inventory_spoilage='.10')),('writeoff10',dict(opening_ar_recovery='.90')),('subsidy1',dict(subsidy_cash='1')),('gst18_refund6',dict(project_gst_cash_rate='.18',gst_recovery_fraction='1')),('gst18_no_refund',dict(project_gst_cash_rate='.18',gst_recovery_fraction='0')),('legal1',dict(legal_payment='1')),('legal5',dict(legal_payment='5')),('equity2m',dict(equity_shares=2000000)),('equity6m',dict(equity_shares=6000000)),('lower_terminal_multiple',dict(exit_multiple='5')),('higher_costs',dict(entry_cost='.03',exit_cost='.05')),('interest15',dict(flex_rate='.15',wc_rate='.13',project_rate='.12')),('high_reserve',dict(reserve_months='1')),('replacement10',dict(terminal_replacement_rate='.10')),('roic10',dict(terminal_roic='.10')),('roic18',dict(terminal_roic='.18'))]
 for name,change in stresses:add('stress_'+name,ref=cond,kind='sensitivity',**change)
 for years in [5,10]:
  for growth in ['.10','.15','.20','.25','.30','.35','.40','.50']:
   for margin in ['.18','.21','.24']:
    add(f'target_{years}y_g{growth}_m{margin}',years=years,ref=cond,kind='target',volume_growth=growth,ebitda_margin=margin,max_capacity='100000',flex_limit='150',flex_cumulative_limit='300')
 return result
