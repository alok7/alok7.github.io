from pathlib import Path
from copy import deepcopy
from decimal import Decimal as D,localcontext
import json,gzip
from independent_replay import check_path
P=Path(__file__).resolve().parent
j=json.loads(gzip.decompress((P/'canonical_paths.json.gz').read_bytes()));p=next(x for x in j['paths'] if x['terminal']);tests=[]
for field in ['cash_close','ar_close','inventory_close','ap_close','raw_advances_close','ipo_capex_close','ipo_wc_close','debt_close','interest','shares_close','cwip_close']:
 q=deepcopy(p);q['monthly'][0][field]=str(D(str(q['monthly'][0][field]))+D('.01'))
 with localcontext() as c:
  c.prec=45
  try:check_path(q,j['inputs'])
  except AssertionError:tests.append({'field':field,'mutation':'Add0.01 to firstrow','detected':True})
  else:raise AssertionError('Missed mutation '+field)
q=deepcopy(p);q['terminal']['price_per_share']=str(D(q['terminal']['price_per_share'])+1)
try:check_path(q,j['inputs'])
except AssertionError:tests.append({'field':'terminalprice','mutation':'Add1','detected':True})
else:raise AssertionError('Missed terminal mutation')
(P/'model_mutation_results.json').write_text(json.dumps({'status':'PASS','test_count':len(tests),'tests':tests,'qualification':'In-memory output mutation controls, not adversarial external operations.'},indent=2)+'\n')
print('PASS',len(tests),'mutation controls')
