"""Reproduce a retained development model without touching its saved original files."""
from pathlib import Path
import argparse,hashlib,json,subprocess,sys,tempfile,shutil
P=Path(__file__).resolve().parent
ap=argparse.ArgumentParser();ap.add_argument('vintage');ap.add_argument('--output',required=True);args=ap.parse_args();src=P/'model_vintages'/args.vintage;dest=Path(args.output);dest.mkdir(parents=True,exist_ok=False)
for name in ['model.py','scenarios.py','run_model.py','model_inputs.json']:shutil.copy2(src/name,dest/name)
subprocess.run([sys.executable,str(dest/'run_model.py')],cwd=dest,check=True)
meta=json.loads((src/'manifest.json').read_text());expected=meta.get('expected_canonical_sha256',meta.get('hashes',{}).get('canonical_paths.json.gz'));actual=hashlib.sha256((dest/'canonical_paths.json.gz').read_bytes()).hexdigest();assert actual==expected,(actual,expected)
print(json.dumps({'status':'PASS','vintage':args.vintage,'canonical_sha256':actual}))
