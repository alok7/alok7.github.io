from pathlib import Path
from decimal import Decimal as D
import json,hashlib,gzip
P=Path(__file__).resolve().parent
f=json.loads((P/'financial_inputs.json').read_text(),parse_float=D);a=json.loads((P/'model_source_anchors.json').read_text());i=json.loads((P/'model_inputs.json').read_text());m=a['march'];r=next(r for r in f['annual'] if r['fy']==2026);checks=[]
def check(label,x,y):
 assert D(str(x))==D(str(y)),(label,x,y);checks.append(label)
for out,key in {'revenue':'revenue','da':'da','cash_total':'cash','receivables':'receivables','inventory':'inventory','payables':'payables','other_current_claims':'other_cl','ppe':'ppe','cwip':'cwip'}.items():check(out,m[out],r[key])
for out,key in {'pledged_fd':'pledged_sbi_fd_outside_cash','raw_advances':'supplier_raw_advances','gst_input':'gst_input','prepaid':'prepaid','duty_receivable':'duty_drawback_receivable','warehouse_deposit':'warehouse_deposit','electricity_deposit':'electricity_deposit','net_current_tax':'current_tax_net','capital_advances':'capital_advances'}.items():check(out,m[out],f['cash_and_claims'][key])
for out,key in {'term_total':'term_total_including_current','hdfc_term':'hdfc_term','current_term_maturity':'current_term_maturities'}.items():check(out,m[out],f['debt'][key])
check('WCdebt',m['wc_debt'],f['debt']['cash_credit']+f['debt']['packing_credit']);check('employeeclaims',m['employee_claim'],f['cash_and_claims']['employee_long_claim']+f['cash_and_claims']['employee_current_claim'])
for out,key in {'ipo_total':'total_unspent','ipo_capex':'capex_unspent','ipo_wc':'wc_unspent','ipo_gcp':'gcp_unspent','ipo_fd':'fd_total'}.items():check(out,a['june'][out],f['june_monitor'][key])
check('IPOFDschedule',sum(D(x) for x in i['ipo_fd_maturity_schedule'].values()),f['june_monitor']['fd_total']);check('normalTax',f['tax']['statutory_source_rate'],'0.2912')
check('commonShares',i['issued_shares'],json.loads((P/'market_inputs.json').read_text())['issued_shares'])
check('projectRemaining',i['opening']['project_remaining'],D(a['project_budget'])-D(m['cwip'])-D(m['capital_advances'])-(D(m['ipo_capex'])-D(a['june']['ipo_capex'])))
check('IPOcash_not_doublecounted',i['opening']['general_cash'],D(m['cash_total'])-D(m['ipo_total']))
for key in ['source_eligible']:assert i[key] is False
canon=json.loads(gzip.decompress((P/'canonical_paths.json.gz').read_bytes()));assert canon['inputs']==i
out={'status':'PASS','source_anchor_checks':len(checks),'checks':checks,'financial_inputs_sha256':hashlib.sha256((P/'financial_inputs.json').read_bytes()).hexdigest(),'model_inputs_sha256':hashlib.sha256((P/'model_inputs.json').read_bytes()).hexdigest(),'canonical_sha256':hashlib.sha256((P/'canonical_paths.json.gz').read_bytes()).hexdigest(),'qualification':'Checks source extraction against final authored primary-source ledger. Does not make missing bank allocation or supplier attribution known.'}
(P/'model_audit.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))
