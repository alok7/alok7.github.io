from pathlib import Path
from decimal import Decimal as D
import json,hashlib,re,gzip,statistics
P=Path(__file__).resolve().parent
read=lambda n:json.loads((P/n).read_text(),parse_float=D)
def main():
 r=read('company_record.json');report=(P/'report.md').read_text();assert re.findall(r'^## (\d+)\. ',report,re.M)==list(map(str,range(1,16)));assert len(read('quality_checks.json')['checks'])==16;assert len(r['factors'])==13
 assert r['isin']=='INE1DLF01018'and r['price']=='114.80'
 for n,h in r['authored_input_sha256'].items():assert hashlib.sha256((P/n).read_bytes()).hexdigest()==h,n
 for n,h in r['output_sha256'].items():assert hashlib.sha256((P/n).read_bytes()).hexdigest()==h,n
 assert D(r['scores']['BQS']['final'])==D('5.26');assert D(r['scores']['GQS']['raw'])==D('6.35');assert D(r['scores']['GQS']['final'])==5;assert r['scores']['IAS']['final']is None;assert not any(v['ranking_eligible']for v in r['scores'].values())
 m=read('market_inputs.json');assert len(m['sessions'])==60 and sum(v['present']for v in m['sessions'])==59;assert m['lot_size']==1000 and m['windows']['60']['missing_dates']==['2026-09-03']
 vals=[D(x['row']['TtlTrfVal'])for x in m['sessions']if x['present']];assert D(m['windows']['60']['mean_traded_value_inr'])==sum(vals)/59;assert D(m['windows']['60']['median_traded_value_inr'])==statistics.median(vals)
 f=read('financial_inputs.json');cf=f['cashflow_reclass'];assert abs(D(cf['fy26_reported_cfo'])+D(cf['fy26_reported_cfi'])-D(cf['fy26_economic_cfo_excluding_capital_advances_and_fd'])-D(cf['fy26_economic_cfi']))<D('.00001')
 met=read('metrics.json');a=[x for x in f['annual']if x['fy']>=2024];assert D(met['cash_conversion']['3']['ratio'])==sum(D(x['cfo'])for x in a)/sum(D(x['pat'])for x in a)
 for row in met['annual']:
  if'ebitda_change'in row:assert abs(D(row['ebitda_change'])-D(row['ebitda_change_sales_effect'])-D(row['ebitda_change_margin_effect']))<D('1e-20')
 c=json.load(gzip.open(P/'canonical_paths.json.gz','rt'));assert len(c['paths'])==r['path_count']
 for x in c['paths']:
  if x['failure']:assert x['terminal']is None and x['summary']['ordinary_irr']is None and x['summary']['conditional_irr']is None
 assert '{{'not in report and '/workspace/'not in report
 html=(P/'report.html').read_text();assert html.count('<h2>')==15;assert '<table>'in html and 'overflow-x:auto'in html
 result={'status':'PASS','sections':15,'checks':16,'factors':13,'paths':r['path_count'],'source_eligible_paths':r['source_eligible_path_count'],'html_static':{'headings':15,'tables':html.count('<table>'),'links':html.count('<a href=')},'browser_pixel_qa':'Unavailable: ordinary installed Chromium could not initialize its user-data directory; a bounded retry using a fresh writable profile reached socket() Operation not permitted before loading the file. No bypass attempted. Structural HTML checks only; no pixel review claimed.'}
 (P/'verification.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n');print(json.dumps(result))
if __name__=='__main__':main()
