from decimal import Decimal as D
import json,hashlib,html,re
def js(x,pretty=False):return json.dumps(x,ensure_ascii=False,default=lambda v:str(v)if isinstance(v,D)else str(v),sort_keys=True,indent=2 if pretty else None,separators=None if pretty else(',',':'))
def sha(b):return hashlib.sha256(b).hexdigest()
def fmt(x,n=2):
 if x is None:return 'ND'
 try:return f'{D(str(x)):,.{n}f}'
 except:return str(x)
def pct(x):return 'NS'if x is None else fmt(D(str(x))*100)+'%'
def humanize(value):
 t=str(value);saved=[]
 def keep(m):
  saved.append(m.group(0));return '@@TOKEN'+str(len(saved)-1)+'@@'
 t=re.sub(r'https?://[^\s)]+|\bB2[BC]\b|SFL-[A-Z0-9]+|PEER-[A-Z0-9]+|NSE-MARKET|https?://[^\s)]+|\bv[0-9]+\.[0-9]+\b|[A-Za-z0-9][A-Za-z0-9_.-]*_[A-Za-z0-9_.-]+|\b[0-9a-f]{64}\b|\bINE[A-Z0-9]+\b|\bResults26\b|\b[A-Z]{2,}[0-9]+\b',keep,t)
 replacements={
 'Financialvalues':'Financial values','MissingSeptember':'Missing September','missingSeptember':'missing September','Novpressreleasechart':'November press-release chart','affectsimplementation':'affects implementation','aggregatewinner':'aggregate winner','balancinghalfyear':'balancing half-year','containsunrelatednumbers':'contains unrelated numbers','croreunverified':'crore unverified','financialstatement':'financial statement','nointerimcashflow':'no interim cash flow','nonoperatingasset':'nonoperating asset','useauditedtable':'use audited table','notquarter':'not a quarter','NSE19':'NSE 19','IPOobjects':'IPO objects','nozero':'no zero','PATsum':'PAT sum','capexsum':'capex sum','FCFproxy':'FCF proxy','mainproxy':'main proxy','projectIRR':'project IRR','casessum':'cases sum',
 'issuedshares':'issued shares','issued shares':'issued shares','sourceeligible':'source eligible','sourceeligibility':'source eligibility','source-verified':'source-verified',
 'PRI':'PRI','Volumegrowth':'Volume growth','EBITDAmargin':'EBITDA margin','failuremonth':'failure month','ConditionalIRR':'Conditional IRR','ordinaryIRR':'ordinary IRR','Terminalprice':'Terminal price','Finalshares':'Final shares',
 'currentissuedshares':'current issued shares','weightedEPS':'weighted EPS','withrestrictedcashnetting':'with restricted cash netting','Debt withoutrestrictedcashnetting':'Debt without restricted cash netting','Marchavailablecash':'March available cash','restrictedcash':'restricted cash','notverifiedOctoberfreecash':'not verified October free cash','EV/operatingEBITDA':'EV/operating EBITDA','thatresidual':'that residual','Conditionalcross-check':'Conditional cross-check','doubleaddofprojectcash':'double addition of project cash','ongoingassetvalue':'ongoing asset value','Excludesotherincome':'Excludes other income','uses29.12':'uses 29.12',
 'term allocation':'term allocation','Card/seniorclaims':'Card/senior claims','reportedP/E':'reported P/E','Book includesproject,advances and noncashassets; notliquidationvalue':'Book includes project, advances and noncash assets; not liquidation value',
 'Movecapitaladvanceoutflow':'Move capital-advance outflow','pledgedFDrelease':'pledged FD release','unchangedtotalcash':'unchanged total cash','rawGQS':'raw GQS','finalGQS':'final GQS',
 'All scenarios':'All scenarios','Volumegrowth':'Volume growth','Reportedcash lessIPOobjects':'Reported cash less IPO objects','Nozero':'No zero','FDrelease':'FD release',
 'Newline':'New line','Machinerydelivery,permits,trial andcommercialdispatch':'Machinery delivery, permits, trial and commercial dispatch','Delay triggersfundingreview':'Delay triggers funding review','repeatedunfundeddelay pluslostcustomers canbreakexpansionthesis':'repeated unfunded delay plus lost customers can break the expansion thesis',
 'JuneWCuse':'June WC use','unverified attribution':'unverified attribution','supplieradvances':'supplier advances','potatoreceipts':'potato receipts','monitorclarification':'monitor clarification','Unreconciled use holdsresearch':'Unreconciled use holds research','verifiedunauthorizedloss/materialdiversion':'verified unauthorized loss/material diversion','changesgovernance':'changes governance',
 'Agedadvances,deliveryquality,refundability andrelatedcounterparties eachhalfyear':'Aged advances, delivery quality, refundability and related counterparties each half-year','Slowdeliveryneedsreview':'Slow delivery needs review','irrecoverableadvances withoutfundingbuffer threatenvalue':'irrecoverable advances without a funding buffer threaten value',
 'agedbuckets withcustomerconcentration':'aged buckets with customer concentration','Longerdayssignalrisk':'Longer days signal risk','materialbaddebts plusweakbuyerretention undermineeconomics':'material bad debts plus weak buyer retention undermine economics',
 'Projectbalancebudgetproxy':'Project balance-budget proxy','atMarch':'at March','Certifiedcost-to-complete includingtax/FX,knownsubsequentpayments':'Certified cost-to-complete including tax/FX and known subsequent payments','Costoverrunisnotfraud':'Cost overrun is not fraud','unfinanceableessentialspend':'unfinanceable essential spend','changesfundinggate':'changes funding gate',
 'JuneunspentIPO':'June unspent IPO','Object-specificaccounts':'Object-specific accounts','anddrawverification':'and draw verification','Do not treatrestrictedcashasgeneralrescue':'Do not treat restricted cash as a general rescue',
 'operatingEBITDA':'operating EBITDA','Volume,mix,inputcost andmargin':'Volume, mix, input cost and margin','Temporarycropcycleisnotthesisfailure':'Temporary crop cycle is not thesis failure','structuralpricepressureplusweakcashis':'structural price pressure plus weak cash is',
 'GOVAOC-2/paytable':'GOV AOC-2/pay table','Correctedfiling andrentalbenchmarking':'Corrected filing and rental benchmarking','Clericalcorrectioncanresolvepresentation':'Clerical correction can resolve presentation','evidencedabuse':'evidenced abuse','Currenttape':'Current tape','position-specificexitplan':'position-specific exit plan','Thinliquidity':'Thin liquidity','automaticbusinessfailure':'automatic business failure',
 'sourcefiles/pages':'source files/pages','fullclaimledgers':'full claim ledgers','sourcehashes':'source hashes','independentcorroboration':'independent corroboration','statutoryaudit':'statutory audit','itsmanagementresponse':'its management response','independentlyverified':'independently verified',
 'verifieddisclosure':'verified disclosure','managementstatement':'management statement','analystassumption':'analyst assumption','Primarysource':'Primary source','primarysource':'primary source',
 'current4-lot':'current 4-lot','actualspread':'actual spread','circuitqueue':'circuit queue','marketimpact':'market impact','quote-pageHTML':'quote-page HTML','dynamicorderbook':'dynamic order-book','orderbook':'order book',
 'ordinaryR/P':'ordinary R/P','source-bounded':'source-bounded','operatingassetvalue':'operating asset value','hurdle / reverse expectation':'hurdle / reverse expectation','growth/margin/capex':'growth/margin/capex',
 'sourcefinancial':'source financial','Original instrument':'Original instrument','term allocation':'term allocation','normalizedNOPAT':'normalized NOPAT','modelbase':'model base','nettax':'net tax','full-year':'full-year'
 }
 for old,new in sorted(replacements.items(),key=lambda x:-len(x[0])):t=t.replace(old,new)
 t=re.sub(r'(?<=[%×])(?=[A-Za-z0-9])',' ',t)

 for a,b in {'13whole':'13 whole','whole-company5×or10×':'whole-company 5× or 10×','overfive':'over five','overten':'over ten','addone':'add one','orderbookdepth':'order-book depth','source-eligible':'source-eligible'}.items():t=t.replace(a,b)
 t=re.sub(r'(?<=[a-z])(?=[0-9])',' ',t)
 t=re.sub(r'(?<=[0-9])(?=[A-Za-z])',' ',t)
 t=re.sub(r'(?<=[0-9])(cr|crore|lakh)\b',lambda m:' '+('crore'if m.group(1)=='cr'else m.group(1)),t)
 t=re.sub(r'(?<=[A-Za-z])(?=₹)',' ',t)
 t=re.sub(r'(?<=[0-9])(?=(?:January|February|March|April|May|June|July|August|September|October|November|December|Jan|Feb|Mar|Apr|Jun|Jul|Aug|Sep|Oct|Nov|Dec)\b)',' ',t)
 for k,v in enumerate(saved):t=t.replace('@@TOKEN'+str(k)+'@@',v)
 return t

def table(head,rows):return '| '+' | '.join(head)+' |\n|'+ '|'.join(['---']*len(head))+'|\n'+'\n'.join('| '+' | '.join(humanize(x).replace('|',' / ').replace('\n',' ')for x in r)+' |'for r in rows)
def mdhtml(s):
 def inline(t):
  t=html.escape(t);t=re.sub(r'\[([^\]]+)\]\(([^)]+)\)',r'<a href="\2">\1</a>',t);return re.sub(r'\*\*(.+?)\*\*',r'<strong>\1</strong>',t)
 out=[];lines=s.splitlines();i=0
 while i<len(lines):
  l=lines[i]
  if l.startswith('|'):
   a=[]
   while i<len(lines)and lines[i].startswith('|'):a.append(lines[i]);i+=1
   out.append('<div class="table"><table>')
   for k,r in enumerate(a):
    if k==1 and not r.replace('|','').replace('-','').replace(':','').strip():continue
    tag='th'if k==0 else'td';out.append('<tr>'+''.join('<'+tag+'>'+inline(v.strip())+'</'+tag+'>'for v in r.strip('|').split('|'))+'</tr>')
   out.append('</table></div>');continue
  h=re.match(r'^(#{1,6}) (.*)',l)
  if h:out.append('<h'+str(len(h[1]))+'>'+inline(h[2])+'</h'+str(len(h[1]))+'>')
  elif l.strip():out.append('<p>'+inline(l)+'</p>')
  i+=1
 return '<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Shivashrit Foods SME research 368</title><style>body{max-width:1160px;margin:40px auto;padding:0 22px;font:16px/1.55 system-ui;color:#172635;background:#fbfcfe}h1,h2{color:#123e59}h2{margin-top:2.4em}a{color:#05618c;overflow-wrap:anywhere}.table{overflow-x:auto;max-width:100%}table{border-collapse:collapse;width:100%;font-size:13px;margin:16px 0}th,td{border:1px solid #d4dfe7;padding:8px;vertical-align:top}th{background:#e9f0f5}tr:nth-child(even){background:#f3f6f9}</style><body>'+''.join(out)+'</body></html>\n'

def readable(s):
 return s
