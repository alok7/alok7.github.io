# Shivashrit Foods Limited

SME research 368 · Master Prompt v3.0 · Information cutoff 20 October 2026 · Market cutoff 19 October 2026

## 1. Executive Verdict

Hold — unresolved, not an evidence-backed compounder. Shivashrit is an operating potato-flake ingredient manufacturer with demonstrated prior capacity and revenue growth, but concentrated uncontracted buyers, capital-intensive seasonal procurement and weak cumulative cash realization limit quality. The new line could materially expand production, yet the original June 2026 start has moved to a management target of January 2027. More importantly, the June monitoring report could not independently establish expansion-specific attribution of ₹17.06 crore of working-capital spending. The issuer's supplier-advance explanation, no-deviation headline and clean statutory audit are retained; this is a verification hold, not a diversion allegation. At ₹114.80, current-share reported earnings imply roughly 14.9× P/E, which does not establish a margin of safety while funding, deployment and execution assumptions remain unresolved. BQS is 5.3; GQS is capped at 5.0 for persistent weak cash conversion; IAS is NS. The thesis is a capacity-expansion and working-capital execution case, not a proven branded or asset-light franchise. A reconciled project cash/advance ledger, funded commissioning and sustained collections would justify reassessment. [SFL-P](https://nsearchives.nseindia.com/emerge/corporates/content/ShivashritFoodsLimited_PROSP.pdf); [SFL-AR26R](https://nsearchives.nseindia.com/annual_reports/SME_AR_32089_SHIVASHRIT_2025_2026_U_7594527_28092026121229.pdf); [SFL-MONJUN26](https://nsearchives.nseindia.com/corporate/SHIVASHRITFOODS_13082026145123_MAReport30062026.pdf); [SFL-AGM26](https://nsearchives.nseindia.com/corporate/SHIVASHRITFOODS_30092026133208_Outcome_of_AGM-f.pdf); [NSE-MARKET](https://nsearchives.nseindia.com/content/cm/BhavCopy_NSE_CM_0_0_0_20261019_F_0000.csv.zip)

## 2. Research Header, Gates and Data Confidence

| Item | Basis |
|---|---|
| Issuer | Shivashrit Foods Limited / NSE Emerge SHIVASHRIT / INE1DLF01018 |
| Original instrument | Position 368; original symbol SHIVASHRIT |
| Cutoffs | Information 20 October 2026; market 19 October 2026; no later information used |
| Quote | NSE 19 October close ₹114.80; not a guaranteed execution price |
| Shares / board lot | 18,269,000 issued shares;1,000 shares; one lot ₹114,800 |
| Market capitalization | ₹209.73 crore |
| Scope / accounting | Standalone; no subsidiary identified; Indian GAAP Accounting Standards, not assumed IndAS |
| Horizon / units | Five-year scenarios and 10-year optional outcome tests;₹crore unless labeled |
| Hurdle / WACC | 15% nominal before personal taxes; WACC independently assumed and sensitized in model |
| Liquidity reference | ₹5 lakh;4 whole lots cost ₹459,200; reference only, not recommended allocation |

| Gate | Status | Evidence / resolution |
|---|---|---|
| G1 | Conditional | No reviewed substantiated diversion or serious minority-abuse finding; RPT and disclosure inconsistencies need clarification. Resolution: Corrected AOC-2/remuneration disclosures, rental benchmarking and transparent object-use evidence. |
| G2 | Hold — unresolved | Material ₹17.06 crore expansion-WC attribution explicitly could not be independently ascertained in the June monitor. Clean audited statements and management supplier-advance explanation are retained, but do not independently close that use-specific gap. Resolution: Bank-to-supplier-to-stock/project reconciliation, supporting procurement/receipt records and monitor clarification. |
| G3 | Conditional | No evidenced default. Sanctioned project lending and unspent IPO objects support funding, but exact draw/remaining capex and FD encashment availability need a current bridge. Resolution: Dated lender sanction/draw/undrawn and maturity schedule plus complete project cash budget. |
| G4 | Conditional | Trading and lot verified; one missing historical issuer row and unverified depth/spreads prevent a complete liquidity assessment, not proof of effective untradeability. Resolution: Resolve missing September 3 session and verify executable order depth for actual proposed position. |

| Subject | Confidence and limitation |
|---|---|
| governance | Medium on disclosed ownership, vote process and audit; unresolved related-party/disclosure and IPO-use questions remain. |
| historical financials | Medium to High on primary statements and documented restatements; specific IPO-WC attribution remains unresolved. |
| growth | Medium; comparable annual revenue and physical history available, FY26 shipment/price split ND. |
| capital returns | Medium; committed-capital proxy and alternative definitions disclosed, not a project IRR. |
| funding and valuation | Low for current complete project availability and source-eligible forward returns. |
| overall | Low for an investment conclusion because material deployment/funding and full liquidity evidence remain unresolved. |

## 3. Scorecard and Calculation Audit

| Measure | Raw | Final | Coverage | Missing-data bound / cap | Ranking eligible |
|---|---|---|---|---|---|
| BQS | 5.2600 | 5.3 | 100.00% | 5.2600 to 5.2600; cap none | False |
| GQS | 6.3500 | 5.0 | 100.00% | 6.3500 to 6.3500; cap 5 | False |
| IAS | NS | NS | 25.00% | 2.0650 to 8.8150; cap none | False |

| Factor | Score / confidence | Evidence and contrary evidence | Why / weighted BQS GQS IAS contributions |
|---|---|---|---|
| GOV | 5 / Medium | The June 2026 monitor could not independently ascertain expansion attribution for ₹17.06 crore of working-capital deployment; management explains supplier advances and the headline says no object deviation. Related-party cold-storage rent and the inconsistent AOC-2 arm’s-length heading require scrutiny. Counterevidence: September shareholding reports no promoter encumbrance; interested promoter votes were invalidated on the new-site resolution; clean main audit/IFC and resolved old tax dispute are preserved. [SFL-MONJUN26](https://nsearchives.nseindia.com/corporate/SHIVASHRITFOODS_13082026145123_MAReport30062026.pdf); [SFL-EGMRESULT](https://nsearchives.nseindia.com/corporate/SHIVASHRITFOODS_21032026174805_FinaloutcomeofEGMSFL.pdf); [SFL-AR26R](https://nsearchives.nseindia.com/annual_reports/SME_AR_32089_SHIVASHRIT_2025_2026_U_7594527_28092026121229.pdf); [SFL-SHP26](https://nsearchives.nseindia.com/corporate/xbrl/SHP_1741163_19102026113011_WEB.xml) | Mixed stewardship and unresolved verification justify 5, not a misconduct score or an assumption of diversion. Contributions: 1.000 / NA / NA |
| MOAT | 5 / Medium | Specialized processing equipment, food-safety consistency and repeat industrial orders create useful capability. FY25 top-five customers account for 79.10% and no legally binding/formal customer contracts were disclosed. Counterevidence: Earlier capacity doubling and actual production growth demonstrate commercial competence; procurement proximity can lower logistics costs. [SFL-P](https://nsearchives.nseindia.com/emerge/corporates/content/ShivashritFoodsLimited_PROSP.pdf) | Useful but contestable relationships/processes. No demonstrated customer lock-in, brand moat or structural pricing power. Contributions: 1.000 / NA / NA |
| REV | 8 / Medium | Comparable FY23–26 reported revenue CAGR is about 35.8%, from 45.351 to 113.515 crore. FY26 growth slowed to 8.43%; physical production rose throughFY25 butFY26 volume is ND and price/mix contributes. Counterevidence: Growth is not merely an invented TAM forecast; previous physical capacity and actual production increased. [SFL-P](https://nsearchives.nseindia.com/emerge/corporates/content/ShivashritFoodsLimited_PROSP.pdf); [SFL-AR26R](https://nsearchives.nseindia.com/annual_reports/SME_AR_32089_SHIVASHRIT_2025_2026_U_7594527_28092026121229.pdf) | Five-year window unavailable; three-year selected before scoring. Starting 9 for≥30%; net−1 for demonstrated full-year slowdown yields 8, also within the short-history/Medium confidence ceiling. No additional small-base penalty. Contributions: 0.960 / 3.200 / NA |
| DUR | 6 / Medium | Industrial snack and shelf-stable ingredient demand provide accessible avenues beyond the existing plant. Expansion would add 15,840 tonnes annual engineering capacity, but commissioning, customer uptake and seasonal funding are conditions. Counterevidence: Concentrated customers without firm contracts and larger competing processors constrain accessible demand. [SFL-P](https://nsearchives.nseindia.com/emerge/corporates/content/ShivashritFoodsLimited_PROSP.pdf); [SFL-AGM26](https://nsearchives.nseindia.com/corporate/SHIVASHRITFOODS_30092026133208_Outcome_of_AGM-f.pdf) | Meaningful runway with material customer, execution and funding constraints, not an unrestricted global TAM. Contributions: 0.600 / 1.200 / NA |
| CAP | 5 / Medium | Three-year post-tax incremental accounting return is materially lower on full committed capital than the simple core-asset denominator. CWIP and capital advances tie up funds before new-line profits; historical margin expansion partly reflects existing-line economics. Counterevidence: Prior production expansion and higher operating profits provide evidence of useful invested capacity. [SFL-P](https://nsearchives.nseindia.com/emerge/corporates/content/ShivashritFoodsLimited_PROSP.pdf); [SFL-AR26R](https://nsearchives.nseindia.com/annual_reports/SME_AR_32089_SHIVASHRIT_2025_2026_U_7594527_28092026121229.pdf) | Mixed incremental economics around the cost-of-capital range; accounting proxy is not project IRR or proof of high-return future reinvestment. Contributions: 0.600 / 0.750 / NA |
| CASH | 3 / Medium | Multi-year cumulative reported operating cash conversion is poor despite positive profits. Reclassifying capital advances and pledged-deposit movements improves the economic operating view, but does not produce strong cumulative cash realization. Counterevidence: Seasonal potato procurement and some supplier advances are commercially explicable; reported near-zero CFO is not entirely operating weakness. [SFL-P](https://nsearchives.nseindia.com/emerge/corporates/content/ShivashritFoodsLimited_PROSP.pdf); [SFL-AR26R](https://nsearchives.nseindia.com/annual_reports/SME_AR_32089_SHIVASHRIT_2025_2026_U_7594527_28092026121229.pdf) | Persistent weak cash realization merits 3 with the stated GQS cap. Do not double-penalize capex as operating cash consumption. Contributions: 0.300 / 0.300 / NA |
| BAL | 5 / Medium | Debt and seasonal inventory/advance funding remain material; not all IPO bank balances are unrestricted corporate cash. Project sanctions exist but precise current undrawn allocation and encashment/remaining-spend bridge are conditional. Counterevidence: Clean no-default/CARO evidence and separately identified unspent project proceeds are positives; an analytical cash floor is not an actual covenant breach. [SFL-AR26R](https://nsearchives.nseindia.com/annual_reports/SME_AR_32089_SHIVASHRIT_2025_2026_U_7594527_28092026121229.pdf); [SFL-P](https://nsearchives.nseindia.com/emerge/corporates/content/ShivashritFoodsLimited_PROSP.pdf); [SFL-MONJUN26](https://nsearchives.nseindia.com/corporate/SHIVASHRITFOODS_13082026145123_MAReport30062026.pdf) | Manageable documented base assets/facilities with meaningful stress sensitivity; uncertain current availability is not an evidenced default. Contributions: 0.400 / NA / NA |
| EXEC | 5 / Medium | Earlier line expansion translated into actual output growth. New-line commercial target moved fromJune 2026 toNovember 2026 and thenJanuary 2027; site moved with shareholder approval. Counterevidence: Management explains imported-machinery/geopolitical delays; the line is not yet falsely credited as commissioned in this analysis. [SFL-P](https://nsearchives.nseindia.com/emerge/corporates/content/ShivashritFoodsLimited_PROSP.pdf); [SFL-MONJUN26](https://nsearchives.nseindia.com/corporate/SHIVASHRITFOODS_13082026145123_MAReport30062026.pdf); [SFL-AGM26](https://nsearchives.nseindia.com/corporate/SHIVASHRITFOODS_30092026133208_Outcome_of_AGM-f.pdf); [SFL-EGM26](https://nsearchives.nseindia.com/corporate/SHIVASHRITFOODS_24022026155654_SFL_-_Final_Notice_of_EGM.pdf) | Mixed delivery. A delayed major project is important, but earlier execution and documented explanation prevent treating every project as failed. Contributions: 0.400 / NA / NA |
| EARN | 6 / Medium | Operating EBITDA and EBIT improved alongside revenue; other income and tax relief still affect reported PAT. Current-share FY26 earnings are below weighted-average EPS because IPO shares joined during the year. Counterevidence: Improvement is not solely nonoperating income; earlier operating margins were lower and production scale rose. [SFL-P](https://nsearchives.nseindia.com/emerge/corporates/content/ShivashritFoodsLimited_PROSP.pdf); [SFL-AR26R](https://nsearchives.nseindia.com/annual_reports/SME_AR_32089_SHIVASHRIT_2025_2026_U_7594527_28092026121229.pdf) | Mixed-to-adequate recurring operating growth, with margin/tax/weighted-share normalization needed. Cash realization is scored separately. Contributions: NA / 0.900 / NA |
| R | NS / Low | Source-bounded project funding and IPO-WC attribution remain unresolved. Conditional model returns are not a supported ordinary base return. Counterevidence: Explicit operating and funding sensitivities still provide useful diagnostics. [SFL-MONJUN26](https://nsearchives.nseindia.com/corporate/SHIVASHRITFOODS_13082026145123_MAReport30062026.pdf) | NS instead of assigning a return score to an unverified financing path. Contributions: NA / NA / NS |
| D | NS / Low | Linked margin, procurement, delay and liquidity stresses expose material downside. Current financing availability and recovery of supplier/project advances are not fully verified. Counterevidence: Clean audit/no-default evidence and existing operating business may provide recovery value. [SFL-AR26R](https://nsearchives.nseindia.com/annual_reports/SME_AR_32089_SHIVASHRIT_2025_2026_U_7594527_28092026121229.pdf); [SFL-MONJUN26](https://nsearchives.nseindia.com/corporate/SHIVASHRITFOODS_13082026145123_MAReport30062026.pdf) | Loss severity cannot be collapsed into a precise resilience score while essential funding/attribution is unresolved. Contributions: NA / NA / NS |
| P | NS / Low | Price-implied revenue and margin requirements can be calculated conditionally. The required funding and project delivery assumptions are not all source-verified. Counterevidence: A roughly 15× current-share earnings cross-check is not, by itself, an extreme multiple. [NSE-MARKET](https://nsearchives.nseindia.com/content/cm/BhavCopy_NSE_CM_0_0_0_20261019_F_0000.csv.zip); [SFL-MONJUN26](https://nsearchives.nseindia.com/corporate/SHIVASHRITFOODS_13082026145123_MAReport30062026.pdf) | Conditional reverse expectations are not a scored robust price-implied setup. Contributions: NA / NA / NS |
| L | NS / Low | Current lot is 1000 shares and one lot costs ₹114800. 59 of 60 issuer rows are present;September 3 is missing, not zero; complete 20-day data do not replace the prescribed 60-day test. Counterevidence: Observed-only 60-session turnover implies approximately 2.11 days at 5% participation; all 20 latest rows are present. [NSE-MARKET](https://nsearchives.nseindia.com/content/cm/BhavCopy_NSE_CM_0_0_0_20261019_F_0000.csv.zip) | NS because full 60-session execution evidence is incomplete, not because suspension or zero liquidity has been established. Contributions: NA / NA / NS |

GQS means Growth Quality Score; GOV is governance. Exact Decimal arithmetic is retained, with half-up one-decimal display and unrounded classification. IAS includes the unrounded BQS contribution once:0.25× 5.26=1.315. Its 25% coverage and 2.065–8.815 mathematical bound do not create a point score. CASH3 reflects persistent weak operating realization; final GQS capped 5. No governance or funding-failure numeric cap applied. G2 material unresolved use-of-proceeds verification excludes numerical quality rankings and favorable investment classifications. Missing R,D,P,L produce IASNS without renormalization. Conditional financing returns are not used as ordinary base-case returns. A one-point change in GOV or MOAT changes BQS by 0.20;CAP±1 changesBQS by 0.12 and raw GQS by 0.15. REV±1 changesBQS by 0.12 and raw GQS by 0.40. The GQS cap and unresolved gate persist; nearby scores are not statistically precise rankings.

## 4. Business Overview

### Business and value chain

Shivashrit Foods Limited (NSE Emerge SHIVASHRIT, ISIN INE1DLF01018) was incorporated on 23 August 2017 and commenced commercial potato-flake production in 2018. The public-company conversion certificate was issued on 4 October 2024. It processes potatoes in Aligarh, Uttar Pradesh into dehydrated flakes and, on customer request, milled flour. Industrial snack and processed-food manufacturers buy consistency, food safety, rehydration and functional texture rather than a consumer-facing story. Washing, peeling, blanching, cooking, mashing and drum drying convert a bulky perishable crop into shelf-stable ingredients. The plant, associated water/energy supply, cold storage and working-capital funding are all necessary parts of the economics. [SFL-P, printed pp 137–149](https://nsearchives.nseindia.com/emerge/corporates/content/ShivashritFoodsLimited_PROSP.pdf)

The business is overwhelmingly B2B. FY25 domestic B2B revenue was ₹81.3843 crore and exports ₹23.2922 crore; own/third-party website sales together were only ₹0.0169 crore, about 0.016% of total revenue. The December 2024 consumer launch is therefore an option, not an established brand moat or a reason to apply branded-FMCG valuations. FY26 export FOB revenue fell to ₹21.1847 crore, despite total revenue increasing to ₹113.5147 crore: domestic growth, not broad export acceleration, drove the latest year. The September 2026 AGM describes first steps into snacks, but no material separately profitable consumer franchise is demonstrated. [SFL-P p 140](https://nsearchives.nseindia.com/emerge/corporates/content/ShivashritFoodsLimited_PROSP.pdf); [SFL-AR26R note 37](https://nsearchives.nseindia.com/annual_reports/SME_AR_32089_SHIVASHRIT_2025_2026_U_7594527_28092026121229.pdf); [SFL-AGM26 pp 2–3](https://nsearchives.nseindia.com/corporate/SHIVASHRITFOODS_30092026133208_Outcome_of_AGM-f.pdf)

FY25 export sales were concentrated in Israel (43.97% of exports), Belgium (33.41%) and Bangladesh (18.85%). Export destination count and a list of historical markets do not establish diversified current earnings. Current FY26 country-level concentration and exact customer-level pricing contracts are ND. FY25 Uttar Pradesh generated 40.68% of domestic sales, with Gujarat 20.33% and Maharashtra 17.87%; these are shares of domestic, not total revenue. [SFL-P pp 140–141](https://nsearchives.nseindia.com/emerge/corporates/content/ShivashritFoodsLimited_PROSP.pdf)

## 5. Moat and Industry Position

### Concentration, procurement and moat mechanism

FY25 top-five customers represented 79.10% and top-ten 88.39% of revenue. The prospectus explicitly says there were no legally binding/formal customer agreements, while describing repeat relationships and no historical major-customer loss. Both observations matter: repeat orders support commercial competence, but do not create contracted backlog or lock-in. Top-ten concentration increased from 73.33% in FY24. Customer identities, current FY26 concentration and the margin effect of losing the largest customer remain ND. Older FY23 percentage and rupee concentration tables do not exactly reconcile to reported revenue; do not silently adopt their percentages. [SFL-P pp 27–28](https://nsearchives.nseindia.com/emerge/corporates/content/ShivashritFoodsLimited_PROSP.pdf)

The procurement narrative emphasizes farmers, but FY25 source mix was 9.32% farmers,88.60% traders and 2.08% other suppliers. There were 114 associated farmers, not 114 contracted exclusive suppliers. No long-term purchase arrangements were disclosed. Top-five suppliers supplied 38.61% and top-ten 60.41% of FY25 purchases. Historical supplier tables use inconsistent potato-only versus total-purchase denominators; the clearly reconciled FY25 figures are the comparison anchor, not evidence of a perfectly integrated seed-to-shelf system. [SFL-P pp 28–29,149–150](https://nsearchives.nseindia.com/emerge/corporates/content/ShivashritFoodsLimited_PROSP.pdf)

Potential advantages should be interpreted mechanism-by-mechanism:

- Procurement proximity and adjacent storage reduce logistics/spoilage risk. Evidence is the Aligarh location and leased cold storage. Durability is moderate because other UP processors, including Agristo Masa, also access this crop belt. Failure modes are bad processing-potato crops, traders repricing supply and cold-storage losses.
- Process control and customer qualification can create repeat-purchase friction. The prospectus describes automated imported Tummers equipment and food-safety certifications. These are capabilities and entry costs, not patented exclusivity. A funded entrant can buy comparable equipment and seek qualification; exact qualification time and loss rates are ND.
- A consistent low-moisture ingredient can command better economics than raw potatoes, but pass-through/pricing power is not demonstrated. Large concentrated buyers and international alternative suppliers constrain price; input-cost and output-price cycles can move differently.
- Brand/network moat is unproven. Retail revenue was immaterial, patents are not the thesis, trademark applications were pending and copyright applications objected at the prospectus date. These IP application statuses are historical disclosure, not proof of infringement or current rejection. [SFL-P pp 137–159](https://nsearchives.nseindia.com/emerge/corporates/content/ShivashritFoodsLimited_PROSP.pdf)

A narrow-to-moderate processing capability is defensible; an enduring high-moat platform is not established. The proposition is an agricultural-ingredient capacity expansion with capital/working-capital discipline, not a demonstrated asset-light compounder.

#### Primary-source economic peer comparison

Information cutoff: 20 October 2026. Amounts are INR crore. These are economic comparisons, not market-price or P/E comparables. The four rows represent three independent business groups: Agristo NV is the sponsor-related mature benchmark for Agristo Masa. Private-company credit reports do not establish traded-equity valuation.

| Business and reporting scope | Period and revenue | Operating margin | Capital, funding or cash-cycle evidence | What can actually be compared |
|---|---|---|---|---|
| Iscon Balaji Foods, standalone potato processing, frozen fries and snacks | FY26 estimated ₹1,945; FY25 ₹1,488.92 | FY26 estimated 17.5%; FY25 20.6% | Gross current assets 304 days; receivables 80 days; estimated interest cover 4.34 x; 79% exports | Processing-margin cyclicality and working-capital strain at much greater scale, not an assumed comparable ROIC |
| Asandas & Sons / HyFun, consolidated processing group | FY25 narrative ₹1,541; financial table conflicts on period/value | Narrative FY25 13.40%; table also presents 15.26% in its next column | Narrative debt ₹1,370.11, working-capital cycle 181 days and interest cover 2 x; approximately ₹900 crore expansion | Leveraged expansion, procurement integration and liquidity risk; source inconsistency prevents precise ranking |
| Agristo Masa, standalone Indian JV | FY25 audited ₹108.5; PAT −₹39.3 | OPBDIT −15.5% | TOL/TNW 1.8 x; interest cover −1.6 x; sponsor funding ₹139 crore in FY25 | A geographically relevant processing entrant can incur substantial ramp-up losses despite strong sponsors |
| Agristo NV, standalone Belgian sponsor-related benchmark | CY24 audited ₹12,218.9; PAT ₹2,031.6 | OPBDIT 24.3% | TOL/TNW 0.6 x; debt/OPBDIT 0.6 x; interest cover 18 x | Mature international processing can earn attractive margins, but geography, product mix, scale and calendar prevent direct translation |

#### Sources and interpretation

Iscon Balaji’s September 2026 CRISIL report supports the comparison above. Its declining margin and rising receivables show that sales growth need not improve cash conversion. Gross current asset days are not cash-conversion-cycle days. FY26 values remain agency estimates; one sentence repeats FY2026 for both margin observations, whereas the surrounding narrative distinguishes the prior year. The FY25 PAT/printed PAT-margin table also does not exactly reconcile, so no PAT-margin ranking is used. Source: https://www.crisilratings.com/mnt/winshare/Ratings/RatingList/RatingDocs/IsconBalajiFoodsPrivateLimited_September%2003_%202026_RR_405056.html

Asandas is useful because its seed/farmer pipeline and broader product base differ from Shivashrit’s trader-heavy procurement. The March 2026 Infomerics narrative and financial table disagree: the narrative associates ₹1,541 revenue with FY25, while the table labels ₹1,541.64 and ₹1,770.07 as March 2024/2025 respectively. Its EBITDA columns are ₹206.63/₹270.03. Preserve both versions rather than silently choosing one. The downgrade reflects leverage and expansion risk, not a default finding. Source: https://infomericstorage.blob.core.windows.net/uploads/PR_Asandas_and_Sons02_March26_37f431865b.pdf

Agristo Masa and Agristo NV are shown separately, but are not independent peer groups. The Indian JV’s historical flakes operation is closer operationally to Shivashrit; its proposed fries expansion changes future mix. Its BBB+(CE) credit rating benefits from support, whereas the unenhanced rating is BB+. Negative operating earnings make debt/OPBDIT economically non-meaningful rather than cheap. The Belgian benchmark illustrates mature processing economics, not an appropriate Indian SME equity multiple. Source: https://www.icra.in/Rating/ShowRationalReportFilePdf/139371

#### Denominator and comparability safeguards

1. Iscon operating margin and Agristo OPBDIT are agency-defined operating measures, not automatically identical to issuer model EBITDA. Report each definition and avoid basis-point precision across them.
2. GCA days, receivable days and net working-capital days have different denominators and components. They cannot be ranked as if each were CCC. Agriculture requires seasonal monthly funding analysis even when annual working capital falls.
3. Comparable audited CFO and consistent operating invested capital were not established for these peers. CFO conversion and ROIC are therefore ND, not imputed from EBITDA, PAT, cash accrual or sponsor support. No peer ROIC premium is asserted.
4. Standalone and consolidated scopes, FY26 estimates, FY25 audited figures and CY24 audited figures are explicitly separated. No future expansion capacity is treated as delivered production.
5. Shivashrit’s proposed expansion adds process capacity but also fixed assets, start-up cost and procurement finance. The relevant benchmark question is sustainable margin after utilization, interest, tax and recurring capital/working-capital needs, not whether a global potato market is large.

#### Investment implication

The peer evidence supports a viable but capital- and crop-sensitive processing industry. It does not prove a durable high-return moat for Shivashrit. Larger peers demonstrate both achievable margins and substantial financing needs; a credible sponsor does not eliminate ramp-up losses. For Shivashrit, customer concentration, site execution, actual seasonal funding and related-party economics are more decision-useful than importing a private peer’s credit rating or mature overseas margin into a valuation multiple.

The machine-readable evidence is in peer_inputs.json. The source ledger is peer_source_ledger.csv, linked to the broader business_source_register.json. Missing financial denominators remain explicit.


## 6. Revenue Growth and Scale

| FY / basis | Revenue | Annual addition | YoY | Operating EBITDA / margin | Operating EBIT / PAT |
|---|---|---|---|---|---|
| 2023 / Aug 2025 prospectus restated | 45.3510 | ND | NS | 4.8504 / 10.70% | 2.7601 / 1.5156 |
| 2024 / Aug 2025 prospectus restated | 76.2205 | 30.8695 | 68.07% | 18.6334 / 24.45% | 14.4645 / 11.6139 |
| 2025 / Aug 2025 prospectus restated | 104.6934 | 28.4729 | 37.36% | 22.2293 / 21.23% | 17.8481 / 12.0550 |
| 2026 / Revised annual report 28 Sep 2026, financials unchanged from 8 Sep; signed 30 May 2026 | 113.5147 | 8.8213 | 8.43% | 24.0867 / 21.22% | 20.3192 / 14.0500 |

| Window | Start / end | CAGR |
|---|---|---|
| 3 years 2023–2026 | 45.3510 / 113.5147 | 35.78% |
| 5 years 2021–2026 | ND / 113.5147 | NS |
| 10 years 2016–2026 | ND / 113.5147 | NS |

### Physical scaling and growth decomposition

The prospectus engineer-certified table reports production of 4,021 MT/FY22, 4,055 MT/FY23, 6,005 MT/FY24 and 7,019 MT/FY25. Installed annual capacity was 4,320 MT/FY22–23, 6,840 MT weighted in FY24 and 8,640 MT/FY25, based on 300 working days. Utilization was 93.08%, 93.87%, 87.80% and 81.24%. Thus actual production grew materially after the FY24 extension, while utilization of expanded capacity was lower; neither declining utilization nor growth alone tells the whole story. [SFL-P pp 156–157](https://nsearchives.nseindia.com/emerge/corporates/content/ShivashritFoodsLimited_PROSP.pdf)

The planned additional 52.8 MT/day line is additive to existing 28.8 MT/day, implying 81.6 MT/day (rounded to approximately 82 in the document), or 24,480 MT/year at 300 days. The new line alone implies 15,840 MT/year. The November 2025 investor presentation independently states aggregate capacity of 24,480 MT/year (slide 9), corroborating the additive calculation. These are engineering capacities, not orders, actual output or recognized sales. The original prospectus envisaged an adjacent site; the subsequently approved Madrak site is separate, about 10 km away. An analyst must not retain the original adjacent-site efficiency assumptions uncritically. [SFL-P p 152](https://nsearchives.nseindia.com/emerge/corporates/content/ShivashritFoodsLimited_PROSP.pdf); [SFL-PRESENT25 slide 9](https://nsearchives.nseindia.com/corporate/SHIVASHRITFOODS_19112025192456_InvestorPresentationNov2025SFL.pdf); [SFL-EGM26 explanatory statement](https://nsearchives.nseindia.com/corporate/SHIVASHRITFOODS_24022026155654_SFL_-_Final_Notice_of_EGM.pdf)

FY24 production increased 48.1% and FY25 16.9%. Sales increased faster in FY25, but revenue divided by production is only a revenue-per-produced-tonne proxy because production differs from sales volumes and product inventories move. No precise price/volume allocation should be asserted without shipment data. FY26 physical output and average realizations are not separately verified in the currently reviewed filings. Management attributes FY26 growth partly to realizations, so the latest 8.43% revenue increase should not be mechanically treated as volume growth. [SFL-P pp 156–157](https://nsearchives.nseindia.com/emerge/corporates/content/ShivashritFoodsLimited_PROSP.pdf); [SFL-AGM26 p 2](https://nsearchives.nseindia.com/corporate/SHIVASHRITFOODS_30092026133208_Outcome_of_AGM-f.pdf)

Raw potato buying is highly seasonal: 80–90% is procured during December–March. Seasonal stock building is economically explicable, but still consumes cash. Expansion needs potatoes, cold storage, customer credit and supplier advances before the resulting profits arrive. A larger processing line cannot support an unconstrained revenue CAGR without this financing bridge. The financial/model sections must separate the crop-purchase pulse from annual consumption, rather than treating seasonal inventory as costless reserve capacity. [SFL-P pp 105–107,137–150](https://nsearchives.nseindia.com/emerge/corporates/content/ShivashritFoodsLimited_PROSP.pdf)

The preferred five-year CAGR requires a FY21 starting observation, which is not established in the comparable primary financial set. The three-year FY23–26 window is therefore fixed before scoring. It is not replaced by a more flattering selected trough. FY24 benefited from an expanded line and a major processing-margin improvement; FY25 had further production growth, while FY26 revenue growth slowed materially and export revenue declined. There is no verified FY26 shipment/realization bridge, so reported revenue growth is not called pure volume growth. Revenue-per-produced-tonne is only a proxy because production and shipment inventories differ. No value is assigned to an unbuilt capacity announcement merely to increase REV. [SFL-P](https://nsearchives.nseindia.com/emerge/corporates/content/ShivashritFoodsLimited_PROSP.pdf); [SFL-AR26R](https://nsearchives.nseindia.com/annual_reports/SME_AR_32089_SHIVASHRIT_2025_2026_U_7594527_28092026121229.pdf); [SFL-AGM26](https://nsearchives.nseindia.com/corporate/SHIVASHRITFOODS_30092026133208_Outcome_of_AGM-f.pdf)

REV begins at 9 under the ≥30% three-year growth schedule. The complete FY26 slowdown supports a net one-point reduction; final 8 also respects the short-history/Medium-confidence ceiling. This is one disclosed adjustment, not an additional small-base penalty or a projected-growth uplift. H2 is an audited balancing half-year, not a quarter; no missing quarterly CFO or FY27 TTM is invented. [SFL-RESULT26](https://nsearchives.nseindia.com/corporate/SHIVASHRITFOODS_30052026155046_SFLOutcomes30052026.pdf); [SFL-CLARJUL26](https://nsearchives.nseindia.com/corporate/SHIVASHRITFOODS_03072026152613_SFLClarificationjuly26withMAreport.pdf)

| Comparable half | Revenue | PAT | Revenue YoY / interpretation |
|---|---|---|---|
| H1 FY26 | 61.1815 | 7.5134 | 20.46% |
| H2 FY26 | 52.3332 | 6.5366 | -2.91% |
| H1 FY25 | 50.7904 | 6.1798 | Prior comparison |
| H2 FY25 | 53.9030 | 5.8344 | Prior comparison |

H2 values are balancing half-years, not quarters. The November press-release chart contains unrelated figures; use the audited table. No interim cash-flow statement is available. [SFL-RESULT26](https://nsearchives.nseindia.com/corporate/SHIVASHRITFOODS_30052026155046_SFLOutcomes30052026.pdf); [SFL-CLARJUL26](https://nsearchives.nseindia.com/corporate/SHIVASHRITFOODS_03072026152613_SFLClarificationjuly26withMAreport.pdf)

## 7. Growth Quality and Reinvestment Runway

### Industry position and accessible runway

Shelf-stable potato ingredients benefit from convenience-food demand, industrial snacks, product consistency and export access. Food safety, usable potato varieties, drying technology and working capital create nontrivial entry requirements. However, the relevant competitive set includes larger processors and international suppliers, not only similarly sized listed SME food companies. Iscon Balaji, Asandas/Hy Fun and Agristo Masa provide primary-source evidence of both viable scale and the risk of debt-funded ramp-up. Agristo NV is a separate mature international benchmark, not a fourth independent Indian peer or a second unrelated group. See the peer comparison for period and scope limitations.

The issuer's prospectus cites Department of Commerce potato-flake export values of US$58.09 m in FY24 and US$63.27 m in FY25 (HS11052000). This is an export-flow statistic, not the whole Indian market, and the prospectus's broad potato or frozen-potato tables use other HS codes. It cannot justify a market-share percentage for flakes or prove that planned output can be sold. No independently verified current domestic market share has been established. A credible bottom-up runway is utilization of existing equipment, commissioning the additional line, customer onboarding, collections and a reasonable share of relevant industrial demand. [SFL-P pp 134–136](https://nsearchives.nseindia.com/emerge/corporates/content/ShivashritFoodsLimited_PROSP.pdf)

The physical expansion arithmetic is attractive only if customers, crop procurement, storage, energy, permits and cash grow together. Existing 8,640-tonne annual capacity plus the proposed 15,840-tonne line imply 24,480 tonnes at the prospectus's 300 working days. The larger separate site changes logistics from the original adjacent-site plan. No capacity percentage is automatically translated into revenue: volume is constrained by available capacity, ramp, customer uptake and procurement funding in the model. Management's January 2027 target is an assumption to test, not a commissioning certificate. [SFL-P](https://nsearchives.nseindia.com/emerge/corporates/content/ShivashritFoodsLimited_PROSP.pdf); [SFL-EGM26](https://nsearchives.nseindia.com/corporate/SHIVASHRITFOODS_24022026155654_SFL_-_Final_Notice_of_EGM.pdf); [SFL-AGM26](https://nsearchives.nseindia.com/corporate/SHIVASHRITFOODS_30092026133208_Outcome_of_AGM-f.pdf)

Growth quality is not the same as fast historical sales. Raw GQS is 6.35, but persistent weak CASH=3 activates the framework's cap of 5. The historic margin jump, three-year committed-capital return around 14.3% and much weaker recent incremental ratios do not demonstrate that a substantially larger project will earn exceptional returns. The main capital measure includes CWIP and capital advances; excluding those balances is only a lagged illustration, never free growth capital. [SFL-AR26R](https://nsearchives.nseindia.com/annual_reports/SME_AR_32089_SHIVASHRIT_2025_2026_U_7594527_28092026121229.pdf); [SFL-P](https://nsearchives.nseindia.com/emerge/corporates/content/ShivashritFoodsLimited_PROSP.pdf)

| FY | Normalized NOPAT29.12% tax | Financing-side committed IC | Alternative core / broad operating proxy |
|---|---|---|---|
| 2023 | 1.9564 | 31.1732 | 21.8875 / 31.2576 |
| 2024 | 10.2524 | 55.9017 | 41.1460 / 57.5909 |
| 2025 | 12.6507 | 77.8542 | 63.8048 / 79.4486 |
| 2026 | 14.4022 | 118.2393 | 83.0164 / 108.8115 |

| Window | ΔNOPAT / ΔcommittedIC | Incremental ratio |
|---|---|---|
| 2023_2026 | 12.4459 / 87.0661 | 14.29% |
| 2024_2026 | 4.1498 / 62.3376 | 6.66% |
| 2025_2026 | 1.7515 / 40.3851 | 4.34% |

IC = equity + interest-bearing debt − all reported cash − non-current investments (property, mutual funds and gold). It includes CWIP and capital advances through deployed financing. This is not project IRR. Unspent IPO cash is excluded. Operating EBIT excludes all other income; normalized NOPAT uses a stated 29.12% assumption.

Excluding the latest ₹27.7777 crore CWIP and capital advances gives an illustrative lagged ratio of 20.99%, not the main return. Illustrative lagged-capital view only. The numerator cannot perfectly attribute profits to old assets, and new investment is not free. The primary committed-capital calculation must remain. Funding-side IC excludes idle cash, including unspent IPO funds, to avoid rewarding idle proceeds; this is not permission to net restricted cash against debt for liquidity or equity valuation. The three-year denominator includes substantial old-asset margin improvement in the numerator and unmatured new capital at the end. Compare the 14.3% main proxy with a reasoned 13–17% nominal capital-cost range, not an asserted project IRR. Five-year incremental return is ND because the starting observation is unavailable. [SFL-P](https://nsearchives.nseindia.com/emerge/corporates/content/ShivashritFoodsLimited_PROSP.pdf); [SFL-AR26R](https://nsearchives.nseindia.com/annual_reports/SME_AR_32089_SHIVASHRIT_2025_2026_U_7594527_28092026121229.pdf)

## 8. Management, Governance and Execution

### Promoters, ownership and governance counterevidence

Nishant and Prashant Singhal have been associated since incorporation; the prospectus describes roughly 20/22 years in storage/business development and about 7 years in food processing, not two decades of listed manufacturing results. Prashant is the nonexecutive chairman and Nishant the managing director; Sunita Singhal is a nonexecutive director. Three of six directors are designated independent. Family control and related-party infrastructure make minority protections important, but family ownership alone is not misconduct. [SFL-P pp 173–177](https://nsearchives.nseindia.com/emerge/corporates/content/ShivashritFoodsLimited_PROSP.pdf); [SFL-AR26R Board report](https://nsearchives.nseindia.com/annual_reports/SME_AR_32089_SHIVASHRIT_2025_2026_U_7594527_28092026121229.pdf)

The September 30 shareholding filing, submitted 19 October 2026, reports 13,337,000 promoter/group shares out of 18,269,000, approximately 73.00%, and 4,932,000 public shares. It declares no promoter pledge/NDU/other encumbrance and no outstanding convertibles, warrants or ESOPs. These are dated issuer disclosures, not real-time bank confirmations. The IPO sold 616,000 existing shares for ₹8.7472 crore to selling shareholders and issued 4,316,000 new shares for ₹61.2872 crore gross to the company. OFS proceeds are not company funding. The prospectus anticipated 73.01% using its disclosed rounded ratios; actual shares give about 73.003%. [SFL-SHP26](https://nsearchives.nseindia.com/corporate/xbrl/SHP_1741163_19102026113011_WEB.xml); [SFL-P cover,pp 21–22](https://nsearchives.nseindia.com/emerge/corporates/content/ShivashritFoodsLimited_PROSP.pdf)

The March 20 project-location resolution involved promoter landlords. The results identify promoter interest and invalidate 13,037,000 promoter votes; valid votes were 300,000 other promoter-group votes plus 73,000 public votes (71,000 in favour/2,000 against), giving 371,000/373,000 favour. The disclosed invalidation is meaningful minority-process counterevidence; do not falsely claim all 13.337 m promoter shares forced through the resolution. It is also not an independent appraisal of rental fairness or project economics. [SFL-EGMRESULT PDFp 6](https://nsearchives.nseindia.com/corporate/SHIVASHRITFOODS_21032026174805_FinaloutcomeofEGMSFL.pdf)

RGAR & Associates were appointed at the 2024 AGM for five years through 2029. The statutory opinion/IFC/CARO must be read with their specific observations rather than inferred from the Board's assertion of no qualification. The revised annual report dated 28 September adds maternity-related disclosure and MD/CFO certification and expressly says financial statements are unchanged. It is not a financial restatement resolving all other disclosure issues. The secretarial audit generally reports compliance but explicitly says systems/processes have scope for improvement and excludes finance/tax assurance. [SFL-AR26R cover,Board report,secretarial report](https://nsearchives.nseindia.com/annual_reports/SME_AR_32089_SHIVASHRIT_2025_2026_U_7594527_28092026121229.pdf)

### Related parties, capital stewardship and unresolved presentation issues

Nishant Cold Storage is integral infrastructure linked to promoters. FY26 rent was ₹2.8750 crore versus ₹2.0564 crore FY25 (about 39.8% higher); the AOC2 lists security ₹2.2121 crore. FY26 rent is about 20.5% of ₹14.0500 crore PAT; it is an operating expense already deducted, not an additional profit haircut. Megha Enterprises expenses rose to ₹0.8015 crore from ₹0.4249 crore. MD pay ₹0.60 crore is about 4.27% of PAT. These comparisons flag scope/materiality without asserting above-market pricing. Historical cold-storage advances and repayments are separately disclosed; cashflows should not be confused with net year-end exposure. [SFL-P pp 222–223](https://nsearchives.nseindia.com/emerge/corporates/content/ShivashritFoodsLimited_PROSP.pdf); [SFL-AR26R notes 36/AOC2](https://nsearchives.nseindia.com/annual_reports/SME_AR_32089_SHIVASHRIT_2025_2026_U_7594527_28092026121229.pdf)

The annual report has an unresolved AOC2 presentation conflict: the opening says no non-arm's-length contracts, while the next heading labels the cold-storage rental as NOT at arm’s length. The Board report makes an exception for AOC2, while the financial note says ordinary-course transactions on mutually agreed terms. Do not dismiss it automatically as a typo or claim proven abusive pricing. Seek a corrected AOC2 and commercial rental benchmarking. [SFL-AR26R PDFpp 44,88](https://nsearchives.nseindia.com/annual_reports/SME_AR_32089_SHIVASHRIT_2025_2026_U_7594527_28092026121229.pdf)

Remuneration disclosures likewise need caution. MD pay is consistently ₹60 lakhs in the financial notes, but the annexure shows ₹12 lakhs prior-year and 116% growth rather than the mathematical 400% increase between those stated amounts. A footnote says prior-year remuneration covered only part of the year, so the amounts are not a like-for-like annual pay-growth comparison; it still does not reconcile the displayed percentage. The CFO row shows ₹159.15 lakhs, conflicting with the later assertion that no employee received ₹102 lakhs or more and the visible salary disclosure structure. This cannot be presented as verified ₹1.59 crore CFO compensation. Employee tables describe Priyansh/Shivansh as unrelated, whereas note 36 lists them among KMP relatives; the nature of relationships needs clarification. Preserve the inconsistencies without inventing personal enrichment. [SFL-AR26R PDFpp 45–47,87–88](https://nsearchives.nseindia.com/annual_reports/SME_AR_32089_SHIVASHRIT_2025_2026_U_7594527_28092026121229.pdf)

Residential-property advances ₹2.81 crore, a ₹3.34 crore vehicle financing arrangement, gold and financial investments merit capital-allocation scrutiny while the operating expansion and seasonal funding need cash. The accounts do not establish personal use, diversion or illegality. Property advances are not operating working capital or immediately available cash. Compare their purpose/returns with deploying scarce resources in core processing. [SFL-AR26R notes 6,11–12](https://nsearchives.nseindia.com/annual_reports/SME_AR_32089_SHIVASHRIT_2025_2026_U_7594527_28092026121229.pdf)

New Madrak land totals 6,300 sqm with promoter landlords, lease 29 years 11 months and total ₹36,000 annual rent. This differs from the substantial cold-storage service rental above; do not combine the two or mistake ₹36,000 annual rent for ₹36,000 monthly. Low land rent can benefit the issuer, while dependency on promoter-owned premises and termination/renewal terms still warrant review. [SFL-EGM26 explanatory statement](https://nsearchives.nseindia.com/corporate/SHIVASHRITFOODS_24022026155654_SFL_-_Final_Notice_of_EGM.pdf)

The June 2026 CARE monitoring report adds a material, specific qualification to the issuer’s no-deviation headline. Against certified cumulative expansion-related working-capital spending of ₹17.06 crore (₹13.91 crore in FY26), CARE could not independently ascertain whether the spending actually related to the expansion: the plant was not yet operating and reported inventory had declined. Management rebutted that lower potato prices and advance payments to suppliers explained lower physical stocks, and that those advances secured raw materials for expansion. This is an unresolved attribution and documentation issue, not a finding of proven diversion. CARE also recorded pending government approvals and the absence of approval for the timeline extension; management attributed delay to imported-equipment disruption. The June report expected November 2026 commissioning, later shifted to January 2027 in the September AGM. Model IPO cash by permitted object and actual accessibility, not as unrestricted cash. Count this once as a governance/execution uncertainty, not repeatedly as a separate proven loss. [SFL-MA-JUN26, section 3 and utilization schedule](https://nsearchives.nseindia.com/corporate/SHIVASHRITFOODS_13082026145123_MAReport30062026.pdf); [SFL-AGM26](https://nsearchives.nseindia.com/corporate/SHIVASHRITFOODS_30092026133208_Outcome_of_AGM-f.pdf)

### Tax, regulatory and litigation balance

The prospectus disclosed old income-tax proceedings, including challenged Section 80 IB deduction and demands, while reporting no then-current criminal/civil/regulatory proceedings against issuer/promoters. The FY26 note 41 subsequently says a ₹91.83 lakh tax claim was resolved, with ₹22.28 lakh refund including ₹19.25 lakh previously paid. That positive resolution must supersede a stale narrative treating the earlier demand as outstanding. An exact mapping of each older prospectus line to the final order is not fully shown; do not sum old demands and a resolved new amount into an invented liability. [SFL-P pp 250–253](https://nsearchives.nseindia.com/emerge/corporates/content/ShivashritFoodsLimited_PROSP.pdf); [SFL-AR26R note 41](https://nsearchives.nseindia.com/annual_reports/SME_AR_32089_SHIVASHRIT_2025_2026_U_7594527_28092026121229.pdf)

Customs-related bank guarantees and their deposits have their own status in current notes; ceased/matured facilities are not recurring contingent claims. The residual guarantee/disputed vehicle prepayment figures in the financial analysis must remain distinct from the old tax issue. No reviewed evidence supports a fraud/diversion allegation. Conversely a clean main audit opinion does not certify related-party pricing or resolve internally inconsistent tables. [SFL-AR26R notes 40–44](https://nsearchives.nseindia.com/annual_reports/SME_AR_32089_SHIVASHRIT_2025_2026_U_7594527_28092026121229.pdf)

### Promises versus delivery

| Dated source | Original target or action | Evidence by 20 October 2026 | Interpretation |
|---|---|---|---|
| FY24 historical expansion, documented final prospectus 28 August 2025 | Increase old line from 14.4 to 28.8 MT/day | FY25 installed 8,640 MT/year and production 7,019 MT | Actual earlier scale-up is positive execution evidence, not proof next project is low risk |
| Final prospectus 28 August 2025, printed p 105 | Machinery receipt January 2026; installation January–April; trial May; commercial operation 1 June 2026 | September 30 AGM now expects machinery October 2026 and operation January 2027 | Approximately 7-month commercial delay against original schedule; management attributes imported-equipment/geopolitical disruption |
| EGM notice 24 February 2026 | Shift expansion from 3,651 sqm adjacent land to 6,300 sqm Madrak; same stated purpose/cost/capacity | Shareholder approval 20 March, results filed 21 March | Approved implementation change, not automatically diversion; separate-site operational effects and permits still matter |
| EGM notice, February 2026 | Building-plan application pending, other identified permissions obtained | No fully verified subsequent operating/commissioning certificate in reviewed set | A later statement that all approvals were obtained in the same notice conflicts with the listed pending building application; monitor actual documents |
| December 2024 consumer entry | Develop B2C channel | FY25 online sales ₹1.69 lakhs; FY26 snacks described as small beginning | No established retail scale or margin demonstrated |
| September 30 AGM 2026 | January 2027 start; broaden agricultural-commodity trading objects | The AGM proposed the scope expansion; subsequent result requires separate verification | Forward optionality may dilute focus; it is not recognized revenue or proof of a new moat |

The AGM's description of January 2027 as consistent with the prospectus objects does not make it consistent with the original June 2026 date. Preserve management's explanation and the original schedule together. [SFL-P p 105](https://nsearchives.nseindia.com/emerge/corporates/content/ShivashritFoodsLimited_PROSP.pdf); [SFL-EGM26](https://nsearchives.nseindia.com/corporate/SHIVASHRITFOODS_24022026155654_SFL_-_Final_Notice_of_EGM.pdf); [SFL-EGMRESULT](https://nsearchives.nseindia.com/corporate/SHIVASHRITFOODS_21032026174805_FinaloutcomeofEGMSFL.pdf); [SFL-AGM26](https://nsearchives.nseindia.com/corporate/SHIVASHRITFOODS_30092026133208_Outcome_of_AGM-f.pdf)

## 9. Financial Forensics

| FY | Value-added proxy | EBITDA / EBIT | PAT / normalized PAT | Current-share EPS proxy | CFO / cash capex / FCF |
|---|---|---|---|---|---|
| 2023 | 10.4503 | 4.8504 / 2.7601 | 1.5156 / 0.9332 | 0.8296 | -0.2703 / 0.8190 / -1.0893 |
| 2024 | 26.3614 | 18.6334 / 14.4645 | 11.6139 / 8.5666 | 6.3572 | 5.4445 / 14.6589 / -9.2144 |
| 2025 | 29.4911 | 22.2293 / 17.8481 | 12.0550 / 9.9474 | 6.5986 | -8.3409 / 1.7232 / -10.0641 |
| 2026 | 32.9038 | 24.0867 / 20.3192 | 14.0500 / 11.2035 | 7.6906 | -0.0756 / 23.7093 / -23.7849 |

Current-share historical EPS proxies are not reported historical EPS or actual past investor ownership. Normalized PAT excludes other income and assumes 29.12% tax; operating EBITDA excludes other income, unlike management total-income EBITDA. Value-added proxy is sales less material/purchase/stock-change charges, not an audited gross-profit label. [SFL-P](https://nsearchives.nseindia.com/emerge/corporates/content/ShivashritFoodsLimited_PROSP.pdf); [SFL-AR26R](https://nsearchives.nseindia.com/annual_reports/SME_AR_32089_SHIVASHRIT_2025_2026_U_7594527_28092026121229.pdf)

| FY | Debt / equity | Inventory / receivables / payables | Supplier/ST advances | Average receivable / inventory / payable days | Reported ROE |
|---|---|---|---|---|---|
| 2023 | 22.67 / 10.93 | 24.32 / 2.69 / 12.88 | 7.83 | ND / ND / ND | NS |
| 2024 | 36.97 / 22.54 | 34.27 / 5.54 / 16.62 | 13.97 | 19.70 / 214.47 / 107.97 | 69.40% |
| 2025 | 47.96 / 34.60 | 57.92 / 12.45 / 21.86 | 12.52 | 31.36 / 223.73 / 93.36 | 42.20% |
| 2026 | 47.52 / 102.64 | 33.03 / 19.17 / 4.42 | 25.15 | 50.84 / 205.90 / 59.48 | 20.48% |

Average balances; total sales substitutes for credit sales, manufacturing cost is only a cost-compatible inventory/payable proxy, not actual credit purchases. Broad ONWC includes mixed advances pending disclosed decomposition.

#### Shivashrit Foods: primary financial review

All amounts are INR crore unless explicitly identified as lakh. Information cutoff: 20 October 2026. This is a standalone business; the statutory auditor reports no subsidiaries, associates or joint ventures. The September 28 revised annual report says the financial statements are unchanged; it adds maternity-benefit disclosure and CEO/CFO certification. The original scanned financial pages were inspected and agree with the searchable revised statements. Primary URLs, file hashes and page references are in financial_inputs.json.

#### Source hierarchy and accounting comparability

Use the final August 28, 2025 prospectus, not the draft, for FY23–25 restated history. Use the signed May 30, 2026 annual statements, reproduced in the September 28 annual report, for FY26 and separately retain its original FY25 comparator. These are Indian GAAP Accounting Standards, not an assumed Ind AS consolidated series.

The prospectus's FY25 restated PAT is 12.0550 versus the later annual's original comparator 12.0142. Restated PBT 15.1866 versus original 15.0713 differs by 0.1153, principally employee-benefit provisions and prepaid-insurance treatment: employee expense 2.0114 versus 2.1789 and other expenses 5.2504 versus 5.1982. The FY24 restated PAT 11.6139 versus original 10.6055 is mainly a 1.0558 deferred-tax adjustment, offset by other employee/tax/insurance adjustments. FY23 restated PAT 1.5156 versus original 1.5863 is also retained. These are disclosed restatements, not evidence of falsification. The restatement report explains re-audit/reclassification and gives an unmodified opinion.

The published FY25 restated cash-flow split is CFO −8.3409/CFI +1.7539/CFF +7.1771. The annual FY25 comparator is CFO −5.5128/CFI −1.0742/CFF +7.1771. CFO and CFI differ symmetrically by 2.8281; both yield cash growth 0.59 and closing cash 0.9875. A 2.9267 capital-advance release moves between investing and operating and explains most of that difference; the balance is associated with other non-current assets and presentation changes. Do not splice these into an apparently identical accounting series or call the 2.8281 missing cash. The alternate economic classification below is shown separately.

#### Operating results and cash realization

FY23/FY24/FY25 restated/FY26 sales are 45.3510/76.2205/104.6934/113.5147. Operating EBITDA excluding all other income is 4.8504/18.6334/22.2293/24.0867; operating EBIT 2.7601/14.4645/17.8481/20.3192. The FY26 management EBITDA 26.0482 includes 1.9615 other income. That is a definition difference, not an arithmetic contradiction.

Direct-cost value-added proxy (sales minus materials, stock purchases and finished-goods inventory change) is 10.4503/26.3614/29.4911/32.9038. Materials cost includes production expenses, including storage, power, freight and packing, so this proxy is not a standardized gross-profit margin. The FY24 margin leap is important: profit growth benefited from better economics on the earlier capacity and cannot all be credited to subsequent new capital. FY26 revenue growth slows to 8.43%, while operating EBIT growth is 13.85% versus the restated FY25 base. Declining depreciation and increased other income also support reported profit growth.

FY26 PAT 14.05 includes 0.2895 deferred-tax benefit. Other income consists of forex 0.4531, duty drawback 0.0311, RoDTEP 0.7336, bank interest 0.6630, mutual-fund gain 0.0003, income-tax refund interest 0.0303 and storage rent 0.0501. Export-linked incentives and some forex are economically related to operations; excluding all other income is a deliberately narrow operating measure, not a claim that every item is exceptional. Interest on IPO deposits should not be valued as durable operating earnings after deployment.

FY26 source CFO −0.0756 is not explained merely by buying fixed assets. Its working-capital bridge includes inventory release 24.8916, receivable absorption 6.7244, supplier-advance absorption 14.8377, supplier payments 17.4369 and other non-current asset absorption 6.0094. Supplier advances must be considered together with inventory, not treated as disappearances. Raw-material inventory is 29.0167 and raw-material supplier advances 25.0743 at March 2026, compared with 53.4829 and 10.2365 a year earlier.

However,6.7775 of the other-non-current-asset outflow is capital-goods advances, while 0.7680 is a release of SBI deposits. Moving both out of operating cash gives an analytical FY26 CFO 5.9339 and CFI −28.5466, with total cash unchanged. Economic cash capex becomes 30.4868 (reported PPE/CWIP cash 23.7093 plus capital advances 6.7775). The adjusted CFO is only 42.2% of PAT. For FY25, removing the 2.9267 capital-advance release and moving the 0.0332 other-NCA cash outflow to investing gives an alternate CFO −8.4063/CFI +1.8193; that remains 0.0654 away from the prospectus's different restatement presentation. Preserve the difference rather than silently manufacture an identical series.

On the FY24/FY25-restated/FY26 source series, cumulative CFO is −2.9720 against PAT 37.7189. The preferred comparable ratio replaces only FY26 with the economic reclassification: (5.4445 − 8.3409 + 5.9339) / 37.7189 = 0.08053, or 8.05% of cumulative PAT. FY25 restated CFO already includes its source capital-advance reclassification and is not adjusted again. A separately labelled alternative replaces FY25 with its original-vintage economic CFO −8.4063 and its original PAT 12.0142: cumulative CFO 2.9721 / cumulative PAT 37.6781 = 0.07888, or 7.89%. The 0.0654 CFO classification residual between these variants remains explicit; they are not presented as perfectly identical vintages. The corresponding economic CFI is −28.5466 for FY26 and +1.8193 for the alternate FY25, so each CFO reclassification has an equal and opposite CFI adjustment and no change in net cash. Adding all disclosed non-interest other income as a further favorable sensitivity would improve conversion, but does not approach strong multi-year cash realization. Thus a low CASH assessment remains supportable after, not because of, proper capex reclassification. Classification uncertainty is not a reason to call source CFO a pure collection metric.

Source cash-tax presentation also requires care: the cash-flow statement's direct-tax line is 0.3968, but advance-tax/TDS movements are embedded in working-capital presentation. Do not treat 0.3968 as the complete economic tax burden or project that rate. The model should calculate taxes explicitly rather than reuse a single CFS tax caption.

#### Working capital, ageing and funding

March 2026 receivables 19.1746 versus 12.4502 increased about 54.0% against 8.43% sales growth. The annual ageing table lists 18.2090 less than six months,0.1719 six to twelve months,0.7624 one to two years and 0.0314 two to three years. All are classified undisputed and good by management. Receivables older than one year have risen from 0.0314 to 0.7938. The minor 0.0001 sum-rounding difference is not a material unreconciled balance. The prospectus FY25 ageing total 12.4655 differs from its balance sheet 12.4502; the current annual comparative corrects the youngest bucket and reconciles 12.4502.

Trade creditors fell from 21.8558 to 4.4189. March 2026 payable ageing is 4.0418 less than one year,0.0852 one to two years,0.0090 two to three years and 0.2829 over three years. This large creditor repayment partly explains cash consumption and is not intrinsically negative stewardship. Note 44 says trade balances, advances and liabilities remain subject to confirmations/reconciliations, while management expects no material adjustment. The clean audit and bank-stock-return reconciliation are contrary evidence to an unsupported allegation of unreliable accounts.

March cash 27.4089 comprises cash in hand 0.5205, HDFC current account 22.3884 and HDFC short-term deposits 4.50. Of this,23.6521 is explicitly unspent IPO money, leaving a mathematical non-IPO residual 3.7568, not independently confirmed unrestricted October liquidity. A separate 0.1083 SBI deposit is outside cash equivalents. Non-current investments 4.5083 include mutual funds 1.2757, property advances 2.81 and gold 0.4226; they are not all cash available for the factory.

Other non-current assets 10.4008 comprise warehouse security 2.2121, capital-goods advances 8.0275, electricity deposit 0.0529 and SBI deposit 0.1083. Short-term advances 25.1453 comprise raw-material suppliers 25.0743 and a related-party advance 0.0711. Other current assets 1.9587 include GST credit 1.6426, tax refund 0.2228, prepaid expenses 0.0755 and duty drawback 0.0178. These distinctions prevent capital advances being counted both in working capital and remaining project capex, or GST credits being treated as immediate cash.

Total interest-bearing debt 47.5211 comprises term debt 29.2228 including current maturities 3.6534, plus cash credit 8.5691 and packing credit 9.7292. Term debt includes HDFC 25.7194, HDFC vehicle 2.8931 and unsecured ICICI business 0.6103. Current HDFC term and working-capital rates are 8.75%, floating; term tenures 48–96 months. Cash/packing credit is on demand and annually renewable. Vehicle finance originally 3.34 carries 8.70% and 84 monthly instalments. The exact old/new project-loan allocation and presently undrawn drawing power are not supplied.

A conditional project-headroom bound against the 35 sanction is 9.2806 if all current HDFC term debt is treated as project debt, up to 20.5953 if the prior 11.3147 old HDFC balance remains outstanding and no additional old-line draws occurred. These assumptions are not bank confirmation. Do not add sub-limits to sanctioned principal, treat original sanction as fresh cash, or infer covenant compliance/refinancing failure from missing granular repayment schedules. The auditor reports no default or willful-defaulter status and no short-term financing of long-term uses.

Other current liabilities 1.3089 include 0.3962 credit-card dues and 0.0948 accrued interest; separate these finance-like claims from trade working capital in models. Net current tax liability is 1.3031. Employee obligations are 0.3182 long-term plus 0.0321 current. These are not silently zero at terminal value.

#### IPO, execution and restricted funds

Fresh proceeds 61.2872 came from 4,316,000 shares at 142; the 616,000-share OFS 8.7472 belongs to selling holders, not company funding. The final prospectus allocates company issue cost 6.8021, capex 26.30, expansion working capital 19.00 and GCP 9.1851. The securities-premium note charges total IPO expenses 7.2964,0.4943 above the issue-use table's 6.8021; this is a funding/expense reconciliation question, not proof that the total restricted pool is missing. Use the actual equity/cash movement when testing funds, retain the difference, and do not presume all expenses were funded from the issue account.

Total expansion cost is 61.30, not the 26.30 IPO contribution. The financing plan is IPO 26.30, HDFC 34.00 and a conditional subsidy 1.00. Individual project estimates exclude GST/applicable taxes; the 39.3633 imported-machinery estimate assumes EPCG duty benefit and EUR 4,187,580 at 94 INR/EUR. Model duty, FX, GST timing, cost overruns and subsidy conditions. No 61.30 all-in cash certainty is established.

March CWIP 19.7502 comprises potato-flake line 18.4980, Comitrol processor 0.9203 and Madrak building 0.3319. Adding separately disclosed capital advances 8.0275 yields 27.7777 already committed, a useful project proxy but not a certified cost-to-complete reconciliation. PPE cash additions 3.9591 less depreciation 3.7675 reconcile the 0.1917 net PPE increase, within rounding. Adding CWIP 19.7502 plus capital-advance growth 6.7775 gives 30.4868 cash capex. Most commissioned PPE additions were vehicles 3.2412, rather than proof that the new potato line was commissioned.

Original final-prospectus commercial operation date was 1 June 2026, following April installation and May trials. March 20 shareholders approved moving the project to a larger Madrak site. June monitoring described a November 2026 expected start; September 30 AGM moved this to January 2027 and explained imported-equipment delays. Objects may be unchanged, but the original schedule was missed. Neither a sanctioned loan, shareholder land approval nor paid CWIP proves operating output.

March unspent IPO 23.6521 splits capex 18.1512, expansion WC 5.0945 and GCP 0.4064. June CARE monitoring reports capex utilized 9.81/remain 16.49; WC utilized 17.06/remain 1.94; GCP utilized 8.82/remain 0.36; total unspent 18.80. Rounded components total 18.79, so a 0.01 reconciliation reserve is appropriate rather than manufacturing funds.

The June pool includes fifteen-and-a-half crore of deposits with contractual maturities in March–December 2027, not automatic on-demand liquidity. The exact nine maturity amounts are in financial_inputs.json, without bank account identifiers. Premature-redemption ability and penalty must be explicit assumptions. March free cash cannot simply be carried forward while separately adding June IPO money; a current gross-cash bridge is needed.

#### Monitoring qualification and fair counterevidence

CARE's August 12 report for June 30 has a headline of no deviation from the objects and recognizes March 20 shareholder approval of the site change. Nevertheless, it expressly cannot independently determine whether 17.06 of expansion working-capital spending was actually for that project: March inventory fell in value and quantity while commissioning slipped. Management explains that supplier advances secured potato purchases before physical stocking and that inventory alone omits this use. The annual balance sheet corroborates increased supplier advances, but does not independently allocate each supplier advance to the new unit. This is an unresolved material verification question, not a finding of diversion or fraud.

CARE also states that delay-extension approval had not been received at June 30, and notes possible financing effects. The July 2 exchange clarification supplied legible results and argued that CARE appointment made separate auditor certificates unnecessary; it is not a subsequent resolution of the June verification qualification. The monitor itself provides limited reliance-based assurance, not an audit. Preserve both its favorable no-deviation statement and its limitations.

#### Capital efficiency and normalized returns

Use normalized NOPAT at 29.12% for comparability; this is an analyst steady-state assumption based on the source statutory rate, not a prediction of a future election. FY26 actual current tax 4.0073/PBT 17.7678 is 22.55%, and net tax 3.7178/PBT is 20.92%. The 80 IB deduction is 5.3227. The prospectus describes 100% relief in the first five years and 30% in the next five; exact fiscal expiry was not verified, so do not assert a precise expiry year.

A financing-side invested-capital proxy, equity plus debt less reported cash and identified non-operating investments, gives FY23/FY24/FY25-restated/FY26 IC 31.1732/55.9017/77.8542/118.2393. It includes deployed working capital, CWIP and capital advances through the financing identity, while excluding unused IPO cash. Three-year normalized NOPAT rises 1.95636 to 14.40225, a 12.44589 increase against 87.06610 additional capital:14.2948% observed incremental return. Two-year return is 6.6570%; one-year 4.3370% on restated FY25. Using the original FY25 comparator instead changes the latest-year ratio modestly, not the conclusion.

The three-year ratio lies around, not decisively above, a reasonable 13–17% cost-of-capital judgment range. Removing 27.7777 of the latest uncommissioned CWIP/capital advances from the endpoint gives a 20.9921% lagged/commissioned illustration. This favorable countercheck is not the primary measure: capital already committed is real, and observed profit cannot be perfectly assigned to old versus new assets. Much of the numerator comes from the FY24 margin jump; the new expansion has not yet earned a demonstrated project return. CAP 5 is a reasonable mixed-economics interpretation; CAP NS is not forced solely by IPO timing, and CAP 7+ is not justified solely by the old operating ROCE.

#### Governance, resolved issues and disclosure limits

The auditor gives an unmodified main opinion and adequate/effective IFC opinion, reports no 10% inventory discrepancy, says bank current-asset statements agree with books, and reports compliant related-party approvals and no financing default. These findings do not independently verify economic fairness or future cash resilience, but must accompany concerns.

The old income-tax dispute 0.9183 is resolved in the company's favor; tax refund 0.2228 includes 0.1925 previously paid and 0.0303 interest. The old Customs guarantee 0.525 ceased and its deposit matured. Current guarantees 0.07 and disputed vehicle-prepayment charge 0.0136 total 0.0836. The fee was already bank-debited, so an adverse outcome must not subtract it a second time. The archived prospectus litigation narrative is historical, not a live unresolved claim.

Related storage rent 2.875 versus 2.0564, warehouse security 2.2121, Megha Enterprises expenses 0.8015 and residential-property advances 2.68 warrant allocation scrutiny. Property advances 2.81 include 2.63 toward Godrej Tropical Isle residential apartments,0.05 Kalpataru residential flat and 0.13 land. Gold 0.4226 and new vehicles 3.2412 are not productive-line capacity. Do not claim personal use without evidence.

The signed note confirms managing-director remuneration 0.60 versus 0.12 individually, while total director remuneration rises 0.36 to 0.60. The table includes a partial-year footnote, so the visible 0.12-to-0.60 change is not a like-for-like full-year remuneration comparison. Although the arithmetic change is 400%, it must not be characterized as comparable annual pay growth. The printed 116% does not reconcile to the visible amounts and needs clarification. Its CFO 159.15-lakh figure is inconsistent with the employee disclosure and should not be asserted as verified actual CFO compensation. The AOC-2 arm's-length headings conflict with each other and the directors' narrative; this is a clarification point, not established abusive pricing. The independent governance review should retain the approved related-party terms and auditor compliance statement.

#### Required remaining evidence for a confident investment verdict

A current projectwise funding and commissioning bridge; bank-confirmed remaining term draw availability and deposit redemption conditions; supplier-level allocation of the 17.06 expansion WC; actual capex taxes/FX and funding; correction of remuneration/AOC headings; and confirmation of current advance/receivable recoverability. These are specific evidence needs, not generic SME suspicion. No public publication or financial transaction is authorized by this file.


| View / period | CFO | CFI | Meaning |
|---|---|---|---|
| FY26 source | -0.0756 | -22.5371 | Original classifications |
| FY26 economic reclass | 5.9339 | -28.5466 | Move capital-advance outflow and pledged FD release symmetrically; unchanged total cash |
| FY25 current comparative | -5.5128 | -1.0742 | Original comparative retained |
| FY25 prospectus restated | -8.3409 | 1.7539 | Already differently regrouped; do not reclass twice |
| FY25 alternative economic view | -8.4063 | 1.8193 | Separate residual disclosed |

Reported FY24–26 CFO sum ₹-2.9720 crore divided by PAT sum ₹37.7189 crore=-0.0788×. Cash capex sum ₹40.0914 crore gives reported FCF proxy ₹-43.0634 crore. Replacing only FY26 with the economic operating view produces(5.4445−8.3409+5.9339)/37.7189=approximately 0.0805×. The alternate FY25 economic regrouping gives about 0.0789× using its matched PAT; the ₹0.0654 crore classification residual is retained. Neither adjustment creates strong multi-year cash realization. No arithmetic average of yearlyCFO/PAT is used. [SFL-P](https://nsearchives.nseindia.com/emerge/corporates/content/ShivashritFoodsLimited_PROSP.pdf); [SFL-AR26R](https://nsearchives.nseindia.com/annual_reports/SME_AR_32089_SHIVASHRIT_2025_2026_U_7594527_28092026121229.pdf)

| FY transition | Δoperating EBITDA | Sales effect at average margin | Margin effect on average sales |
|---|---|---|---|
| 2024 | 13.7830 | 5.4241 | 8.3589 |
| 2025 | 3.5959 | 6.5031 | -2.9072 |
| 2026 | 1.8574 | 1.8724 | -0.0150 |

The symmetric decomposition exactly sums to EBITDA change; it is an accounting attribution, not proof of causality. Operating EBIT/EBITDA exclude all reported other income. That is deliberately transparent, not a claim that every export incentive or currency gain is non-operating: a sensitivity can include recurring export-related items with matched receipt and cost assumptions. Deposit interest, tax-refund interest and mutual-fund gains should not be capitalized as processing margins. The source tax calculation uses 29.12% before Section 80 IB relief; a steady-state 29.12% no-relief model is an analyst normalization, not a verified election or a claimed hard expiry date. Tax relief timing remains a sensitivity. No dividends were assumed and then counted again as retained cash. [SFL-AR26R](https://nsearchives.nseindia.com/annual_reports/SME_AR_32089_SHIVASHRIT_2025_2026_U_7594527_28092026121229.pdf)

Current issued shares, historical weighted-average shares and pre-IPO adjusted shares have different purposes. ₹14.05 crore FY26 PAT divided by 18,269,000 current shares gives about ₹7.69 per share; the reported weighted EPS of approximately ₹8.51 is not a contradiction. Fresh IPO shares raised company cash; the 616,000-share OFS did not. September shareholding declares no outstanding warrants, convertibles or ESOPs. Model recapitalization, if any, is an explicit analyst scenario with whole shares and cash proceeds, not an asserted corporate plan. [SFL-P](https://nsearchives.nseindia.com/emerge/corporates/content/ShivashritFoodsLimited_PROSP.pdf); [SFL-AR26R](https://nsearchives.nseindia.com/annual_reports/SME_AR_32089_SHIVASHRIT_2025_2026_U_7594527_28092026121229.pdf); [SFL-SHP26](https://nsearchives.nseindia.com/corporate/xbrl/SHP_1741163_19102026113011_WEB.xml)

| Window | Observed / missing / observedzero | Mean / median turnover ₹ | Observed-only exit days 2% /5% /10% |
|---|---|---|---|
| 20 | 20 / 0 / 0 | 6,086,735.00 / 5,898,425.00 | 4.24 / 1.70 / 0.85 |
| 60 | 59 / 1 / 0 | 6,365,536.44 / 4,745,450.00 | 5.27 / 2.11 / 1.05 |

The 59 observed rows are not a complete 60-session liquidity sample. Missing 3 September is unknown, not zero. L remainsNS; the observed-only 2.11 days does not prove executable capacity. Current 4-lot reference ₹459,200 is rounded below ₹5 lakh; actual spread, circuit queue and market impact remain unverified. Official quote-page HTML was retrieved but did not contain dynamic order-book data, so search-rendered order book snapshots are not claimed as verified. [NSE-MARKET](https://nsearchives.nseindia.com/content/cm/BhavCopy_NSE_CM_0_0_0_20261019_F_0000.csv.zip)

## 10. Valuation and Market Expectations

| Cross-check | Value | Qualification |
|---|---|---|
| Current-share reported P/E | 14.93× | FY26 PAT/current issued shares, notweighted EPS |
| Price/book | 2.04× | Book includes project, advances and noncash assets; not liquidation value |
| Debt without restricted cash netting | ₹47.52 crore | Card/senior claims and term allocation separately reviewed |
| Conditional March available cash residual | ₹3.76 crore | Reported cash less IPO objects; not verified October free cash |
| EV/operating EBITDA using that residual | 10.52× | Conditional cross-check; no double addition of project cash or ongoing asset value |
| Normalized current-share earnings | 6.13 | Excludes other income and uses 29.12% tax assumption |

A saleable nonoperating asset recovery is not assumed merely because it has a book value. The main model does not value residential advances/gold as immediately liquid operating cash. A conditional multiple or return is not an intrinsic-value observation. [SFL-AR26R](https://nsearchives.nseindia.com/annual_reports/SME_AR_32089_SHIVASHRIT_2025_2026_U_7594527_28092026121229.pdf); [NSE-MARKET](https://nsearchives.nseindia.com/content/cm/BhavCopy_NSE_CM_0_0_0_20261019_F_0000.csv.zip)

#### Shivashrit Foods monthly valuation and funding model

#### What the model establishes

This is a conditional, source-anchored operating and funding experiment, not a current bank reconciliation or a forecast that the company will default. It starts its hypothetical monthly clock in November 2026, with 60- and 120-month holding periods at the observed 19 October 2026 price of ₹114.80. All money is in ₹ crore, except per-share prices and explicit rupee inputs. Physical production is in metric tonnes. Current issued shares are 18,269,000.

A numerical conditional return is not an ordinary IAS base-case return. CARE could not independently ascertain the expansion attribution of ₹17.06 crore working-capital use at June 2026. The complete March-to-current financial bridge, actual remaining project-loan drawing power, supplier advance attribution and premature redemption terms for IPO deposits are also unverified. These are specific unresolved funding/use-of-proceeds inputs, not a general rule that old financial statements make every SME unscoreable. All paths retain source_eligible=false until those material points are resolved. This does not by itself establish G1 misconduct or an actual G3 default.

#### Dated opening state and bridge

The model does not silently mix a June cash balance with a March balance sheet. The starting construction is explicit and hypothetical:

1. Audited March cash of ₹27.4089 crore includes ₹23.6521 crore of unused IPO proceeds. The mathematical general-cash residual is ₹3.7568 crore, not ₹27.4089 crore plus IPO cash. It is not independently confirmed usable October liquidity.
2. March IPO capex, working-capital and general-corporate pools are ₹18.1512 crore, ₹5.0945 crore and ₹0.4064 crore. June monitoring reports ₹16.49 crore, ₹1.94 crore and ₹0.36 crore. Their ₹18.79 crore sum is ₹0.01 crore below the rounded total of ₹18.80 crore. The difference is excluded, not manufactured as liquidity.
3. Only the identified capex object reduction of ₹1.6612 crore is added to the March committed-project proxy and deducted from remaining budget. The ₹3.1545 crore working-capital reduction is added to supplier advances as a **management-consistent modeling hypothesis**, not verified expansion deployment. Other intervening cash, asset, liability and income movements are unknown. Holding them unchanged is a scenario assumption, not a claim about June or October accounts.
4. March CWIP of ₹19.7502 crore and capital advances of ₹8.0275 crore are separate components of a ₹27.7777 crore committed-project proxy. They are counted once. Against the ₹61.30 crore source project budget, the post-bridge remaining project amount is ₹31.8611 crore. Existing equipment PPE of ₹15.4838 crore is separate. Capital advances are not also left in operating working capital.
5. Supplier advances, GST input, prepaid expense, duty receivable and operating security deposits are retained in working capital with separate purposes. Capital advances, the pledged FD, tax-refund receivable and nonoperating assets are not misclassified as freely available operating cash.

The proxy does not establish that all CWIP or all advances belong exclusively to the new plant, that ₹61.30 crore is an all-in final cost, or that no other expenditure occurred after March. Those unresolved mappings are reasons for conditional interpretation. Overrun, timing, GST and FX stresses are retained.

#### IPO and deposit cash controls

Capex IPO money can pay only modeled project expenditure. Working-capital IPO money can reimburse only incremental operating assets net of trade financing. It cannot fund old debt repayments, taxes, general operating losses or dividends merely because cash is needed. The general-corporate remainder is excluded from general liquidity rather than treated as unrestricted debt-service money. No OFS proceeds are added to company cash.

The June deployment schedule contains ₹15.52 crore of deposits. The maturity ladder is ₹2 crore in March 2027, ₹2.5 crore in September 2027, ₹10.02 crore in October 2027 and ₹1 crore in December 2027. The source-bounded stress allocates the full locked deposit balance to the capex pool, a conservative but explicitly unverified allocation because object-by-deposit mapping is absent. It releases principal only at those maturities. The conditional cases assume permitted premature encashment; separate 1% and 3% redemption-cost sensitivities test the cost. Interest income on these deposits is not assumed to fund the project. Neither deposit ownership nor a future maturity proves immediate unrestricted cash access.

The ₹0.1083 crore pledged SBI FD remains outside usable cash unless an explicit release condition is selected. Its value is not added to terminal equity while its associated restriction remains.

#### Project debt and existing obligations

March debt is ₹47.5211 crore: ₹18.2983 crore of cash/packing credit and ₹29.2228 crore of term debt, including ₹3.6534 crore of current term maturities. Existing disclosed lending rates are approximately 8.75%, with a small car-loan component at 8.7%. The model uses 8.75% for the aggregated existing and project facilities, while testing higher rates. The aggregation is an approximation, not an instrument-perfect bank schedule.

The source reports a ₹35 crore project sanction, but does not separate current old and new HDFC balances sufficiently to verify undrawn availability. Assuming no intervening draws and a still-effective sanction, subtracting all ₹25.7194 crore current HDFC term balance gives a conservative arithmetic headroom of ₹9.2806 crore. Keeping up to the prior ₹11.3147 crore old HDFC balance gives an upper arithmetic headroom of ₹20.5953 crore. Neither bound is a bank-confirmed facility. The conditional reference uses ₹15.3711 crore, derived from project committed-capital minus capex IPO use as an illustrative debt-allocation proxy; it is not a disclosed loan balance. Both source-bound alternatives are tested.

The first twelve months repay the disclosed current term maturity evenly. Subsequent aggregated old-term amortization closes the modeled balance by month 48. Source term tenures span 48–96 months; this is an accelerated stress schedule, not asserted actual contractual dates. Newly drawn project debt starts amortization at month 6 over a 72-month assumption, with a final payoff at month 78. Interest is charged on opening debt and on new draws in the month drawn. Existing credit renewal is allowed in the reference cases, consistent with annual-renewal facilities; an on-demand call/no-renewal case is a separate stress, not silently imposed as the ordinary base.

Additional flexible borrowing is wholly hypothetical. Reference cases cap outstanding extra debt at ₹80 crore and gross cumulative draws at ₹160 crore, priced at 13% with fees and 36-month maturities. The target grid permits larger stated caps, not evidence of lender consent. Draws solve the current-month fee, interest and tax interaction, rather than filling the cash gap and charging interest only later. Renewal fees and repayments are explicit. No new flexible debt, equity rescue or flexible-debt renewal is allowed after the holding-period exit; the terminal cash test continues long enough to include its maturities. Merely moving a loan beyond year five cannot make it disappear.

#### Production, growth and procurement

The verified existing capacity is 8,640 tonnes per year. The proposed plant adds 15,840 tonnes, producing aggregate capacity of 24,480 tonnes. This is supported by the final prospectus and the November 2025 presentation, not inferred from a generic sector expansion. The January 2027 commissioning date is September 2026 management guidance after earlier June/November dates; it is not observed commissioning.

The model permits productive capacity only after the remaining modeled project budget is paid and the chosen commissioning date is reached. A subsequent utilization ramp is explicit. Later expansion purchases have their own 18-month construction lead time. Pending initial-project capacity is included in committed capacity when deciding whether another order is needed, avoiding redundant plant orders. Initial-project commissioning does not prematurely capitalize unrelated future expansion assets.

FY25 actual production is 7,019 tonnes and revenue ₹104.6934 crore. FY26 physical output and realized price were not verified. The FY26 unit base is therefore **7610.4098 constant-FY25-realization equivalent tonnes**, calculated from FY26 revenue ₹113.5147 crore. It is not claimed actual production or a proven organic-volume bridge. Annual demand growth and price growth are separate assumptions. Each modeled year's demand is constrained by productive capacity; unmet demand is not booked as revenue.

Reference variable input cost is the FY26 materials, purchases and inventory-change proxy of ₹80.6109 crore divided by ₹113.5147 crore sales. This includes more than raw potatoes, so the input-price shock is a broad purchased-input stress, not an exact commodity-price forecast. The EBITDA-margin parameter is a **current-scale reference margin**, not a flat realized margin every year. Thirty percent of other operating costs is held fixed against original sales, with the balance varying with output. Annual tables therefore show the actual modeled operating leverage and realized EBITDA.

The source says approximately 80–90% of potatoes are procured in December–March. Seasonal monthly inventory-cover assumptions produce a high March supply buffer and a lower pre-harvest buffer. They are not claims of exact monthly historical stocks. Supplier advances can secure part of that supply, so the model does not demand two complete buffers of potatoes, one in inventory and another in advances. The supply target subtracts the explicitly assumed usable advance backing, subject to a minimum inventory floor. Separate cases remove or halve that usability.

Advances are applied to purchases before the remaining invoices become payables. New cash advances replenish only the stated target; they are not magically refunded as cash. A 50% target-normalization case, full application/release case, stuck-advance case and 150% target case retain different financing consequences. Beginning receivables and payables settle through separate queues. Delayed collections, loss allowances, spoilage, supplier terms, raw-price shocks and demand loss affect cash as well as earnings. The treatment distinguishes a plausible procurement explanation from independently verified expansion use.

#### Taxes, capital costs and exceptional claims

The main normalized tax assumption is 29.12%, the rate disclosed in the source tax computation. It assumes no indefinite continuation of current 80 IB relief; the exact fiscal expiry was not verified and is not invented. The current-tax benefit sensitivity is explicit. Tax is not credited on losses unless cash realization is demonstrated. Original tax provisions are settled separately from new tax expense, and normal depreciation is not assumed identical to maintenance capex.

Capex GST/import duties are not certified included in the ₹61.30 crore budget. The base does not insert an invented tax payable; the 18% cash-tax stresses show delayed full recovery and no recovery. The FX stress applies a disclosed imported-cost-share approximation to remaining project costs, not a claim that every open invoice remains in euros. Maintenance spending is at least the scenario sales ratio; terminal replacement is no less than modeled depreciation. Growth reinvestment is the greater of explicit capacity plus working-capital needs and an economic NOPAT× growth/ROIC floor.

The source's old tax demand was resolved and the disputed bank fee was already debited; neither is charged again as a new cash outflow. The remaining ₹0.07 crore guarantee is tested separately. Larger legal-payment cases are hypothetical severity tests, not allegations that such debts exist. Employee claims of ₹0.3503 crore remain explicit senior claims. Nonoperating mutual funds, property advances, gold, the related advance and tax-refund receivable total ₹4.8022 crore before recovery assumptions. Conditional exit recovery is tested at 0%, 50% and 100% of source carrying amount. Book value is not asserted market value, and the same asset is not also counted as opening cash.

#### Terminal valuation and failure gates

After the 5- or 10-year holding period, the model runs at least twelve months and long enough to test outstanding flexible/project maturities. The first twelve months determine recurring terminal FCFF. Later transition months test survival, cash reserves and repayments. Replacement and growth cash requirements continue through the transition, scaled with terminal growth. Capacity shortfalls prevent capitalizing an undeliverable terminal demand path.

Terminal enterprise value is recurring FCFF divided by WACC less terminal growth. The main WACC is 16%, separately sensitized at 13–20%; terminal growth is tested at 2–5%, always below WACC. The 15% equity hurdle is not used as WACC. An EBITDA-multiple cross-check includes a compression case.

The enterprise-to-common-equity bridge subtracts debt and remaining senior claims, adds only cash above operating requirements and the separately qualified nonoperating recovery, and divides by actual scenario shares. Debt-service earmarked cash is not deducted twice: operating and financing reserves are shown separately, debt is deducted once, and a separate funding-reserve test must pass. No dividend is paid and also retained in exit cash. Cashflows use nominal INR; personal investor taxes are excluded. Entry and exit execution costs are 1% and 2%, with wider-cost sensitivities.

A path failing its liquidity floor, funding cap or terminal replacement/capacity/reserve condition retains all rows up to failure and an explicit reason. It has no ordinary or conditional terminal return. A liquidity-floor shortfall is not an observed corporate default; the liquidity floor itself is an analyst choice. Funded conditional paths retain numeric price/return diagnostics, but ordinary IAS returns stay NS until the identified source gaps are resolved.

Hypothetical new shares are issued as whole shares at a stated price and cost; cash and dilution enter together. The largest test remains below the source authorized-capital ceiling. No future issuance approval or investor funding is represented as obtained.

#### Sensitivities, reverse expectations and outcome grid

The complete dataset preserves every tested growth/margin pair, WACC/terminal-growth pair, financing, timing, advance, cash, fee, tax and dilution path. Hurdle entry prices are computed at 12%, 15% and 18%, but are conditional outputs rather than buy limits. Reverse expectations can be read from the funded grid: no supported growth forecast is invented to fill a missing crossing. A finite grid with no crossing does not prove a target is impossible.

The 5× and 10× tests use five- and ten-year horizons, actual modeled shares and financing, execution costs, capacity and terminal cash. A tenfold stock price needs approximately 58.49% annually over five years or 25.89% over ten years before implementation costs. All source-eligible crossing counts remain zero; none is sold as a proven multibagger.

#### Reproducibility and model limitations

The current canonical gzip includes inputs, all path assumptions, monthly rows, annual rows, terminal attempts, funded values and failed outcomes. Decimal arithmetic and deterministic gzip timestamps make exact rebuilds possible. Independent arithmetic checks do not import the production engine. In-memory mutation controls verify that key cash, asset, debt, interest, share and terminal-price discrepancies are caught.

Earlier developmental model versions are preserved with their source inputs, runtime and expected canonical hashes. They are labeled superseded, including errors found during construction, and are not alternative approved research. Their outputs can be rebuilt in a fresh directory without modifying the saved originals. Model assurance demonstrates reproducibility and internal arithmetic, not that assumptions will occur or that unavailable primary information has become known.


| Path | Volume growth / reference EBITDA margin | Funded / failure month / gap | Conditional IRR / ordinary IRR | Terminal price / sales |
|---|---|---|---|---|
| source_bear | 0.00% / 16.00% | False / 6 / 5.58 | NS / NS | ND / ND |
| source_base | 12.00% / 21.00% | False / 1 / 3.28 | NS / NS | ND / ND |
| source_bull | 22.00% / 23.00% | False / 1 / 6.22 | NS / NS | ND / ND |
| conditional_base | 12.00% / 21.00% | True / None / ND | -3.77% / NS | 97.61 / 220.87 |
| conditional_bear | 0.00% / 16.00% | False / 65 / 12.18 | NS / NS | ND / 96.49 |
| conditional_bull | 22.00% / 23.00% | True / None / ND | 8.18% / NS | 175.27 / 338.73 |
| conditional_advance_normalization | 12.00% / 21.00% | True / None / ND | -3.74% / NS | 97.79 / 220.87 |
| conditional_base_10y | 12.00% / 21.00% | False / 156 / 0.00 | NS / NS | ND / 429.77 |

The EBITDA-margin input is a reference current-scale margin, not a constant realized forecast margin: fixed operating costs create explicit operating leverage, shown in annual path tables. All scenarios are explicit assumptions, not forecast probabilities. A failed funding or terminal-funding path has no ordinary target/IRR; source-bounded stress failure is not an observed default. Conditional paths require the stated lender, deposit, advance-attribution and operating assumptions. Full monthly states and all failed trials accompany the report. The conditional base 10-year path fails the terminal physical-capacity gate at month 156 with a zero cash shortfall; this is not a cash-deficit failure.

### Terminal reconciliation

| Path | Terminal field | Value |
|---|---|---|
| conditional_base | next sales | 229.7082 |
| conditional_base | next nopat | 31.3185 |
| conditional_base | next da | 6.8373 |
| conditional_base | replacement capex | 6.8373 |
| conditional_base | physical growth capex | 0.0000 |
| conditional_base | working reinvestment | 4.1077 |
| conditional_base | growth reinvestment | 8.9482 |
| conditional_base | extra cash requirement | 5.9351 |
| conditional_base | fcff | 22.3704 |
| conditional_base | cash at exit | 52.5289 |
| conditional_base | funding reserve | 35.6584 |
| conditional_base | operating reserve | 31.7530 |
| conditional_base | cash bridge | 20.7759 |
| conditional_base | distributable cash | 16.8705 |
| conditional_base | debt | 30.9227 |
| conditional_base | senior claims | 0.3503 |
| conditional_base | shares | 18,269,000.0000 |
| conditional_base | restricted cash excluded | 0.1083 |
| conditional_base | terminal lost units | 0.0000 |
| conditional_base | funded | True |
| conditional_base | transition months | 36.0000 |
| conditional_base | enterprise value | 186.4198 |
| conditional_base | nonoperating recovery | 2.4011 |
| conditional_base | equity value | 178.3238 |
| conditional_base | price per share | 97.6101 |
| conditional_base | conditional irr | -0.0377 |
| conditional_base | ordinary irr | ND |
| conditional_base | multiple equity value | 383.5488 |
| conditional_base | multiple price | 209.9451 |
| conditional_base | operating pv | 36.4238 |
| conditional_base | terminal pv | 88.7569 |
| conditional_base | operating dcf | 125.1807 |
| conditional_base | conditional dcf equity | 98.0273 |
| conditional_base | terminal share | 0.7090 |
| conditional_bull | next sales | 352.2779 |
| conditional_bull | next nopat | 55.2611 |
| conditional_bull | next da | 7.3476 |
| conditional_bull | replacement capex | 8.8069 |
| conditional_bull | physical growth capex | 0.0000 |
| conditional_bull | working reinvestment | 5.1704 |
| conditional_bull | growth reinvestment | 15.7889 |
| conditional_bull | extra cash requirement | 10.6185 |
| conditional_bull | fcff | 38.0129 |
| conditional_bull | cash at exit | 83.7947 |
| conditional_bull | funding reserve | 48.4192 |
| conditional_bull | operating reserve | 46.2062 |
| conditional_bull | cash bridge | 37.5885 |
| conditional_bull | distributable cash | 35.3755 |
| conditional_bull | debt | 36.2085 |
| conditional_bull | senior claims | 0.3503 |
| conditional_bull | shares | 18,269,000.0000 |
| conditional_bull | restricted cash excluded | 0.1083 |
| conditional_bull | terminal lost units | 0.0000 |
| conditional_bull | funded | True |
| conditional_bull | transition months | 36.0000 |
| conditional_bull | enterprise value | 316.7740 |
| conditional_bull | nonoperating recovery | 2.4011 |
| conditional_bull | equity value | 320.2048 |
| conditional_bull | price per share | 175.2722 |
| conditional_bull | conditional irr | 0.0818 |
| conditional_bull | ordinary irr | ND |
| conditional_bull | multiple equity value | 659.0490 |
| conditional_bull | multiple price | 360.7472 |
| conditional_bull | operating pv | 53.6360 |
| conditional_bull | terminal pv | 150.8202 |
| conditional_bull | operating dcf | 204.4562 |
| conditional_bull | conditional dcf equity | 177.3028 |
| conditional_bull | terminal share | 0.7377 |
| conditional_advance_normalization | next sales | 229.7082 |
| conditional_advance_normalization | next nopat | 31.3185 |
| conditional_advance_normalization | next da | 6.8373 |
| conditional_advance_normalization | replacement capex | 6.8373 |
| conditional_advance_normalization | physical growth capex | 0.0000 |
| conditional_advance_normalization | working reinvestment | 3.0091 |
| conditional_advance_normalization | growth reinvestment | 8.9482 |
| conditional_advance_normalization | extra cash requirement | 7.0336 |
| conditional_advance_normalization | fcff | 22.3704 |
| conditional_advance_normalization | cash at exit | 80.0328 |
| conditional_advance_normalization | funding reserve | 65.7535 |
| conditional_advance_normalization | operating reserve | 59.6740 |
| conditional_advance_normalization | cash bridge | 20.3587 |
| conditional_advance_normalization | distributable cash | 14.2793 |
| conditional_advance_normalization | debt | 30.1685 |
| conditional_advance_normalization | senior claims | 0.3503 |
| conditional_advance_normalization | shares | 18,269,000.0000 |
| conditional_advance_normalization | restricted cash excluded | 0.1083 |
| conditional_advance_normalization | terminal lost units | 0.0000 |
| conditional_advance_normalization | funded | True |
| conditional_advance_normalization | transition months | 36.0000 |
| conditional_advance_normalization | enterprise value | 186.4198 |
| conditional_advance_normalization | nonoperating recovery | 2.4011 |
| conditional_advance_normalization | equity value | 178.6608 |
| conditional_advance_normalization | price per share | 97.7945 |
| conditional_advance_normalization | conditional irr | -0.0374 |
| conditional_advance_normalization | ordinary irr | ND |
| conditional_advance_normalization | multiple equity value | 383.8858 |
| conditional_advance_normalization | multiple price | 210.1296 |
| conditional_advance_normalization | operating pv | 53.8865 |
| conditional_advance_normalization | terminal pv | 88.7569 |
| conditional_advance_normalization | operating dcf | 142.6434 |
| conditional_advance_normalization | conditional dcf equity | 115.4900 |
| conditional_advance_normalization | terminal share | 0.6222 |

### Reverse expectations and hurdle sensitivity

| Path | Hurdle / reverse expectation | Value |
|---|---|---|
| conditional_base | hurdle prices | {"0.12":"53.74142269385449279864639837458589","0.15":"47.08798114847525317262862958948481","0.18":"41.39894140729603191816780222886116"} |
| conditional_bull | hurdle prices | {"0.12":"96.50008104551455008137617158056563","0.15":"84.55291596917741792219746110891407","0.18":"74.33746634808416967816230778112864"} |
| conditional_advance_normalization | hurdle prices | {"0.12":"53.84299480212545793776876106140816","0.15":"47.17697815078239576958192524983366","0.18":"41.47718603775323913683438427467544"} |

These are conditional entry/required-outcome calculations, not a certified fair-price range. Assumed expansion delivery and funding must be satisfied first; ordinary R/P remainNS.

| Reference margin | Tested annual volume growth | Minimum tested cost-adjusted break-even growth | Minimum tested growth meeting 15% IRR |
|---|---|---|---|
| 16.00% | 0.00%, 5.00%, 10.00%, 15.00%, 20.00%, 25.00%, 30.00% | No crossing in tested grid | No crossing in tested grid |
| 19.00% | 0.00%, 5.00%, 10.00%, 15.00%, 20.00%, 25.00%, 30.00% | No crossing in tested grid | No crossing in tested grid |
| 21.00% | 0.00%, 5.00%, 10.00%, 15.00%, 20.00%, 25.00%, 30.00% | 20.00% growth / 1.30% IRR | No crossing in tested grid |
| 23.00% | 0.00%, 5.00%, 10.00%, 15.00%, 20.00%, 25.00%, 30.00% | 15.00% growth / 1.48% IRR | No crossing in tested grid |
| 25.00% | 0.00%, 5.00%, 10.00%, 15.00%, 20.00%, 25.00%, 30.00% | 10.00% growth / 0.23% IRR | No crossing in tested grid |

This is a finite-grid reverse test at the actual ₹114.80 quote, including 1% entry and 2% exit costs, not an interpolated solution. Only funded five-year growth/margin paths qualify. A missing crossing is not proof of impossibility. Compare FY26 revenue growth of 8.43% and FY23–26 revenue CAGR of 35.78%, which include price/mix and are not equivalent to sustained physical volume growth. FY25 output was 7,019 MT against 8,640 MT existing capacity; the proposed addition would raise aggregate capacity to 24,480 MT, subject to commissioning and ramp. Beyond that, the model must fund additional capacity with construction lead times and a 60,000 MT ceiling. Higher growth alone cannot rescue a path that fails financing, construction or terminal capacity. Reference margin is a current-scale calibration, not a constant forecast margin. All such solutions remain conditional and do not restore ordinary IAS return factors.

### Retained sensitivity paths

| Path | Volume growth / reference EBITDA margin | Funded / failure | Conditional IRR / terminalprice | Final shares / debt raised |
|---|---|---|---|---|
| source_bear | 0.00% / 16.00% | False / 6 | NS / ND | 18269000 / 0.00 |
| source_base | 12.00% / 21.00% | False / 1 | NS / ND | 18269000 / 0.00 |
| source_bull | 22.00% / 23.00% | False / 1 | NS / ND | 18269000 / 0.00 |
| conditional_base | 12.00% / 21.00% | True / None | -3.77% / 97.61 | 18269000 / 9.00 |
| conditional_bear | 0.00% / 16.00% | False / 65 | NS / ND | 18269000 / 30.11 |
| conditional_bull | 22.00% / 23.00% | True / None | 8.18% / 175.27 | 18269000 / 14.28 |
| conditional_advance_normalization | 12.00% / 21.00% | True / None | -3.74% / 97.79 | 18269000 / 8.24 |
| conditional_base_10y | 12.00% / 21.00% | False / 156 | NS / ND | 18269000 / 9.00 |
| growth_0_margin_.16 | 0.00% / 16.00% | True / None | -23.65% / 30.71 | 18269000 / 0.12 |
| growth_0_margin_.19 | 0.00% / 19.00% | True / None | -16.92% / 46.83 | 18269000 / 0.00 |
| growth_0_margin_.21 | 0.00% / 21.00% | True / None | -13.42% / 57.56 | 18269000 / 0.00 |
| growth_0_margin_.23 | 0.00% / 23.00% | True / None | -10.41% / 68.28 | 18269000 / 0.00 |
| growth_0_margin_.25 | 0.00% / 25.00% | True / None | -7.76% / 79.01 | 18269000 / 0.00 |
| growth_.05_margin_.16 | 5.00% / 16.00% | True / None | -19.15% / 40.87 | 18269000 / 7.96 |
| growth_.05_margin_.19 | 5.00% / 19.00% | True / None | -12.62% / 60.27 | 18269000 / 0.48 |
| growth_.05_margin_.21 | 5.00% / 21.00% | True / None | -9.25% / 72.83 | 18269000 / 0.24 |
| growth_.05_margin_.23 | 5.00% / 23.00% | True / None | -6.32% / 85.38 | 18269000 / 0.00 |
| growth_.05_margin_.25 | 5.00% / 25.00% | True / None | -3.72% / 97.88 | 18269000 / 0.00 |
| growth_.10_margin_.16 | 10.00% / 16.00% | False / 96 | NS / ND | 18269000 / 27.63 |
| growth_.10_margin_.19 | 10.00% / 19.00% | True / None | -8.75% / 74.83 | 18269000 / 11.61 |
| growth_.10_margin_.21 | 10.00% / 21.00% | True / None | -5.25% / 90.34 | 18269000 / 2.08 |
| growth_.10_margin_.23 | 10.00% / 23.00% | True / None | -2.36% / 105.00 | 18269000 / 1.83 |
| growth_.10_margin_.25 | 10.00% / 25.00% | True / None | 0.23% / 119.66 | 18269000 / 1.58 |
| growth_.15_margin_.16 | 15.00% / 16.00% | False / 77 | NS / ND | 18269000 / 52.34 |
| growth_.15_margin_.19 | 15.00% / 19.00% | True / None | -5.18% / 90.67 | 18269000 / 34.35 |
| growth_.15_margin_.21 | 15.00% / 21.00% | True / None | -1.61% / 109.08 | 18269000 / 22.38 |
| growth_.15_margin_.23 | 15.00% / 23.00% | True / None | 1.48% / 127.36 | 18269000 / 10.64 |
| growth_.15_margin_.25 | 15.00% / 25.00% | True / None | 4.18% / 145.20 | 18269000 / 3.33 |
| growth_.20_margin_.16 | 20.00% / 16.00% | False / 53 | NS / ND | 18269000 / 80.00 |
| growth_.20_margin_.19 | 20.00% / 19.00% | True / None | -2.41% / 104.73 | 18269000 / 62.48 |
| growth_.20_margin_.21 | 20.00% / 21.00% | True / None | 1.30% / 126.18 | 18269000 / 49.23 |
| growth_.20_margin_.23 | 20.00% / 23.00% | True / None | 4.52% / 147.59 | 18269000 / 36.04 |
| growth_.20_margin_.25 | 20.00% / 25.00% | True / None | 7.39% / 169.00 | 18269000 / 22.86 |
| growth_.25_margin_.16 | 25.00% / 16.00% | False / 41 | NS / ND | 18269000 / 80.00 |
| growth_.25_margin_.19 | 25.00% / 19.00% | False / 52 | NS / ND | 18269000 / 80.00 |
| growth_.25_margin_.21 | 25.00% / 21.00% | False / 53 | NS / ND | 18269000 / 80.00 |
| growth_.25_margin_.23 | 25.00% / 23.00% | True / None | 6.87% / 164.94 | 18269000 / 71.51 |
| growth_.25_margin_.25 | 25.00% / 25.00% | True / None | 9.93% / 189.91 | 18269000 / 56.89 |
| growth_.30_margin_.16 | 30.00% / 16.00% | False / 40 | NS / ND | 18269000 / 80.00 |
| growth_.30_margin_.19 | 30.00% / 19.00% | False / 41 | NS / ND | 18269000 / 80.00 |
| growth_.30_margin_.21 | 30.00% / 21.00% | False / 41 | NS / ND | 18269000 / 80.00 |
| growth_.30_margin_.23 | 30.00% / 23.00% | False / 52 | NS / ND | 18269000 / 80.00 |
| growth_.30_margin_.25 | 30.00% / 25.00% | False / 52 | NS / ND | 18269000 / 80.00 |
| wacc_.13_g_.02 | 12.00% / 21.00% | True / None | 1.58% / 127.98 | 18269000 / 9.00 |
| wacc_.13_g_.03 | 12.00% / 21.00% | True / None | 1.85% / 129.67 | 18269000 / 9.00 |
| wacc_.13_g_.04 | 12.00% / 21.00% | True / None | 2.15% / 131.62 | 18269000 / 9.00 |
| wacc_.13_g_.05 | 12.00% / 21.00% | True / None | 2.51% / 133.94 | 18269000 / 9.00 |
| wacc_.14_g_.02 | 12.00% / 21.00% | True / None | -0.21% / 117.10 | 18269000 / 9.00 |
| wacc_.14_g_.03 | 12.00% / 21.00% | True / None | -0.13% / 117.57 | 18269000 / 9.00 |
| wacc_.14_g_.04 | 12.00% / 21.00% | True / None | -0.05% / 118.02 | 18269000 / 9.00 |
| wacc_.14_g_.05 | 12.00% / 21.00% | True / None | 0.02% / 118.46 | 18269000 / 9.00 |
| wacc_.16_g_.02 | 12.00% / 21.00% | True / None | -3.30% / 100.02 | 18269000 / 9.00 |
| wacc_.16_g_.03 | 12.00% / 21.00% | True / None | -3.51% / 98.95 | 18269000 / 9.00 |
| wacc_.16_g_.04 | 12.00% / 21.00% | True / None | -3.77% / 97.61 | 18269000 / 9.00 |
| wacc_.16_g_.05 | 12.00% / 21.00% | True / None | -4.11% / 95.93 | 18269000 / 9.00 |
| wacc_.18_g_.02 | 12.00% / 21.00% | True / None | -5.92% / 87.21 | 18269000 / 9.00 |
| wacc_.18_g_.03 | 12.00% / 21.00% | True / None | -6.34% / 85.29 | 18269000 / 9.00 |
| wacc_.18_g_.04 | 12.00% / 21.00% | True / None | -6.84% / 83.03 | 18269000 / 9.00 |
| wacc_.18_g_.05 | 12.00% / 21.00% | True / None | -7.45% / 80.34 | 18269000 / 9.00 |
| wacc_.20_g_.02 | 12.00% / 21.00% | True / None | -8.18% / 77.24 | 18269000 / 9.00 |
| wacc_.20_g_.03 | 12.00% / 21.00% | True / None | -8.75% / 74.85 | 18269000 / 9.00 |
| wacc_.20_g_.04 | 12.00% / 21.00% | True / None | -9.43% / 72.10 | 18269000 / 9.00 |
| wacc_.20_g_.05 | 12.00% / 21.00% | True / None | -10.25% / 68.91 | 18269000 / 9.00 |
| stress_nonop_zero | 12.00% / 21.00% | True / None | -4.03% / 96.30 | 18269000 / 9.00 |
| stress_nonop_fullbook | 12.00% / 21.00% | True / None | -3.52% / 98.92 | 18269000 / 9.00 |
| stress_BG_call | 12.00% / 21.00% | True / None | -3.78% / 97.56 | 18269000 / 9.08 |
| stress_FX10_importshare_proxy | 12.00% / 21.00% | True / None | -4.08% / 96.04 | 18269000 / 11.33 |
| stress_advances_not_supply | 12.00% / 21.00% | False / 53 | NS / ND | 18269000 / 80.00 |
| stress_advances_half_supply | 12.00% / 21.00% | False / 96 | NS / ND | 18269000 / 44.53 |
| stress_advance_normalization50 | 12.00% / 21.00% | True / None | -3.74% / 97.79 | 18269000 / 8.24 |
| stress_advance_full_release | 12.00% / 21.00% | True / None | -3.51% / 98.96 | 18269000 / 5.72 |
| stress_advances_stuck | 12.00% / 21.00% | True / None | -3.51% / 98.98 | 18269000 / 6.50 |
| stress_advance_growth150 | 12.00% / 21.00% | True / None | -5.09% / 91.11 | 18269000 / 19.33 |
| stress_FD_penalty1pct | 12.00% / 21.00% | True / None | -3.80% / 97.48 | 18269000 / 9.23 |
| stress_FD_penalty3pct | 12.00% / 21.00% | True / None | -3.85% / 97.21 | 18269000 / 9.69 |
| stress_current_tax_benefit | 12.00% / 21.00% | True / None | -0.93% / 112.89 | 18269000 / 2.71 |
| stress_no_premature_FD_release | 12.00% / 21.00% | True / None | -6.40% / 84.99 | 18269000 / 30.87 |
| stress_project_defer_to_maturity | 12.00% / 21.00% | True / None | -4.49% / 94.04 | 18269000 / 14.37 |
| stress_headroom_lower | 12.00% / 21.00% | True / None | -3.74% / 97.80 | 18269000 / 10.66 |
| stress_headroom_upper | 12.00% / 21.00% | True / None | -3.78% / 97.56 | 18269000 / 12.51 |
| stress_cash_zero | 12.00% / 21.00% | True / None | -4.42% / 94.38 | 18269000 / 14.59 |
| stress_no_project_loan | 12.00% / 21.00% | True / None | -3.86% / 97.16 | 18269000 / 15.47 |
| stress_no_wc_renewal | 12.00% / 21.00% | True / None | -3.98% / 96.55 | 18269000 / 28.82 |
| stress_no_flex | 12.00% / 21.00% | False / 1 | NS / ND | 18269000 / 0.00 |
| stress_flex20 | 12.00% / 21.00% | True / None | -3.77% / 97.61 | 18269000 / 9.00 |
| stress_flex40 | 12.00% / 21.00% | True / None | -3.77% / 97.61 | 18269000 / 9.00 |
| stress_no_flex_renewal | 12.00% / 21.00% | True / None | -3.77% / 97.64 | 18269000 / 11.76 |
| stress_delay6 | 12.00% / 21.00% | True / None | -3.83% / 97.33 | 18269000 / 9.10 |
| stress_delay12 | 12.00% / 21.00% | True / None | -3.94% / 96.79 | 18269000 / 9.24 |
| stress_overrun15 | 12.00% / 21.00% | True / None | -4.54% / 93.80 | 18269000 / 14.72 |
| stress_overrun30 | 12.00% / 21.00% | True / None | -5.40% / 89.63 | 18269000 / 21.05 |
| stress_raw10 | 12.00% / 21.00% | False / 65 | NS / ND | 18269000 / 64.50 |
| stress_raw20 | 12.00% / 21.00% | False / 41 | NS / ND | 18269000 / 80.00 |
| stress_collection3 | 12.00% / 21.00% | True / None | -6.65% / 83.87 | 18269000 / 32.41 |
| stress_collection4 | 12.00% / 21.00% | False / 77 | NS / ND | 18269000 / 57.09 |
| stress_spoil10 | 12.00% / 21.00% | True / None | -3.92% / 96.88 | 18269000 / 10.26 |
| stress_writeoff10 | 12.00% / 21.00% | True / None | -4.02% / 96.36 | 18269000 / 11.17 |
| stress_subsidy1 | 12.00% / 21.00% | True / None | -3.64% / 98.31 | 18269000 / 7.78 |
| stress_gst18_refund6 | 12.00% / 21.00% | True / None | -3.90% / 96.96 | 18269000 / 10.13 |
| stress_gst18_no_refund | 12.00% / 21.00% | True / None | -4.70% / 92.99 | 18269000 / 17.00 |
| stress_legal1 | 12.00% / 21.00% | True / None | -3.91% / 96.91 | 18269000 / 10.21 |
| stress_legal5 | 12.00% / 21.00% | True / None | -4.51% / 93.92 | 18269000 / 15.39 |
| stress_equity2m | 12.00% / 21.00% | True / None | -3.93% / 96.81 | 20269000 / 0.00 |
| stress_equity6m | 12.00% / 21.00% | True / None | -4.57% / 93.65 | 24269000 / 0.00 |
| stress_lower_terminal_multiple | 12.00% / 21.00% | True / None | -3.77% / 97.61 | 18269000 / 9.00 |
| stress_higher_costs | 12.00% / 21.00% | True / None | -4.74% / 97.61 | 18269000 / 9.00 |
| stress_interest15 | 12.00% / 21.00% | True / None | -4.34% / 94.78 | 18269000 / 13.44 |
| stress_high_reserve | 12.00% / 21.00% | True / None | -4.93% / 91.90 | 18269000 / 18.62 |
| stress_replacement10 | 12.00% / 21.00% | True / None | -3.78% / 97.56 | 18269000 / 9.00 |
| stress_roic10 | 12.00% / 21.00% | True / None | -7.42% / 80.47 | 18269000 / 9.00 |
| stress_roic18 | 12.00% / 21.00% | True / None | -1.97% / 107.13 | 18269000 / 9.00 |

## 11. Bear Case and Permanent Loss Path

The strongest permanent-loss path is not simply a lower potato price or a temporarily weak quote. It is a linked sequence: the larger plant is delayed or ramps slowly; concentrated industrial customers do not absorb output at expected processing margins; seasonal potatoes and supplier advances consume cash; collections lengthen; restricted IPO deposits cannot cover unrelated losses or debt; lender renewal or additional capital becomes necessary. If funding is supplied on unattractive terms, aggregate profit growth can coexist with weak per-share value. If the new machinery becomes economically redundant or advances do not convert into usable supply, accounting book value is not equivalent to cash recovery.

The critical thesis variable is cash earned per additional rupee committed to mature processing capacity. The strongest evidence against a favorable compounder interpretation is weak multi-year operating realization despite a profitable existing business, plus the monitor's specific deployment-verification gap before the new unit operates. Conversely, the earlier line was expanded successfully, the main audit and IFC opinion are clean, source stock/bank-return checks did not find material discrepancies, and an old tax dispute was resolved. Those facts limit the claim: the evidence supports investigation and conditional modeling, not a finding of fraud or observed insolvency. [SFL-AR26R](https://nsearchives.nseindia.com/annual_reports/SME_AR_32089_SHIVASHRIT_2025_2026_U_7594527_28092026121229.pdf); [SFL-MONJUN26](https://nsearchives.nseindia.com/corporate/SHIVASHRITFOODS_13082026145123_MAReport30062026.pdf)

Permanent impairment risk is assessed High on this unresolved expansion case because procurement, capex, timing and financing can fail together. This is an analyst risk classification, not a default probability. A modeled reserve shortfall is neither a bank covenant violation nor an observed company default. A failed model path has no ordinary terminal target or IRR; recovery would depend on actual asset saleability, customer economics, senior claims and financing terms that are not certified by the model. Clearing the deployment and funding evidence, commissioning on revised terms and sustained mature-line cash conversion would change the thesis more than one favorable trading day.

## 12. Fivefold and Tenfold Feasibility

| Horizon / multiple | Paths / funded / failed | Conditional / source-eligible crossings | Least tested growth |
|---|---|---|---|
| 5 years / 5× | 24 / 10 / 14 | 0 / 0 | NS |
| 5 years / 10× | 24 / 10 / 14 | 0 / 0 | NS |
| 10 years / 5× | 24 / 7 / 17 | 0 / 0 | NS |
| 10 years / 10× | 24 / 7 / 17 | 0 / 0 | NS |

Speculative / unsupported as a source-verified 5×/10× thesis. A 10× price outcome needs 58.49% annual growth over 5 years or 25.89% over 10 before execution costs. Full growth, margin, capex, working capital, debt, dilution and terminal assumptions are retained for each tested path. Finite-grid failure does not prove impossibility, and a conditional crossing does not cure source eligibility. Market share required cannot be honestly stated as a precise percentage without a verified domestic flake-market denominator. Product volume/capacity and primary peer scale supply more useful constraints.

## 13. Monitoring Plan

### Monitoring and disconfirmation

The strongest thesis is that additional capacity, sold at sustainable processing margins and financed with controlled seasonal cash, can lift owner earnings. The strongest falsifier is commissioning followed by poor orders or cash conversion: new machines and rising receivables can produce accounting growth while exhausting funding.

Monitor machinery delivery/installation/consent and actual January 2027 commercial start; monthly/seasonal output and utilization; executed customer orders rather than generalized demand; concentration and payment terms; potatoes procured/held/consumed; expiry and availability of seasonal bank lines; exact IPO object cash spending versus bank balances; current cold-storage rental terms; corrections to AOC2/remuneration; and the economic purpose/returns of noncore assets. Delays or one season of stock build trigger review, not automatic fraud/default. Persistent negative operating cash despite mature capacity and growing debt would undermine a compounder claim. A priced consumer brand or broader commodity trading proposal is no substitute for demonstrated per-share cash returns.

| KPI / baseline | Expected milestone / review | Warning versus thesis break |
|---|---|---|
| New line: originalJune 2026, nowJanuary 2027 target | Machinery delivery, permits, trial and commercial dispatch certificates | Delay triggers funding review; repeated unfunded delay plus lost customers can break the expansion thesis |
| June WC use ₹17.06 crore unverified attribution | Project supplier advances→potato receipts→production ledger andmonitor clarification | Unreconciled use holds research; verified unauthorized loss/material diversion changes governance |
| FY26 supplier advances ₹25.0743 crore | Aged advances, delivery quality, refundability and related counterparties each half-year | Slow delivery needs review; irrecoverable advances without a funding buffer threaten value |
| FY26 receivables ₹19.1746 crore | Collections andaged buckets with customer concentration | Longer days signal risk; material bad debts plus weak buyer retention undermine economics |
| Project balance-budget proxy ₹33.5223 crore at March | Certified cost-to-complete including tax/FX and known subsequent payments | Cost overrun is not fraud; unfinanceable essential spend changes funding gate |
| June unspent IPO ₹18.80 crore | Object-specific accounts,FD release terms and draw verification | Do not treat restricted cash as a general rescue |
| FY26 operating EBITDA ₹24.0867 crore | Volume, mix, input cost and margin comparisons | Temporary crop cycle is not thesis failure; structural price pressure plus weak cash is |
| GOV AOC-2/pay table inconsistencies | Corrected filing and rental benchmarking | Clerical correction can resolve presentation; evidenced abuse changesG1 |
| 1,000-sharelot / missingSep 3 row | Current tape,depth/spread andposition-specific exit plan | Thin liquidity affects implementation, notautomatic business failure |

## 14. Final Classification and Conditional Action

Hold — unresolved. The numerical quality assessments describe the evidence available; they do not override the material G2 deployment-verification hold. BQS 5.26 (displayed 5.3) and capped GQS 5.0 are excluded from eligible rankings. IAS remains NS because a fully supported return/resilience/price-expectations assessment and complete liquidity evidence are not available. Missing components are not set to zero or replaced by a midpoint, and the remaining IAS weights are not renormalized.

Research priority is verification of the expansion-specific supplier-advance/stock ledger, project cost-to-complete and actual available financing, followed by customer demand and cash delivery. This is not an automatic sell instruction for an existing holding: position size, taxes, alternatives, liquidity and the holder's original thesis are unknown. Nor is a low P/E a sufficient reason to initiate a position while the important evidence is unresolved. No evidence-backed compounder designation is earned; several required factors are below the framework's thresholds even if the open verification issues were resolved.

A lower quote can improve conditional return arithmetic but cannot, by itself, settle the use-of-proceeds question or commission the plant. A price-sensitive conclusion should be recomputed only after the same source, capital, tax, liquidity and ownership assumptions are made explicit. The 15% nominal before-personal-tax hurdle is an analytical policy assumption, distinct from the model's WACC and not a promise of return.

## 15. Sources, Assumptions and Open Questions

| ID | Date / primary source | Scope and limit |
|---|---|---|
| SFL-P | 2025-08-28 [Final IPO prospectus](https://nsearchives.nseindia.com/emerge/corporates/content/ShivashritFoodsLimited_PROSP.pdf) |  Printed page numbers are used; PDF page is printed+3. Historical not current source. |
| SFL-AR26R | 2026-09-28 [Revised FY26 annual report](https://nsearchives.nseindia.com/annual_reports/SME_AR_32089_SHIVASHRIT_2025_2026_U_7594527_28092026121229.pdf) |  Corrigendum maternity/certification only; financial statements unchanged. PDF pages used where specified. |
| SFL-AR26O | 2026-09-08 [Original FY26 annual report](https://archives.nseindia.com/annual_reports/SME_AR_31963_SHIVASHRIT_2025_2026_A_17054833_08092026212301.pdf) |  Superseded by revised report; retained for reconciliation, not independent corroboration. |
| SFL-AGM26 | 2026-09-30 [AGM proceedings and chairman comments](https://nsearchives.nseindia.com/corporate/SHIVASHRITFOODS_30092026133208_Outcome_of_AGM-f.pdf) |  Forward guidance is management statement. |
| SFL-EGM26 | 2026-02-24 [EGM notice and location-change explanatory statement](https://nsearchives.nseindia.com/corporate/SHIVASHRITFOODS_24022026155654_SFL_-_Final_Notice_of_EGM.pdf) |  Proposal at issue date; approval separately verified. |
| SFL-EGMRESULT | 2026-03-21 [March 20 EGM scrutinizer/voting results](https://nsearchives.nseindia.com/corporate/SHIVASHRITFOODS_21032026174805_FinaloutcomeofEGMSFL.pdf) |  Resolution passed; interested votes excluded, no opinion on commercial fairness. |
| SFL-SHP26 | 2026-10-19 [September 30 shareholding XBRL](https://nsearchives.nseindia.com/corporate/xbrl/SHP_1741163_19102026113011_WEB.xml) |  As-of holdings datedSep 30, filedOct 19; declarations not current bank confirmations. |
| SFL-PRESENT25 | 2025-11-19 [Investor presentation](https://nsearchives.nseindia.com/corporate/SHIVASHRITFOODS_19112025192456_InvestorPresentationNov2025SFL.pdf) |  Management statements; OCR source images retained. |
| PEER-IBF | 2026-09-03 [CRISIL Iscon Balaji rationale](https://www.crisilratings.com/mnt/winshare/Ratings/RatingList/RatingDocs/IsconBalajiFoodsPrivateLimited_September%2003_%202026_RR_405056.html) |  FY26 estimates vsFY25 reported; no rawCFO. Retrieved through web; shellHTTP406, no local original. |
| PEER-ASPL | 2026-03-02 [Infomerics Asandas rationale](https://infomericstorage.blob.core.windows.net/uploads/PR_Asandas_and_Sons02_March26_37f431865b.pdf) |  Internal period/value conflicts between narrative and financialtable retained; not a precise valuation comparator. |
| PEER-AM | 2025-11-28 [ICRA Agristo Masa / Agristo NV rationale](https://www.icra.in/Rating/ShowRationalReportFilePdf/139371) |  Two related entities, not independent fourth group; separate standalone scopes, IndiaFY vsEuropeCY. |
| SFL-MA-JUN26 | 2026-08-13 [CARE monitoring report for quarter ended June 2026](https://nsearchives.nseindia.com/corporate/SHIVASHRITFOODS_13082026145123_MAReport30062026.pdf) |  Management certificates and rebuttal retained alongside agency qualification; no proven diversion conclusion. |
| SFL-AR25 | 2025-09-09 [ar 25](https://archives.nseindia.com/annual_reports/SME_AR_29010_SHIVASHRIT_2024_2025_A_6138634_09092025213427.pdf) |  Primary issuer filing; date, period and disclosure qualifications retained in the financial reconciliation. |
| SFL-H126 | 2025-11-14 [h 126](https://nsearchives.nseindia.com/corporate/SHIVASHRITFOODS_14112025142237_Financial-PR-merged.pdf) |  Primary issuer filing; date, period and disclosure qualifications retained in the financial reconciliation. |
| SFL-MONJUN26 | 2026-08-13 [monitor june 26](https://nsearchives.nseindia.com/corporate/SHIVASHRITFOODS_13082026145123_MAReport30062026.pdf) | PDF1 issuer cover;3 monitor limits;5 delay approval;6-8 WC verification and issuer response;10-12 object use;13 FD deployment Primary issuer filing; date, period and disclosure qualifications retained in the financial reconciliation. |
| SFL-CLARJUL26 | 2026-07-03 [clarification july 26](https://nsearchives.nseindia.com/corporate/SHIVASHRITFOODS_03072026152613_SFLClarificationjuly26withMAreport.pdf) | PDF1-2 clarification;financial statement section and Marchmonitor attached Primary issuer filing; date, period and disclosure qualifications retained in the financial reconciliation. |
| SFL-RESULT26 | 2026-05-30 [result 26](https://nsearchives.nseindia.com/corporate/SHIVASHRITFOODS_30052026155046_SFLOutcomes30052026.pdf) |  Primary issuer filing; date, period and disclosure qualifications retained in the financial reconciliation. |
| NSE-MARKET | 2026-10-19 [NSE daily bhavcopy and verified security master](https://nsearchives.nseindia.com/content/cm/BhavCopy_NSE_CM_0_0_0_20261019_F_0000.csv.zip) |  Full per-session hashes and issuer rows in market_inputs.json;59 of 60 issuer rows observed. Missing September 3 is not zero. |

V=verified disclosure;C=calculation;M=management statement;A=analyst assumption. Financial values are cited to source files/pages in financial_inputs.json and financial_notes.md; full claim ledgers andsource hashes accompany the reader. A revisedPDF is not independent corroboration of its original. The June monitoring report is not a statutory audit and its management response is not an independently verified conclusion.

The highest-priority open questions are: independent linkage of expansion supplier advances to actual potatoes and project stock; current bank-certified cash, encashable FD and undrawn project facilities; old/new HDFC term-loan allocation and repayments; project-specific remaining costs including GST, FX and permits; commissioning evidence and confirmed buyer uptake; corrected AOC-2 and remuneration disclosures; and the missing 3 September trading observation. The model keeps these gaps visible rather than substituting historical balances as current facts.

Reproduction checks establish that the authored calculations regenerate from the supplied inputs. They do not independently audit issuer assertions or predict outcomes. Full current and retained model inputs, failed paths, monthly funding records, terminal tests and source hashes accompany the readable report. Forecasts and classifications are analytical judgments using a common v3.0 framework, not statistically validated guarantees.

| Quality check | Evidence / treatment |
|---|---|
| 1. Identity and scope | NSE SHIVASHRIT / INE1DLF01018; standalone Indian GAAP; source cutoffs and current issued shares verified. |
| 2. Primary evidence and assumptions | Final prospectus, original/revised audited reports, IPO monitor, EGM votes and latest shareholding read; management targets and conditional model inputs labeled. |
| 3. Audit RPT financing dilution | Clean main/IFC/CARO counterevidence preserved alongside AOC-2/remuneration and restricted IPO deployment gaps; OFS is not company funding. |
| 4. Periods units TTM | Crore/lakh conversions and original/restated FY25 kept separate; H2 is a balancing half, not a quarter; no invented quarterly CFO or FY27 TTM. |
| 5. Revenue growth decomposition | Three-year primary growth window selected because five-year start unavailable; physical output and realization limitations explicit; no projected capacity bonus. |
| 6. CFO ratio of sums | Reported and economic 3-year sum CFO/sum PAT shown; symmetric CFI reclassification and FY25 residual retained without double-adjusting capital advances. |
| 7. Incremental returns | Inclusive financing-side committed IC with CWIP/capital advances; 3/2/1-year proxies and favorable lagged illustration; not project IRR. |
| 8. Normalization claims dilution | 29.12% tax normalization separate from relief; operating/nonoperating income explicit; current/weighted shares and company/OFS cash distinguished. |
| 9. Linked cash financing scenarios | Seasonal procurement, supplier advances, IPO object buckets, debt, FDs, project commissioning, shocks and terminal reserves linked; failures retained. |
| 10. Canonical factors and weights | Exactly 13 factors; BQS/GQS/IAS weights each 1; BQS contribution reused unrounded once in IAS. |
| 11. Missing evidence | R/D/P/L remainNS, coverage and mathematical bounds shown; source verification holds do not become invented scores. |
| 12. Raw final overrides | BQS5.26, GQS6.35 capped 5 forCASH3,IASNS; no hidden governance/default cap. |
| 13. Classification | Hold—unresolved from scopedG2; numeric quality excluded from eligible ranks; compounder tests not met. |
| 14. Liquidity | ₹5 lakh reference,1000-sharelot;59/60 rows withSep 3 missing unknown,20/20 recent complete; no zero imputation. |
| 15. Bear case | Linked delay/customer/margin/procurement/funding stress; cash-per-capital thesis-break variable and positive audit counterevidence explicit. |
| 16. Ranking consistency | v3.0 common cutoffs, no aggregate winner, no rank created for excluded/NS record; research completion separate from investment evidence completeness. |
