# Primary-source economic peer comparison

Information cutoff: 20 October 2026. Amounts are INR crore. These are economic comparisons, not market-price or P/E comparables. The four rows represent three independent business groups: Agristo NV is the sponsor-related mature benchmark for Agristo Masa. Private-company credit reports do not establish traded-equity valuation.

| Business and reporting scope | Period and revenue | Operating margin | Capital, funding or cash-cycle evidence | What can actually be compared |
|---|---|---|---|---|
| Iscon Balaji Foods, standalone potato processing, frozen fries and snacks | FY26 estimated ₹1,945; FY25 ₹1,488.92 | FY26 estimated 17.5%; FY25 20.6% | Gross current assets 304 days; receivables 80 days; estimated interest cover 4.34x; 79% exports | Processing-margin cyclicality and working-capital strain at much greater scale, not an assumed comparable ROIC |
| Asandas & Sons / HyFun, consolidated processing group | FY25 narrative ₹1,541; financial table conflicts on period/value | Narrative FY25 13.40%; table also presents 15.26% in its next column | Narrative debt ₹1,370.11, working-capital cycle 181 days and interest cover 2x; approximately ₹900 crore expansion | Leveraged expansion, procurement integration and liquidity risk; source inconsistency prevents precise ranking |
| Agristo Masa, standalone Indian JV | FY25 audited ₹108.5; PAT −₹39.3 | OPBDIT −15.5% | TOL/TNW 1.8x; interest cover −1.6x; sponsor funding ₹139 crore in FY25 | A geographically relevant processing entrant can incur substantial ramp-up losses despite strong sponsors |
| Agristo NV, standalone Belgian sponsor-related benchmark | CY24 audited ₹12,218.9; PAT ₹2,031.6 | OPBDIT 24.3% | TOL/TNW 0.6x; debt/OPBDIT 0.6x; interest cover 18x | Mature international processing can earn attractive margins, but geography, product mix, scale and calendar prevent direct translation |

## Sources and interpretation

Iscon Balaji’s September 2026 CRISIL report supports the comparison above. Its declining margin and rising receivables show that sales growth need not improve cash conversion. Gross current asset days are not cash-conversion-cycle days. FY26 values remain agency estimates; one sentence repeats FY2026 for both margin observations, whereas the surrounding narrative distinguishes the prior year. The FY25 PAT/printed PAT-margin table also does not exactly reconcile, so no PAT-margin ranking is used. Source: https://www.crisilratings.com/mnt/winshare/Ratings/RatingList/RatingDocs/IsconBalajiFoodsPrivateLimited_September%2003_%202026_RR_405056.html

Asandas is useful because its seed/farmer pipeline and broader product base differ from Shivashrit’s trader-heavy procurement. The March 2026 Infomerics narrative and financial table disagree: the narrative associates ₹1,541 revenue with FY25, while the table labels ₹1,541.64 and ₹1,770.07 as March 2024/2025 respectively. Its EBITDA columns are ₹206.63/₹270.03. Preserve both versions rather than silently choosing one. The downgrade reflects leverage and expansion risk, not a default finding. Source: https://infomericstorage.blob.core.windows.net/uploads/PR_Asandas_and_Sons02_March26_37f431865b.pdf

Agristo Masa and Agristo NV are shown separately, but are not independent peer groups. The Indian JV’s historical flakes operation is closer operationally to Shivashrit; its proposed fries expansion changes future mix. Its BBB+(CE) credit rating benefits from support, whereas the unenhanced rating is BB+. Negative operating earnings make debt/OPBDIT economically non-meaningful rather than cheap. The Belgian benchmark illustrates mature processing economics, not an appropriate Indian SME equity multiple. Source: https://www.icra.in/Rating/ShowRationalReportFilePdf/139371

## Denominator and comparability safeguards

1. Iscon operating margin and Agristo OPBDIT are agency-defined operating measures, not automatically identical to issuer model EBITDA. Report each definition and avoid basis-point precision across them.
2. GCA days, receivable days and net working-capital days have different denominators and components. They cannot be ranked as if each were CCC. Agriculture requires seasonal monthly funding analysis even when annual working capital falls.
3. Comparable audited CFO and consistent operating invested capital were not established for these peers. CFO conversion and ROIC are therefore ND, not imputed from EBITDA, PAT, cash accrual or sponsor support. No peer ROIC premium is asserted.
4. Standalone and consolidated scopes, FY26 estimates, FY25 audited figures and CY24 audited figures are explicitly separated. No future expansion capacity is treated as delivered production.
5. Shivashrit’s proposed expansion adds process capacity but also fixed assets, start-up cost and procurement finance. The relevant benchmark question is sustainable margin after utilization, interest, tax and recurring capital/working-capital needs, not whether a global potato market is large.

## Investment implication

The peer evidence supports a viable but capital- and crop-sensitive processing industry. It does not prove a durable high-return moat for Shivashrit. Larger peers demonstrate both achievable margins and substantial financing needs; a credible sponsor does not eliminate ramp-up losses. For Shivashrit, customer concentration, site execution, actual seasonal funding and related-party economics are more decision-useful than importing a private peer’s credit rating or mature overseas margin into a valuation multiple.

The machine-readable evidence is in peer_inputs.json. The source ledger is peer_source_ledger.csv, linked to the broader business_source_register.json. Missing financial denominators remain explicit.
