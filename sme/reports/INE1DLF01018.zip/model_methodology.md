# Shivashrit Foods monthly valuation and funding model

## What the model establishes

This is a conditional, source-anchored operating and funding experiment, not a current bank reconciliation or a forecast that the company will default. It starts its hypothetical monthly clock in November 2026, with 60- and 120-month holding periods at the observed 19 October 2026 price of ₹114.80. All money is in ₹ crore, except per-share prices and explicit rupee inputs. Physical production is in metric tonnes. Current issued shares are 18,269,000.

A numerical conditional return is not an ordinary IAS base-case return. CARE could not independently ascertain the expansion attribution of ₹17.06 crore working-capital use at June 2026. The complete March-to-current financial bridge, actual remaining project-loan drawing power, supplier advance attribution and premature redemption terms for IPO deposits are also unverified. These are specific unresolved funding/use-of-proceeds inputs, not a general rule that old financial statements make every SME unscoreable. All paths retain source_eligible=false until those material points are resolved. This does not by itself establish G1 misconduct or an actual G3 default.

## Dated opening state and bridge

The model does not silently mix a June cash balance with a March balance sheet. The starting construction is explicit and hypothetical:

1. Audited March cash of ₹27.4089 crore includes ₹23.6521 crore of unused IPO proceeds. The mathematical general-cash residual is ₹3.7568 crore, not ₹27.4089 crore plus IPO cash. It is not independently confirmed usable October liquidity.
2. March IPO capex, working-capital and general-corporate pools are ₹18.1512 crore, ₹5.0945 crore and ₹0.4064 crore. June monitoring reports ₹16.49 crore, ₹1.94 crore and ₹0.36 crore. Their ₹18.79 crore sum is ₹0.01 crore below the rounded total of ₹18.80 crore. The difference is excluded, not manufactured as liquidity.
3. Only the identified capex object reduction of ₹1.6612 crore is added to the March committed-project proxy and deducted from remaining budget. The ₹3.1545 crore working-capital reduction is added to supplier advances as a **management-consistent modeling hypothesis**, not verified expansion deployment. Other intervening cash, asset, liability and income movements are unknown. Holding them unchanged is a scenario assumption, not a claim about June or October accounts.
4. March CWIP of ₹19.7502 crore and capital advances of ₹8.0275 crore are separate components of a ₹27.7777 crore committed-project proxy. They are counted once. Against the ₹61.30 crore source project budget, the post-bridge remaining project amount is ₹31.8611 crore. Existing equipment PPE of ₹15.4838 crore is separate. Capital advances are not also left in operating working capital.
5. Supplier advances, GST input, prepaid expense, duty receivable and operating security deposits are retained in working capital with separate purposes. Capital advances, the pledged FD, tax-refund receivable and nonoperating assets are not misclassified as freely available operating cash.

The proxy does not establish that all CWIP or all advances belong exclusively to the new plant, that ₹61.30 crore is an all-in final cost, or that no other expenditure occurred after March. Those unresolved mappings are reasons for conditional interpretation. Overrun, timing, GST and FX stresses are retained.

## IPO and deposit cash controls

Capex IPO money can pay only modeled project expenditure. Working-capital IPO money can reimburse only incremental operating assets net of trade financing. It cannot fund old debt repayments, taxes, general operating losses or dividends merely because cash is needed. The general-corporate remainder is excluded from general liquidity rather than treated as unrestricted debt-service money. No OFS proceeds are added to company cash.

The June deployment schedule contains ₹15.52 crore of deposits. The maturity ladder is ₹2 crore in March 2027, ₹2.5 crore in September 2027, ₹10.02 crore in October 2027 and ₹1 crore in December 2027. The source-bounded stress allocates the full locked deposit balance to the capex pool, a conservative but explicitly unverified allocation because object-by-deposit mapping is absent. It releases principal only at those maturities. The conditional cases assume permitted premature encashment; separate 1% and 3% redemption-cost sensitivities test the cost. Interest income on these deposits is not assumed to fund the project. Neither deposit ownership nor a future maturity proves immediate unrestricted cash access.

The ₹0.1083 crore pledged SBI FD remains outside usable cash unless an explicit release condition is selected. Its value is not added to terminal equity while its associated restriction remains.

## Project debt and existing obligations

March debt is ₹47.5211 crore: ₹18.2983 crore of cash/packing credit and ₹29.2228 crore of term debt, including ₹3.6534 crore of current term maturities. Existing disclosed lending rates are approximately 8.75%, with a small car-loan component at 8.7%. The model uses 8.75% for the aggregated existing and project facilities, while testing higher rates. The aggregation is an approximation, not an instrument-perfect bank schedule.

The source reports a ₹35 crore project sanction, but does not separate current old and new HDFC balances sufficiently to verify undrawn availability. Assuming no intervening draws and a still-effective sanction, subtracting all ₹25.7194 crore current HDFC term balance gives a conservative arithmetic headroom of ₹9.2806 crore. Keeping up to the prior ₹11.3147 crore old HDFC balance gives an upper arithmetic headroom of ₹20.5953 crore. Neither bound is a bank-confirmed facility. The conditional reference uses ₹15.3711 crore, derived from project committed-capital minus capex IPO use as an illustrative debt-allocation proxy; it is not a disclosed loan balance. Both source-bound alternatives are tested.

The first twelve months repay the disclosed current term maturity evenly. Subsequent aggregated old-term amortization closes the modeled balance by month 48. Source term tenures span 48–96 months; this is an accelerated stress schedule, not asserted actual contractual dates. Newly drawn project debt starts amortization at month 6 over a 72-month assumption, with a final payoff at month 78. Interest is charged on opening debt and on new draws in the month drawn. Existing credit renewal is allowed in the reference cases, consistent with annual-renewal facilities; an on-demand call/no-renewal case is a separate stress, not silently imposed as the ordinary base.

Additional flexible borrowing is wholly hypothetical. Reference cases cap outstanding extra debt at ₹80 crore and gross cumulative draws at ₹160 crore, priced at 13% with fees and 36-month maturities. The target grid permits larger stated caps, not evidence of lender consent. Draws solve the current-month fee, interest and tax interaction, rather than filling the cash gap and charging interest only later. Renewal fees and repayments are explicit. No new flexible debt, equity rescue or flexible-debt renewal is allowed after the holding-period exit; the terminal cash test continues long enough to include its maturities. Merely moving a loan beyond year five cannot make it disappear.

## Production, growth and procurement

The verified existing capacity is 8,640 tonnes per year. The proposed plant adds 15,840 tonnes, producing aggregate capacity of 24,480 tonnes. This is supported by the final prospectus and the November 2025 presentation, not inferred from a generic sector expansion. The January 2027 commissioning date is September 2026 management guidance after earlier June/November dates; it is not observed commissioning.

The model permits productive capacity only after the remaining modeled project budget is paid and the chosen commissioning date is reached. A subsequent utilization ramp is explicit. Later expansion purchases have their own 18-month construction lead time. Pending initial-project capacity is included in committed capacity when deciding whether another order is needed, avoiding redundant plant orders. Initial-project commissioning does not prematurely capitalize unrelated future expansion assets.

FY25 actual production is 7,019 tonnes and revenue ₹104.6934 crore. FY26 physical output and realized price were not verified. The FY26 unit base is therefore **7610.4098 constant-FY25-realization equivalent tonnes**, calculated from FY26 revenue ₹113.5147 crore. It is not claimed actual production or a proven organic-volume bridge. Annual demand growth and price growth are separate assumptions. Each modeled year's demand is constrained by productive capacity; unmet demand is not booked as revenue.

Reference variable input cost is the FY26 materials, purchases and inventory-change proxy of ₹80.6109 crore divided by ₹113.5147 crore sales. This includes more than raw potatoes, so the input-price shock is a broad purchased-input stress, not an exact commodity-price forecast. The EBITDA-margin parameter is a **current-scale reference margin**, not a flat realized margin every year. Thirty percent of other operating costs is held fixed against original sales, with the balance varying with output. Annual tables therefore show the actual modeled operating leverage and realized EBITDA.

The source says approximately 80–90% of potatoes are procured in December–March. Seasonal monthly inventory-cover assumptions produce a high March supply buffer and a lower pre-harvest buffer. They are not claims of exact monthly historical stocks. Supplier advances can secure part of that supply, so the model does not demand two complete buffers of potatoes, one in inventory and another in advances. The supply target subtracts the explicitly assumed usable advance backing, subject to a minimum inventory floor. Separate cases remove or halve that usability.

Advances are applied to purchases before the remaining invoices become payables. New cash advances replenish only the stated target; they are not magically refunded as cash. A 50% target-normalization case, full application/release case, stuck-advance case and 150% target case retain different financing consequences. Beginning receivables and payables settle through separate queues. Delayed collections, loss allowances, spoilage, supplier terms, raw-price shocks and demand loss affect cash as well as earnings. The treatment distinguishes a plausible procurement explanation from independently verified expansion use.

## Taxes, capital costs and exceptional claims

The main normalized tax assumption is 29.12%, the rate disclosed in the source tax computation. It assumes no indefinite continuation of current 80IB relief; the exact fiscal expiry was not verified and is not invented. The current-tax benefit sensitivity is explicit. Tax is not credited on losses unless cash realization is demonstrated. Original tax provisions are settled separately from new tax expense, and normal depreciation is not assumed identical to maintenance capex.

Capex GST/import duties are not certified included in the ₹61.30 crore budget. The base does not insert an invented tax payable; the 18% cash-tax stresses show delayed full recovery and no recovery. The FX stress applies a disclosed imported-cost-share approximation to remaining project costs, not a claim that every open invoice remains in euros. Maintenance spending is at least the scenario sales ratio; terminal replacement is no less than modeled depreciation. Growth reinvestment is the greater of explicit capacity plus working-capital needs and an economic NOPAT×growth/ROIC floor.

The source's old tax demand was resolved and the disputed bank fee was already debited; neither is charged again as a new cash outflow. The remaining ₹0.07 crore guarantee is tested separately. Larger legal-payment cases are hypothetical severity tests, not allegations that such debts exist. Employee claims of ₹0.3503 crore remain explicit senior claims. Nonoperating mutual funds, property advances, gold, the related advance and tax-refund receivable total ₹4.8022 crore before recovery assumptions. Conditional exit recovery is tested at 0%, 50% and 100% of source carrying amount. Book value is not asserted market value, and the same asset is not also counted as opening cash.

## Terminal valuation and failure gates

After the 5- or 10-year holding period, the model runs at least twelve months and long enough to test outstanding flexible/project maturities. The first twelve months determine recurring terminal FCFF. Later transition months test survival, cash reserves and repayments. Replacement and growth cash requirements continue through the transition, scaled with terminal growth. Capacity shortfalls prevent capitalizing an undeliverable terminal demand path.

Terminal enterprise value is recurring FCFF divided by WACC less terminal growth. The main WACC is 16%, separately sensitized at 13–20%; terminal growth is tested at 2–5%, always below WACC. The 15% equity hurdle is not used as WACC. An EBITDA-multiple cross-check includes a compression case.

The enterprise-to-common-equity bridge subtracts debt and remaining senior claims, adds only cash above operating requirements and the separately qualified nonoperating recovery, and divides by actual scenario shares. Debt-service earmarked cash is not deducted twice: operating and financing reserves are shown separately, debt is deducted once, and a separate funding-reserve test must pass. No dividend is paid and also retained in exit cash. Cashflows use nominal INR; personal investor taxes are excluded. Entry and exit execution costs are 1% and 2%, with wider-cost sensitivities.

A path failing its liquidity floor, funding cap or terminal replacement/capacity/reserve condition retains all rows up to failure and an explicit reason. It has no ordinary or conditional terminal return. A liquidity-floor shortfall is not an observed corporate default; the liquidity floor itself is an analyst choice. Funded conditional paths retain numeric price/return diagnostics, but ordinary IAS returns stay NS until the identified source gaps are resolved.

Hypothetical new shares are issued as whole shares at a stated price and cost; cash and dilution enter together. The largest test remains below the source authorized-capital ceiling. No future issuance approval or investor funding is represented as obtained.

## Sensitivities, reverse expectations and outcome grid

The complete dataset preserves every tested growth/margin pair, WACC/terminal-growth pair, financing, timing, advance, cash, fee, tax and dilution path. Hurdle entry prices are computed at 12%, 15% and 18%, but are conditional outputs rather than buy limits. Reverse expectations can be read from the funded grid: no supported growth forecast is invented to fill a missing crossing. A finite grid with no crossing does not prove a target is impossible.

The 5× and 10× tests use five- and ten-year horizons, actual modeled shares and financing, execution costs, capacity and terminal cash. A tenfold stock price needs approximately 58.49% annually over five years or 25.89% over ten years before implementation costs. All source-eligible crossing counts remain zero; none is sold as a proven multibagger.

## Reproducibility and model limitations

The current canonical gzip includes inputs, all path assumptions, monthly rows, annual rows, terminal attempts, funded values and failed outcomes. Decimal arithmetic and deterministic gzip timestamps make exact rebuilds possible. Independent arithmetic checks do not import the production engine. In-memory mutation controls verify that key cash, asset, debt, interest, share and terminal-price discrepancies are caught.

Earlier developmental model versions are preserved with their source inputs, runtime and expected canonical hashes. They are labeled superseded, including errors found during construction, and are not alternative approved research. Their outputs can be rebuilt in a fresh directory without modifying the saved originals. Model assurance demonstrates reproducibility and internal arithmetic, not that assumptions will occur or that unavailable primary information has become known.
