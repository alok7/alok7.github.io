# Shree Karni Fabcom Limited: business, governance and execution evidence

Information cutoff: 20 October 2026. This is an authored evidence module, not a claim of investment approval. Monetary amounts are rupees crore unless specified. Source IDs map to the accompanying source registry. Reported facts, management aspirations and analytical inferences are distinguished throughout.

## 1. Business overview

### Legal identity and economic perimeter
Shree Karni Fabcom Limited is the listed issuer, ISIN INE0S4Y01010, NSE symbol SHREEKARNI, CIN L47820GJ2023PLC140106. Its antecedent LLP was incorporated on 7 March 2018; commercial operations began in 2019, conversion to a company occurred on 11 April 2023, and it became public on 20 October 2023. Listing followed on 14 March 2024. This is a young operating and public-market history, not a long-cycle proof of compounder economics. [SKFL-P; SKFL-AR26]

The business manufactures and supplies technical fabrics used in luggage, backpacks, footwear and apparel lining, medical arch support, chairs and upholstery. It is a B2B producer: the end consumer normally buys a customer's product, not a Shree Karni-branded fabric. The economic activity combines yarn procurement, fabric production, processing, finishing and customer-specific delivery. The parent performs knitting and now dyeing; IGK Technical Textiles LLP supplies important weaving/coating/sizing/embossing capabilities. The parent owns 66.67% of IGK. Textron Fabtech LLP is a 45%-owned associate (FY26 AOC1, printed p37/PDF40), not a wholly owned plant whose cash belongs entirely to listed shareholders. Consolidated operating performance must therefore be separated from owner-attributable profit and distributable cash. Eliminating intercompany transactions is essential. [SKFL-P pp128–134; SKFL-AR26 pp36–42 and financial notes]

This is physical manufacturing with meaningful fixed assets, inventory and receivable funding. It is not an asset-light platform, a contracted utility or an EPC order-book business. It carries raw-material costs and customer collection risk even when incremental demand can use installed machinery. Procurement purchase orders and forecasts are not equivalent to long-duration take-or-pay contracts.

### How customers decide and what creates cash
A buyer evaluates fabric strength, colour consistency, coating quality, waterproof or other performance attributes, approved specifications, delivery reliability and price. Process coordination and quality control can make a qualified supplier useful. The economic benefit accrues only if that usefulness translates into repeat orders at prices covering raw material, conversion, depreciation, finance costs and collection risk. Famous customer logos alone do not establish pricing power or exclusivity.

The prospectus identifies a highly competitive, fragmented industry and purchase-order based selling without long-term customer contracts. The company also lacked a formal binding service agreement with IGK at IPO and did not generally have binding raw-material supply contracts. Integration lowers coordination exposure but does not make polyester or nylon prices controllable. The absence of long contracts need not prevent a good manufacturing business, but it changes the duration of the cash-flow claim: each selling cycle has to be earned again. [SKFL-P pp31–33,132–134,219]

### Facility status is not interchangeable with product ambition
Dyeing commenced commercially on 6 April 2025, according to a signed exchange disclosure. A Noida facility commenced on 27 June 2025. These are actual milestones, unlike capacity proposals. However, the board approved closure of the stitching facility on 24 June 2026, with completion expected by the end of that month. FY26 turnover of the unit was ₹16.29 crore, 8.03% of the stated company turnover, and net worth ₹10.47 crore, 9.60%. The disclosure says a sale agreement is not applicable. Those are economic scale figures, not cash-sale proceeds. Do not silently retain closed stitching capacity in a growth model or assume its net worth is realizable cash. [SKFL-DYE25; SKFL-NOIDA25; SKFL-CLOSE26]

## 2. Moat and industry position

### Integration: a useful capability, not a monopoly
Mechanism: weaving/knitting, coating and dyeing coordination can reduce outsourced lead times and rejects and improve specification control. Evidence: operating IGK production, commercial dyeing commissioning and a multi-process portfolio. Durability: these facilities and trained processes take capital and time to replicate. Failure mode: capable competing mills can buy similar equipment; excess industry capacity or customer dual-sourcing can pass savings to buyers. Public evidence does not quantify a persistent cost gap against the next-best supplier. Therefore integration supports a contestable operating advantage, not an automatic high-moat score. [SKFL-P; SKFL-PPT25; SKFL-DYE25]

### Qualification: stronger evidence than logos, weaker than guaranteed revenue
The signed 27 June 2025 exchange announcement states that Shree Karni cleared Walmart's audit and became an approved vendor in India. In November 2025 management discussed Walmart and Target vendor codes and hoped these customers could contribute 20% of business in the following year, conditional on tariff conditions. Approval demonstrates a capability threshold. It does not disclose minimum purchases, duration, exclusivity, price protection, margins or cash advances. The June 2026 stitching closure undermines a straight-line extrapolation of the finished-product strategy without proving vendor approval itself was revoked. A responsible report preserves both the qualification achievement and the subsequently changed monetization route. [SKFL-WALMART25; SKFL-CALL25 pp15–17; SKFL-CLOSE26]

### Concentration and switching
FY23 top-five customer concentration was 43.54%; top ten were 61.12%. For the eight months ended November 2023, corresponding figures were 60.30% and 74.23%. These are dated concentration measures, not FY26 customer shares. The partial-period increase may reflect seasonality as well as concentration, but it leaves insufficient evidence for broad customer diversification. FY23 Maharashtra contributed 43.02% and Gujarat 26.44%, with the top five states accounting for 84.78%. FY23 top-ten suppliers were 46.97% of purchases. Current customer/supplier concentration and binding contract duration remain open items. [SKFL-P pp31–33,132–134]

A customer can value reliable delivery and still negotiate aggressively. No verified market-share denominator establishes national leadership in the exact product set. Management's narrow positioning claims must not be expanded into a general technical-textiles market monopoly. Retention, price resets and rejection data over several years would be more probative than a customer logo page.

### Comparative moat judgment
Nobletex is a closer process/product comparator than a civil contractor. Mayur Uniquoters is an adjacent coated-fabric producer whose automotive qualification and export mix make its economics informative but not directly transferable. SRF's coated/laminated-fabric operations are relevant, while SRF's chemicals earnings are not. Garware's specialized application development illustrates what deeper intellectual-property/customer-solution differentiation can look like, but it is not a like-for-like luggage-fabric peer. The separate peer module specifies period, scope and unavailable cash data rather than assigning unverified multiples.

Suggested MOAT: 5/10, medium confidence. Useful integration and demonstrated vendor qualification coexist with replicable machinery, concentrated purchase-order demand and unproven sustained pricing advantage. A score of 7 would require clearer evidence of superior retained economics and switching costs, not simply larger installed capacity.

## 3. Revenue growth and scale

### Historical expansion is real; reporting scope matters
The IPO financial KPI table gives revenue ₹32.8742 crore in FY21, ₹83.5736 crore in FY22 and ₹126.9465 crore in FY23. The latest annual report gives FY26 revenue ₹203.5441 crore versus ₹166.9777 crore in FY25. These represent substantial absolute scaling, but the five-year starting point includes the pandemic period and the legal/group perimeter evolved. The financial reconstruction establishes a three-year group CAGR of 17.0431%, while the preferred parent-only series gives 16.9298%; both fall in the framework starting REV7 band. These are reconciled, perimeter-qualified series, with the parent series preferred over the acquisition-affected group series; neither is a measured organic-growth series. A raw high CAGR from FY21 must not be selected simply because it scores better. Nor should an arbitrary acquisition discount be invented when organic growth cannot be measured. [SKFL-P p98; SKFL-AR26 p18]

FY26 revenue grew about 21.90%. That is commercially meaningful and below the minimum 25% growth aspiration stated in November 2025. One annual deviation is not evidence of dishonesty; it does show why guidance is not a substitute for recorded revenue. The latest half-year comparisons and owner-attributable profit bridge should be taken from audited financial reconstruction, not this business module. Profit-margin improvement or new capex cannot earn REV points.

### Driver bridge
1. Production volume increased as woven capacity and utilization expanded.
2. Vertical integration added dyeing capability and potential savings; it does not automatically add an equal amount of third-party consolidated revenue because internal processing must be eliminated.
3. Higher-value nylon or specialty products can lift rupees per metre, but this is mix, not the same as physical volume.
4. Finished bags added a new business line that was subsequently curtailed through stitching closure.
5. Contract manufacturing may support revenue without identical owned-machine output, while requiring supplier quality control and working capital.
6. Imported/distributed technical knits under the Italian partnership create a different gross-margin and capital-intensity mix from proprietary manufacturing.

Management said in November 2025 that product prices could range from approximately ₹30 fabric to ₹100 nylon and that additional revenue could come with relatively few machines. This is evidence that product mix and bottlenecks matter, not a valid universal realized selling price. Applying one price to all weaving, coating and dyeing throughput would double-count material moving through several stages. [SKFL-CALL25 pp6,17]

### Capacity units and utilization
Prospectus woven capacity was 1.04 million metres in FY22 and 12.48 million in FY23, with production 0.535822 million and 10.637544 million respectively. Knitting was stated in kilograms: installed 945,000 kg and production 671,000 kg in FY23. The August 2025 presentation's knitting chart shows figures four times those kilogram numbers, suggesting a conversion basis; without a clearly verified unit caption, do not treat the charts as directly comparable kilograms. Woven FY25 chart capacity/production was 21.2m/15.118m, approximately 71.31% utilization; coating capacity/production 33.6m/29.307m, or 87.22%. These are different process stages, not additive finished-fabric capacities. The same presentation's FY25 backpack capacity 1 million/production 114,000 means 11.4% utilization, an early warning that installed capacity did not prove demand. [SKFL-P p132; SKFL-PPT25 PDF12]

## 4. Runway and demand durability

### Addressable demand versus bankable demand
Luggage, footwear, upholstery and functional apparel offer multiple applications. Travel and replacement demand can expand over time; premium or recycled materials can change product mix. Nevertheless, global technical-textiles TAM is much broader than the products, certifications, geography and customer channels this company can actually address. No defensible exact company market share or five-year accessible market denominator was located. Demand breadth earns some runway credit but not a guaranteed growth trajectory.

In November 2025 management described luggage as 50–60% of revenue and targeted no industry above 30% by FY27/FY28. This is a diversification goal, not a current result. Three-to-six-month customer forecasts are not binding backlog. Responsive delivery requires ready inventory and therefore financing before customers pay. Management's ₹300 crore revenue possibility included contract manufacturing; it is not a verified owned-capacity ceiling or a funded order book. [SKFL-CALL25 pp5,15,17]

### Italian agency: access, not owned intellectual property
The 6 May 2026 announcement describes an exclusive arrangement to promote, brand and sell Italian technical knitted fabrics in India. The annual report identifies YEGOF of the Carvico Group. This may broaden access to nylon/spandex and polyester/spandex products. The partner's famous customers do not automatically become direct Shree Karni customers. Minimum purchases, commission schedule, margin, duration and termination economics were not verified. This is a real commercial avenue with unquantified earnings, not a contracted annuity. [SKFL-ITALY26; SKFL-AR26 p6]

### Original project rights versus available funding
The IPO proposed ₹30.7048 crore for dyeing, ₹1.8682 crore for bag machinery, ₹5 crore for working capital and ₹3.5 crore for general corporate purposes. Dyeing was designed for 80,000 metres/day. These original proposal figures are not verified October 2026 output, replacement cost or remaining cash. Prospectus p81 reports net proceeds ₹41.0730 crore whereas its object amounts sum to ₹41.5730 crore and p82 uses that latter total. Preserve and reconcile this ₹0.5 crore source inconsistency against later certified utilization rather than force a balancing plug. Project estimates were not independently bank-appraised. [SKFL-P pp81–88]

All 315,000 promoter warrants were exercised in three 105,000-share tranches on 25 August, 29 August and 2 September 2026. Each primary filing explicitly records receipt of ₹6.024375 crore, a cumulative ₹18.073125 crore after March. The earlier 25% subscription payment must not be counted again. Issued shares became 7,543,750. November 2025 management's suggestion of converting promoter loans does not override the later receipt filings. Conversely, gross receipt is not current cash and does not establish that no debt was subsequently repaid. The monthly funding model must retain that reconciliation uncertainty. [SKFL-W1/W2/W3]

Suggested DUR: 5/10, medium confidence. Existing fabric capabilities, multiple applications and the agency agreement support some runway. Concentrated demand, the closure of the stitching route, uncontracted customers and qualification requirements prevent calling it secure. Returns on incremental capital belong in CAP, not an overlapping discretionary DUR penalty.

## 5. Execution: original promises versus delivery

| Original commitment | Outcome through the cutoff | Interpretation |
|---|---|---|
| IPO dyeing commercial production November 2024, pp86–87 | 23-Nov-2024 postponed to March 2025; 31-Mar-2025 postponed to first week of April; commissioned 6-Apr-2025 | Delivered approximately five months late, not an unbuilt plant. |
| IPO bag machinery commercial production September 2024, p88 | 31-January-2025 commercial production with 200 machines [SKFL-BAGS25]; FY25 backpack utilization only 11.4%; stitching closure approved June 2026 | Implementation did not establish durable commercial success. |
| Noida facility announced May 2025 | Commercial production disclosed 27-Jun-2025 | An actual commissioning achievement, not proof of profitable utilization. |
| Walmart qualification June 2025 and 20% Walmart/Target contribution aspiration November 2025 | Vendor approval disclosed, no minimum orders; subsequent stitching closure | Do not mark the 20% aspiration as delivered or vendor qualification as automatically revoked. |
| November 2025 minimum 25% growth aspiration and 12–13% PAT margin target | FY26 revenue growth 21.90%; annual profit margin below the target | Meaningful growth, but numerical aspirations not achieved. Owner profit and profit before non-controlling interests are separately identified in the financial analysis. |
| November 2025 reference to 30% margin | Transcript specifically corrected it to gross margin | Do not invent a 30% net-profit promise. |
| Promoter warrant exercise | Three completed cash-receipt/allotment filings in August/September 2026 | Funding completion is proven; capital deployment quality remains separate. |

The closure disclosure cites operational optimization, profitability and geopolitical risk. This is a plausible corrective response in a tariff-sensitive export strategy. Credit the willingness to adapt, while requiring evidence of saved cash, asset recovery and profitable remaining operations. Neither automatic praise nor an accusation of fraud follows from closure alone. [SKFL-CLOSE26]

Final EXEC: 4/10, medium confidence. Commissioning, revenue scaling and completed promoter funding are meaningful counterevidence. However, delayed ramp-up, low backpack utilization and closure of the recently launched stitching route constitute realized capital-execution misses, not merely future warning risks. This is a below-average delivery assessment, not a misconduct allegation. An explained strategic correction can be sensible while the preceding investment outcome remains weak.

## 6. Governance, allocation and minority treatment

### Promoter control and ownership reconciliation
Four promoter executives sit on a seven-member board with three independent directors. Rajiv Lakhotia, Radhe Shyam Daga, Manoj Kumar Karnani and Raj Kumar Agarwal each exercised 26,250 warrants in each of the three 2026 tranches. March actual promoter ownership was 5,002,700 shares out of 7,228,750, or 69.21%. The 70.49% in the March filing's diluted column assumed then-unexercised warrants; it was not issued ownership at that date. AGM records at the 23-September-2026 cutoff verify promoter holdings of 5,317,700 out of 7,543,750, or 70.4915%. Public shares stayed 2,226,050. [SKFL-SHP26; SKFL-AGM26; SKFL-W1/W2/W3]

The March shareholding filing states no promoter pledge, NDU or other encumbrance. That is a dated finding, not proof of October status. This module did not independently locate the September shareholding pattern. The AGM confirms capital and holdings but does not substitute for all encumbrance disclosures.

### Explicitly non-arm's-length land lease
AOC2 explicitly identifies a land lease to IGK Technical Textiles LLP as not at arm's length. Parent-owned land at Umalla/Jhagadia/Bharuch is leased for 27 years at ₹5,000 annually. Board approval was 29-May-2025 and shareholder approval 30-September-2025. The disclosed justification is solar generation, energy savings and sharing benefits with the parent under a mutual understanding. A quantified, enforceable savings-sharing formula was not located. Because IGK is only 66.67% owned, the economic benefit also accrues to outside LLP interests. This creates a legitimate minority-allocation question, not proof of improper diversion. [SKFL-AR26 p42/PDF45]

The 2026 AGM RPT resolution authorized up to ₹30 crore in goods/services and ₹0.0005 crore annual rent. FY26 goods/jobwork transactions were ₹15.9395 crore, and June-quarter 2026 jobwork ₹2.3684 crore. Importantly, the signed voting record shows interested promoters cast zero votes on resolution 4; 311,700 public votes supported it, with none against. Disclosure and disinterested approval are meaningful counterevidence. They do not replace an independent commercial valuation of the unpriced benefit-sharing arrangement. Monitor realized energy savings, their allocation and settlement terms. [SKFL-AR26 pp62–66; SKFL-AGM26 PDF15]

### Non-core allocation and funding obligations
The financial notes disclose venture/angel-fund investments and uncalled commitments. The audited schedules show ₹2.2664 crore of non-operating fund investments and ₹2.2311 crore uncalled commitment at 31-March-2026. Such assets may generate value, but they compete with manufacturing and working capital for funding. Uncalled commitments are possible cash uses, not free cash. They are not automatically related-party abuse or prohibited IPO use; that claim would require source-of-funds evidence. [SKFL-AR26 financial notes]

### Remuneration, personnel and audit
Four promoter executives received ₹5 lakh a month each, ₹60 lakh annually each and ₹2.4 crore combined, with no FY26 increase disclosed. Compare remuneration to owner profit and operating cash, not only sales. Independent director Sriyans Lunia ceased on 31-May-2025 because of death; Pankaj Mohta was appointed 8-September and regularized 30-September-2025. That is not an adverse director resignation. The company secretary ceased 5-August-2025 and was reappointed 4-November-2025. Any September 2026 change needs a separate primary filing before inclusion. [SKFL-AR26 pp20–21,45–46]

The annual report describes an unqualified statutory opinion and no auditor-reported fraud. The actual audit text and financial notes govern; a clean opinion does not certify good capital allocation. The LLP audit-trail exemption is an applicability point, not evidence of concealed transactions by itself. Secretarial compliance test-checking is not a blanket guarantee that no lapse occurred. [SKFL-AR26]

### Precisely bounded adverse evidence
The NSE email dated 29-October-2025, disclosed by the issuer on 30-October, warned that notice of a 31-December-2024 analyst meeting was not submitted two working days in advance. This is a documented disclosure-timing lapse. It is not a financial penalty or an allegation of financial fraud. It supports closer procedural monitoring without justifying a catastrophic governance label. [SKFL-WARN25 PDF2]

The IPO prospectus records a criminal miscellaneous complaint initiated by the issuer against a land counterparty for alleged failure to execute a sale deed after payment of ₹34.25 lakh and a demand for a further ₹20 lakh. The issuer was the complainant, not the accused. It was pending at the prospectus date; current resolution is unknown. Historical nil adverse-litigation tables should not be represented as current legal clearance. [SKFL-P p222]

Suggested GOV: 5/10, medium confidence. The concessionary subsidiary lease, unquantified savings-sharing, non-core allocation and process warning warrant concern. Disclosure, disinterested approval, completed promoter cash subscription and the absence of substantiated fraud in reviewed sources are real counterweights. GOV of 3 or lower and a fraud gate are not supported by these facts. GOV of 7 would require stronger evidence of priced minority-fair treatment and disciplined deployment.

### Evidence that would change the judgment
Priority gaps are current customer concentration, executed Italian agency terms, post-closure costs and asset recovery, product-level volumes and realizations, quantified solar benefit allocation, latest encumbrance disclosures and the cash/debt use of promoter subscription receipts. Durable cash-backed growth and owner-per-share gains would improve the case. More capacity and customer logos alone would not. Recurring collection strain, demonstrably noncommercial RPT benefits or unexplained deviations from approved uses would weaken it.
