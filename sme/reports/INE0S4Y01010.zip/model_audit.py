from pathlib import Path
import json,gzip,hashlib
from decimal import Decimal as D
from independent_replay import check
P=Path(__file__).resolve().parent
b=(P/'canonical_paths.json.gz').read_bytes();c=json.loads(gzip.decompress(b));count=check(c)
assert len({p['path_id'] for p in c['paths']})==len(c['paths'])
assert c['inputs']['shares']==7543750
assert D(c['inputs']['gross_subsequent_warrant_receipt'])==D('6.024375')*3
assert all(p['spec']['opening_new_shares']==0 for p in c['paths'])
assert all(D(p['spec']['opening_cash_increment'])+D(p['spec']['opening_debt_repayment'])<=D(c['inputs']['gross_subsequent_warrant_receipt']) for p in c['paths'])
assert D(c['inputs']['opening']['term_debt'])+D(c['inputs']['opening']['wc_debt'])+D(c['inputs']['opening']['demand_debt'])==D('98.2332')
assert all(p['terminal'] is None for p in c['paths'] if p['failure'])
adjustments=[D(p['terminal']['dcf_signed_opening_cash_adjustment']) for p in c['paths'] if p['terminal']];assert any(v<0 for v in adjustments) and any(v>0 for v in adjustments)
out={'status':'PASS','checks':count+9,'path_count':len(c['paths']),'monthly_rows':sum(len(p['monthly']) for p in c['paths']),'canonical_sha256':hashlib.sha256(b).hexdigest(),'controls':['Actualissued7543750, nofuture315000warrants','Grossreceiptallocationmutuallyexclusive','Debt98.2332withoutguaranteedoublecount','FailuresretainNULLordinaryreturns','Rawindependentrecurrencesandterminalfunding']};(P/'model_audit.json').write_text(json.dumps(out,indent=2)+'\n');print(out)
