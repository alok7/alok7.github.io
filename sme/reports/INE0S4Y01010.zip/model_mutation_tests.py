from pathlib import Path
from copy import deepcopy
import json,gzip
from independent_replay import check
P=Path(__file__).resolve().parent;c=json.loads(gzip.decompress((P/'canonical_paths.json.gz').read_bytes()));p=next(x for x in c['paths'] if x['terminal']);sample={'inputs':c['inputs'],'paths':[p]};check(sample);cases=[]
for label,section,key in [('Cashphantom','row','cash_close'),('Receivablemisstatement','row','ar_close'),('Supplierpaymentomitted','row','supplier_cash'),('Demanddebtomitted','row','demand_debt_close'),('Fundcommitmentnotasset','row','fund_assets_close'),('Currentdrawinterestomitted','row','interest'),('Cashreserveaddedtwice','terminal','cash_addable'),('NCIclaimomitted','terminal','equity_value'),('Terminalgrowthinvestmentomitted','terminal','terminal_growth_capex'),('Sharecountwrong','terminal','price_per_share'),('Signedreservegapclipped','terminal','dcf_signed_opening_cash_adjustment')]:
 a=deepcopy(sample);x=a['paths'][0]['monthly'][0] if section=='row' else a['paths'][0]['terminal'];from decimal import Decimal as D;x[key]=str(D(x[key])+D('1'))
 try:check(a)
 except AssertionError:cases.append({'test':label,'status':'DETECTED'})
 else:raise AssertionError('Mutation escaped '+label)
(P/'model_mutation_results.json').write_text(json.dumps({'status':'PASS','negative_controls':cases,'count':len(cases)},indent=2)+'\n');print('PASS',len(cases),'negativecontrols')
