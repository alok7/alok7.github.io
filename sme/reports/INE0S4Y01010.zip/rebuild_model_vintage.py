"""Reproduce a retained development model in a new explicit directory."""
from pathlib import Path
import argparse,shutil,subprocess,sys,json,hashlib
P=Path(__file__).resolve().parent
ap=argparse.ArgumentParser();ap.add_argument('vintage');ap.add_argument('--output',required=True);a=ap.parse_args();src=P/'model_vintages'/a.vintage;dest=Path(a.output);dest.mkdir(parents=True,exist_ok=False)
for name in ['model.py','scenarios.py','run_model.py','model_source_anchors.json']:shutil.copy2(src/name,dest/name)
subprocess.run([sys.executable,str(dest/'run_model.py')],cwd=dest,check=True)
h=hashlib.sha256((dest/'canonical_paths.json.gz').read_bytes()).hexdigest();expected=json.loads((src/'manifest.json').read_text())['expected_canonical_sha256'];assert h==expected,(h,expected)
print(json.dumps({'status':'PASS','vintage':a.vintage,'canonical_sha256':h}))
