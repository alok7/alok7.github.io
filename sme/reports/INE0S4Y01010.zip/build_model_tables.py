from pathlib import Path
from decimal import Decimal as D
import json,gzip
P=Path(__file__).resolve().parent;c=json.loads(gzip.decompress((P/'canonical_paths.json.gz').read_bytes()));ps=c['paths']
def fmt(x):return f'{D(x):.2f}'
def cell(p):return 'FAIL M'+str(p['failure']['month']) if p['failure'] else fmt(D(p['terminal']['irr'])*100)+'% / ₹'+fmt(p['terminal']['dcf_per_diluted_share'])
def table(headers,rows):return '| '+' | '.join(headers)+' |\n| '+' | '.join(['---']*len(headers))+' |\n'+'\n'.join('| '+' | '.join(map(str,r))+' |'for r in rows)
out=['# Linked model sensitivity tables','All outputs below are conditional research experiments, not source-eligible IAS or price targets. A failed path has no ordinary return. M means month from the assumed November2026 opening; breaches concern an analyst liquidity reserve, not observed default. A cell with two numbers is investor IRR / conditional DCF per fully diluted share.']
for title,label,rowkey,colkey in [('Growth versus exit multiple','Growth / multiple grid','volume_growth','terminal_multiple'),('Margin versus WACC','Margin / WACC grid','ebitda_margin','wacc'),('WACC versus terminal growth','WACC / terminal growth grid','wacc','terminal_growth')]:
 a=[p for p in ps if p['spec']['label']==label];rv=sorted({p['spec'][rowkey]for p in a},key=D);cv=sorted({p['spec'][colkey]for p in a},key=D);lookup={(p['spec'][rowkey],p['spec'][colkey]):p for p in a};out+=['## '+title,table([rowkey+' / '+colkey]+cv,[[r]+[cell(lookup[(r,v)])for v in cv]for r in rv])]
funded=[p for p in ps if p['terminal']];selected=[p for p in funded if p['spec']['kind']in['source_bounded','recovery'] or p['terminal']and D(p['terminal']['irr'])>=D('.15')]
out+=['## Hurdle-price sensitivity',table(['Path','Condition','12% hurdle','15% hurdle','18% hurdle','Realized sales CAGR','Unserved sales'],[[p['path_id'],p['spec']['label']]+['₹'+fmt(p['terminal']['hurdle_prices'][h])for h in ['0.12','0.15','0.18']]+[fmt(D(p['summary']['realized_revenue_cagr'])*100)+'%',fmt(p['summary']['unserved_sales'])]for p in selected]),'Quoted entry prices already allow the assumed 1% entry cost and 1% exit friction. No supported base-case entry range is asserted because the reference base path fails and current funding data are incomplete.']
out+=['## Reverse expectations and target feasibility','Only SKF087 among the tested 162 conditional paths crosses the 15% hurdle; it is an assumed financing/dilution target experiment, not an endorsed required-growth solution. Full scenario, realized growth and capacity loss are preserved. None of the tested five/ten-year paths reaches 5× or 10× after the stated implementation friction. This finite grid is not a proof no future outcome is possible.']
(P/'model_sensitivity_tables.md').write_text('\n\n'.join(out)+'\n')
