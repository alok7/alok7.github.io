from decimal import Decimal as D

def calculate(f,m):
 out={'series':{},'growth':{},'valuation':{},'issued_capital_basis':'Actual completed September2 allotments, not stale trading-master capital'}
 for scope in ['consolidated','standalone']:
  seq={**f['predecessor_restated'],**f[scope]};rows=[]
  for year,r in seq.items():
   r={k:D(v)for k,v in r.items()};row={'fy':year,**r};row['ebit']=r['pbt']+r['finance_cost']-r['other_income'];row['ebitda']=row['ebit']+r['da'];row['ebitda_margin']=row['ebitda']/r['revenue'];row['normalized_pat']=(row['ebit']-r['finance_cost'])*(1-D(f['normalization_assumptions']['tax_rate']));row['fcf']=r['cfo']-r['cash_capex'];row['current_share_owner_eps']=r['pat_owner']*10000000/D(m['issued_shares']);row['basis']='Restated predecessor LLP'if year<'FY24'else scope+' full-year, FY24 split-period reconciled'
   if rows:
    prev=rows[-1];row['sales_addition']=r['revenue']-prev['revenue'];row['sales_growth']=r['revenue']/prev['revenue']-1;row['ebitda_change']=row['ebitda']-prev['ebitda'];row['sales_effect']=row['sales_addition']*(row['ebitda_margin']+prev['ebitda_margin'])/2;row['margin_effect']=(row['ebitda_margin']-prev['ebitda_margin'])*(r['revenue']+prev['revenue'])/2;row['average_roe']=r['pat_owner']/((r['equity']+prev['equity'])/2)
   rows.append(row)
  out['series'][scope]=rows
 a=out['series']['consolidated'][-1];mc=D(m['quote']['close'])*D(m['issued_shares'])/10000000
 out['valuation']={'market_cap':mc,'owner_pat_current_share_pe':mc/a['pat_owner'],'current_share_eps':a['current_share_owner_eps'],'book_multiple_including_received_warrant_deposit':mc/a['equity'],'gross_debt':a['debt'],'cash':a['cash'],'fd_not_verified_available':a['fd'],'ev_without_nonop_adjustments':mc+a['debt']-a['cash']+a['nci'],'ev_ebitda_without_nonop_adjustments':(mc+a['debt']-a['cash']+a['nci'])/a['ebitda'],'qualification':'Current equity share count paired with dated March debt/cash/NCI is a reference bridge only, not observed current enterprise value. Subtract associate/funds only if separately valued, and do not use restricted FD as free cash.'}
 return out
