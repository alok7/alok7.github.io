"""Independent stock-flow/claims/valuation checker. Does not import model.py."""
from pathlib import Path
from decimal import Decimal as D,localcontext
import json,gzip,hashlib
P=Path(__file__).resolve().parent
Z=D(0);ONE=D(1);CR=D(10000000)
def d(x):return x if isinstance(x,D) else D(str(x))
def check(c):
 count=0
 def eq(a,b,label):
  nonlocal count
  count+=1
  assert abs(d(a)-d(b))<=D('1e-23')*max(ONE,abs(d(b))), (label,a,b)
 with localcontext() as ctx:
  ctx.prec=34
  i=c['inputs'];o={k:d(v) for k,v in i['opening'].items()}
  for p in c['paths']:
   s=p['spec'];rows=p['monthly'];n=p['years']*12
   assert bool(p['failure']) != bool(p['terminal']);count+=1
   for idx,r in enumerate(rows):
    r={k:({kk:d(vv) for kk,vv in v.items()} if k=='opening' else d(v) if k not in ['date','phase'] else v) for k,v in r.items()};a=r['opening'];m=int(r['month']);blend=min(ONE,d(m)/d(s['working_capital_transition_months']))
    eq(r['ar_close'],a['ar']+r['sales']-r['collections']-r['receivable_writeoff'],'AR identity');eq(r['inventory_close'],a['inv']+r['purchases']-r['material']-r['inventory_writeoff'],'inventory');eq(r['ap_close'],a['ap']+r['purchases']-r['supplier_cash'],'AP');eq(r['other_assets_close'],a['other']+r['other_assets_change'],'otherassets')
    eq(r['collections'],max(Z,a['ar']+r['sales']-(o['receivables']*(ONE-blend)+r['sales']*d(s['receivable_days'])/30*blend)),'collections target')
    eq(r['purchases'],max(Z,r['material']+(o['inventory']*(ONE-blend)+r['material']*d(s['inventory_days'])/30*blend)-a['inv']),'purchase target')
    eq(r['supplier_cash'],max(Z,a['ap']+r['purchases']-(o['payables']*(ONE-blend)+r['purchases']*d(s['payable_days'])/30*blend)),'supplier target')
    eq(r['material'],r['sales']*d(s['material_ratio'])*(ONE+d(s['material_price_shock'])),'material')
    eq(r['opex'],r['sales']*max(Z,ONE-d(s['ebitda_margin'])-d(s['fixed_cost_ratio'])-d(s['material_ratio']))+o['sales']/12*d(s['fixed_cost_ratio']),'opex')
    eq(r['ebitda'],r['sales']-r['material']-r['opex'],'EBITDA');eq(r['ebit'],r['ebitda']-r['da']-r['receivable_writeoff']-r['inventory_writeoff'],'EBIT')
    eq(r['interest'],(a['term']*d(s['term_rate'])+a['wc']*d(s['wc_rate'])+a['demand']*d(s['demand_rate'])+a['flex']*d(s['flex_rate'])+r['flex_draw']*d(s['flex_rate']))/12,'interest incldraw')
    eq(r['current_draw_interest'],r['flex_draw']*d(s['flex_rate'])/12,'currentinterest');eq(r['tax'],max(Z,r['ebit']-r['interest'])*d(s['tax_rate']),'tax')
    eq(r['term_debt_close'],a['term']-r['term_principal'],'term');eq(r['wc_debt_close'],a['wc']-r['wc_principal'],'WCdebt');eq(r['demand_debt_close'],a['demand']-r['demand_principal'],'demanddebt');eq(r['flex_debt_close'],a['flex']+r['flex_draw']-r['flex_principal'],'flex');eq(r['debt_close'],sum(r[k] for k in ['term_debt_close','wc_debt_close','demand_debt_close','flex_debt_close']),'totaldebt')
    eq(r['restricted_cash_close'],a['restricted']-r['restricted_release'],'restrictedcash');eq(r['claims_close'],a['claims']-r['claims_payment'],'claims');eq(r['fund_assets_close'],a['fund_assets']+r['fund_payment'],'fundasset');eq(r['fund_commitment_remaining'],a['fund_remaining']-r['fund_payment'],'fundcommit')
    eq(r['remaining_nonop_close'],a['remaining_nonop']-r['nonop_recovery'],'nonop');eq(r['shares_close'],a['shares']+r['equity_shares'],'shares');eq(r['equity_cash'],r['equity_shares']*d(s['equity_price'])/CR*(ONE-d(s['equity_fee'])),'equitycash')
    eq(r['flex_fee'],r['flex_draw']*d(s['flex_fee']),'drawfee');eq(r['capex'],r['maintenance_capex']+r['growth_capex'],'capex')
    inflow=sum(r[k] for k in ['collections','asset_sale','restricted_release','nonop_recovery','equity_cash','flex_draw']);outflow=sum(r[k] for k in ['supplier_cash','opex','other_assets_change','interest','tax','sale_tax','capex','term_principal','wc_principal','demand_principal','flex_principal','claims_payment','roll_fee','annual_bank_fee','closure_cost','contingent_payment','fund_payment','flex_fee','dividend'])
    eq(r['cash_close'],a['cash']+inflow-outflow,'grosscash');eq(r['reserve'],max(d(s['cash_floor']),(r['material']+r['opex'])*d(s['reserve_months'])),'reserve');eq(r['shortfall'],max(Z,r['reserve']-r['cash_close']),'shortfall');eq(r['required_cash_reserve_change'],r['reserve']-(d(rows[idx-1]['reserve']) if idx else r['reserve']),'reserveinvestment');eq(r['valuation_fcff'],r['fcff']-r['required_cash_reserve_change'],'valuationFCFF');eq(r['fcff'],r['collections']-r['supplier_cash']-r['opex']-r['other_assets_change']-max(Z,r['ebit'])*d(s['tax_rate'])-r['capex'],'FCFF')
    for key in ['collections','purchases','supplier_cash','ar_close','inventory_close','ap_close','shares_close','debt_close','restricted_cash_close','fund_commitment_remaining']:
     assert r[key]>=-D('1e-23'),key;count+=1
    if idx:
     prev=rows[idx-1]
     for key,closed in [('cash','cash_close'),('ar','ar_close'),('inv','inventory_close'),('ap','ap_close'),('term','term_debt_close'),('wc','wc_debt_close'),('demand','demand_debt_close'),('flex','flex_debt_close'),('shares','shares_close'),('fund_assets','fund_assets_close'),('fund_remaining','fund_commitment_remaining')]:eq(a[key],prev[closed],'opening carry '+key)
   if p['failure']:
    eq(p['failure']['shortfall'],rows[-1]['shortfall'],'failure terminal');assert p['summary']['terminal_price'] is None and p['summary']['irr'] is None;count+=1
   else:
    t={k:d(v) if isinstance(v,str) else v for k,v in p['terminal'].items()};last=rows[n-1];ny=rows[n:n+12];w=d(s['wacc']);g=min(d(s['terminal_growth']),max(Z,sum(d(r['sales']) for r in ny)/d(t['revenue'])-ONE));ly=rows[n-12:n]
    eq(t['revenue'],sum(d(r['sales']) for r in ly),'terminalrevenue');eq(t['ebitda'],sum(d(r['ebitda']) for r in ly),'terminalEBITDA');eq(t['next_year_fcff'],sum(d(r['valuation_fcff']) for r in ny),'nextFCFF')
    nopat=sum(max(Z,d(r['ebit']))*(ONE-d(s['tax_rate'])) for r in ny);da=sum(d(r['da']) for r in ny);maint=max(sum(d(r['maintenance_capex']) for r in ny),d(last['ppe_close'])*d(s['replacement_rate']));growthcap=max(sum(d(r['growth_capex']) for r in ny),t['revenue']*g*d(s['capex_per_sales']));wc=max(Z,sum(d(last[k]) for k in ['ar_close','inventory_close','other_assets_close'])-d(last['ap_close']))*g;reservecap=max(Z,d(ny[-1]['reserve'])-d(last['reserve']),d(last['reserve'])*g);steady=nopat+da-maint-growthcap-wc-reservecap;earned=min(t['next_year_fcff'],steady)
    for key,v in [('terminal_nopat',nopat),('terminal_da',da),('terminal_maintenance',maint),('terminal_growth_capex',growthcap),('terminal_working_capital_investment',wc),('terminal_cash_reserve_investment',reservecap),('terminal_steady_fcff',steady),('terminal_earned_fcff',earned)]:eq(t[key],v,key)
    eq(t['terminal_growth_applied'],g,'capacity-constrainedterminalgrowth');eq(t['terminal_ev_dcf'],max(Z,earned)/(w-g),'DCFterminal');eq(t['terminal_ev_multiple'],t['ebitda']*d(s['terminal_multiple']),'exitEV');eq(t['cash_addable'],max(Z,d(last['cash_close'])-d(last['reserve'])),'cashnotdouble');eq(t['equity_value'],max(Z,t['terminal_ev_multiple']-d(last['debt_close'])-d(last['claims_close'])-d(s['nci_claim'])+t['cash_addable']+d(s['associate_recovery'])+d(last['fund_assets_close'])*d(s['fund_terminal_recovery'])),'equityclaims');eq(t['price_per_share'],t['equity_value']*CR/d(last['shares_close']),'price')
    pvoper=sum(d(r['valuation_fcff'])/(ONE+w)**(d(r['month'])/12) for r in rows[:n]);pvtv=t['terminal_ev_dcf']/(ONE+w)**p['years'];pvfund=t['fund_recovery']/(ONE+w)**p['years']-sum(d(r['fund_payment'])/(ONE+w)**(d(r['month'])/12) for r in rows[:n]);pvequity=sum(d(r['equity_cash'])/(ONE+w)**(d(r['month'])/12) for r in rows[:n]);initialdebt=o['term_debt']+o['wc_debt']+o['demand_debt']-d(s['opening_debt_repayment']);initialcash=o['cash']+d(s['opening_cash_increment'])+d(s['opening_equity_cash']);dcf=max(Z,pvoper+pvtv+pvequity-initialdebt-o['other_claims']-d(s['nci_claim'])+(initialcash-d(rows[0]['reserve']))+d(s['associate_recovery'])+pvfund);eq(t['dcf_signed_opening_cash_adjustment'],initialcash-d(rows[0]['reserve']),'signedopeningreservecapital');eq(t['dcf_ev'],pvoper+pvtv,'dcfEV');eq(t['dcf_fund_net_present_value'],pvfund,'fundPV');eq(t['dcf_new_equity_present_value'],pvequity,'equityPV');eq(t['dcf_equity'],dcf,'dcfEquity');eq(t['dcf_per_diluted_share'],dcf*CR/d(last['shares_close']),'dcfDilution');assert all(d(r['shortfall'])<=D('1e-20') for r in rows);count+=len(rows)
    div=[r for r in rows[:n] if d(r['dividend'])>0];entry=d(i['entry_price'])*(ONE+d(s['entry_cost']));net=t['price_per_share']*(ONE-d(s['exit_cost']));irr=t['irr'];wealth=sum(d(r['dividend'])*CR/d(r['shares_close']) for r in div)+net
    if wealth>0:eq(entry,sum(d(r['dividend'])*CR/d(r['shares_close'])/(ONE+irr)**(d(r['month'])/12) for r in div)+net/(ONE+irr)**p['years'],'IRR root')
    for hurdle,value in t['hurdle_prices'].items():eq(value,(sum(d(r['dividend'])*CR/d(r['shares_close'])/(ONE+d(hurdle))**(d(r['month'])/12) for r in div)+net/(ONE+d(hurdle))**p['years'])/(ONE+d(s['entry_cost'])),'hurdleprice')
   assert p['summary']['source_eligible'] is False;count+=1
 return count
if __name__=='__main__':
 b=(P/'canonical_paths.json.gz').read_bytes();c=json.loads(gzip.decompress(b));n=check(c);out={'status':'PASS','independent_checks':n,'paths':len(c['paths']),'monthly_rows':sum(len(p['monthly']) for p in c['paths']),'canonical_sha256':hashlib.sha256(b).hexdigest(),'method':'Independent raw-source identities, stock-flow recurrence, gross cash, claims, terminal reinvestment and IRR; does not import production model.'};(P/'independent_replay_results.json').write_text(json.dumps(out,indent=2)+'\n');print(out)
