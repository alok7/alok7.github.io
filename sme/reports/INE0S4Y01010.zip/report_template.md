# Shree Karni Fabcom Limited

SME research 369 · Master Prompt v3.0 · Information cutoff 20 October 2026 · Market cutoff 19 October 2026

## 1. Executive Verdict

{{VERDICT}}

## 2. Research Header, Gates and Data Confidence

{{HEADER}}

{{GATES}}

{{CONFIDENCE}}

## 3. Scorecard and Calculation Audit

{{SCORES}}

{{FACTORS}}

{{SCORE_NOTES}}

## 4. Business Overview

{{BUSINESS}}

## 5. Moat and Industry Position

{{MOAT}}

{{PEERS}}

## 6. Revenue Growth and Scale

{{GROWTH}}

{{GROWTH_NOTES}}

{{INTERIM}}

## 7. Growth Quality and Reinvestment Runway

{{RUNWAY}}

{{CAPITAL_RETURNS}}

## 8. Management, Governance and Execution

{{GOVERNANCE}}

{{EXECUTION}}

## 9. Financial Forensics

{{HISTORICAL}}

{{FORENSICS}}

{{CASH_BRIDGE}}

{{NORMALIZATION}}

{{LIQUIDITY}}

## 10. Valuation and Market Expectations

{{VALUATION}}

{{MODEL_SPEC}}

{{MAIN_CASES}}

{{TERMINAL}}

{{REVERSE}}

{{SENSITIVITY}}

## 11. Bear Case and Permanent Loss Path

{{BEAR}}

## 12. Fivefold and Tenfold Feasibility

{{TARGETS}}

## 13. Monitoring Plan

{{MONITORING}}

## 14. Final Classification and Conditional Action

{{CLASSIFICATION}}

## 15. Sources, Assumptions and Open Questions

{{SOURCES}}

{{OPEN}}

{{QUALITY}}
