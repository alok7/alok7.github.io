# Financial forensics: Shree Karni Fabcom Limited

Information cutoff: 20 October 2026. Units: ₹ crore unless explicitly stated. This is an analytical research supplement, not a trade instruction.

## Scope, periods and accounting

The investable parent owns 66.67% of IGK Technical Textiles LLP and 45% of Textron Fabtech LLP, both acquired on 31 October 2023. Group figures include the subsidiary and equity-accounted associate; parent figures are shown as a cross-check. Indian GAAP Accounting Standards apply, not Ind AS. The consolidated fixed-asset note retains the LLP’s tax-block depreciation alongside the parent’s Companies Act schedule; these are not a uniform group depreciation basis. [SKF-AR26, printed 36–37,130,144–146]

FY2024 requires special care: the company’s 12 April–31 March P&L and predecessor’s 1–11 April P&L are separate columns. Summing those non-overlapping periods gives full-year consolidated revenue ₹137.0777 and PBT ₹19.0358. The cash-flow column already covers the full year, so the predecessor cash-flow column must not be added a second time. [SKF-AR24, printed 117–119; SKF-AR25 current comparative]

IPO-restated FY2023 PAT ₹5.5525 differs from the later annual report’s original ₹4.6177 because tax-act depreciation was replaced with Companies Act depreciation and deferred tax/loss adjustments were made. The prospectus provides this bridge explicitly. FY2021–22 income tax was paid/adjusted through LLP partners rather than expensed in reported P&L; those reported PAT numbers are not directly comparable with corporate after-tax profit. Historical operating returns therefore use a consistently disclosed 25.17% analytical tax rate. [SKF-PROS, PDF 201]

## Audited/restated historical operating table

FY2021–23 are restated predecessor figures. FY2024–26 are the consolidated group; the acquisition perimeter change is visible, not silently treated as organic growth. Strict operating EBITDA = PBT + finance cost + depreciation − all other income. This conservative cross-check is not the company’s own EBITDA definition.

| Period/scope | Revenue | Strict operating EBITDA | EBIT | Owner PAT | Reported CFO | Cash capex | CFO−cash capex |
|---|---:|---:|---:|---:|---:|---:|---:|
|FY21 predecessor|32.8742|3.7806|3.5405|1.5348|2.7354|2.2831|0.4523|
|FY22 predecessor|83.5736|8.2032|7.6768|5.1484|0.4137|11.0468|-10.6331|
|FY23 predecessor|126.9465|15.0976|13.5728|5.5525|-0.2342|10.2235|-10.4577|
|FY24 consolidated|137.0777|25.4809|22.3785|14.7126|-7.4645|8.9070|-16.3715|
|FY25 consolidated|166.9777|28.0487|21.9585|15.1064|-6.6048|40.4931|-47.0979|
|FY26 consolidated|203.5441|31.1954|21.6502|15.2354|15.9221|26.7648|-10.8427|

Sources: SKF-PROS PDF 170–174; SKF-AR24 printed 116–119; SKF-AR25 consolidated statements; SKF-AR26 printed 133–140. Underlying original values, vintages and formula outputs are retained in financial_inputs.json and financial_metrics.json.

### Parent cross-check

| Period | Revenue | EBITDA | PAT | CFO | Cash capex | Debt |
|---|---:|---:|---:|---:|---:|---:|
|FY24|130.7984|20.8790|13.0115|-5.7891|5.0706|49.6552|
|FY25|165.7103|23.4125|15.1067|-5.2916|38.8552|70.7076|
|FY26|202.9533|26.5669|15.2355|4.6892|24.9268|74.1451|

## Growth, margins and latest comparable halves

Three-year revenue CAGR is 17.04% for the consolidated sequence and 16.93% using parent endpoints, from ₹126.9465 crore in FY2023 to ₹203.5441/₹202.9533 crore in FY2026. The parent revenue series is the closer constant-perimeter cross-check, but acquired manufacturing integration changed costs and margins. The five-year reported CAGR is approximately 44%; the pandemic-period base and business/perimeter evolution make it unsuitable as an unqualified primary growth score. FY2024–26 annual group revenue additions were ₹10.1312, ₹29.9000 and ₹36.5664 crore. The existence of true scaling is not denied just because the starting company was small.

Latest comparable half-year evidence: H1FY2026 revenue ₹107.3010 versus ₹76.8069 crore, +39.70%; owner PAT ₹6.1699 versus ₹4.8670 crore, +26.77%. H2FY2026, derived as audited full-year minus the original H1 filing, revenue ₹96.2431 versus ₹90.1708 crore, +6.73%; owner PAT ₹9.0655 versus ₹10.2394 crore, −11.46%. This slowdown supports no extra positive trajectory adjustment. H1FY2027 results were not available by the cutoff; no forward TTM is invented. The original H1 PDF image says September 2025; OCR misleadingly renders 2026 in the heading. [SKF-H126, PDF 8; SKF-AR26, printed 134]

### Material value added, not fabricated gross profit

Full manufacturing gross profit is ND because direct labour/overheads are not cleanly allocated between manufacturing costs and the remaining expenses. A reproducible material-spread cross-check subtracts materials plus inventory change from sales. It rises from ₹36.6947 crore/26.77% in FY2024 to ₹46.3734 crore/27.77% in FY2025 and ₹59.1599 crore/29.06% in FY2026. This is value added before employee and other operating costs, not a labelled gross profit. FY2025 material/inventory lines were regrouped in FY2026 comparatives; their net cost is unchanged to rounding. [SKF-AR25 consolidated P&L; SKF-AR26 notes 21–28]

Group strict operating EBITDA rises ₹28.0487→₹31.1954 crore, only 11.22% versus 21.90% sales growth. Its margin falls 16.80%→15.33%. Employee costs rise ₹9.7681→₹13.5038 crore; other expenses ₹8.5566→₹14.4607 crore. Depreciation ₹6.0902→₹9.5452 and finance cost ₹2.8445→₹5.6620 absorb further growth, leaving owner PAT almost flat at ₹15.1064→₹15.2354 crore. Increased material spread has therefore not translated into equivalent owner-earnings progress.

Other income rises ₹2.4852→₹4.8808 crore and includes ₹1.5622 subsidy, ₹0.676 miscellaneous income, ₹0.2639 asset-sale profit, ₹0.6965 FX gain and ₹0.9961 export incentives. Interest subsidy ₹0.2991 is netted against finance costs on an accrual basis. Export incentives/FX may be recurrent economic items, but all other income is excluded in the strict core cross-check and restoration should be an explicit sensitivity, not a hidden benefit. Removing nonrecurring gains alone differs from removing all other income. [SKF-AR26 notes 22,26]

FY2025 deferred revenue/startup expenditure ₹2.7493 was not expensed immediately. FY2026 charges ₹1.9391 during stitching restructuring while ₹0.8102 remains. Management explains the matching treatment; an analyst should show symmetric earlier-expense/current-addback sensitivity, not simply add back the current charge to inflate normalized profit and ignore prior capitalization. The auditor highlights restructuring in an Emphasis of Matter, without modifying the main opinion. [SKF-AR26 printed 80/118,102/138,104/140,151]

## Cash conversion and working capital

FY2024–26 group CFO totals ₹1.8528 crore against ₹46.0556 crore PAT before associate/NCI adjustments, a ratio of sums of 4.02%. Using owner PAT against group CFO would mismatch the consolidation perimeter. Parent CFO totals −₹6.3915 crore against ₹43.3537 crore PAT,−14.74%. Three-year group cash capex totals ₹76.1649 crore. Weak CFO is primarily operating working-capital absorption; capex is an investing outflow and is not an excuse for weak CFO. FY2026 CFO ₹15.9221 is a real reported improvement, but it does not erase the prior two cash-negative years. [SKF-AR24/25/26 cash-flow statements]

FY2026 CFO bridge: PBT ₹20.8690 plus depreciation ₹9.5452, finance cost ₹5.6620 and other disclosed noncash/nonoperating adjustments produces pre-WC operating cash ₹35.8516 crore. Inventory absorbs ₹20.2089; other current assets release ₹5.4556; receivables release ₹0.1410; other noncurrent assets release ₹0.5451; payables consume ₹1.0930; other current liabilities add ₹0.1754. Cash generated ₹20.8668 less cash taxes ₹4.9447 gives ₹15.9221. None of these lines makes receivables or inventory universally liquid.

Classification sensitivity only: capital advances fall ₹0.4150, noncurrent FD grows ₹0.2797, and partner-capital within current liabilities disappears ₹1.5926. Moving financing/capital items out of CFO may increase the analytical figure, but the partner-capital change could be a noncash transfer into borrowing rather than repayment. No verified actual extra cash is asserted. Deferred-expense amortization is already offset through the change in other current assets; adding it back again would double count. The original cash totals remain the anchor.

Group receivables are ₹51.9991 crore, almost flat; balances older than six months improve ₹8.7700→₹4.4928 crore. This is favorable counterevidence to an indiscriminate collections claim. Inventory grows ₹49.4575→₹69.6664 crore and drives the broader funding burden; no item-age breakdown was located. The auditor’s inventory KAM and physical-count finding of no class discrepancy of 10% or more are retained, not dismissed. AP older than one year includes ₹2.4990 in 1–2 years and ₹0.0643 beyond 3 years. [SKF-AR26 printed 138,143]

| Group average-balance proxy | FY2025 | FY2026 |
|---|---:|---:|
| Receivable days, total revenue proxy |92.60|93.37|
| Inventory days, net material-cost proxy |132.05|150.57|
| Payable days, purchases/direct-cost proxy |54.34|61.60|
| Cash-cycle proxy |170.30|182.34|

These use average opening/closing balances, not period-end ratios. Inventory denominator is net material cost, not fully allocated COGS; payable denominator includes direct costs and is not verified credit-only purchases. They are disclosed approximations. Parent cash-cycle proxy also rises 152.97→167.76 days. Other assets, cash taxes, capital advances and overdue/nonoperating items are separately analyzed.

## Incremental capital returns and investment bridge

Consistent analytical tax is 25.17%; nominal INR cost-of-capital comparison range 12–15% is an assumption, not a measured rate. IC = reported owner capital (including received warrants) + pending share application + NCI + gross debt − cash − investments − noncurrent FDs. All CWIP remains in committed capital. Excluding FDs is a capital-analysis classification, not permission to use restricted/unverified deposits to repay debt. Including them instead leaves the weak return conclusion unchanged. [Financial input and metric files]

Parent core FY2023→FY2026 normalized NOPAT rises ₹10.1565→₹16.1469 crore while financing IC rises ₹59.0886→₹181.4149 crore: delta NOPAT ₹5.9904/delta IC ₹122.3263=4.90%. The five-year parent proxy is 8.38%; group proxies are 4.02% and 7.17%, but the acquisition/perimeter caveat is stronger. These are accounting proxies, not project IRRs and not proof all profits came from new assets. Newly commissioned dyeing assets have not had a full maturation period; prospective higher returns remain possible, not demonstrated.

FY2025→FY2026 group PPE+intangibles+CWIP rises ₹14.3149 crore; cash capex less sale proceeds and depreciation is ₹14.1742, leaving ₹0.1407 of cash/accrual/subsidy/disposal classification residual. Trade ONWC rises ₹21.1609; total financing IC rises ₹27.9777. The remaining −₹7.4981 is explicitly retained as other operating/deferred-tax/nonoperating/financing classification movements, not concealed as project return. Parent corresponding changes are ₹18.0814 fixed capital, ₹22.6724 trade ONWC and ₹36.3506 IC, residual −₹4.4032. Acquisition/net assets are included once; adding purchase consideration again would double count. [SKF-AR26 balance/asset schedules; financial_metrics.json]

## Liquidity, claims and audited counterevidence

At 31 March 2026 group debt ₹98.2332 comprises term/vehicle debt ₹29.9126 including current maturities ₹9.2120, cash credit ₹42.5556, and unsecured demand debt ₹25.7650. Available disclosed cash is only ₹0.1230, of which ₹0.0171 is current-bank balances. Noncurrent FD ₹3.4730 is not proven immediately free. Gross nominal CC limits total ₹49.5 crore against ₹42.5556 drawn; the ₹6.9444 arithmetic gap is not an unconditional cash facility, because collateral/borrowing-base and current utilization matter. Original loan tenors are not remaining maturity schedules. [SKF-AR26 notes 7,10,10A,19]

Other claims include current income tax ₹0.9008, gratuity ₹0.6977, expense payables ₹2.0977 and fund commitments ₹2.2311. Customer advances ₹1.3081 are funding tied to performance. Venture funds ₹2.2664 and associate carrying ₹0.8494 are not operating cash. Parent guarantees IGK debt secured at ICICI; consolidated borrowing already includes the subsidiary, so adding the same guaranteed debt again would double count. Subsidiary NCI is a claim on IGK, not 33.33% of the whole listed group. IGK annual PAT is only ₹0.1798 on assets ₹30.6230 and liabilities ₹25.3290; economic NCI valuation needs its own sensitivity. [SKF-AR26 printed 36–37,137,141–146,151]

Positive counterevidence: the FY2026 audit reports no borrowing default or willful-defaulter status, no material statutory dues unpaid over six months or disputed dues, and proper use of term-loan/preferential funds. Main opinion is unmodified and IFC opinion is positive. Debt falls ₹4.9207 crore in FY2026. Later actual warrant conversion receipts need the separately verified post-March bridge; they cannot simultaneously increase free cash and extinguish debt. No fresh investment decision should assume the entire gross receipt is still available.

Bank-return differences are quantified, including Q4 stock reported ₹64.0680 versus books ₹67.3752 crore and AP ₹22.8230 versus ₹21.2005 crore. Management/auditor disclosure cites timing of credit/debit notes and inventory cost inclusions. This is a control weakness to monitor, not automatic evidence of diversion or a qualified audit. [SKF-AR26 printed 86]

## Proportionate scoring recommendations

CAP 3, Medium: multi-year committed-capital returns are below 12–15% despite a recent ramp-up caveat; the optimistic future project is not already earned. CASH 3, Medium: three-year conversion is persistently weak despite FY2026 improvement and better aged receivables. These independently justify the framework’s GQS cap 5; do not add an extra undisclosed penalty. EARN 4, Medium: owner EPS/PAT progress is weak after capital raising, other income matters, and deferred startup costs require symmetric normalization; this is separate from cash collection. BAL 4, Medium: net debt/strict EBITDA≈3.15×, thin cash and demand funding make resilience fragile, while no audited default and actual fresh equity receipt are important counterevidence. G2 Conditional rather than automatic Hold/Fail; G3 Conditional unless credible modeled shortfall and source evidence justify stronger status. Analyst reserve breaches must not be labelled observed defaults.

## Exact original-source qualifications and open questions

- FY24 split reporting: Company Apr 12–Mar 31 plus predecessor Apr 1–11; group revenue 127.1687+9.9090=137.0777, PBT 18.0761+.9597=19.0358. Do not use company period as full FY or add predecessor to already full cash flow.

- FY23 restatement: PROS profit 4.6177+IT Act DA 2.9193-Companies Act DA 1.5248-loss adjustment .0053-DT .4545=5.5524(round source 5.5525). AR24 uses original IT Act figures. Use PROS restated for normalized long window and retain both vintages.

- FY21/22 tax: LLP partner income-tax was adjusted to partners, not P&L; published PAT 1.5348/5.1484 not equivalent to corporate after tax. Normalize operating tax consistently.

- FY25 EPS: Front consolidated P&L 22.51 contradicts detailed note 21.36 and 15.1064 cr / 7,072,000 shares=21.36199. Use calculated 21.36, flag original typo.

- FY25 balance comparatives: AR26 moves capital advance 2.5143 current to noncurrent; nets off doubtful AR .0286 and matching other liability; investment carrying 3.3401→3.0303 also changed, no cash assumed. Archive original and new comparatives.

- FY25 cost regrouping: AR25 material 132.2576 plus inventory −11.6532=120.6044; AR26 comparative 127.5540−6.9497=120.6043 rounding. No change in EBITDA from regrouping.

- FY25 financing labels: Cash flow swaps warrant 3.0122 / share application 6.9768 labels; balances and FY26 comparative identify categories. FY25 NCI financing+.4048 equals NCI profit increase, not verified new cash contribution; retain limited classification uncertainty.

- FY26 subsidiary tax depreciation: Consolidated fixed asset note combines parent Companies Act table and IGK tax blocks; preserve original, no false group uniform depreciation.

- Obtain a dated cash/debt/use-of-proceeds bridge after the August–September 2026 conversions, including whether amounts were paid in cash or adjusted/used to settle promoter debt.

- Obtain remaining contractual debt maturities and confirmed drawing power, FD lien/release status, facility renewals and underwriting covenants.

- Obtain current asset realization and remaining liabilities of the closed stitching division; neither the original business contribution nor a book asset value guarantees recovery.

- Obtain commissioning-date cohort returns, inventory-age details and supported subsidy/interest receivable realization.

- The annual report states the company has not availed a credit rating. This is not an adverse withdrawal or default statement. [SKF-AR26 printed 14]
