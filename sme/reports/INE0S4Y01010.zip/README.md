# Shree Karni Fabcom research 369

This source-safe package concerns Shree Karni Fabcom Limited, NSE Emerge SHREEKARNI, ISIN INE0S4Y01010. It applies Master Prompt v3.0 to information available by 20 October 2026 and the 19 October 2026 close. It does not use later information to improve a historical conclusion.

Open report.html or report.md. The full company record, original-source references, authored data, assumptions, failed paths and reproduction code accompany the report. Original copyrighted PDFs, downloaded source text and private account data are not included. Original source URLs and hashes are retained for verification.

Python 3 standard library is sufficient for offline reproduction. Run build.py and verify.py. guarded_rebuild.py copies only declared inputs to a new temporary directory, rebuilds every declared output and compares exact hashes without changing or deleting the source package. package.py creates compact and full ZIPs with identical contents at different compression levels; extract either one, not both.

Model reproduction is not proof of forecast accuracy, current liquidity or investment eligibility. Missing evidence and conditions remain stated. The illustrative ₹5 lakh liquidity test is not a recommended allocation. No trading instruction or personal portfolio circumstances are assumed.
