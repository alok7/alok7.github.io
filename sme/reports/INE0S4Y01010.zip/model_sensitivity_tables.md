# Linked model sensitivity tables

All outputs below are conditional research experiments, not source-eligible IAS or price targets. A failed path has no ordinary return. M means month from the assumed November2026 opening; breaches concern an analyst liquidity reserve, not observed default. A cell with two numbers is investor IRR / conditional DCF per fully diluted share.

## Growth versus exit multiple

| volume_growth / terminal_multiple | 5 | 7 | 9 | 11 | 13 |
| --- | --- | --- | --- | --- | --- |
| 0 | -17.50% / ₹34.12 | -10.85% / ₹34.12 | -5.73% / ₹34.12 | -1.53% / ₹34.12 | 2.05% / ₹34.12 |
| .05 | -12.95% / ₹46.73 | -5.63% / ₹46.73 | -0.06% / ₹46.73 | 4.50% / ₹46.73 | 8.37% / ₹46.73 |
| .10 | FAIL M50 | FAIL M50 | FAIL M50 | FAIL M50 | FAIL M50 |
| .15 | FAIL M26 | FAIL M26 | FAIL M26 | FAIL M26 | FAIL M26 |
| .20 | FAIL M14 | FAIL M14 | FAIL M14 | FAIL M14 | FAIL M14 |
| .25 | FAIL M13 | FAIL M13 | FAIL M13 | FAIL M13 | FAIL M13 |
| .30 | FAIL M13 | FAIL M13 | FAIL M13 | FAIL M13 | FAIL M13 |
| .35 | FAIL M13 | FAIL M13 | FAIL M13 | FAIL M13 | FAIL M13 |

## Margin versus WACC

| ebitda_margin / wacc | .12 | .14 | .16 | .18 |
| --- | --- | --- | --- | --- |
| .12 | FAIL M26 | FAIL M26 | FAIL M26 | FAIL M26 |
| .14 | FAIL M38 | FAIL M38 | FAIL M38 | FAIL M38 |
| .16 | FAIL M50 | FAIL M50 | FAIL M50 | FAIL M50 |
| .18 | 3.84% / ₹111.37 | 3.84% / ₹67.36 | 3.84% / ₹37.33 | 3.84% / ₹15.65 |
| .20 | 7.18% / ₹167.74 | 7.18% / ₹113.31 | 7.18% / ₹76.12 | 7.18% / ₹49.22 |

## WACC versus terminal growth

| wacc / terminal_growth | 0 | .02 | .04 | .05 |
| --- | --- | --- | --- | --- |
| .12 | FAIL M50 | FAIL M50 | FAIL M50 | FAIL M50 |
| .15 | FAIL M50 | FAIL M50 | FAIL M50 | FAIL M50 |
| .18 | FAIL M50 | FAIL M50 | FAIL M50 | FAIL M50 |

## Hurdle-price sensitivity

| Path | Condition | 12% hurdle | 15% hurdle | 18% hurdle | Realized sales CAGR | Unserved sales |
| --- | --- | --- | --- | --- | --- | --- |
| SKF005 | Bull source-bounded, gross receipts use unverified | ₹316.13 | ₹276.99 | ₹243.53 | 2.47% | 439.83 |
| SKF087 | Fivefold / tenfold feasibility experiment | ₹483.00 | ₹423.20 | ₹372.07 | 11.06% | 103.64 |
| SKF162 | No growth cash-conversion recovery | ₹196.47 | ₹172.15 | ₹151.35 | -1.65% | 0.00 |

Quoted entry prices already allow the assumed 1% entry cost and 1% exit friction. No supported base-case entry range is asserted because the reference base path fails and current funding data are incomplete.

## Reverse expectations and target feasibility

Only SKF087 among the tested 162 conditional paths crosses the 15% hurdle; it is an assumed financing/dilution target experiment, not an endorsed required-growth solution. Full scenario, realized growth and capacity loss are preserved. None of the tested five/ten-year paths reaches 5× or 10× after the stated implementation friction. This finite grid is not a proof no future outcome is possible.
