"""Shree Karni monthly group funding laboratory; normalized INR crore, Decimal.
A scenario is conditional, never a bank commitment or an observed default.
"""
from decimal import Decimal as D, localcontext
from copy import deepcopy
Z=D(0); ONE=D(1); CR=D(10000000)
def d(x):
 if isinstance(x,float):raise TypeError('Use decimal strings, not binary floats')
 return x if isinstance(x,D) else D(str(x))
def date(m):
 x=2026*12+10+m-1
 return f'{x//12:04d}-{x%12+1:02d}'
def run(i,s,years,path_id):
 with localcontext() as c:
  c.prec=34
  return _run(i,deepcopy(s),years,path_id)
def _run(i,s,years,path_id):
 n=12*years;o={k:d(v) for k,v in i['opening'].items()};cash=o['cash']+d(s['opening_cash_increment']);restricted=o['restricted_cash'];ar=o['receivables'];inv=o['inventory'];ap=o['payables'];other=o['other_operating_assets'];claims=o['other_claims'];ppe=o['ppe'];term=o['term_debt'];wc=o['wc_debt'];demand=o['demand_debt'];flex=Z;shares=int(i['shares']);capacity=o['revenue_capacity'];pipeline=[];loans=[];rows=[];failure=None;cumdraw=Z;dividends=[];closed_assets=o['closed_unit_assets'];available_equity=int(s['equity_share_cap']);remaining_nonop=o['recoverable_nonop_assets'];fund_assets=o['fund_assets'];fund_remaining=o['fund_commitment'];old_term_initial=term;cumdiv=Z
 # May be stale dated source proxies; model eligibility remains separate from arithmetic.
 cash+=d(s['opening_equity_cash']);shares+=int(s['opening_new_shares']);demand=max(Z,demand-d(s['opening_debt_repayment']))
 if d(s['opening_debt_repayment'])>o['demand_debt']:raise ValueError('Repayment exceeds disclosed demand debt')
 initial_debt=term+wc+demand;initial_cash=cash
 terminal_test_months=max(36,int(s['term_final_month'])-n,int(s['demand_call_month'])-n,int(s['flex_tenor']))
 for m in range(1,n+terminal_test_months+1):
  y=(m-1)//12;phase='horizon' if m<=n else 'terminal_transition';opening=dict(cash=cash,restricted=restricted,ar=ar,inv=inv,ap=ap,other=other,claims=claims,ppe=ppe,term=term,wc=wc,demand=demand,flex=flex,shares=shares,capacity=capacity,closed_assets=closed_assets,remaining_nonop=remaining_nonop,fund_assets=fund_assets,fund_remaining=fund_remaining)
  for a in pipeline:
   if a['due']==m:capacity+=a['capacity'];ppe+=a['cost']
  pipeline=[a for a in pipeline if a['due']!=m]
  growth=d(s['volume_growth']) if m<=n else d(s['terminal_growth']);price_growth=d(s['price_growth']) if m<=n else Z
  if m==1:annual_demand=o['sales']*(ONE+growth)*(ONE+price_growth)*(ONE-d(s['customer_loss']))
  elif (m-1)%12==0:annual_demand*= (ONE+growth)*(ONE+price_growth)
  # Capacity expressed as revenue at fixed starting realization: price inflation does not create physical capacity.
  price_index=(ONE+d(s['price_growth']))**min(y+1,years)
  desired_real=annual_demand/price_index;committed=capacity+sum((a['capacity'] for a in pipeline),Z)
  growth_capex=Z;added_capacity=Z
  if s['expansion_gate'] and desired_real*d(s['capacity_buffer'])>committed:
   added_capacity=min(max(Z,desired_real*d(s['capacity_buffer'])-committed),max(Z,d(s['maximum_capacity'])-committed));growth_capex=added_capacity*d(s['capex_per_sales']);pipeline.append(dict(capacity=added_capacity,cost=growth_capex,due=m+int(s['expansion_delay'])))
  sales=min(annual_demand,capacity*price_index)/12;unserved=max(Z,annual_demand/12-sales)
  variable_ratio=ONE-d(s['ebitda_margin'])-d(s['fixed_cost_ratio']);material=sales*d(s['material_ratio'])*(ONE+d(s['material_price_shock']));other_variable=sales*max(Z,variable_ratio-d(s['material_ratio']));fixed=o['sales']/12*d(s['fixed_cost_ratio']);opex=other_variable+fixed;ebitda=sales-material-opex
  # Collection is a stock-flow identity. No negative collection or supplier payment financing artifact.
  blend=min(ONE,d(m)/d(s['working_capital_transition_months']));ar_target=o['receivables']*(ONE-blend)+sales*d(s['receivable_days'])/D(30)*blend;collections=max(Z,ar+sales-ar_target);ar=ar+sales-collections
  writeoff=ar*d(s['receivable_loss']) if m==int(s['receivable_loss_month']) else Z;ar-=writeoff
  inv_target=o['inventory']*(ONE-blend)+material*d(s['inventory_days'])/D(30)*blend;purchases=max(Z,material+inv_target-inv);inv+=purchases-material
  spoilage=inv*d(s['inventory_loss']) if m==int(s['inventory_loss_month']) else Z;inv-=spoilage
  ap_target=o['payables']*(ONE-blend)+purchases*d(s['payable_days'])/D(30)*blend;supplier_cash=max(Z,ap+purchases-ap_target);ap=ap+purchases-supplier_cash
  target_other=o['other_operating_assets']*(ONE-blend)+sales*d(s['other_assets_ratio'])*12*blend;other_change=target_other-other;other=target_other
  maintenance=max(sales*d(s['maintenance_ratio']),ppe*d(s['replacement_rate'])/12 if m>n else Z);ppe+=maintenance;da=min(ppe,o['da']/12+max(Z,ppe-o['ppe'])*d(s['new_asset_da_rate'])/12);ppe-=da
  closure_cost=d(s['closure_cost']) if m==int(s['closure_month']) else Z;asset_sale=Z;asset_sale_basis=Z
  if s['asset_sale_gate'] and m==int(s['asset_sale_month']):asset_sale_basis=closed_assets;asset_sale=closed_assets*d(s['asset_sale_recovery']);closed_assets=Z
  sale_tax=max(Z,asset_sale-asset_sale_basis)*d(s['tax_rate']);ebit=ebitda-da-writeoff-spoilage
  term_pay=(min(term,o['current_term_maturity']/12) if m<=12 else min(term,max(Z,old_term_initial-o['current_term_maturity'])/d(s['term_amort_months']))) if m>=int(s['term_amort_start']) else Z
  if m>=int(s['term_final_month']):term_pay=term
  term-=term_pay;wc_pay=wc if m==int(s['wc_review_month']) and not s['wc_renewal_gate'] else Z;wc-=wc_pay
  prom_pay=demand if m==int(s['demand_call_month']) and not s['demand_roll_gate'] else Z;demand-=prom_pay
  due=Z;rollfee=Z;newlist=[]
  for a in loans:
   if a['due']==m:
    if m<=n and s['flex_roll_gate']:rollfee+=a['amount']*d(s['roll_fee']);newlist.append(dict(amount=a['amount'],due=m+int(s['flex_tenor'])))
    else:due+=a['amount']
   else:newlist.append(a)
  loans=newlist;flex-=due
  interest=(opening['term']*d(s['term_rate'])+opening['wc']*d(s['wc_rate'])+opening['demand']*d(s['demand_rate'])+opening['flex']*d(s['flex_rate']))/12
  tax=max(Z,ebit-interest)*d(s['tax_rate']);claims_pay=min(claims,o['other_claims']/d(s['claims_months'])) if m<=int(s['claims_months']) else Z;claims-=claims_pay
  restricted_release=restricted if s['restricted_release_gate'] and m==int(s['restricted_release_month']) else Z;restricted-=restricted_release
  nonop_recovery=remaining_nonop*d(s['nonop_recovery_fraction']) if m==int(s['nonop_recovery_month']) else Z;remaining_nonop-=nonop_recovery
  fund_payment=min(fund_remaining,o['fund_commitment']/d(s['fund_call_months'])) if m<=int(s['fund_call_months']) else Z;fund_remaining-=fund_payment;fund_assets+=fund_payment
  annualfee=d(s['annual_bank_fee'])/12;legal=d(s['contingent_payment']) if m==int(s['contingent_month']) else Z
  capex=maintenance+growth_capex;reserve=max(d(s['cash_floor']),(material+opex)*d(s['reserve_months']))
  pre=cash+collections+asset_sale+restricted_release+nonop_recovery-supplier_cash-opex-other_change-interest-tax-sale_tax-capex-term_pay-wc_pay-prom_pay-due-claims_pay-rollfee-annualfee-closure_cost-legal-fund_payment
  # Hypothetical equity availability is separately gated; share cap is a scenario assumption, not authorization.
  equity_shares=0;equity_cash=Z
  if s['equity_gate'] and m==int(s['equity_month']):
   equity_shares=available_equity;available_equity=0;equity_cash=d(equity_shares)*d(s['equity_price'])/CR*(ONE-d(s['equity_fee']));shares+=equity_shares;pre+=equity_cash
  need=max(Z,reserve-pre);draw=Z;drawfee=Z
  if s['flex_gate'] and m<=n:
   ir=d(s['flex_rate'])/12;fee=d(s['flex_fee']);tr=d(s['tax_rate']);taxable=max(Z,ebit-interest);candidate=need/(ONE-fee-ir*(ONE-tr))
   if candidate*ir>taxable:candidate=(need-taxable*tr)/(ONE-fee-ir)
   draw=min(max(Z,candidate),max(Z,d(s['flex_limit'])-flex),max(Z,d(s['flex_cumulative_limit'])-cumdraw));drawfee=draw*fee;flex+=draw;cumdraw+=draw
   if draw:loans.append(dict(amount=draw,due=m+int(s['flex_tenor'])))
  drawinterest=draw*d(s['flex_rate'])/12;oldtax=tax;interest+=drawinterest;tax=max(Z,ebit-interest)*d(s['tax_rate']);cash=pre+draw-drawfee-drawinterest+oldtax-tax
  dividend=Z
  if m<=n and m%12==0 and s['dividend_gate']:
   dividend=min(max(Z,cash-reserve),max(Z,ebit-interest-tax)*12*d(s['payout']));cash-=dividend;cumdiv+=dividend;dividends.append(dict(month=m,total=dividend,per_share=dividend*CR/d(shares)))
  shortfall=max(Z,reserve-cash);fcff=collections-supplier_cash-opex-other_change-max(Z,ebit)*d(s['tax_rate'])-capex
  row=dict(month=m,date=date(m),phase=phase,year=y+1,opening=opening,sales=sales,annual_demand=annual_demand,price_index=price_index,capacity=capacity,unserved_sales=unserved,material=material,opex=opex,ebitda=ebitda,da=da,ebit=ebit,interest=interest,current_draw_interest=drawinterest,tax=tax,collections=collections,purchases=purchases,supplier_cash=supplier_cash,ar_close=ar,inventory_close=inv,ap_close=ap,other_assets_close=other,other_assets_change=other_change,receivable_writeoff=writeoff,inventory_writeoff=spoilage,ppe_close=ppe,growth_capex=growth_capex,growth_capacity=added_capacity,maintenance_capex=maintenance,capex=capex,asset_sale=asset_sale,asset_sale_basis=asset_sale_basis,sale_tax=sale_tax,closure_cost=closure_cost,closed_assets_close=closed_assets,term_principal=term_pay,wc_principal=wc_pay,demand_principal=prom_pay,flex_principal=due,term_debt_close=term,wc_debt_close=wc,demand_debt_close=demand,flex_debt_close=flex,debt_close=term+wc+demand+flex,flex_draw=draw,flex_fee=drawfee,roll_fee=rollfee,annual_bank_fee=annualfee,equity_shares=equity_shares,equity_cash=equity_cash,shares_close=shares,restricted_release=restricted_release,restricted_cash_close=restricted,nonop_recovery=nonop_recovery,remaining_nonop_close=remaining_nonop,fund_payment=fund_payment,fund_assets_close=fund_assets,fund_commitment_remaining=fund_remaining,claims_payment=claims_pay,claims_close=claims,contingent_payment=legal,cash_close=cash,reserve=reserve,shortfall=shortfall,dividend=dividend,fcff=fcff)
  rows.append(row)
  if m==n:exitrow=deepcopy(row)
  if shortfall>D('1e-20'):
   failure=dict(month=m,phase=phase,date=date(m),reason='Assumed minimum-liquidity reserve not funded; not an assertion of observed default',shortfall=shortfall,cash=cash,reserve=reserve);break
 terminal=None
 if failure is None:
  # Transition tests full debt maturities and cash reinvestment before ordinary valuation eligibility.
  lastyear=rows[n-12:n];nextyear=rows[n:n+12];lastsales=sum((r['sales'] for r in lastyear),Z);lastebitda=sum((r['ebitda'] for r in lastyear),Z);lastfcff=sum((r['fcff'] for r in lastyear),Z);nextfcff=sum((r['fcff'] for r in nextyear),Z);wacc=d(s['wacc']);declared_tg=d(s['terminal_growth']);tg=min(declared_tg,max(Z,sum((r['sales'] for r in nextyear),Z)/lastsales-ONE)) if lastsales>0 else Z;assert wacc>tg
  terminal_nopat=sum((max(Z,r['ebit'])*(ONE-d(s['tax_rate'])) for r in nextyear),Z);terminal_da=sum((r['da'] for r in nextyear),Z);terminal_maintenance=max(sum((r['maintenance_capex'] for r in nextyear),Z),exitrow['ppe_close']*d(s['replacement_rate']));terminal_growth_capex=max(sum((r['growth_capex'] for r in nextyear),Z),lastsales*tg*d(s['capex_per_sales']));terminal_wc=max(Z,exitrow['ar_close']+exitrow['inventory_close']+exitrow['other_assets_close']-exitrow['ap_close'])*tg;steady_fcff=terminal_nopat+terminal_da-terminal_maintenance-terminal_growth_capex-terminal_wc;earned_fcff=min(nextfcff,steady_fcff);tv=max(Z,earned_fcff)/(wacc-tg);ev_multiple=max(Z,lastebitda)*d(s['terminal_multiple']);cash_available=max(Z,exitrow['cash_close']-exitrow['reserve']);nci=max(Z,d(s['nci_claim']));associate=max(Z,d(s['associate_recovery']));fund_recovery=exitrow['fund_assets_close']*d(s['fund_terminal_recovery'])
  senior=exitrow['debt_close']+exitrow['claims_close']+nci;equity=max(Z,ev_multiple-senior+cash_available+associate+fund_recovery);price=equity*CR/d(exitrow['shares_close']);entry=d(i['entry_price'])*(ONE+d(s['entry_cost']));netprice=price*(ONE-d(s['exit_cost']));totaldiv=sum((z['per_share'] for z in dividends),Z)
  def npv(rate):return -entry+sum((z['per_share']/(ONE+rate)**(d(z['month'])/12) for z in dividends),Z)+netprice/(ONE+rate)**years
  lo=D('-.9999');hi=D('10')
  for _ in range(180):
   mid=(lo+hi)/2
   if npv(mid)>0:lo=mid
   else:hi=mid
  irr=(lo+hi)/2 if netprice+totaldiv>0 else D(-1)
  pvfcff=sum((r['fcff']/(ONE+wacc)**(d(r['month'])/12) for r in rows[:n]),Z);pvtv=tv/(ONE+wacc)**years;dcfev=pvfcff+pvtv;pvfund=fund_recovery/(ONE+wacc)**years-sum((r['fund_payment']/(ONE+wacc)**(d(r['month'])/12) for r in rows[:n]),Z);pvequity=sum((r['equity_cash']/(ONE+wacc)**(d(r['month'])/12) for r in rows[:n]),Z);dcfequity=max(Z,dcfev+pvequity-initial_debt-o['other_claims']-nci+max(Z,initial_cash-d(s['cash_floor']))+associate+pvfund)
  terminal=dict(revenue=lastsales,ebitda=lastebitda,fcff=lastfcff,next_year_fcff=nextfcff,terminal_steady_fcff=steady_fcff,terminal_earned_fcff=earned_fcff,terminal_nopat=terminal_nopat,terminal_growth_declared=declared_tg,terminal_growth_applied=tg,terminal_da=terminal_da,terminal_maintenance=terminal_maintenance,terminal_growth_capex=terminal_growth_capex,terminal_working_capital_investment=terminal_wc,terminal_ev_multiple=ev_multiple,terminal_ev_dcf=tv,debt=exitrow['debt_close'],claims=exitrow['claims_close'],nci_claim=nci,associate_recovery=associate,fund_recovery=fund_recovery,cash_total=exitrow['cash_close'],required_cash_reserve=exitrow['reserve'],cash_addable=cash_available,equity_value=equity,shares=exitrow['shares_close'],price_per_share=price,net_exit_price=netprice,total_dividends_per_share=totaldiv,irr=irr,price_multiple=netprice/entry,dcf_ev=dcfev,dcf_fund_net_present_value=pvfund,dcf_new_equity_present_value=pvequity,dcf_share_count=exitrow['shares_close'],dcf_equity=dcfequity,dcf_per_diluted_share=dcfequity*CR/d(exitrow['shares_close']),dcf_terminal_fraction=pvtv/dcfev if dcfev>0 else None,hurdle_prices={str(h):sum((z['per_share']/(ONE+h)**(d(z['month'])/12) for z in dividends),Z)+netprice/(ONE+h)**years for h in [D('.12'),D('.15'),D('.18')]},terminal_transition_months=terminal_test_months,terminal_transition_min_cash=min(r['cash_close'] for r in rows[n:]),terminal_transition_min_cushion=min(r['cash_close']-r['reserve'] for r in rows[n:]),unserved_horizon_sales=sum((r['unserved_sales'] for r in rows[:n]),Z))
 annual=[]
 for yr in range(1,(len(rows)+11)//12+1):
  a=rows[(yr-1)*12:yr*12]
  if not a:continue
  annual.append(dict(year=yr,months=len(a),phase=a[-1]['phase'],**{k:sum((r[k] for r in a),Z) for k in ['sales','ebitda','ebit','interest','tax','collections','supplier_cash','capex','maintenance_capex','growth_capex','flex_draw','equity_cash','fcff','dividend']},cash_close=a[-1]['cash_close'],debt_close=a[-1]['debt_close'],shares_close=a[-1]['shares_close']))
 summary=dict(path_id=path_id,label=s['label'],kind=s['kind'],years=years,volume_growth=s['volume_growth'],margin=s['ebitda_margin'],terminal_multiple=s['terminal_multiple'],wacc=s['wacc'],terminal_growth=s['terminal_growth'],funded=terminal is not None,source_eligible=False,realized_revenue_cagr=((terminal['revenue']/o['sales'])**(ONE/d(years))-ONE) if terminal else None,unserved_sales=terminal['unserved_horizon_sales'] if terminal else sum((r['unserved_sales'] for r in rows[:n]),Z),terminal_applied_growth=terminal['terminal_growth_applied'] if terminal else None,failure_month=failure['month'] if failure else None,shortfall=failure['shortfall'] if failure else Z,terminal_price=terminal['price_per_share'] if terminal else None,irr=terminal['irr'] if terminal else None,dcf_price=terminal['dcf_per_diluted_share'] if terminal else None,price_multiple=terminal['price_multiple'] if terminal else None)
 return dict(path_id=path_id,years=years,spec=s,monthly=rows,annual=annual,failure=failure,terminal=terminal,summary=summary)
