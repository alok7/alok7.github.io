"""Explicit analyst cases; no scenario financing is represented as a sanction."""
from copy import deepcopy
from decimal import Decimal as D
def base(i):
 return {'label':'Conditional analytical reference','kind':'conditional_reference','volume_growth':'.10','price_growth':'0','customer_loss':str(D('16.29')/D(i['opening']['sales'])),'working_capital_transition_months':6,'ebitda_margin':'.16','fixed_cost_ratio':'.05','material_ratio':'.65','material_price_shock':'0','receivable_days':'90','inventory_days':'175','payable_days':'70','other_assets_ratio':str(D(i['opening']['other_operating_assets'])/D(i['opening']['sales'])),'receivable_loss':'0','receivable_loss_month':6,'inventory_loss':'0','inventory_loss_month':6,'maintenance_ratio':'.04','replacement_rate':'.10','new_asset_da_rate':'.10','expansion_gate':True,'capacity_buffer':'1.05','maximum_capacity':'1000','capex_per_sales':'.45','expansion_delay':12,'closure_cost':'.50','closure_month':1,'asset_sale_gate':False,'asset_sale_month':12,'asset_sale_recovery':'.5','term_amort_start':1,'term_amort_months':36,'term_final_month':48,'wc_review_month':12,'wc_renewal_gate':True,'demand_call_month':12,'demand_roll_gate':True,'flex_roll_gate':False,'flex_tenor':36,'roll_fee':'.01','term_rate':'.11','wc_rate':'.115','demand_rate':'.06','flex_rate':'.14','tax_rate':'.26','claims_months':12,'restricted_release_gate':False,'restricted_release_month':24,'nonop_recovery_fraction':'0','nonop_recovery_month':12,'annual_bank_fee':'.25','fund_call_months':12,'fund_terminal_recovery':'.5','contingent_payment':'0','contingent_month':12,'cash_floor':'.5','reserve_months':'.10','equity_gate':False,'equity_month':1,'equity_share_cap':0,'equity_price':'300','equity_fee':'.03','flex_gate':True,'flex_limit':'20','flex_cumulative_limit':'40','flex_fee':'.02','dividend_gate':False,'payout':'.10','wacc':'.15','terminal_growth':'.03','terminal_multiple':'8','nci_claim':'1.7645','associate_recovery':'.4247','entry_cost':'.01','exit_cost':'.01','opening_cash_increment':i['gross_subsequent_warrant_receipt'],'opening_equity_cash':'0','opening_new_shares':0,'opening_debt_repayment':'0'}
def scenarios(i):
 out=[];n=0
 def add(label,years=5,kind='sensitivity',**kw):
  nonlocal n
  n+=1;s=base(i);s.update(kw);s['label']=label;s['kind']=kind;out.append({'path_id':f'SKF{n:03d}','years':years,'spec':s})
 for name,g,margin,ard,invd in [('Bear','-.02','.12','135','210'),('Base','.10','.16','90','175'),('Bull','.18','.18','75','145')]:
  add(name+' source-bounded, gross receipts use unverified',kind='source_bounded',volume_growth=g,ebitda_margin=margin,receivable_days=ard,inventory_days=invd,opening_cash_increment='0',flex_gate=False,expansion_gate=False,terminal_multiple='6' if name=='Bear' else '8' if name=='Base' else '10')
  add(name+' conditional retained-receipt / financing laboratory',kind='conditional_reference',volume_growth=g,ebitda_margin=margin,receivable_days=ard,inventory_days=invd,terminal_multiple='6' if name=='Bear' else '8' if name=='Base' else '10')
 add('Conditional known receipt assumed demand-debt repayment',kind='receipt_use',opening_cash_increment='0',opening_debt_repayment=i['gross_subsequent_warrant_receipt'])
 add('Conditional known receipt already deployed',kind='receipt_use',opening_cash_increment='0')
 add('Conditional known receipt retained, no incremental borrowing',kind='receipt_use',flex_gate=False)
 for g in ['0','.05','.10','.15','.20','.25','.30','.35']:
  for mult in ['5','7','9','11','13']:add('Growth / multiple grid',volume_growth=g,terminal_multiple=mult)
 for margin in ['.12','.14','.16','.18','.20']:
  for w in ['.12','.14','.16','.18']:add('Margin / WACC grid',ebitda_margin=margin,wacc=w)
 for w in ['.12','.15','.18']:
  for tg in ['0','.02','.04','.05']:add('WACC / terminal growth grid',wacc=w,terminal_growth=tg)
 for years in [5,10]:
  for g in ['.10','.15','.20','.25','.30','.35','.40','.50']:
   for mult in ['6','10','14']:add('Fivefold / tenfold feasibility experiment',years,kind='target',volume_growth=g,terminal_multiple=mult,flex_limit='40',flex_cumulative_limit='80',maximum_capacity='3000',equity_gate=True,equity_share_cap=1500000,equity_price='300')
 for days in ['60','90','120','150']:
  for inv in ['120','180','240']:add('Receivable / inventory grid',receivable_days=days,inventory_days=inv)
 add('Bank line not renewed',kind='stress',wc_renewal_gate=False)
 add('All unsecured demand debt called month1',kind='stress',demand_roll_gate=False,demand_call_month=1)
 add('Unsecured demand debt called at terminal year',kind='stress',demand_roll_gate=False,demand_call_month=60)
 add('Unsecured demand debt called after terminal year',kind='stress',demand_roll_gate=False,demand_call_month=66)
 add('Receivables10percent loss plus customer loss',kind='stress',receivable_loss='.10',customer_loss='.25',receivable_days='150',ebitda_margin='.12')
 add('Inventory20percent loss / input inflation',kind='stress',inventory_loss='.20',material_price_shock='.10')
 add('Higher replacement capex',kind='stress',replacement_rate='.16',maintenance_ratio='.06')
 add('FD availability confirmed only as hypothetical release',kind='stress',restricted_release_gate=True,restricted_release_month=1)
 add('Lender headline headroom not independently available',kind='stress',flex_limit='6.9444',flex_cumulative_limit='6.9444')
 add('No funding other than conditional current cash',kind='stress',flex_gate=False)
 add('Early fund call all in month1',kind='stress',fund_call_months=1)
 add('NCIclaim at earningsmultiple lower',kind='claim_sensitivity',nci_claim='.599')
 add('NCIclaim above book',kind='claim_sensitivity',nci_claim='3')
 add('Associate and funds zero recovery',kind='claim_sensitivity',associate_recovery='0',fund_terminal_recovery='0')
 add('Associate and funds book recovery',kind='claim_sensitivity',associate_recovery='.8494',fund_terminal_recovery='1')
 add('Hypothetical equity funding, full issuancecost',kind='equity_sensitivity',equity_gate=True,equity_share_cap=1000000)
 add('Dividend distribution cannot remain terminal cash',kind='equity_sensitivity',dividend_gate=True)
 add('Additional indirect-tax working-capital drag',kind='stress',other_assets_ratio='.06')
 add('Instant working-capital target sensitivity',kind='stress',working_capital_transition_months=1)
 add('Slow twelve-month working-capital transition',kind='stress',working_capital_transition_months=12)
 add('No growth cash-conversion recovery',kind='recovery',volume_growth='0',receivable_days='60',inventory_days='120',ebitda_margin='.17',expansion_gate=False,flex_gate=False)
 return out
