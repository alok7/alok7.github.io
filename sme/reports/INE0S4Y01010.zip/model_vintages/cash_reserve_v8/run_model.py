from pathlib import Path
from decimal import Decimal as D
import json,gzip,hashlib,csv
from model import run
from scenarios import scenarios
P=Path(__file__).resolve().parent
def enc(x):
 if isinstance(x,D):return str(x)
 raise TypeError(type(x).__name__)
def write(n,x):(P/n).write_text(json.dumps(x,indent=2,default=enc)+'\n')
def main():
 i=json.loads((P/'model_source_anchors.json').read_text());write('model_inputs.json',i);specs=scenarios(i);write('scenario_inputs.json',specs);paths=[run(i,x['spec'],x['years'],x['path_id']) for x in specs];canon={'schema':'shree-karni-monthly-v1','units':'INRcrore unlessshares/price; signed originalclaims are separate from analyst assumptions','inputs':i,'paths':paths};b=json.dumps(canon,default=enc,separators=(',',':')).encode();(P/'canonical_paths.json.gz').write_bytes(gzip.compress(b,compresslevel=9,mtime=0));summaries=[p['summary'] for p in paths];targets=[]
 for years in [5,10]:
  a=[p for p in paths if p['years']==years and p['spec']['kind']=='target']
  for target in [5,10]:
   funded=[p for p in a if p['terminal']];cross=[p for p in funded if p['terminal']['price_multiple']>=target];targets.append(dict(years=years,target_multiple=target,paths=len(a),funded=len(funded),failed=len(a)-len(funded),conditional_crossings=len(cross),source_eligible_crossings=0,least_tested_growth=min((D(p['spec']['volume_growth']) for p in cross),default=None),crossing_paths=[p['path_id'] for p in cross]))
 summary={'path_count':len(paths),'monthly_rows':sum(len(p['monthly']) for p in paths),'funded_count':sum(p['terminal'] is not None for p in paths),'failed_count':sum(p['failure'] is not None for p in paths),'source_eligible_count':0,'main_cases':[p['summary'] for p in paths if p['spec']['kind']=='source_bounded'],'conditional_cases':[p['summary'] for p in paths if p['spec']['kind'] in ['conditional_reference','receipt_use','recovery']],'target_tests':targets,'paths':summaries,'canonical_sha256':hashlib.sha256((P/'canonical_paths.json.gz').read_bytes()).hexdigest(),'source_limit':i['source_eligibility_limit']};summary['reverse_expectations']={'method':'All tested funded paths, not a unique supported required-growth solution','hurdle':'0.15','tested_paths':len(paths),'funded_paths':sum(p['terminal'] is not None for p in paths),'conditional_hurdle_crossings':[p['summary'] for p in paths if p['terminal'] and p['terminal']['irr']>=D('.15')],'source_eligible_crossings':0};write('model_summary.json',summary);write('model_trace.json',{'canonical_sha256':summary['canonical_sha256'],'opening_inputs':i,'source_limit':i['source_eligibility_limit'],'all_path_summary':summaries,'all_monthly_rows_retained':'canonical_paths.json.gz','reverse_expectations':summary['reverse_expectations']});write('model_tables.json',{'main_paths':[{'summary':p['summary'],'spec':p['spec'],'annual':p['annual'],'terminal':p['terminal'],'failure':p['failure']} for p in paths if p['spec']['kind'] in ['source_bounded','conditional_reference','receipt_use','recovery']],'sensitivities':summaries,'target_tests':targets})
 with(P/'trial_index.csv').open('w') as f:
  w=csv.DictWriter(f,fieldnames=list(summaries[0]));w.writeheader();w.writerows(summaries)
 with(P/'annual_paths.csv').open('w') as f:
  a=[dict(path_id=p['path_id'],**r) for p in paths for r in p['annual']];w=csv.DictWriter(f,fieldnames=list(a[0]));w.writeheader();w.writerows(a)
 print(json.dumps({k:summary[k] for k in ['path_count','monthly_rows','funded_count','failed_count','canonical_sha256']}))
if __name__=='__main__':main()
