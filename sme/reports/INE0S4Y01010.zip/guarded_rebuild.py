"""Fresh inputs-only offline rebuild and exact output verification. No deletion or network."""
from pathlib import Path
import json,hashlib,subprocess,sys,shutil,tempfile
P=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def main():
 r=json.loads((P/'company_record.json').read_text());before={n:sha(P/n)for n in r['authored_input_sha256']}
 assert before==r['authored_input_sha256']
 target=Path(tempfile.mkdtemp(prefix='shree_karni369_rebuild_'))
 for n,h in before.items():
  q=target/n;q.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(P/n,q);assert sha(q)==h
 subprocess.run([sys.executable,str(target/'build.py')],cwd=target,check=True,capture_output=True,text=True)
 expected=dict(r['output_sha256']);expected['company_record.json']=sha(P/'company_record.json');expected['build_manifest.json']=sha(P/'build_manifest.json')
 comparisons={n:{'expected':h,'actual':sha(target/n),'match':sha(target/n)==h}for n,h in expected.items()}
 assert all(x['match']for x in comparisons.values()),comparisons
 assert {n:sha(P/n)for n in before}==before
 result={'status':'PASS','input_count':len(before),'output_count':len(comparisons),'inputs_only':True,'network_used':False,'source_unchanged':True,'comparisons':comparisons,'scope':'Deterministic reproduction of authored research; source reliability and investment eligibility remain separately qualified.'}
 (P/'rebuild_attestation.json').write_text(json.dumps(result,sort_keys=True,indent=2)+'\n')
 print(json.dumps({'status':'PASS','inputs':len(before),'outputs':len(comparisons)}))
if __name__=='__main__':main()
