# Shree Karni Fabcom Limited

SME research 369 · Master Prompt v3.0 · Information cutoff 20 October 2026 · Market cutoff 19 October 2026

## 1. Executive Verdict

Shree Karni Fabcom is a small B2B technical-fabric manufacturer and sourcing business whose integrated weaving, knitting, coating and dyeing capabilities offer a useful but contestable position. The investable thesis is an execution-sensitive manufacturing/redeployment situation, not an evidenced hold-forever compounder. Revenue has grown, but cash absorption and returns on the enlarged capital base have lagged accounting profit. The stitching-unit closure approved in June 2026 supersedes the earlier finished-goods growth story; existing fabric operations must justify the capital already committed. Completed promoter warrant conversions support financing but do not demonstrate that gross proceeds remain freely available. At the dated ₹418 close, the report separates scoreable historical quality from conditional valuation experiments and unresolved implementation evidence. Better cash conversion, a verified post-conversion funding bridge and profitable redeployment would matter more than promotional customer names or a lower quoted P/E.

## 2. Research Header, Gates and Data Confidence

| Item | Basis |
|---|---|
| Issuer | Shree Karni Fabcom Limited / NSE Emerge SHREEKARNI / INE0S4Y01010 |
| Original instrument | Position 369; original symbol SHREEKARNI |
| Cutoffs | Information 20 October 2026; market 19 October 2026; no later information used |
| Price | NSE 19 October close ₹418; not a guaranteed executable quote |
| Issued shares / trading master | 7543750 actual issued; 7228750 in dated trading master |
| Board lot / reference | 150 shares / ₹62,700; seven lots cost ₹438,900 within illustrative ₹5 lakh |
| Market capitalization | ₹315.33 crore on actual issued shares |
| Scope / accounting | Consolidated group, separately identified predecessor and parent-core cross-check; Indian GAAP Accounting Standards, not Ind AS |
| Units / horizon | ₹ crore unless labeled; five-year scenarios and ten-year feasibility |
| Equity hurdle / WACC | 15% nominal before investor taxes; 12% and 18% hurdle sensitivities. Nominal WACC is a separate assumption, not mechanically the hurdle. |

| Gate | Status | Evidence / what resolves it |
|---|---|---|
| G1 | Conditional | Mixed capital allocation, related-party structure and procedural disclosure issues, but no substantiated severe integrity failure identified in reviewed records. Track fair terms, use of capital, closure costs and complete related-party/pledge disclosures. |
| G2 | Conditional | Original restatements, FY24 split periods, deferred costs, EPS presentation errors and bank-return differences are retained and substantially bounded; main audit and IFC are unmodified. Obtain outstanding classification/confirmation clarifications and maintain comparable accounting bases. This is not an evidenced fraud or blanket financial-reliability hold. |
| G3 | Conditional | High working-capital and debt dependence with low March cash, tempered by no audited default and actual later exercise receipts; present usable funding is not fully bridged. Reconcile post-conversion cash/debt, borrowing-base headroom, maturity dates, fund calls and stress financing. |
| G4 | Conditional | Observed trading and verified board lot, but thin recent turnover, two unknown issuer rows and unverified depth/spread prevent a complete implementation score. Verify all 60 sessions, current surveillance restrictions and position-specific executable depth before considering a trade. |

| Subject | Assessment |
|---|---|
| identity | High: issuer ISIN and dated allotments distinguish actual issued from market-master shares. |
| historical financials | Medium: original statements reconcile materially, with scope, tax and comparative limitations retained. |
| governance | Medium: primary audit and capital-allocation evidence available; some confirmation/term details remain. |
| growth decomposition | Medium: parent-core revenue history is available; exact organic volume/mix and post-closure unit contributions are incomplete. |
| capital returns | Medium: committed-capital proxies and tax normalization support weak realized returns; integration and maturation limit attribution. |
| valuation inputs | Low for an actionable current valuation: cash/debt bridge, terminal ownership claims and implementation conditions remain uncertain. |

## 3. Scorecard and Calculation Audit

| Measure | Raw | Final / display | Coverage | Mathematical bound / cap | Quality ranking eligible |
|---|---|---|---|---|---|
| BQS | 4.6400 | 4.6 | 100.00% | 4.6400 to 4.6400; cap none | True |
| GQS | 5.1500 | 5.0 | 100.00% | 5.1500 to 5.1500; cap 5 | True |
| IAS | NS | NS | 25.00% | 1.9100 to 8.6600; cap none | False |

| Factor | Score / confidence | Facts and contrary evidence | Rationale / source IDs |
|---|---|---|---|
| GOV | 5 / Medium | The group includes controlled and associated LLPs, related-party finance and business dealings requiring minority-owner scrutiny. Capital was committed to a stitching adjacency later closed; a dated late-meeting-notice warning and deferred-cost accounting require proportionate attention. Counterevidence: The main audit and IFC opinions are unmodified, bank differences have stated explanations, actual promoter exercise receipts are disclosed and the regulatory warning is not a finding of fraud. | Mixed stewardship rather than evidenced severe abuse. Do not infer misconduct from an LLP structure, an SME exemption or an unsuccessful investment. [SKFL-AR26](https://archives.nseindia.com/annual_reports/SME_AR_31851_SHREEKARNI_2025_2026_A_7707609_08092026130825.pdf); [SKFL-W1](https://skflindia.com/wp-content/uploads/2026/08/Outcome_of_Circular_Resolution_Allotment_25082026.pdf); [SKFL-W2](https://skflindia.com/wp-content/uploads/2026/09/Outcome_of_Circular_Resolution_Allotment_29082026.pdf); [SKFL-W3](https://skflindia.com/wp-content/uploads/2026/09/Outcome_of_Circular_Resolution_Allotment_02092026.pdf); [SKFL-WARN25](https://skflindia.com/wp-content/uploads/2025/10/Covering_Cautioning_Email_30102025.pdf) |
| MOAT | 5 / Medium | Integrated fabrication and customer-specific technical fabrics provide useful process know-how and qualification relationships. Customer bargaining power, import competition, sourcing alternatives and limited independently established market share constrain pricing power. Counterevidence: An established fabric business and operating scale are real capabilities; closure of a separate stitching operation does not erase them. | Useful but contestable capabilities, not a demonstrated structural moat or automatic premium for famous prospective customers. [SKFL-P](https://skflindia.com/wp-content/uploads/2023/12/Shree_Karni_Fabcom_Limited-PROSPECTUS.pdf); [SKFL-AR26](https://archives.nseindia.com/annual_reports/SME_AR_31851_SHREEKARNI_2025_2026_A_7707609_08092026130825.pdf); [SKFL-CALL25](https://nsearchives.nseindia.com/corporate/SHREEKARNI_27112025171406_Intimation_Earning_Call_Transcript_Signed.pdf) |
| REV | 7 / Medium | Preferred parent-core FY23–26 revenue grows from ₹126.9465 crore to ₹202.9533 crore, a 16.93% CAGR. The consolidated three-year cross-check is about 17.04%; five-year growth starts in a pandemic-depressed period and changes operating perimeter. Counterevidence: FY26 parent revenue growth remains above 20%, but the closed stitching business and uncertain mix/volume split constrain extrapolation. | Starting 7 for 15% to less than 20% comparable three-year CAGR; no net trajectory adjustment. Window chosen before scoring, not selected to obtain a preferred score. The COVID-distorted five-year result is disclosed, not hidden. [SKFL-P](https://skflindia.com/wp-content/uploads/2023/12/Shree_Karni_Fabcom_Limited-PROSPECTUS.pdf); [SKFL-AR24](https://archives.nseindia.com/annual_reports/SME_AR_25895_SHREEKARNI_2023_2024_05092024193034.pdf); [SKFL-AR25](https://archives.nseindia.com/annual_reports/SME_AR_28942_SHREEKARNI_2024_2025_A_11564635_08092025185428.pdf); [SKFL-AR26](https://archives.nseindia.com/annual_reports/SME_AR_31851_SHREEKARNI_2025_2026_A_7707609_08092026130825.pdf) |
| DUR | 5 / Medium | Technical fabrics have several continuing end-use applications and potential specialized-product/distribution avenues. The stitching closure removes a previously promoted growth route; customer adoption, sourcing economics and capacity utilization remain constraints. Counterevidence: Broader fabrics and Italian product distribution can provide genuine opportunity if orders and economics follow. | Accessible but execution-dependent runway, without treating global technical-textiles TAM as contracted company demand. Returns on the required capital are assessed in CAP, not deducted twice here. [SKFL-AR26](https://archives.nseindia.com/annual_reports/SME_AR_31851_SHREEKARNI_2025_2026_A_7707609_08092026130825.pdf); [SKFL-CALL25](https://nsearchives.nseindia.com/corporate/SHREEKARNI_27112025171406_Intimation_Earning_Call_Transcript_Signed.pdf); [SKFL-CLOSE26](https://skflindia.com/wp-content/uploads/2026/06/Outcome_of_Board_Meeting_24062026.pdf); [SKFL-PARTNER26](https://skflindia.com/wp-content/uploads/2026/05/Press_Release.pdf) |
| CAP | 3 / Medium | The parent-core three-year normalized incremental NOPAT / committed IC proxy is about 4.90%, with all committed capital included. The five-year parent proxy is about 8.38%, also below the disclosed 12–15% nominal capital-cost range; group proxies are weaker and perimeter-qualified. Counterevidence: Newly commissioned assets may mature and earlier margins on old assets were useful; these possibilities do not establish adequate realized incremental returns. | Persistent weak additional-capital productivity, not a punishment for expansion itself. Total committed CWIP, financing and nonoperating exclusions are explicit, and no accounting ratio is called a project IRR. [SKFL-P](https://skflindia.com/wp-content/uploads/2023/12/Shree_Karni_Fabcom_Limited-PROSPECTUS.pdf); [SKFL-AR24](https://archives.nseindia.com/annual_reports/SME_AR_25895_SHREEKARNI_2023_2024_05092024193034.pdf); [SKFL-AR25](https://archives.nseindia.com/annual_reports/SME_AR_28942_SHREEKARNI_2024_2025_A_11564635_08092025185428.pdf); [SKFL-AR26](https://archives.nseindia.com/annual_reports/SME_AR_31851_SHREEKARNI_2025_2026_A_7707609_08092026130825.pdf) |
| CASH | 3 / Medium | FY24–26 group CFO totals ₹1.8528 crore against aligned PAT of ₹46.0556 crore, only about 4.02%. Parent cumulative CFO is negative despite profits; inventory and trade working capital absorb substantial funding. Counterevidence: FY26 group CFO turns positive and receivables over six months decline; the symmetric economic cash-flow sensitivity is better than reported CFO. | Multi-year weak realization merits 3; a genuine latest-year recovery does not yet undo the record. Capex affects investing cash rather than excusing operating cash absorption. [SKFL-AR24](https://archives.nseindia.com/annual_reports/SME_AR_25895_SHREEKARNI_2023_2024_05092024193034.pdf); [SKFL-AR25](https://archives.nseindia.com/annual_reports/SME_AR_28942_SHREEKARNI_2024_2025_A_11564635_08092025185428.pdf); [SKFL-AR26](https://archives.nseindia.com/annual_reports/SME_AR_31851_SHREEKARNI_2025_2026_A_7707609_08092026130825.pdf) |
| BAL | 4 / Medium | FY26 group net debt excluding unverified FD availability is ₹98.1102 crore, about 3.15 times strict operating EBITDA; strict EBIT interest coverage is about 3.82 times. Reported cash ₹0.123 crore is small against ₹9.212 crore next-year term maturities, ₹25.765 crore unsecured demand borrowing and ₹2.2311 crore fund commitments. Counterevidence: Auditors report no default, gross debt declined during FY26 and subsequent promoter warrant balance receipts total ₹18.073125 crore. | Material funding sensitivity is sufficiently evidenced to score 4 rather than force NS. The current use of exercise proceeds and drawable credit remain scenario conditions, not assumed available rescue. [SKFL-AR26](https://archives.nseindia.com/annual_reports/SME_AR_31851_SHREEKARNI_2025_2026_A_7707609_08092026130825.pdf); [SKFL-W1](https://skflindia.com/wp-content/uploads/2026/08/Outcome_of_Circular_Resolution_Allotment_25082026.pdf); [SKFL-W2](https://skflindia.com/wp-content/uploads/2026/09/Outcome_of_Circular_Resolution_Allotment_29082026.pdf); [SKFL-W3](https://skflindia.com/wp-content/uploads/2026/09/Outcome_of_Circular_Resolution_Allotment_02092026.pdf) |
| EXEC | 4 / Medium | The June 2026 stitching closure supersedes the prior finished-goods/Walmart/Target expansion expectations. An enlarged committed asset base has not yet produced commensurate operating profit and cash, and deferred expansion costs were charged off. Counterevidence: The continuing fabric business grew sales and commissioned dyeing assets; stopping a poor project can be a rational corrective action. | Material mixed delivery with a failed adjacency; 4 reflects observed execution rather than a penalty for not issuing guidance. The dated target-versus-outcome table preserves both successes and reversals. [SKFL-AR26](https://archives.nseindia.com/annual_reports/SME_AR_31851_SHREEKARNI_2025_2026_A_7707609_08092026130825.pdf); [SKFL-CALL25](https://nsearchives.nseindia.com/corporate/SHREEKARNI_27112025171406_Intimation_Earning_Call_Transcript_Signed.pdf); [SKFL-CLOSE26](https://skflindia.com/wp-content/uploads/2026/06/Outcome_of_Board_Meeting_24062026.pdf) |
| EARN | 4 / Medium | FY26 owner PAT is broadly flat while current-share and historical weighted EPS bases differ; revenue expansion did not translate into comparable owner earnings growth. Operating EBIT is weaker than gross sales growth, other income is material and deferred startup costs make year-on-year earnings interpretation less clean. Counterevidence: Profit remains positive and the strict operating core is material; the write-off and original comparative corrections are disclosed rather than hidden. | Mixed to weak recurring per-share progression and normalization dependence. This factor addresses profit sources and dilution, not a repeat of the cash-conversion deduction. [SKFL-AR26](https://archives.nseindia.com/annual_reports/SME_AR_31851_SHREEKARNI_2025_2026_A_7707609_08092026130825.pdf); [SKFL-AR25](https://archives.nseindia.com/annual_reports/SME_AR_28942_SHREEKARNI_2024_2025_A_11564635_08092025185428.pdf); [SKFL-P](https://skflindia.com/wp-content/uploads/2023/12/Shree_Karni_Fabcom_Limited-PROSPECTUS.pdf) |
| R | NS / Low | Model paths require explicit choices about the post-March cash/debt bridge and disposition of subsequent exercise receipts. Scenario growth, debt renewal and additional financing are not lender commitments or independently supported current balances. Counterevidence: The operating business and known promoter receipts permit useful conditional experiments. | A supported live base-case investor return is not established; retain NS rather than convert a favorable hypothetical path into R. [SKFL-AR26](https://archives.nseindia.com/annual_reports/SME_AR_31851_SHREEKARNI_2025_2026_A_7707609_08092026130825.pdf); [SKFL-W3](https://skflindia.com/wp-content/uploads/2026/09/Outcome_of_Circular_Resolution_Allotment_02092026.pdf) |
| D | NS / Low | Linked operating and funding stress can impair equity through dilution, cash shortfalls and weak recovery of illiquid assets. Exact current usable cash, maturity timing and ownership claims affect recovery materially. Counterevidence: No audited default is reported and genuine new capital was disclosed. | Conditional stress is quantified but a source-supported numerical downside-resilience score is not forced. Severe hypothetical loss is not observed default. [SKFL-AR26](https://archives.nseindia.com/annual_reports/SME_AR_31851_SHREEKARNI_2025_2026_A_7707609_08092026130825.pdf); [SKFL-W3](https://skflindia.com/wp-content/uploads/2026/09/Outcome_of_Circular_Resolution_Allotment_02092026.pdf) |
| P | NS / Low | Reverse expectations require the same unverified current funding bridge as prospective returns. Capacity and margin assumptions, additional capex, terminal claims and multiple normalization materially change hurdle prices. Counterevidence: The report supplies a finite disclosed grid and current-multiple cross-check instead of omitting valuation. | Do not score a conditional reverse model as a verified priced-in expectation for this equity. [SKFL-AR26](https://archives.nseindia.com/annual_reports/SME_AR_31851_SHREEKARNI_2025_2026_A_7707609_08092026130825.pdf); [SKFL-CALL25](https://nsearchives.nseindia.com/corporate/SHREEKARNI_27112025171406_Intimation_Earning_Call_Transcript_Signed.pdf) |
| L | NS / Low | The recent 20-session window is complete; a ₹5 lakh position at 5% of its conservative traded value implies about 19.54 theoretical exit days. The 60-session set has 58 observed issuer rows; July 24 and July 28 are unknown, and spread/order depth are unverified. Counterevidence: The security traded on October 19 and one 150-share lot costs ₹62,700; absence of two rows is not proof of suspension. | Keep L NS because the prescribed 60-session denominator is incomplete. No zero imputation or false certainty about execution. [NSE-MARKET](https://nsearchives.nseindia.com/content/cm/BhavCopy_NSE_CM_0_0_0_20261019_F_0000.csv.zip) |

| Factor | BQS contribution | GQS contribution | IAS contribution |
|---|---|---|---|
| GOV | 1.0000 | NA | NA |
| MOAT | 1.0000 | NA | NA |
| REV | 0.8400 | 2.8000 | NA |
| DUR | 0.5000 | 1.0000 | NA |
| CAP | 0.3600 | 0.4500 | NA |
| CASH | 0.3000 | 0.3000 | NA |
| BAL | 0.3200 | NA | NA |
| EXEC | 0.3200 | NA | NA |
| EARN | NA | 0.6000 | NA |
| R | NA | NA | NS |
| D | NA | NA | NS |
| P | NA | NA | NS |
| L | NA | NA | NS |
| BQS | NA | NA | 1.1600 |

GQS is Growth Quality Score, not governance. GOV is the governance factor. Exact Decimal arithmetic and conventional half-up display are retained; unrounded scores govern classification and IAS. CAP 3 and CASH 3 reflect persistent weak incremental productivity and cash realization; final GQS is capped at 5. This is one disclosed cap, not two cumulative deductions. No governance or evidenced-funding-failure cap is applied. Critical IAS evidence remains NS without weight redistribution.

GOV or MOAT ±1 changes BQS by 0.20; CAP ±1 changes BQS by 0.12 and raw GQS by 0.15. REV ±1 changes BQS by 0.12 and raw GQS by 0.40. These are judgment sensitivities, not confidence intervals. A scoreable historical quality record need not have a scoreable investment setup; conditional gates are not automatically failed gates.

## 4. Business Overview

### Business overview

### Legal identity and economic perimeter
Shree Karni Fabcom Limited is the listed issuer, ISIN INE0S4Y01010, NSE symbol SHREEKARNI, CIN L47820GJ2023PLC140106. Its antecedent LLP was incorporated on 7 March 2018; commercial operations began in 2019, conversion to a company occurred on 11 April 2023, and it became public on 20 October 2023. Listing followed on 14 March 2024. This is a young operating and public-market history, not a long-cycle proof of compounder economics. [SKFL-P](https://skflindia.com/wp-content/uploads/2023/12/Shree_Karni_Fabcom_Limited-PROSPECTUS.pdf); [SKFL-AR26](https://archives.nseindia.com/annual_reports/SME_AR_31851_SHREEKARNI_2025_2026_A_7707609_08092026130825.pdf)

The business manufactures and supplies technical fabrics used in luggage, backpacks, footwear and apparel lining, medical arch support, chairs and upholstery. It is a B2B producer: the end consumer normally buys a customer's product, not a Shree Karni-branded fabric. The economic activity combines yarn procurement, fabric production, processing, finishing and customer-specific delivery. The parent performs knitting and now dyeing; IGK Technical Textiles LLP supplies important weaving/coating/sizing/embossing capabilities. The parent owns 66.67% of IGK. Textron Fabtech LLP is a 45%-owned associate (FY26 AOC1, printed p37/PDF40), not a wholly owned plant whose cash belongs entirely to listed shareholders. Consolidated operating performance must therefore be separated from owner-attributable profit and distributable cash. Eliminating intercompany transactions is essential. [SKFL-P pp128–134](https://skflindia.com/wp-content/uploads/2023/12/Shree_Karni_Fabcom_Limited-PROSPECTUS.pdf); [SKFL-AR26 pp36–42 and financial notes](https://archives.nseindia.com/annual_reports/SME_AR_31851_SHREEKARNI_2025_2026_A_7707609_08092026130825.pdf)

This is physical manufacturing with meaningful fixed assets, inventory and receivable funding. It is not an asset-light platform, a contracted utility or an EPC order-book business. It carries raw-material costs and customer collection risk even when incremental demand can use installed machinery. Procurement purchase orders and forecasts are not equivalent to long-duration take-or-pay contracts.

### How customers decide and what creates cash
A buyer evaluates fabric strength, colour consistency, coating quality, waterproof or other performance attributes, approved specifications, delivery reliability and price. Process coordination and quality control can make a qualified supplier useful. The economic benefit accrues only if that usefulness translates into repeat orders at prices covering raw material, conversion, depreciation, finance costs and collection risk. Famous customer logos alone do not establish pricing power or exclusivity.

The prospectus identifies a highly competitive, fragmented industry and purchase-order based selling without long-term customer contracts. The company also lacked a formal binding service agreement with IGK at IPO and did not generally have binding raw-material supply contracts. Integration lowers coordination exposure but does not make polyester or nylon prices controllable. The absence of long contracts need not prevent a good manufacturing business, but it changes the duration of the cash-flow claim: each selling cycle has to be earned again. [SKFL-P pp31–33,132–134,219](https://skflindia.com/wp-content/uploads/2023/12/Shree_Karni_Fabcom_Limited-PROSPECTUS.pdf)

### Facility status is not interchangeable with product ambition
Dyeing commenced commercially on 6 April 2025, according to a signed exchange disclosure. A Noida facility commenced on 27 June 2025. These are actual milestones, unlike capacity proposals. However, the board approved closure of the stitching facility on 24 June 2026, with completion expected by the end of that month. FY26 turnover of the unit was ₹16.29 crore, 8.03% of the stated company turnover, and net worth ₹10.47 crore, 9.60%. The disclosure says a sale agreement is not applicable. Those are economic scale figures, not cash-sale proceeds. Do not silently retain closed stitching capacity in a growth model or assume its net worth is realizable cash. [SKFL-DYE25](https://skflindia.com/wp-content/uploads/2025/04/Intimation_Commercial_Production_06042025.pdf); [SKFL-NOIDA25](https://skflindia.com/wp-content/uploads/2025/06/Intimation_Commercial-Production_Noida-Factory_27.06.2025.pdf); [SKFL-CLOSE26](https://skflindia.com/wp-content/uploads/2026/06/Outcome_of_Board_Meeting_24062026.pdf)

## 5. Moat and Industry Position

### Moat and industry position

### Integration: a useful capability, not a monopoly
Mechanism: weaving/knitting, coating and dyeing coordination can reduce outsourced lead times and rejects and improve specification control. Evidence: operating IGK production, commercial dyeing commissioning and a multi-process portfolio. Durability: these facilities and trained processes take capital and time to replicate. Failure mode: capable competing mills can buy similar equipment; excess industry capacity or customer dual-sourcing can pass savings to buyers. Public evidence does not quantify a persistent cost gap against the next-best supplier. Therefore integration supports a contestable operating advantage, not an automatic high-moat score. [SKFL-P](https://skflindia.com/wp-content/uploads/2023/12/Shree_Karni_Fabcom_Limited-PROSPECTUS.pdf); [SKFL-PPT25](https://nsearchives.nseindia.com/corporate/SHREEKARNI_24082025125109_INVESTOR_PRESENTATION.pdf); [SKFL-DYE25](https://skflindia.com/wp-content/uploads/2025/04/Intimation_Commercial_Production_06042025.pdf)

### Qualification: stronger evidence than logos, weaker than guaranteed revenue
The signed 27 June 2025 exchange announcement states that Shree Karni cleared Walmart's audit and became an approved vendor in India. In November 2025 management discussed Walmart and Target vendor codes and hoped these customers could contribute 20% of business in the following year, conditional on tariff conditions. Approval demonstrates a capability threshold. It does not disclose minimum purchases, duration, exclusivity, price protection, margins or cash advances. The June 2026 stitching closure undermines a straight-line extrapolation of the finished-product strategy without proving vendor approval itself was revoked. A responsible report preserves both the qualification achievement and the subsequently changed monetization route. [SKFL-WALMART25](https://skflindia.com/wp-content/uploads/2025/06/Intimation_Business_Updates_27062025.pdf); [SKFL-CALL25 pp15–17](https://nsearchives.nseindia.com/corporate/SHREEKARNI_27112025171406_Intimation_Earning_Call_Transcript_Signed.pdf); [SKFL-CLOSE26](https://skflindia.com/wp-content/uploads/2026/06/Outcome_of_Board_Meeting_24062026.pdf)

### Concentration and switching
FY23 top-five customer concentration was 43.54%; top ten were 61.12%. For the eight months ended November 2023, corresponding figures were 60.30% and 74.23%. These are dated concentration measures, not FY26 customer shares. The partial-period increase may reflect seasonality as well as concentration, but it leaves insufficient evidence for broad customer diversification. FY23 Maharashtra contributed 43.02% and Gujarat 26.44%, with the top five states accounting for 84.78%. FY23 top-ten suppliers were 46.97% of purchases. Current customer/supplier concentration and binding contract duration remain open items. [SKFL-P pp31–33,132–134](https://skflindia.com/wp-content/uploads/2023/12/Shree_Karni_Fabcom_Limited-PROSPECTUS.pdf)

A customer can value reliable delivery and still negotiate aggressively. No verified market-share denominator establishes national leadership in the exact product set. Management's narrow positioning claims must not be expanded into a general technical-textiles market monopoly. Retention, price resets and rejection data over several years would be more probative than a customer logo page.

### Comparative moat judgment
Nobletex is a closer process/product comparator than a civil contractor. Mayur Uniquoters is an adjacent coated-fabric producer whose automotive qualification and export mix make its economics informative but not directly transferable. SRF's coated/laminated-fabric operations are relevant, while SRF's chemicals earnings are not. Garware's specialized application development illustrates what deeper intellectual-property/customer-solution differentiation can look like, but it is not a like-for-like luggage-fabric peer. The separate peer module specifies period, scope and unavailable cash data rather than assigning unverified multiples.

Suggested MOAT: 5/10, medium confidence. Useful integration and demonstrated vendor qualification coexist with replicable machinery, concentrated purchase-order demand and unproven sustained pricing advantage. A score of 7 would require clearer evidence of superior retained economics and switching costs, not simply larger installed capacity.

#### Economic peer comparison: bounded rather than false precision

Cutoff 20-Oct-2026. Comparators are selected for process economics, customer qualification and working-capital/cash characteristics, not an industry label. None supplies a directly transferable valuation multiple. Periods differ and are explicitly retained; ND means not independently verified, not zero.

| Comparator / evidence period | Economic relevance | Verified economics | Cash evidence / limitations |
|---|---|---|---|
| Nobletex Industries, FY23 | Direct unlisted technical/coated-fabric comparator identified in Shree Karni's prospectus. | Revenue ₹178.2868 crore; EBITDA ₹16.017 crore; PAT ₹8.3583 crore. Recalculated EBITDA margin 8.98%, PAT margin 4.69%. | CFO/capex ND. Prospectus reports net debt/EBITDA2.11 but uses its own definitions. Its printed margins 8.89%/4.64% do not exactly match the displayed numerator/denominator, so do not silently use them as audited recalculations. Data are historical, not FY26. [SKFL-P p 99](https://skflindia.com/wp-content/uploads/2023/12/Shree_Karni_Fabcom_Limited-PROSPECTUS.pdf) |
| Mayur Uniquoters, FY25 consolidated | Adjacent PVC/PU coated-fabric manufacturer serving automotive, footwear and furnishing, with qualification and export exposure. | Revenue operations ₹880.1375 crore versus ₹802.9794 crore, +9.61%; PAT ₹149.2894 crore; PAT margin 16.96%. Other income₹40.725 crore is significant and is not sales. | CFO₹156.9381 crore; cash PPE/intangible acquisition₹19.4019 crore; simple CFO-minus-cash-capex₹137.5362 crore; CFO/PAT1.0512x. This is not shareholder FCFE because financing, dividends and acquisitions require separate treatment. [PEER-MAYUR25 printed 173,175/PDF176,178](https://bsmedia.business-standard.com/_media/bs/data/announcements/bse/18082025/add1cb35-e052-45c2-9b85-1990c463ffc0.pdf) |
| Garware Technical Fibres, qualitative historical comparator | Specialized application development in geosynthetic solutions and technical fibres provides an alternative source of differentiation to general fabric capacity. | Issuer investor page explicitly dates its figures to FY21–22:65% international revenue and more than 75patents filed/23 received. These must not be labeled FY26. | Current audited CFO/capex not independently retrieved in this module. Use as a moat mechanism contrast only, not a current financial or valuation benchmark. [PEER-GARWARE-WEB](https://www.garwarefibres.com/investors) |
| SRF Others segment, FY26 consolidated | Coated fabric, laminated fabric and ancillary activities; specifically not chemicals. | Revenue ₹366.38 crore versus ₹427.54 crore, down 14.31%; segment EBIT ₹47.03 crore versus ₹68.83 crore, down 31.67%; EBIT margin 12.84% versus 16.10%. | Segment capital expenditure ₹41.10 crore versus ₹22.43 crore; depreciation₹12.26 crore versus ₹7.80 crore. Segment CFO is not disclosed here. Capex is a segment accounting measure, not established cash paid; do not label EBIT+depreciation−capex as FCF. [PEER-SRF26 printed 449–451/PDF227–228](https://cdn.financialreports.eu/financialreports/media/filings/61903/2026/RNS/61903_rns_2026-06-06_12d05341-f32b-4ff4-b16b-4abc690b2d3d.pdf) |

Mayur's FY26 chairman statement reports consolidated total income₹1,022.0762 crore and PAT₹191.74 crore,53.6million linear metres total PVC/PU capacity and 42% export revenue. These are issuer statements, not a reconstructed FY26 cash-flow table. Total income must not be equated with revenue from operations. The verified FY25 audited cash comparison is therefore retained rather than joining FY26 earnings to FY25 cash. [PEER-MAYUR26-WEB](https://www.mayuruniquoters.com/chairman-communication.php)

The strongest quantitative comparison here is Mayur: a coating-related producer can generate operating cash broadly matching profit and fund modest cash capex internally. Shree Karni cannot borrow that outcome from a similar product label; its own receivables, inventory, new-facility utilization and debt servicing must establish it. Conversely, Mayur's qualification mix and scale make its margins an aspirational cross-check, not a realistic automatic terminal margin for Shree Karni.

Nobletex makes a different point: a closer process competitor historically had materially lower margins than Mayur. Product and customer mix can dominate the broad technical-textiles label. Because Nobletex's source is an issuer prospectus reproducing peer annual-report data, it is primary for what Shree Karni disclosed, not an independently archived Nobletex annual report. Financial comparability confidence is medium-low.

This module does not claim a complete synchronized three-peer financial panel. Three numerical comparisons and one qualitative control are available; current peer cash data remain a gap. A reviewer should retain this limitation rather than fill missing cells from an aggregator or pretend that infrastructure contractors are economic peers.

SRF supplies a useful cycle cross-check: even a larger integrated coating operation suffered declining sales and EBIT in FY26 while segment investment increased. Its financial strength and chemical profits do not insulate the coating segment from competition and demand weakness. This supports testing utilization and margins jointly rather than assuming that new Shree Karni capacity must deliver premium margins.


## 6. Revenue Growth and Scale

| FY / scope | Revenue | Annual addition | YoY | Operating EBITDA / margin | Operating EBIT |
|---|---|---|---|---|---|
| FY21 Restated predecessor LLP | 32.8742 | ND | NS | 3.7806 / 11.50% | 3.5405 |
| FY22 Restated predecessor LLP | 83.5736 | 50.6994 | 154.22% | 8.2032 / 9.82% | 7.6768 |
| FY23 Restated predecessor LLP | 126.9465 | 43.3729 | 51.90% | 15.0976 / 11.89% | 13.5728 |
| FY24 consolidated full-year, FY24 split-period reconciled | 137.0777 | 10.1312 | 7.98% | 25.4809 / 18.59% | 22.3785 |
| FY25 consolidated full-year, FY24 split-period reconciled | 166.9777 | 29.9000 | 21.81% | 28.0487 / 16.80% | 21.9585 |
| FY26 consolidated full-year, FY24 split-period reconciled | 203.5441 | 36.5664 | 21.90% | 31.1954 / 15.33% | 21.6502 |

| Window / scope | Starting / ending revenue | CAGR |
|---|---|---|
| consolidated 3y | 126.9465 / 203.5441 | 17.04% |
| consolidated 5y | 32.8742 / 203.5441 | 44.00% |
| standalone 3y | 126.9465 / 202.9533 | 16.93% |
| standalone 5y | 32.8742 / 202.9533 | 43.92% |

Ten-year CAGR is ND: an eleven-observation comparable operating series is unavailable. FY24 predecessor plus company-period revenue is reconciled, not double counted. [SKFL-P](https://skflindia.com/wp-content/uploads/2023/12/Shree_Karni_Fabcom_Limited-PROSPECTUS.pdf); [SKFL-AR24](https://archives.nseindia.com/annual_reports/SME_AR_25895_SHREEKARNI_2023_2024_05092024193034.pdf); [SKFL-AR25](https://archives.nseindia.com/annual_reports/SME_AR_28942_SHREEKARNI_2024_2025_A_11564635_08092025185428.pdf); [SKFL-AR26](https://archives.nseindia.com/annual_reports/SME_AR_31851_SHREEKARNI_2025_2026_A_7707609_08092026130825.pdf)

### Revenue growth and scale

### Historical expansion is real; reporting scope matters
The IPO financial KPI table gives revenue ₹32.8742 crore in FY21, ₹83.5736 crore in FY22 and ₹126.9465 crore in FY23. The latest annual report gives FY26 revenue ₹203.5441 crore versus ₹166.9777 crore in FY25. These represent substantial absolute scaling, but the five-year starting point includes the pandemic period and the legal/group perimeter evolved. The financial reconstruction establishes a three-year group CAGR of 17.0431%, while the preferred parent-only series gives 16.9298%; both fall in the framework starting REV7 band. These are reconciled, perimeter-qualified series, with the parent series preferred over the acquisition-affected group series; neither is a measured organic-growth series. A raw high CAGR from FY21 must not be selected simply because it scores better. Nor should an arbitrary acquisition discount be invented when organic growth cannot be measured. [SKFL-P p98](https://skflindia.com/wp-content/uploads/2023/12/Shree_Karni_Fabcom_Limited-PROSPECTUS.pdf); [SKFL-AR26 p18](https://archives.nseindia.com/annual_reports/SME_AR_31851_SHREEKARNI_2025_2026_A_7707609_08092026130825.pdf)

FY26 revenue grew about 21.90%. That is commercially meaningful and below the minimum 25% growth aspiration stated in November 2025. One annual deviation is not evidence of dishonesty; it does show why guidance is not a substitute for recorded revenue. The latest half-year comparisons and owner-attributable profit bridge should be taken from audited financial reconstruction, not this business module. Profit-margin improvement or new capex cannot earn REV points.

### Driver bridge
1. Production volume increased as woven capacity and utilization expanded.
2. Vertical integration added dyeing capability and potential savings; it does not automatically add an equal amount of third-party consolidated revenue because internal processing must be eliminated.
3. Higher-value nylon or specialty products can lift rupees per metre, but this is mix, not the same as physical volume.
4. Finished bags added a new business line that was subsequently curtailed through stitching closure.
5. Contract manufacturing may support revenue without identical owned-machine output, while requiring supplier quality control and working capital.
6. Imported/distributed technical knits under the Italian partnership create a different gross-margin and capital-intensity mix from proprietary manufacturing.

Management said in November 2025 that product prices could range from approximately ₹30 fabric to ₹100 nylon and that additional revenue could come with relatively few machines. This is evidence that product mix and bottlenecks matter, not a valid universal realized selling price. Applying one price to all weaving, coating and dyeing throughput would double-count material moving through several stages. [SKFL-CALL25 pp6,17](https://nsearchives.nseindia.com/corporate/SHREEKARNI_27112025171406_Intimation_Earning_Call_Transcript_Signed.pdf)

### Capacity units and utilization
Prospectus woven capacity was 1.04 million metres in FY22 and 12.48 million in FY23, with production 0.535822 million and 10.637544 million respectively. Knitting was stated in kilograms: installed 945,000 kg and production 671,000 kg in FY23. The August 2025 presentation's knitting chart shows figures four times those kilogram numbers, suggesting a conversion basis; without a clearly verified unit caption, do not treat the charts as directly comparable kilograms. Woven FY25 chart capacity/production was 21.2m/15.118m, approximately 71.31% utilization; coating capacity/production 33.6m/29.307m, or 87.22%. These are different process stages, not additive finished-fabric capacities. The same presentation's FY25 backpack capacity 1 million/production 114,000 means 11.4% utilization, an early warning that installed capacity did not prove demand. [SKFL-P p132](https://skflindia.com/wp-content/uploads/2023/12/Shree_Karni_Fabcom_Limited-PROSPECTUS.pdf); [SKFL-PPT25 PDF12](https://nsearchives.nseindia.com/corporate/SHREEKARNI_24082025125109_INVESTOR_PRESENTATION.pdf)

The preferred growth window is selected before the score: a comparable three-year revenue bridge is more informative than a five-year CAGR starting in pandemic-depressed FY21. Both are disclosed. This is a correction for an economically distorted starting period, not an automatic penalty for a small company. Changes in ownership of manufacturing LLPs can change margin and cash-flow scope even when the parent continues to sell substantially the same output. Reported consolidated growth is therefore not described as precisely measured organic volume growth. The predecessor-period merger and alternative depreciation/tax presentations are reconciled rather than chosen opportunistically.

| Period / scope | Revenue | Owner PAT | Interpretation |
|---|---|---|---|
| H1FY25 | 76.8069 | 4.8670 | Unaudited consolidated half-year |
| H1FY26 | 107.3010 | 6.1699 | Unaudited consolidated half-year |
| H2FY25 | 90.1708 | 10.2394 | Balancing annual less H1, not a quarter |
| H2FY26 | 96.2431 | 9.0655 | Balancing annual less H1, not a quarter |

| Comparable half | Revenue YoY | Owner PAT YoY |
|---|---|---|
| H1 | 39.70% | 26.77% |
| H2 | 6.73% | -11.46% |

The latest available full-year is FY26. No H1 FY27 result was available within the fixed cutoff; there is no constructed FY27 TTM or invented quarterly cash flow. [SKF-H126](https://nsearchives.nseindia.com/corporate/SHREEKARNI_13112025181922_Outcome_Financials_Signed.pdf); [SKFL-AR26](https://archives.nseindia.com/annual_reports/SME_AR_31851_SHREEKARNI_2025_2026_A_7707609_08092026130825.pdf)

## 7. Growth Quality and Reinvestment Runway

### Runway and demand durability

### Addressable demand versus bankable demand
Luggage, footwear, upholstery and functional apparel offer multiple applications. Travel and replacement demand can expand over time; premium or recycled materials can change product mix. Nevertheless, global technical-textiles TAM is much broader than the products, certifications, geography and customer channels this company can actually address. No defensible exact company market share or five-year accessible market denominator was located. Demand breadth earns some runway credit but not a guaranteed growth trajectory.

In November 2025 management described luggage as 50–60% of revenue and targeted no industry above 30% by FY27/FY28. This is a diversification goal, not a current result. Three-to-six-month customer forecasts are not binding backlog. Responsive delivery requires ready inventory and therefore financing before customers pay. Management's ₹300 crore revenue possibility included contract manufacturing; it is not a verified owned-capacity ceiling or a funded order book. [SKFL-CALL25 pp5,15,17](https://nsearchives.nseindia.com/corporate/SHREEKARNI_27112025171406_Intimation_Earning_Call_Transcript_Signed.pdf)

### Italian agency: access, not owned intellectual property
The 6 May 2026 announcement describes an exclusive arrangement to promote, brand and sell Italian technical knitted fabrics in India. The annual report identifies YEGOF of the Carvico Group. This may broaden access to nylon/spandex and polyester/spandex products. The partner's famous customers do not automatically become direct Shree Karni customers. Minimum purchases, commission schedule, margin, duration and termination economics were not verified. This is a real commercial avenue with unquantified earnings, not a contracted annuity. [SKFL-ITALY26](https://skflindia.com/wp-content/uploads/2026/05/Press_Release.pdf); [SKFL-AR26 p6](https://archives.nseindia.com/annual_reports/SME_AR_31851_SHREEKARNI_2025_2026_A_7707609_08092026130825.pdf)

### Original project rights versus available funding
The IPO proposed ₹30.7048 crore for dyeing, ₹1.8682 crore for bag machinery, ₹5 crore for working capital and ₹3.5 crore for general corporate purposes. Dyeing was designed for 80,000 metres/day. These original proposal figures are not verified October 2026 output, replacement cost or remaining cash. Prospectus p81 reports net proceeds ₹41.0730 crore whereas its object amounts sum to ₹41.5730 crore and p82 uses that latter total. Preserve and reconcile this ₹0.5 crore source inconsistency against later certified utilization rather than force a balancing plug. Project estimates were not independently bank-appraised. [SKFL-P pp81–88](https://skflindia.com/wp-content/uploads/2023/12/Shree_Karni_Fabcom_Limited-PROSPECTUS.pdf)

All 315,000 promoter warrants were exercised in three 105,000-share tranches on 25 August, 29 August and 2 September 2026. Each primary filing explicitly records receipt of ₹6.024375 crore, a cumulative ₹18.073125 crore after March. The earlier 25% subscription payment must not be counted again. Issued shares became 7,543,750. November 2025 management's suggestion of converting promoter loans does not override the later receipt filings. Conversely, gross receipt is not current cash and does not establish that no debt was subsequently repaid. The monthly funding model must retain that reconciliation uncertainty. [SKFL-W1/W2/W3](https://skflindia.com/wp-content/uploads/2026/08/Outcome_of_Circular_Resolution_Allotment_25082026.pdf)

Suggested DUR: 5/10, medium confidence. Existing fabric capabilities, multiple applications and the agency agreement support some runway. Concentrated demand, the closure of the stitching route, uncontracted customers and qualification requirements prevent calling it secure. Returns on incremental capital belong in CAP, not an overlapping discretionary DUR penalty.

A broad technical-textiles market is not the company's addressable contracted demand. Fabric qualification, customer retention, machine mix, working capital and funding constrain expansion. The November 2025 revenue-capacity statement included outsourced production and product realization; it is not an engineering certificate for owned capacity. The closed stitching business must not be counted as an active route into large US retail orders without fresh evidence. Italian distribution rights can broaden products but bring supplier dependence, channel economics and stock-financing requirements; no unverified revenue is assigned to that partnership.

| Window | Change in normalized NOPAT | Change in committed IC | Incremental accounting proxy / limitation |
|---|---|---|---|
| consolidated 3y | 6.0443 | 150.3343 | 4.02%; Predecessor-to-group perimeter changes Oct 2023; parent core cross-check also changed integration. Includes CWIP; accounting proxy, not project IRR. |
| consolidated 5y | 13.5515 | 189.0899 | 7.17%; Predecessor-to-group perimeter changes Oct 2023; parent core cross-check also changed integration. Includes CWIP; accounting proxy, not project IRR. |
| standalone 3y | 5.9904 | 122.3263 | 4.90%; Predecessor-to-group perimeter changes Oct 2023; parent core cross-check also changed integration. Includes CWIP; accounting proxy, not project IRR. |
| standalone 5y | 13.4975 | 161.0819 | 8.38%; Predecessor-to-group perimeter changes Oct 2023; parent core cross-check also changed integration. Includes CWIP; accounting proxy, not project IRR. |

| Scope / FY | Normalized NOPAT | Financing-side committed IC | Average ROIC |
|---|---|---|---|
| predecessor / FY21 | 2.6494 | 20.3330 | NS |
| predecessor / FY22 | 5.7445 | 38.2438 | NS |
| predecessor / FY23 | 10.1565 | 59.0886 | NS |
| consolidated / FY24 | 16.7458 | 117.4430 | NS |
| consolidated / FY25 | 16.4315 | 181.4452 | 11.00% |
| consolidated / FY26 | 16.2008 | 209.4229 | 8.29% |
| standalone / FY24 | 14.4808 | 84.1803 | NS |
| standalone / FY25 | 15.6367 | 145.0643 | 13.64% |
| standalone / FY26 | 16.1469 | 181.4149 | 9.89% |

The capital basis includes CWIP and received warrant/share-application capital, but excludes cash, investments and deposits analytically. Excluding deposits from operating capital does not permit netting them against debt as freely available cash. The accounting proxy is not a project IRR. Group comparisons cross an acquisition perimeter; parent-core and commissioning sensitivity provide cross-checks rather than false precision. [SKFL-P](https://skflindia.com/wp-content/uploads/2023/12/Shree_Karni_Fabcom_Limited-PROSPECTUS.pdf); [SKFL-AR24](https://archives.nseindia.com/annual_reports/SME_AR_25895_SHREEKARNI_2023_2024_05092024193034.pdf); [SKFL-AR25](https://archives.nseindia.com/annual_reports/SME_AR_28942_SHREEKARNI_2024_2025_A_11564635_08092025185428.pdf); [SKFL-AR26](https://archives.nseindia.com/annual_reports/SME_AR_31851_SHREEKARNI_2025_2026_A_7707609_08092026130825.pdf)

## 8. Management, Governance and Execution

### Governance, allocation and minority treatment

### Promoter control and ownership reconciliation
Four promoter executives sit on a seven-member board with three independent directors. Rajiv Lakhotia, Radhe Shyam Daga, Manoj Kumar Karnani and Raj Kumar Agarwal each exercised 26,250 warrants in each of the three 2026 tranches. March actual promoter ownership was 5,002,700 shares out of 7,228,750, or 69.21%. The 70.49% in the March filing's diluted column assumed then-unexercised warrants; it was not issued ownership at that date. AGM records at the 23-September-2026 cutoff verify promoter holdings of 5,317,700 out of 7,543,750, or 70.4915%. Public shares stayed 2,226,050. [SKFL-SHP26](https://skflindia.com/wp-content/uploads/2026/04/SHP_31_03_2026.pdf); [SKFL-AGM26](https://nsearchives.nseindia.com/corporate/SHREEKARNI_30092026191528_Vorting_Results_Combined.pdf); [SKFL-W1/W2/W3](https://skflindia.com/wp-content/uploads/2026/08/Outcome_of_Circular_Resolution_Allotment_25082026.pdf)

The March shareholding filing states no promoter pledge, NDU or other encumbrance. That is a dated finding, not proof of October status. This module did not independently locate the September shareholding pattern. The AGM confirms capital and holdings but does not substitute for all encumbrance disclosures.

### Explicitly non-arm's-length land lease
AOC2 explicitly identifies a land lease to IGK Technical Textiles LLP as not at arm's length. Parent-owned land at Umalla/Jhagadia/Bharuch is leased for 27 years at ₹5,000 annually. Board approval was 29-May-2025 and shareholder approval 30-September-2025. The disclosed justification is solar generation, energy savings and sharing benefits with the parent under a mutual understanding. A quantified, enforceable savings-sharing formula was not located. Because IGK is only 66.67% owned, the economic benefit also accrues to outside LLP interests. This creates a legitimate minority-allocation question, not proof of improper diversion. [SKFL-AR26 p42/PDF45](https://archives.nseindia.com/annual_reports/SME_AR_31851_SHREEKARNI_2025_2026_A_7707609_08092026130825.pdf)

The 2026 AGM RPT resolution authorized up to ₹30 crore in goods/services and ₹0.0005 crore annual rent. FY26 goods/jobwork transactions were ₹15.9395 crore, and June-quarter 2026 jobwork ₹2.3684 crore. Importantly, the signed voting record shows interested promoters cast zero votes on resolution 4; 311,700 public votes supported it, with none against. Disclosure and disinterested approval are meaningful counterevidence. They do not replace an independent commercial valuation of the unpriced benefit-sharing arrangement. Monitor realized energy savings, their allocation and settlement terms. [SKFL-AR26 pp62–66](https://archives.nseindia.com/annual_reports/SME_AR_31851_SHREEKARNI_2025_2026_A_7707609_08092026130825.pdf); [SKFL-AGM26 PDF15](https://nsearchives.nseindia.com/corporate/SHREEKARNI_30092026191528_Vorting_Results_Combined.pdf)

### Non-core allocation and funding obligations
The financial notes disclose venture/angel-fund investments and uncalled commitments. The audited schedules show ₹2.2664 crore of non-operating fund investments and ₹2.2311 crore uncalled commitment at 31-March-2026. Such assets may generate value, but they compete with manufacturing and working capital for funding. Uncalled commitments are possible cash uses, not free cash. They are not automatically related-party abuse or prohibited IPO use; that claim would require source-of-funds evidence. [SKFL-AR26 financial notes](https://archives.nseindia.com/annual_reports/SME_AR_31851_SHREEKARNI_2025_2026_A_7707609_08092026130825.pdf)

### Remuneration, personnel and audit
Four promoter executives received ₹5 lakh a month each, ₹60 lakh annually each and ₹2.4 crore combined, with no FY26 increase disclosed. Compare remuneration to owner profit and operating cash, not only sales. Independent director Sriyans Lunia ceased on 31-May-2025 because of death; Pankaj Mohta was appointed 8-September and regularized 30-September-2025. That is not an adverse director resignation. The company secretary ceased 5-August-2025 and was reappointed 4-November-2025. Any September 2026 change needs a separate primary filing before inclusion. [SKFL-AR26 pp20–21,45–46](https://archives.nseindia.com/annual_reports/SME_AR_31851_SHREEKARNI_2025_2026_A_7707609_08092026130825.pdf)

The annual report describes an unqualified statutory opinion and no auditor-reported fraud. The actual audit text and financial notes govern; a clean opinion does not certify good capital allocation. The LLP audit-trail exemption is an applicability point, not evidence of concealed transactions by itself. Secretarial compliance test-checking is not a blanket guarantee that no lapse occurred. [SKFL-AR26](https://archives.nseindia.com/annual_reports/SME_AR_31851_SHREEKARNI_2025_2026_A_7707609_08092026130825.pdf)

### Precisely bounded adverse evidence
The NSE email dated 29-October-2025, disclosed by the issuer on 30-October, warned that notice of a 31-December-2024 analyst meeting was not submitted two working days in advance. This is a documented disclosure-timing lapse. It is not a financial penalty or an allegation of financial fraud. It supports closer procedural monitoring without justifying a catastrophic governance label. [SKFL-WARN25 PDF2](https://skflindia.com/wp-content/uploads/2025/10/Covering_Cautioning_Email_30102025.pdf)

The IPO prospectus records a criminal miscellaneous complaint initiated by the issuer against a land counterparty for alleged failure to execute a sale deed after payment of ₹34.25 lakh and a demand for a further ₹20 lakh. The issuer was the complainant, not the accused. It was pending at the prospectus date; current resolution is unknown. Historical nil adverse-litigation tables should not be represented as current legal clearance. [SKFL-P p222](https://skflindia.com/wp-content/uploads/2023/12/Shree_Karni_Fabcom_Limited-PROSPECTUS.pdf)

Suggested GOV: 5/10, medium confidence. The concessionary subsidiary lease, unquantified savings-sharing, non-core allocation and process warning warrant concern. Disclosure, disinterested approval, completed promoter cash subscription and the absence of substantiated fraud in reviewed sources are real counterweights. GOV of 3 or lower and a fraud gate are not supported by these facts. GOV of 7 would require stronger evidence of priced minority-fair treatment and disciplined deployment.

### Evidence that would change the judgment
Priority gaps are current customer concentration, executed Italian agency terms, post-closure costs and asset recovery, product-level volumes and realizations, quantified solar benefit allocation, latest encumbrance disclosures and the cash/debt use of promoter subscription receipts. Durable cash-backed growth and owner-per-share gains would improve the case. More capacity and customer logos alone would not. Recurring collection strain, demonstrably noncommercial RPT benefits or unexplained deviations from approved uses would weaken it.





### Execution: original promises versus delivery

| Original commitment | Outcome through the cutoff | Interpretation |
|---|---|---|
| IPO dyeing commercial production November 2024, pp86–87 | 23-Nov-2024 postponed to March 2025; 31-Mar-2025 postponed to first week of April; commissioned 6-Apr-2025 | Delivered approximately five months late, not an unbuilt plant. |
| IPO bag machinery commercial production September 2024, p88 | 31-January-2025 commercial production with 200 machines [SKFL-BAGS25](https://skflindia.com/wp-content/uploads/2025/02/Intimation_Commercial_Production_Regulation_30.pdf); FY25 backpack utilization only 11.4%; stitching closure approved June 2026 | Implementation did not establish durable commercial success. |
| Noida facility announced May 2025 | Commercial production disclosed 27-Jun-2025 | An actual commissioning achievement, not proof of profitable utilization. |
| Walmart qualification June 2025 and 20% Walmart/Target contribution aspiration November 2025 | Vendor approval disclosed, no minimum orders; subsequent stitching closure | Do not mark the 20% aspiration as delivered or vendor qualification as automatically revoked. |
| November 2025 minimum 25% growth aspiration and 12–13% PAT margin target | FY26 revenue growth 21.90%; annual profit margin below the target | Meaningful growth, but numerical aspirations not achieved. Owner profit and profit before non-controlling interests are separately identified in the financial analysis. |
| November 2025 reference to 30% margin | Transcript specifically corrected it to gross margin | Do not invent a 30% net-profit promise. |
| Promoter warrant exercise | Three completed cash-receipt/allotment filings in August/September 2026 | Funding completion is proven; capital deployment quality remains separate. |

The closure disclosure cites operational optimization, profitability and geopolitical risk. This is a plausible corrective response in a tariff-sensitive export strategy. Credit the willingness to adapt, while requiring evidence of saved cash, asset recovery and profitable remaining operations. Neither automatic praise nor an accusation of fraud follows from closure alone. [SKFL-CLOSE26](https://skflindia.com/wp-content/uploads/2026/06/Outcome_of_Board_Meeting_24062026.pdf)

Final EXEC: 4/10, medium confidence. Commissioning, revenue scaling and completed promoter funding are meaningful counterevidence. However, delayed ramp-up, low backpack utilization and closure of the recently launched stitching route constitute realized capital-execution misses, not merely future warning risks. This is a below-average delivery assessment, not a misconduct allegation. An explained strategic correction can be sensible while the preceding investment outcome remains weak.

## 9. Financial Forensics

| FY / scope | Owner PAT / aligned group PAT | Strict normalized PAT | Current-share owner EPS proxy | CFO / cash capex / FCF |
|---|---|---|---|---|
| FY21 / Restated predecessor LLP | 1.5348 / ND | 1.2411 | 2.0345 | 2.7354 / 2.2831 / 0.4523 |
| FY22 / Restated predecessor LLP | 5.1484 / ND | 3.8745 | 6.8247 | 0.4137 / 11.0468 / -10.6331 |
| FY23 / Restated predecessor LLP | 5.5525 / ND | 6.2972 | 7.3604 | -0.2342 / 10.2235 / -10.4577 |
| FY24 / consolidated full-year, FY24 split-period reconciled | 14.7126 / 15.0838 | 13.7137 | 19.5030 | -7.4645 / 8.9070 / -16.3715 |
| FY25 / consolidated full-year, FY24 split-period reconciled | 15.1064 / 15.6072 | 14.3030 | 20.0251 | -6.6048 / 40.4931 / -47.0979 |
| FY26 / consolidated full-year, FY24 split-period reconciled | 15.2354 / 15.3646 | 11.9640 | 20.1961 | 15.9221 / 26.7648 / -10.8427 |

Current-share EPS proxies use today’s actual issued shares for comparison and are not reported historical EPS. Reported LLP PAT before FY24 does not have the same corporate-tax basis; normalized 25.17% tax is an analyst comparison. [SKFL-P](https://skflindia.com/wp-content/uploads/2023/12/Shree_Karni_Fabcom_Limited-PROSPECTUS.pdf); [SKFL-AR24](https://archives.nseindia.com/annual_reports/SME_AR_25895_SHREEKARNI_2023_2024_05092024193034.pdf); [SKFL-AR25](https://archives.nseindia.com/annual_reports/SME_AR_28942_SHREEKARNI_2024_2025_A_11564635_08092025185428.pdf); [SKFL-AR26](https://archives.nseindia.com/annual_reports/SME_AR_31851_SHREEKARNI_2025_2026_A_7707609_08092026130825.pdf)

| FY / consolidated | Gross debt / cash / noncurrent FD | Equity / NCI | Receivables / inventory / payables | Tangible / intangible / CWIP |
|---|---|---|---|---|
| FY24 | 79.3780 / 26.4033 / 2.1364 | 67.9691 / 1.3498 | 32.5802 / 37.8043 / 11.0556 | 50.5134 / 0.2248 / 3.3123 |
| FY25 | 103.1539 / 10.3041 / 3.1933 | 86.0876 / 1.7546 | 52.1401 / 49.4575 / 28.3253 | 53.1418 / 3.8721 / 31.4395 |
| FY26 | 98.2332 / 0.1230 / 3.4730 | 116.3267 / 1.5748 | 51.9991 / 69.6664 / 27.2323 | 99.9508 / 2.8175 / 0.0000 |

#### Financial forensics: Shree Karni Fabcom Limited

Information cutoff: 20 October 2026. Units: ₹ crore unless explicitly stated. This is an analytical research supplement, not a trade instruction.

#### Scope, periods and accounting

The investable parent owns 66.67% of IGK Technical Textiles LLP and 45% of Textron Fabtech LLP, both acquired on 31 October 2023. Group figures include the subsidiary and equity-accounted associate; parent figures are shown as a cross-check. Indian GAAP Accounting Standards apply, not Ind AS. The consolidated fixed-asset note retains the LLP’s tax-block depreciation alongside the parent’s Companies Act schedule; these are not a uniform group depreciation basis. [SKF-AR26, printed 36–37,130,144–146](https://archives.nseindia.com/annual_reports/SME_AR_31851_SHREEKARNI_2025_2026_A_7707609_08092026130825.pdf)

FY2024 requires special care: the company’s 12 April–31 March P&L and predecessor’s 1–11 April P&L are separate columns. Summing those non-overlapping periods gives full-year consolidated revenue ₹137.0777 and PBT ₹19.0358. The cash-flow column already covers the full year, so the predecessor cash-flow column must not be added a second time. [SKF-AR24, printed 117–119](https://archives.nseindia.com/annual_reports/SME_AR_25895_SHREEKARNI_2023_2024_05092024193034.pdf); [SKF-AR25 current comparative](https://archives.nseindia.com/annual_reports/SME_AR_28942_SHREEKARNI_2024_2025_A_11564635_08092025185428.pdf)

IPO-restated FY2023 PAT ₹5.5525 differs from the later annual report’s original ₹4.6177 because tax-act depreciation was replaced with Companies Act depreciation and deferred tax/loss adjustments were made. The prospectus provides this bridge explicitly. FY2021–22 income tax was paid/adjusted through LLP partners rather than expensed in reported P&L; those reported PAT numbers are not directly comparable with corporate after-tax profit. Historical operating returns therefore use a consistently disclosed 25.17% analytical tax rate. [SKF-PROS, PDF 201](https://skflindia.com/wp-content/uploads/2023/12/Shree_Karni_Fabcom_Limited-PROSPECTUS.pdf)

#### Audited/restated historical operating table

FY2021–23 are restated predecessor figures. FY2024–26 are the consolidated group; the acquisition perimeter change is visible, not silently treated as organic growth. Strict operating EBITDA = PBT + finance cost + depreciation − all other income. This conservative cross-check is not the company’s own EBITDA definition.

| Period/scope | Revenue | Strict operating EBITDA | EBIT | Owner PAT | Reported CFO | Cash capex | CFO−cash capex |
|---|---:|---:|---:|---:|---:|---:|---:|
|FY21 predecessor|32.8742|3.7806|3.5405|1.5348|2.7354|2.2831|0.4523|
|FY22 predecessor|83.5736|8.2032|7.6768|5.1484|0.4137|11.0468|-10.6331|
|FY23 predecessor|126.9465|15.0976|13.5728|5.5525|-0.2342|10.2235|-10.4577|
|FY24 consolidated|137.0777|25.4809|22.3785|14.7126|-7.4645|8.9070|-16.3715|
|FY25 consolidated|166.9777|28.0487|21.9585|15.1064|-6.6048|40.4931|-47.0979|
|FY26 consolidated|203.5441|31.1954|21.6502|15.2354|15.9221|26.7648|-10.8427|

Sources: SKF-PROS PDF 170–174; SKF-AR24 printed 116–119; SKF-AR25 consolidated statements; SKF-AR26 printed 133–140. Underlying original values, vintages and formula outputs are retained in financial_inputs.json and financial_metrics.json.

#### Parent cross-check

| Period | Revenue | EBITDA | PAT | CFO | Cash capex | Debt |
|---|---:|---:|---:|---:|---:|---:|
|FY24|130.7984|20.8790|13.0115|-5.7891|5.0706|49.6552|
|FY25|165.7103|23.4125|15.1067|-5.2916|38.8552|70.7076|
|FY26|202.9533|26.5669|15.2355|4.6892|24.9268|74.1451|

#### Growth, margins and latest comparable halves

Three-year revenue CAGR is 17.04% for the consolidated sequence and 16.93% using parent endpoints, from ₹126.9465 crore in FY2023 to ₹203.5441/₹202.9533 crore in FY2026. The parent revenue series is the closer constant-perimeter cross-check, but acquired manufacturing integration changed costs and margins. The five-year reported CAGR is approximately 44%; the pandemic-period base and business/perimeter evolution make it unsuitable as an unqualified primary growth score. FY2024–26 annual group revenue additions were ₹10.1312, ₹29.9000 and ₹36.5664 crore. The existence of true scaling is not denied just because the starting company was small.

Latest comparable half-year evidence: H1FY2026 revenue ₹107.3010 versus ₹76.8069 crore, +39.70%; owner PAT ₹6.1699 versus ₹4.8670 crore, +26.77%. H2FY2026, derived as audited full-year minus the original H1 filing, revenue ₹96.2431 versus ₹90.1708 crore, +6.73%; owner PAT ₹9.0655 versus ₹10.2394 crore, −11.46%. This slowdown supports no extra positive trajectory adjustment. H1FY2027 results were not available by the cutoff; no forward TTM is invented. The original H1 PDF image says September 2025; OCR misleadingly renders 2026 in the heading. [SKF-H126, PDF 8](https://nsearchives.nseindia.com/corporate/SHREEKARNI_13112025181922_Outcome_Financials_Signed.pdf); [SKF-AR26, printed 134](https://archives.nseindia.com/annual_reports/SME_AR_31851_SHREEKARNI_2025_2026_A_7707609_08092026130825.pdf)

#### Material value added, not fabricated gross profit

Full manufacturing gross profit is ND because direct labour/overheads are not cleanly allocated between manufacturing costs and the remaining expenses. A reproducible material-spread cross-check subtracts materials plus inventory change from sales. It rises from ₹36.6947 crore/26.77% in FY2024 to ₹46.3734 crore/27.77% in FY2025 and ₹59.1599 crore/29.06% in FY2026. This is value added before employee and other operating costs, not a labelled gross profit. FY2025 material/inventory lines were regrouped in FY2026 comparatives; their net cost is unchanged to rounding. [SKF-AR25 consolidated P&L](https://archives.nseindia.com/annual_reports/SME_AR_28942_SHREEKARNI_2024_2025_A_11564635_08092025185428.pdf); [SKF-AR26 notes 21–28](https://archives.nseindia.com/annual_reports/SME_AR_31851_SHREEKARNI_2025_2026_A_7707609_08092026130825.pdf)

Group strict operating EBITDA rises ₹28.0487→₹31.1954 crore, only 11.22% versus 21.90% sales growth. Its margin falls 16.80%→15.33%. Employee costs rise ₹9.7681→₹13.5038 crore; other expenses ₹8.5566→₹14.4607 crore. Depreciation ₹6.0902→₹9.5452 and finance cost ₹2.8445→₹5.6620 absorb further growth, leaving owner PAT almost flat at ₹15.1064→₹15.2354 crore. Increased material spread has therefore not translated into equivalent owner-earnings progress.

Other income rises ₹2.4852→₹4.8808 crore and includes ₹1.5622 subsidy, ₹0.676 miscellaneous income, ₹0.2639 asset-sale profit, ₹0.6965 FX gain and ₹0.9961 export incentives. Interest subsidy ₹0.2991 is netted against finance costs on an accrual basis. Export incentives/FX may be recurrent economic items, but all other income is excluded in the strict core cross-check and restoration should be an explicit sensitivity, not a hidden benefit. Removing nonrecurring gains alone differs from removing all other income. [SKF-AR26 notes 22,26](https://archives.nseindia.com/annual_reports/SME_AR_31851_SHREEKARNI_2025_2026_A_7707609_08092026130825.pdf)

FY2025 deferred revenue/startup expenditure ₹2.7493 was not expensed immediately. FY2026 charges ₹1.9391 during stitching restructuring while ₹0.8102 remains. Management explains the matching treatment; an analyst should show symmetric earlier-expense/current-addback sensitivity, not simply add back the current charge to inflate normalized profit and ignore prior capitalization. The auditor highlights restructuring in an Emphasis of Matter, without modifying the main opinion. [SKF-AR26 printed 80/118,102/138,104/140,151](https://archives.nseindia.com/annual_reports/SME_AR_31851_SHREEKARNI_2025_2026_A_7707609_08092026130825.pdf)

#### Cash conversion and working capital

FY2024–26 group CFO totals ₹1.8528 crore against ₹46.0556 crore PAT before associate/NCI adjustments, a ratio of sums of 4.02%. Using owner PAT against group CFO would mismatch the consolidation perimeter. Parent CFO totals −₹6.3915 crore against ₹43.3537 crore PAT,−14.74%. Three-year group cash capex totals ₹76.1649 crore. Weak CFO is primarily operating working-capital absorption; capex is an investing outflow and is not an excuse for weak CFO. FY2026 CFO ₹15.9221 is a real reported improvement, but it does not erase the prior two cash-negative years. [SKF-AR24/25/26 cash-flow statements](https://archives.nseindia.com/annual_reports/SME_AR_25895_SHREEKARNI_2023_2024_05092024193034.pdf)

FY2026 CFO bridge: PBT ₹20.8690 plus depreciation ₹9.5452, finance cost ₹5.6620 and other disclosed noncash/nonoperating adjustments produces pre-WC operating cash ₹35.8516 crore. Inventory absorbs ₹20.2089; other current assets release ₹5.4556; receivables release ₹0.1410; other noncurrent assets release ₹0.5451; payables consume ₹1.0930; other current liabilities add ₹0.1754. Cash generated ₹20.8668 less cash taxes ₹4.9447 gives ₹15.9221. None of these lines makes receivables or inventory universally liquid.

Classification sensitivity only: capital advances fall ₹0.4150, noncurrent FD grows ₹0.2797, and partner-capital within current liabilities disappears ₹1.5926. Moving financing/capital items out of CFO may increase the analytical figure, but the partner-capital change could be a noncash transfer into borrowing rather than repayment. No verified actual extra cash is asserted. Deferred-expense amortization is already offset through the change in other current assets; adding it back again would double count. The original cash totals remain the anchor.

Group receivables are ₹51.9991 crore, almost flat; balances older than six months improve ₹8.7700→₹4.4928 crore. This is favorable counterevidence to an indiscriminate collections claim. Inventory grows ₹49.4575→₹69.6664 crore and drives the broader funding burden; no item-age breakdown was located. The auditor’s inventory KAM and physical-count finding of no class discrepancy of 10% or more are retained, not dismissed. AP older than one year includes ₹2.4990 in 1–2 years and ₹0.0643 beyond 3 years. [SKF-AR26 printed 138,143](https://archives.nseindia.com/annual_reports/SME_AR_31851_SHREEKARNI_2025_2026_A_7707609_08092026130825.pdf)

| Group average-balance proxy | FY2025 | FY2026 |
|---|---:|---:|
| Receivable days, total revenue proxy |92.60|93.37|
| Inventory days, net material-cost proxy |132.05|150.57|
| Payable days, purchases/direct-cost proxy |54.34|61.60|
| Cash-cycle proxy |170.30|182.34|

These use average opening/closing balances, not period-end ratios. Inventory denominator is net material cost, not fully allocated COGS; payable denominator includes direct costs and is not verified credit-only purchases. They are disclosed approximations. Parent cash-cycle proxy also rises 152.97→167.76 days. Other assets, cash taxes, capital advances and overdue/nonoperating items are separately analyzed.

#### Incremental capital returns and investment bridge

Consistent analytical tax is 25.17%; nominal INR cost-of-capital comparison range 12–15% is an assumption, not a measured rate. IC = reported owner capital (including received warrants) + pending share application + NCI + gross debt − cash − investments − noncurrent FDs. All CWIP remains in committed capital. Excluding FDs is a capital-analysis classification, not permission to use restricted/unverified deposits to repay debt. Including them instead leaves the weak return conclusion unchanged. [Financial input and metric files]

Parent core FY2023→FY2026 normalized NOPAT rises ₹10.1565→₹16.1469 crore while financing IC rises ₹59.0886→₹181.4149 crore: delta NOPAT ₹5.9904/delta IC ₹122.3263=4.90%. The five-year parent proxy is 8.38%; group proxies are 4.02% and 7.17%, but the acquisition/perimeter caveat is stronger. These are accounting proxies, not project IRRs and not proof all profits came from new assets. Newly commissioned dyeing assets have not had a full maturation period; prospective higher returns remain possible, not demonstrated.

FY2025→FY2026 group PPE+intangibles+CWIP rises ₹14.3149 crore; cash capex less sale proceeds and depreciation is ₹14.1742, leaving ₹0.1407 of cash/accrual/subsidy/disposal classification residual. Trade ONWC rises ₹21.1609; total financing IC rises ₹27.9777. The remaining −₹7.4981 is explicitly retained as other operating/deferred-tax/nonoperating/financing classification movements, not concealed as project return. Parent corresponding changes are ₹18.0814 fixed capital, ₹22.6724 trade ONWC and ₹36.3506 IC, residual −₹4.4032. Acquisition/net assets are included once; adding purchase consideration again would double count. [SKF-AR26 balance/asset schedules](https://archives.nseindia.com/annual_reports/SME_AR_31851_SHREEKARNI_2025_2026_A_7707609_08092026130825.pdf); [financial_metrics.json]

#### Liquidity, claims and audited counterevidence

At 31 March 2026 group debt ₹98.2332 comprises term/vehicle debt ₹29.9126 including current maturities ₹9.2120, cash credit ₹42.5556, and unsecured demand debt ₹25.7650. Available disclosed cash is only ₹0.1230, of which ₹0.0171 is current-bank balances. Noncurrent FD ₹3.4730 is not proven immediately free. Gross nominal CC limits total ₹49.5 crore against ₹42.5556 drawn; the ₹6.9444 arithmetic gap is not an unconditional cash facility, because collateral/borrowing-base and current utilization matter. Original loan tenors are not remaining maturity schedules. [SKF-AR26 notes 7,10,10A,19](https://archives.nseindia.com/annual_reports/SME_AR_31851_SHREEKARNI_2025_2026_A_7707609_08092026130825.pdf)

Other claims include current income tax ₹0.9008, gratuity ₹0.6977, expense payables ₹2.0977 and fund commitments ₹2.2311. Customer advances ₹1.3081 are funding tied to performance. Venture funds ₹2.2664 and associate carrying ₹0.8494 are not operating cash. Parent guarantees IGK debt secured at ICICI; consolidated borrowing already includes the subsidiary, so adding the same guaranteed debt again would double count. Subsidiary NCI is a claim on IGK, not 33.33% of the whole listed group. IGK annual PAT is only ₹0.1798 on assets ₹30.6230 and liabilities ₹25.3290; economic NCI valuation needs its own sensitivity. [SKF-AR26 printed 36–37,137,141–146,151](https://archives.nseindia.com/annual_reports/SME_AR_31851_SHREEKARNI_2025_2026_A_7707609_08092026130825.pdf)

Positive counterevidence: the FY2026 audit reports no borrowing default or willful-defaulter status, no material statutory dues unpaid over six months or disputed dues, and proper use of term-loan/preferential funds. Main opinion is unmodified and IFC opinion is positive. Debt falls ₹4.9207 crore in FY2026. Later actual warrant conversion receipts need the separately verified post-March bridge; they cannot simultaneously increase free cash and extinguish debt. No fresh investment decision should assume the entire gross receipt is still available.

Bank-return differences are quantified, including Q4 stock reported ₹64.0680 versus books ₹67.3752 crore and AP ₹22.8230 versus ₹21.2005 crore. Management/auditor disclosure cites timing of credit/debit notes and inventory cost inclusions. This is a control weakness to monitor, not automatic evidence of diversion or a qualified audit. [SKF-AR26 printed 86](https://archives.nseindia.com/annual_reports/SME_AR_31851_SHREEKARNI_2025_2026_A_7707609_08092026130825.pdf)

#### Proportionate scoring recommendations

CAP 3, Medium: multi-year committed-capital returns are below 12–15% despite a recent ramp-up caveat; the optimistic future project is not already earned. CASH 3, Medium: three-year conversion is persistently weak despite FY2026 improvement and better aged receivables. These independently justify the framework’s GQS cap 5; do not add an extra undisclosed penalty. EARN 4, Medium: owner EPS/PAT progress is weak after capital raising, other income matters, and deferred startup costs require symmetric normalization; this is separate from cash collection. BAL 4, Medium: net debt/strict EBITDA≈3.15×, thin cash and demand funding make resilience fragile, while no audited default and actual fresh equity receipt are important counterevidence. G2 Conditional rather than automatic Hold/Fail; G3 Conditional unless credible modeled shortfall and source evidence justify stronger status. Analyst reserve breaches must not be labelled observed defaults.

#### Exact original-source qualifications and open questions

- FY24 split reporting: Company Apr 12–Mar 31 plus predecessor Apr 1–11; group revenue 127.1687+9.9090=137.0777, PBT 18.0761+.9597=19.0358. Do not use company period as full FY or add predecessor to already full cash flow.

- FY23 restatement: PROS profit 4.6177+IT Act DA 2.9193-Companies Act DA 1.5248-loss adjustment .0053-DT .4545=5.5524(round source 5.5525). AR24 uses original IT Act figures. Use PROS restated for normalized long window and retain both vintages.

- FY21/22 tax: LLP partner income-tax was adjusted to partners, not P&L; published PAT 1.5348/5.1484 not equivalent to corporate after tax. Normalize operating tax consistently.

- FY25 EPS: Front consolidated P&L 22.51 contradicts detailed note 21.36 and 15.1064 cr / 7,072,000 shares=21.36199. Use calculated 21.36, flag original typo.

- FY25 balance comparatives: AR26 moves capital advance 2.5143 current to noncurrent; nets off doubtful AR .0286 and matching other liability; investment carrying 3.3401→3.0303 also changed, no cash assumed. Archive original and new comparatives.

- FY25 cost regrouping: AR25 material 132.2576 plus inventory −11.6532=120.6044; AR26 comparative 127.5540−6.9497=120.6043 rounding. No change in EBITDA from regrouping.

- FY25 financing labels: Cash flow swaps warrant 3.0122 / share application 6.9768 labels; balances and FY26 comparative identify categories. FY25 NCI financing+.4048 equals NCI profit increase, not verified new cash contribution; retain limited classification uncertainty.

- FY26 subsidiary tax depreciation: Consolidated fixed asset note combines parent Companies Act table and IGK tax blocks; preserve original, no false group uniform depreciation.

- Obtain a dated cash/debt/use-of-proceeds bridge after the August–September 2026 conversions, including whether amounts were paid in cash or adjusted/used to settle promoter debt.

- Obtain remaining contractual debt maturities and confirmed drawing power, FD lien/release status, facility renewals and underwriting covenants.

- Obtain current asset realization and remaining liabilities of the closed stitching division; neither the original business contribution nor a book asset value guarantees recovery.

- Obtain commissioning-date cohort returns, inventory-age details and supported subsidy/interest receivable realization.

- The annual report states the company has not availed a credit rating. This is not an adverse withdrawal or default statement. [SKF-AR26 printed 14](https://archives.nseindia.com/annual_reports/SME_AR_31851_SHREEKARNI_2025_2026_A_7707609_08092026130825.pdf)


| Perimeter / period | Cumulative CFO | Aligned PAT | Cash conversion | Cash capex / reported FCF |
|---|---|---|---|---|
| consolidated FY24–26 | 1.8528 | 46.0556 | 4.02% | 76.1649 / -74.3121 |
| standalone FY24–26 | -6.3915 | 43.3537 | -14.74% | 68.8526 / -75.2441 |

| FY26 group sensitivity | Amount / interpretation |
|---|---|
| reported cfo | 15.9221 |
| remove capital advance release | -.4150 |
| add back FD increase | .2797 |
| exclude partner capital repayment from CFO | +1.5926 |
| adjusted cfo | 17.3794 |
| counterpart | Conditional reclassification only: remove capital advance release from CFO / add to CFI; add FD increase to CFO / subtract CFI; remove partner-capital decrease from CFO / subtract CFF if financing classification. Partner capital could be noncash transfer; totals unchanged, not asserted actual incremental cash. |

No universal adjusted 3 year ratio forced: FY24 acquisition and FY25 classification uncertain. Reported 3 year ratio and parent cross-check anchor CASH, FY26 sensitivity does not erase persistently weak conversion. [SKFL-AR24](https://archives.nseindia.com/annual_reports/SME_AR_25895_SHREEKARNI_2023_2024_05092024193034.pdf); [SKFL-AR25](https://archives.nseindia.com/annual_reports/SME_AR_28942_SHREEKARNI_2024_2025_A_11564635_08092025185428.pdf); [SKFL-AR26](https://archives.nseindia.com/annual_reports/SME_AR_31851_SHREEKARNI_2025_2026_A_7707609_08092026130825.pdf)

| Consolidated year | EBITDA change | Sales-volume/value effect | Margin-rate effect |
|---|---|---|---|
| FY22 | 4.4226 | 5.4035 | -0.9809 |
| FY23 | 6.8944 | 4.7078 | 2.1866 |
| FY24 | 10.3833 | 1.5441 | 8.8392 |
| FY25 | 2.5678 | 5.2903 | -2.7225 |
| FY26 | 3.1467 | 5.8733 | -2.7266 |

The symmetric two-factor bridge uses average margins and average sales: it exactly allocates EBITDA change, but does not identify physical volume, price or acquired profit. The FY24 perimeter change remains a limitation.

Reported PAT, owner PAT, operating profit and normalized cash earnings answer different questions. Other income is excluded from the main operating EBITDA/EBIT computation; current and deferred tax, historical LLP partner taxation, deferred operating expenses, financing cost and the FY24 predecessor period are treated explicitly. An expense written off after an unsuccessful investment is not automatically erased from economic history. Any valuation sensitivity adding back a nonrecurring charge is paired with the capital-allocation loss and continuing maintenance requirements. The company’s actual issue-price and completed conversion disclosures take precedence over a stale security-master capital field and an older management intention about debt conversion.

| Window | Observed / requested sessions | Mean / median turnover ₹ | Unknown dates | 5 lakh exit days 2% / 5% / 10% |
|---|---|---|---|---|
| 20 | 20 / 20 | 986,561.25 / 511,710.00 | None | 48.86 / 19.54 / 9.77 |
| 60 | 58 / 60 | 2,323,222.63 / 737,726.25 | 2026-07-24, 2026-07-28 | 33.89 / 13.56 / 6.78 |

The 60-session statistics are observed-only, not a complete prescribed denominator. No missing issuer row is recoded as zero. The 20-session evidence demonstrates thin capacity even though it is complete; market impact, spread, one-sided circuits and actual free-float order depth can be worse. The 150-share lot is verified in the dated master. Actual issued capital reflects completed conversions, which can differ from immediately tradable locked shares. [NSE-MARKET](https://nsearchives.nseindia.com/content/cm/BhavCopy_NSE_CM_0_0_0_20261019_F_0000.csv.zip); [SKFL-W1](https://skflindia.com/wp-content/uploads/2026/08/Outcome_of_Circular_Resolution_Allotment_25082026.pdf); [SKFL-W2](https://skflindia.com/wp-content/uploads/2026/09/Outcome_of_Circular_Resolution_Allotment_29082026.pdf); [SKFL-W3](https://skflindia.com/wp-content/uploads/2026/09/Outcome_of_Circular_Resolution_Allotment_02092026.pdf)

## 10. Valuation and Market Expectations

| Dated reference cross-check | Value / qualification |
|---|---|
| market cap | 315.3288 |
| owner pat current share pe | 20.6971 |
| current share eps | 20.1961 |
| book multiple including received warrant deposit | 2.7107 |
| gross debt | 98.2332 |
| cash | 0.1230 |
| fd not verified available | 3.4730 |
| ev without nonop adjustments | 415.0138 |
| ev ebitda without nonop adjustments | 13.3037 |
| qualification | Current equity share count paired with dated March debt/cash/NCI is a reference bridge only, not observed current enterprise value. Subtract associate/funds only if separately valued, and do not use restricted FD as free cash. |

Book equity includes assets and prior warrant capital, not readily distributable cash. An EV bridge must include minority claims and exclude separately valued nonoperating investments consistently. ₹418 / current-share earnings is a reference multiple, not a cash-yield valuation. [SKFL-AR26](https://archives.nseindia.com/annual_reports/SME_AR_31851_SHREEKARNI_2025_2026_A_7707609_08092026130825.pdf); [SKFL-W3](https://skflindia.com/wp-content/uploads/2026/09/Outcome_of_Circular_Resolution_Allotment_02092026.pdf); [NSE-MARKET](https://nsearchives.nseindia.com/content/cm/BhavCopy_NSE_CM_0_0_0_20261019_F_0000.csv.zip)

#### Shree Karni Fabcom: linked monthly funding and valuation laboratory

#### Scope and dates

The model uses the group consolidated operating perimeter, the 20 October 2026 information cutoff and the NSE 19 October close of ₹418. Actual issued capital is 7,543,750 shares after three disclosed 105,000-share warrant exercises in August/September 2026. The exchange master still shows 7,228,750. The 315,000 shares are not future dilution a second time. Original annual profit attributable to owners, not total group profit, is used in the report's historical P/E cross-check. All monetary amounts here are ₹ crore unless explicitly stated as shares or price.

This is not a forecast of observed November cash. The latest detailed opening balance sheet is 31 March 2026 and no independently reconciled October balance bridge was located. Every path is explicitly source-ineligible for a live IAS. This applies even when arithmetic is funded and an output price is positive. A model cash reserve breach is not a statement that the issuer has defaulted.

The three primary exercise filings say that ₹6.024375 crore was received on each occasion, totaling ₹18.073125 crore. That is gross receipt, not current available cash. Mutually exclusive experiments treat it as entirely retained, entirely used to repay unsecured demand debt, or already deployed. They never both add it to cash and subtract it from debt. The older call's suggested loan conversion is not substituted for the actual subsequent receipt language. No remaining exercise is assumed.

#### Operating and closure bridge

FY26 group revenue ₹203.5441 crore is the historical reference. Main cases subtract the disclosed stitching division's ₹16.29 crore revenue once, then apply demand growth. The legacy parameter name customer_loss contains that closure adjustment; in the separate linked customer-loss stress it is replaced by the explicitly stated combined 25% loss. The closure's ₹10.47 crore division net worth is not an asset-sale receipt. No sale or recovery is assumed. A ₹0.50 crore closure cash expense is an analyst stress assumption, not a disclosed liability; it is shown separately from recurring EBITDA.

The ₹230 crore fixed-realization operating capacity ceiling is an analyst experiment, not an audited capacity figure. Management's potential ₹300 crore scale includes sourcing and mix. It is not treated as a firm order or a verified own-production ceiling. Annual demand, realized monthly sales, lost sales and capacity are separately retained. A case with 18% demand growth may realize only about 2.47% CAGR because productive capacity does not expand. That is not evidence supporting an 18% revenue forecast. Expansion cases require cash capex of ₹0.45 per incremental annual revenue rupee, a 12-month lead and a 5% capacity buffer. These are assumptions and sensitivities, not a quotation from an engineering budget.

Cost structure is separated into raw material, other variable cost and fixed expense. Actual margins are derived, not blindly set when sales differ from the old fixed-cost base. Maintenance capex is 4% of sales in the reference experiment and at least a 10% annual asset-replacement envelope in the terminal test; the stress raises those assumptions. Depreciation is separately charged; it is not automatically declared equal to maintenance.

#### Gross monthly working capital and liquidity

Receivables, inventory and trade payables evolve through gross collections, purchases and supplier payments. No negative collection or supplier payment creates phantom financing. Initial balance-sheet stocks transition to selected collection/inventory/payable-day assumptions over six months; one-month and 12-month variants preserve timing sensitivity. Conditional working-capital releases are disclosed rather than claimed as bank cash already collected. Additional indirect-tax working capital is separately stressed.

Core other operating assets are ₹5.1599 crore of supplier advances, other advances and prepayments. Statutory receivables ₹5.4026 crore, interest receivable ₹3.4114 crore and unidentified other receivables are not assumed immediately recoverable or freely available. Neither is added again at the terminal exit. This is deliberately conservative and does not establish that those balances are worthless. Original full balance-sheet figures remain in the financial evidence.

Opening cash is ₹0.123 crore. Other bank deposits ₹3.473 crore are excluded pending availability verification, not asserted to be wholly pledged. A separate case releases them hypothetically. Gross debt ₹98.2332 crore is split into term ₹29.9126 crore, cash credit ₹42.5556 crore and unsecured demand debt ₹25.7650 crore. The latter includes related and unrelated lenders; it is not all called promoter debt. Parent guarantees of consolidated subsidiary debt are not added twice.

The first 12 months pay the disclosed ₹9.212 crore current term maturities evenly, followed by the residual over an assumed 36 months and a hard month-48 final maturity. Exact contractual dates were not disclosed, so these are calendar assumptions. Cash-credit and demand-loan renewal are separately gated. Demand calls at months 1, 60 and 66 and failure to renew cash credit are explicit stresses. Nominal unused lender limits are not automatically spendable. Incremental hypothetical credit has draw fees, interest from its draw month, finite facility and cumulative limits, individual 36-month maturities and no automatic terminal refinancing. It is never described as sanctioned borrowing.

Other claims ₹5.2069 crore include current liabilities, current provisions and noncurrent gratuity. They are settled over an assumed 12 months, conservatively including refund of customer advances rather than inventing contractual future collections. They are not also deducted from opening working capital. This is a stress assumption, not an assertion all claims fall due immediately. The fund commitment ₹2.2311 crore is different: it is a cash investment that creates a separate financial asset, not an operating expense or a factory capex requirement. Existing fund investments ₹2.2664 crore are not liquid cash.

The reference minimum liquidity buffer is the greater of ₹0.50 crore and 10% of a month's modeled material/operating expenditure. It is an analyst operational reserve, not a lender covenant. Cash is traced before and after equity, fees, taxes, claims, loan draws and maturities. Failed paths stop at the first unfunded reserve; ordinary terminal values, IRRs and hurdle prices remain null.

#### Equity and minority claims

Hypothetical future issues have whole-share counts, explicit issue prices, issuance fees and separate share caps. They are not approved transactions or predictions. Current warrant shares are already in the 7,543,750 denominator. Funded exit prices use the resulting fully diluted share count, and dividends leave cash before terminal value, so the same money is not counted twice.

IGK is 66.67% owned. The NCI claim is not 33.33% of the whole group. The reference ₹1.7645 crore claim approximates the minority fraction of disclosed IGK net assets; reported consolidated NCI is ₹1.5748 crore after accounting adjustments. Separate ₹0.599 crore and ₹3 crore claim cases show uncertainty. A book-based claim is not a market valuation or proof of cash fungibility. Consolidated funding is an analytical group pool; unrestricted legal transferability between parent and subsidiary is not independently established. That limitation prevents source eligibility.

Textron's ₹0.8494 crore carrying amount is separately haircut to ₹0.4247 crore in the reference claim bridge. Fund assets, including subsequent funded commitments, receive a separate 50% terminal-recovery assumption, with zero and book-value sensitivities. They are not simultaneously operating assets and extra cash. Neither associate nor fund book value is treated as observable liquidation proceeds.

#### Terminal value and returns

Every financially funded horizon is followed by at least 36 months of cash testing, extended for any later specified maturity. The terminal years continue maintenance, working capital, cash claims and debt repayment without new hypothetical flexible credit. Thus an apparently attractive year-five balance cannot conceal a forced repayment a few months later. A future cash reserve is retained, and only excess horizon cash is added to the enterprise-to-common-equity bridge.

The exit-multiple cross-check capitalizes earned last-year operating EBITDA, then subtracts all horizon debt, unpaid other claims and the explicit NCI claim, and adds only excess cash and separately modeled non-operating recoveries. This is not a liquidation guarantee.

The FCFF DCF is separate. DCF deducts changes in the required operating cash reserve from each monthly operating FCFF, uses the signed initial cash less required reserve adjustment, so an initial reserve deficit is funded once rather than clipped away, and includes the greater of observed terminal reserve increase and growth-required reserve investment in the perpetual envelope. Its terminal cash flow is the lower of actual next-year operating FCFF and a normalized envelope: next-year NOPAT plus depreciation, less the greater of actual/replacement maintenance, less the greater of actual/growth-required capex, less growth-required operating working capital. A temporary stock release cannot create a perpetual cash windfall. Applied terminal growth is capped by actual next-year realized revenue growth; a capacity-bound flat-sales case receives zero terminal growth even if the scenario originally requested 3%.

DCF enterprise cash flows exclude financing. The bridge separately subtracts opening debt and other claims; it applies signed opening cash minus the required reserve, including any opening reserve deficit, then adds the stated associate value and fund net present value after funding commitments. Hypothetical future net equity proceeds are discounted and added once, and the resulting claim is divided by the corresponding fully diluted share count. DCF results are conditional capital-structure experiments, not observed fair prices. The multiple exit and DCF are alternative cross-checks, never summed.

All returns include 1% assumed entry and 1% exit friction, before personal taxes. These assumptions are not measured bid-ask spreads. IRR uses dated monthly dividend distributions and final exit proceeds. Hurdle-price tests use 12%, 15% and 18% nominal equity hurdles. The WACC is separately tested at 12%–18%; it is not mechanically the equity hurdle. Growth/multiple, margin/WACC, WACC/terminal-growth and receivable/inventory grids are fully preserved. Reverse expectations report the tested grid and funded crossings, not an invented unique required CAGR when the cash path fails.

The 5×/10× tests cover five and ten years, include capex, working capital, finite debt and hypothetical dilution, and compare achieved per-share outcomes. No tested crossing is a probability or recommendation. Scenarios that grow demand faster than productive capacity show both quantities explicitly.

#### Reproducibility and safeguards

run_model.py builds all paths offline from authored model_source_anchors.json and scenarios.py using Decimal arithmetic. canonical_paths.json.gz contains every complete retained monthly path, including failures, source inputs and scenario assumptions. model_tables.json, annual_paths.csv and trial_index.csv are readers' views, not substitutes for the complete model. independent_replay.py does not import production model.py and checks stock-flow identities, gross cash, loan/claim movements, equity, terminal reinvestment, capacity-constrained growth, DCF and IRR. Mutation controls intentionally alter eleven values in copied data and require each to be detected. They do not alter source files.

Eight earlier development vintages are retained with contemporaneous runtime/source inputs, expected hashes and fresh-clone proof. They are explicitly superseded, not investment alternatives. Their bulky derived canonical files can be reconstructed exactly; the originals remain on disk. No source PDFs or OCR dumps are required to reproduce the source-safe authored model. Reproduction verifies arithmetic and provenance, not the truth of assumptions, actual liquidity or future returns.


| Path / assumptions | Demand / realized CAGR / margin | Years / funding result | Terminal price / conditional IRR / DCF | Source eligibility |
|---|---|---|---|---|
| SKF001 Bear source-bounded, gross receipts use unverified | -2.00% / NS / 12.00% | 5 / failed month 1; reserve gap ₹6.23 | ND / NS / ND | No |
| SKF003 Base source-bounded, gross receipts use unverified | 10.00% / NS / 16.00% | 5 / failed month 1; reserve gap ₹1.92 | ND / NS / ND | No |
| SKF005 Bull source-bounded, gross receipts use unverified | 18.00% / 2.47% / 18.00% | 5 / funded within assumptions | 568.39 / 5.91% / 99.04 | No |
| SKF002 Bear conditional retained-receipt / financing laboratory | -2.00% / NS / 12.00% | 5 / failed month 22; reserve gap ₹0.18 | ND / NS / ND | No |
| SKF004 Base conditional retained-receipt / financing laboratory | 10.00% / NS / 16.00% | 5 / failed month 50; reserve gap ₹10.92 | ND / NS / ND | No |
| SKF006 Bull conditional retained-receipt / financing laboratory | 18.00% / NS / 18.00% | 5 / failed month 38; reserve gap ₹19.71 | ND / NS / ND | No |
| SKF007 Conditional known receipt assumed demand-debt repayment | 10.00% / NS / 16.00% | 5 / failed month 26; reserve gap ₹3.62 | ND / NS / ND | No |
| SKF008 Conditional known receipt already deployed | 10.00% / NS / 16.00% | 5 / failed month 26; reserve gap ₹5.52 | ND / NS / ND | No |
| SKF009 Conditional known receipt retained, no incremental borrowing | 10.00% / NS / 16.00% | 5 / failed month 26; reserve gap ₹4.94 | ND / NS / ND | No |
| SKF162 No growth cash-conversion recovery | 0.00% / -1.65% / 17.00% | 5 / funded within assumptions | 353.24 / -3.70% / 97.34 | No |

These are conditional funding experiments. ND terminal values on a failed path are intentionally suppressed, not zeros or omitted adverse trials. A funded path remains source-ineligible when its opening cash/debt bridge or financing permissions are assumptions. Demand growth differs from actual constrained production; existing-capacity-only scenarios can survive by forgoing sales that an expansion case tries to fund.

Terminal value uses only cash-flow and claims supported within each modeled path, with an explicit funded replacement/growth working-capital envelope and post-horizon maturity test. Cash needed as the minimum liquidity reserve is not simultaneously distributed as excess terminal cash. NCI, associate, fund claims and cash use assumptions remain scenario-specific, not audited market values. All path-level fields, monthly events and source qualifications are preserved in the canonical model.

No supported current reverse-expectations score is assigned. The model grid tests operating assumptions against the same ₹418 entry price and 12%, 15% and 18% return hurdles. A grid point meeting a hurdle only under unverified funding is not an actionable entry price. The full model tables retain every failed and successful conditional trial, including capacity limits.

| Funded conditional example | Demand CAGR / margin / terminal multiple | Conditional IRR | Conditional DCF price |
|---|---|---|---|
| SKF005 Bull source-bounded, gross receipts use unverified | 18.00% / 18.00% / 10x | 5.91% | 99.04 |
| SKF010 Growth / multiple grid | 0.00% / 16.00% / 5x | -17.50% | 34.12 |
| SKF011 Growth / multiple grid | 0.00% / 16.00% / 7x | -10.85% | 34.12 |
| SKF012 Growth / multiple grid | 0.00% / 16.00% / 9x | -5.73% | 34.12 |
| SKF013 Growth / multiple grid | 0.00% / 16.00% / 11x | -1.53% | 34.12 |
| SKF014 Growth / multiple grid | 0.00% / 16.00% / 13x | 2.05% | 34.12 |
| SKF015 Growth / multiple grid | 5.00% / 16.00% / 5x | -12.95% | 46.73 |
| SKF016 Growth / multiple grid | 5.00% / 16.00% / 7x | -5.63% | 46.73 |
| SKF017 Growth / multiple grid | 5.00% / 16.00% / 9x | -0.06% | 46.73 |
| SKF018 Growth / multiple grid | 5.00% / 16.00% / 11x | 4.50% | 46.73 |
| SKF019 Growth / multiple grid | 5.00% / 16.00% / 13x | 8.37% | 46.73 |
| SKF062 Margin / WACC grid | 10.00% / 18.00% / 8x | 3.84% | 111.37 |

| Scenario group | Trials | Funded within assumptions | Failed | Source-eligible |
|---|---|---|---|---|
| claim_sensitivity | 4 | 0 | 4 | 0 |
| conditional_reference | 3 | 0 | 3 | 0 |
| equity_sensitivity | 2 | 1 | 1 | 0 |
| receipt_use | 3 | 0 | 3 | 0 |
| recovery | 1 | 1 | 0 | 0 |
| sensitivity | 84 | 21 | 63 | 0 |
| source_bounded | 3 | 1 | 2 | 0 |
| stress | 14 | 0 | 14 | 0 |
| target | 48 | 9 | 39 | 0 |

Dominant sensitivities combine demand growth and margin, terminal multiple and financing, WACC and terminal growth, collections/inventory/payables, closure costs, receipt uses, maturity timing and dilution. Hurdle values use dated distributions and trading-cost assumptions; no weighted-average IRR is presented as a portfolio return. Full numeric grids are in model_tables.json and the readable scenario appendices where applicable.

#### Linked model sensitivity tables

All outputs below are conditional research experiments, not source-eligible IAS or price targets. A failed path has no ordinary return. M means month from the assumed November2026 opening; breaches concern an analyst liquidity reserve, not observed default. A cell with two numbers is investor IRR / conditional DCF per fully diluted share.

#### Growth versus exit multiple

| volume_growth / terminal_multiple | 5 | 7 | 9 | 11 | 13 |
| --- | --- | --- | --- | --- | --- |
| 0 | -17.50% / ₹34.12 | -10.85% / ₹34.12 | -5.73% / ₹34.12 | -1.53% / ₹34.12 | 2.05% / ₹34.12 |
| .05 | -12.95% / ₹46.73 | -5.63% / ₹46.73 | -0.06% / ₹46.73 | 4.50% / ₹46.73 | 8.37% / ₹46.73 |
| .10 | FAIL M50 | FAIL M50 | FAIL M50 | FAIL M50 | FAIL M50 |
| .15 | FAIL M26 | FAIL M26 | FAIL M26 | FAIL M26 | FAIL M26 |
| .20 | FAIL M14 | FAIL M14 | FAIL M14 | FAIL M14 | FAIL M14 |
| .25 | FAIL M13 | FAIL M13 | FAIL M13 | FAIL M13 | FAIL M13 |
| .30 | FAIL M13 | FAIL M13 | FAIL M13 | FAIL M13 | FAIL M13 |
| .35 | FAIL M13 | FAIL M13 | FAIL M13 | FAIL M13 | FAIL M13 |

#### Margin versus WACC

| ebitda_margin / wacc | .12 | .14 | .16 | .18 |
| --- | --- | --- | --- | --- |
| .12 | FAIL M26 | FAIL M26 | FAIL M26 | FAIL M26 |
| .14 | FAIL M38 | FAIL M38 | FAIL M38 | FAIL M38 |
| .16 | FAIL M50 | FAIL M50 | FAIL M50 | FAIL M50 |
| .18 | 3.84% / ₹111.37 | 3.84% / ₹67.36 | 3.84% / ₹37.33 | 3.84% / ₹15.65 |
| .20 | 7.18% / ₹167.74 | 7.18% / ₹113.31 | 7.18% / ₹76.12 | 7.18% / ₹49.22 |

#### WACC versus terminal growth

| wacc / terminal_growth | 0 | .02 | .04 | .05 |
| --- | --- | --- | --- | --- |
| .12 | FAIL M50 | FAIL M50 | FAIL M50 | FAIL M50 |
| .15 | FAIL M50 | FAIL M50 | FAIL M50 | FAIL M50 |
| .18 | FAIL M50 | FAIL M50 | FAIL M50 | FAIL M50 |

#### Hurdle-price sensitivity

| Path | Condition | 12% hurdle | 15% hurdle | 18% hurdle | Realized sales CAGR | Unserved sales |
| --- | --- | --- | --- | --- | --- | --- |
| SKF005 | Bull source-bounded, gross receipts use unverified | ₹316.13 | ₹276.99 | ₹243.53 | 2.47% | 439.83 |
| SKF087 | Fivefold / tenfold feasibility experiment | ₹483.00 | ₹423.20 | ₹372.07 | 11.06% | 103.64 |
| SKF162 | No growth cash-conversion recovery | ₹196.47 | ₹172.15 | ₹151.35 | -1.65% | 0.00 |

Quoted entry prices already allow the assumed 1% entry cost and 1% exit friction. No supported base-case entry range is asserted because the reference base path fails and current funding data are incomplete.

#### Reverse expectations and target feasibility

Only SKF087 among the tested 162 conditional paths crosses the 15% hurdle; it is an assumed financing/dilution target experiment, not an endorsed required-growth solution. Full scenario, realized growth and capacity loss are preserved. None of the tested five/ten-year paths reaches 5× or 10× after the stated implementation friction. This finite grid is not a proof no future outcome is possible.


## 11. Bear Case and Permanent Loss Path

The strongest bear case is not that technical textiles disappear. It is that useful capabilities fail to earn adequate returns on the larger asset and working-capital base. The closed stitching adjacency provides an observable example of execution and geopolitical risk. Continuing fabric sales can grow while inventories, customer credit and cash tied in expansion rise faster than owner value. In a linked stress, weaker utilization and raw-material pass-through reduce margins, slower collections and inventory losses absorb liquidity, lenders or unsecured creditors require repayment and an equity raise transfers a larger share of future value to new capital. Illiquid fund investments and collateral deposits need not become cash when needed. A depressed share price can amplify dilution and make an existing holding difficult to exit. Scenario reserve breaches are analytical failures under stated assumptions, not evidence of an observed company default. The key falsification variable is sustained cash generation after the full capital and working-capital commitment, not whether one reporting period shows higher sales.

## 12. Fivefold and Tenfold Feasibility

Fivefold requires about 38.0% annual price growth over five years or 17.5% over ten; tenfold requires about 58.5% or 25.9%, respectively. Price compounding must be distinguished from revenue growth, enterprise value, dilution and dividend distributions.

| Horizon / target | Required / modeled test |
|---|---|
| 5 years / 5× | 24 trials; 6 funded; 0 conditional crossings; 0 source-eligible |
| 5 years / 10× | 24 trials; 6 funded; 0 conditional crossings; 0 source-eligible |
| 10 years / 5× | 24 trials; 3 funded; 0 conditional crossings; 0 source-eligible |
| 10 years / 10× | 24 trials; 3 funded; 0 conditional crossings; 0 source-eligible |

No source-eligible outcome is established. Treat 5×/10× as speculative/unsupported, not a probability estimate. Closed-unit prospects cannot be reintroduced as certain revenue, and future growth must fund capex and working capital before equity value is claimed.

## 13. Monitoring Plan

| Baseline / KPI | Review evidence | Warning / thesis-break distinction |
|---|---|---|
| FY26 group CFO ₹15.9221 crore, three-year conversion about 4.02% | Half-year and full-year cash-flow bridges, collections and supplier financing | One good year is insufficient; persistent absorption with rising debt undermines value creation |
| FY26 inventory ₹69.6664 crore and receivables ₹51.9991 crore | Ageing, write-downs, physical volumes and customer credit | Seasonality is not fraud; unrecoverable balances or liquidity pressure are material |
| Stitching closure approved 24 June 2026 | Closure cost, asset redeployment/sale, remaining deferred costs and customer effects | Revised strategy is allowed; repeated unreported losses or unsupported recoveries would impair confidence |
| Actual 315,000 warrant shares converted; ₹18.073125 crore balance receipts | Bank-backed use-of-proceeds and debt repayment reconciliation | Receipt is not automatically current available cash; diversion requires evidence, not assumption |
| FY26 group gross debt ₹98.2332 crore | Current maturity dates, demand loans, borrowing-base margins and drawable headroom | Model reserve stress is not default; an actual unpaid essential obligation changes G3 |
| FY26 committed-capital returns below cost range | Mature plant utilization, product contribution and incremental cash earnings | Ramping can improve; persistent under-earning after maturity falsifies the return thesis |
| Fund investments ₹2.2664 crore and commitments ₹2.2311 crore | Capital calls, valuation, realizability and strategic rationale | Uncalled commitments are obligations, not available liquidity |
| Promoter/LLP structure and RPTs | Current pledge disclosures, guarantees, loan terms and arm’s-length support | Normal related-party business is not abuse; substantiated minority harm changes G1 |
| 150-share lot; two unknown sessions | Full tape and actual order depth at intended position size | A daily close is not guaranteed entry or exit; liquidity limits implementation |

## 14. Final Classification and Conditional Action

Classification: Insufficient investment evidence; mixed-quality manufacturing/redeployment watchlist. Use the exact scorecard and gate register above. No evidence-backed compounder designation is warranted: cash realization and incremental returns do not meet the framework’s requirements. This is research prioritization and a conditional watch/review conclusion, not a personal allocation or sell order. A current holder would need position size, taxes, execution constraints and portfolio alternatives before an exit count or trade instruction could be justified. A prospective buyer needs a supported funding bridge, current implementation evidence and a return model with independently defensible opening conditions before treating a conditional scenario as an actionable entry price.

## 15. Sources, Assumptions and Open Questions

| ID | Dated primary document | Page / scope / limitation |
|---|---|---|
| SKFL-AR26 | 2026-09-08 [Identity, group perimeter, RPTs, lease, board, remuneration, performance, agency; financial notes for investments/commitments](https://archives.nseindia.com/annual_reports/SME_AR_31851_SHREEKARNI_2025_2026_A_7707609_08092026130825.pdf) | printed6,18–26,36–46,62–66; PDF=printed+3; associate Textron45% at printed37/PDF40  |
| SKFL-P | 2024-03-12 [Business, concentration, original IPO rights/uses, capex timeline, historical capacity, Nobletex, litigation](https://skflindia.com/wp-content/uploads/2023/12/Shree_Karni_Fabcom_Limited-PROSPECTUS.pdf) | printed/PDF31–33,81–99,128–134,219,222 Folder year is not document date; contains objects/net-proceeds and peer-margin inconsistencies; historical, not current concentration |
| SKFL-CALL25 | 2025-11-24 [Guidance, revenue mix, vendor aspiration, capacity/mix, promoter funding intention](https://nsearchives.nseindia.com/corporate/SHREEKARNI_27112025171406_Intimation_Earning_Call_Transcript_Signed.pdf) | printed5–7,15–17; PDF=printed+1 Management assertions, not audited outcomes or binding orders |
| SKFL-PPT25 | 2025-08-24 [FY25 capacity utilization](https://nsearchives.nseindia.com/corporate/SHREEKARNI_24082025125109_INVESTOR_PRESENTATION.pdf) | PDF12 capacity charts Knitting unit conversion ambiguous; process stages not additive |
| SKFL-SHP26 | 2026-03-31 [Actual versus diluted holdings; no pledge/NDU/encumbrance at March](https://skflindia.com/wp-content/uploads/2026/04/SHP_31_03_2026.pdf) | PDF2 and promoter tables Not October encumbrance evidence |
| SKFL-AGM26 | 2026-09-30 [September23 capital/holding; interested promoter abstention; public approval](https://nsearchives.nseindia.com/corporate/SHREEKARNI_30092026191528_Vorting_Results_Combined.pdf) | PDF15 resolution4; capital/holding summary Not September full shareholding/pledge filing |
| SKFL-W1 | 2026-08-25 [105000 shares each,765 issue price,60243750 rupees receipt each, promoter allocation and capital progression](https://skflindia.com/wp-content/uploads/2026/08/Outcome_of_Circular_Resolution_Allotment_25082026.pdf) | PDF1–annexure Receipt is gross inflow, not current unrestricted cash |
| SKFL-W2 | 2026-08-29 [105000 shares each,765 issue price,60243750 rupees receipt each, promoter allocation and capital progression](https://skflindia.com/wp-content/uploads/2026/09/Outcome_of_Circular_Resolution_Allotment_29082026.pdf) | PDF1–annexure Receipt is gross inflow, not current unrestricted cash |
| SKFL-W3 | 2026-09-02 [105000 shares each,765 issue price,60243750 rupees receipt each, promoter allocation and capital progression](https://skflindia.com/wp-content/uploads/2026/09/Outcome_of_Circular_Resolution_Allotment_02092026.pdf) | PDF1–annexure Receipt is gross inflow, not current unrestricted cash |
| SKFL-CLOSE26 | 2026-06-24 [Stitching closure, turnover16.29cr/networth10.47cr; no sale agreement](https://skflindia.com/wp-content/uploads/2026/06/Outcome_of_Board_Meeting_24062026.pdf) | PDF1–2 Book networth is not sale proceeds; expected completion is not independently inspected physical closure |
| SKFL-DYE25 | 2025-04-06 [Intimation Commercial Production 06.04.2025](https://skflindia.com/wp-content/uploads/2025/04/Intimation_Commercial_Production_06042025.pdf) | PDF1  |
| SKFL-WALMART25 | 2025-06-27 [Intimation Business Updates 27.06.2025](https://skflindia.com/wp-content/uploads/2025/06/Intimation_Business_Updates_27062025.pdf) | PDF1  |
| SKFL-NOIDA25 | 2025-06-27 [Intimation Commercial Production Noida Factory 27.06.2025](https://skflindia.com/wp-content/uploads/2025/06/Intimation_Commercial-Production_Noida-Factory_27.06.2025.pdf) | PDF1  |
| SKFL-WARN25 | 2025-10-30 [Covering Cautioning Email 30.10.2025](https://skflindia.com/wp-content/uploads/2025/10/Covering_Cautioning_Email_30102025.pdf) | PDF1; warning letter PDF2  |
| SKFL-CONF26 | 2026-03-10 [Post Conference Announcement 10.03.2026](https://skflindia.com/wp-content/uploads/2026/03/Post_Conference_Announcement_10032026.pdf) | PDF1  |
| SKFL-DELAY25 | 2025-03-31 [Intimation Commercial Production Postponement 31.03.2025](https://skflindia.com/wp-content/uploads/2025/03/Intimation_Commercial_Production_Postponement_31032025.pdf) | PDF1  |
| SKFL-DELAY24 | 2024-11-23 [Intimation Postponement Commercial Production 23.11.2024](https://skflindia.com/wp-content/uploads/2024/11/Intimation_Postponement_Commercial-Production_23112024.pdf) | PDF1  |
| SKFL-ITALY26 | 2026-05-06 [Exclusive Italian agency](https://skflindia.com/wp-content/uploads/2026/05/Press_Release.pdf) | PDF1–2; AR26printed6 identifies partner Document has no date printed; 6May2026 official statutory listing supplies date; terms and minimum revenue not disclosed |
| PEER-MAYUR25 | 2025-08-18 [Audited consolidated earnings and cash flow](https://bsmedia.business-standard.com/_media/bs/data/announcements/bse/18082025/add1cb35-e052-45c2-9b85-1990c463ffc0.pdf) | printed173,175;PDF176,178 Original issuer URL406; mirror document is annual report, not secondary analysis |
| PEER-MAYUR26-WEB | FY2025-26 statement [FY26 total income/PAT, export share, PVC/PU capacity](https://www.mayuruniquoters.com/chairman-communication.php) | web lines15–46 Retrieved25Oct; fiscal information pertains pre-cutoff annual report; no independent current cash reconstruction |
| PEER-GARWARE-WEB | FY2021-22 explicitly historical figures [Applications, export mix and patent differentiation](https://www.garwarefibres.com/investors) | web lines70–94 Not current financials; archived annual-report retrieval failed |
| PEER-SRF-LOCATOR | FY2025-26 [Primary report location only](https://www.srf.com/annual-report-2025-26/docs/SRF%20annual%20report%2025-26.pdf) | not retrieved 503/502; secondary financial claims excluded |
| SKFL-BAGS25 | 2025-01-31 [Surat end-to-end bags facility200 machines commercial production31Jan2025](https://skflindia.com/wp-content/uploads/2025/02/Intimation_Commercial_Production_Regulation_30.pdf) | PDF1  |
| PEER-SRF26 | 2026-06-06 [Others definition; FY26/FY25 revenue,EBIT,segmentcapex,depreciation](https://cdn.financialreports.eu/financialreports/media/filings/61903/2026/RNS/61903_rns_2026-06-06_12d05341-f32b-4ff4-b16b-4abc690b2d3d.pdf) | printed449–451;PDF227–228 two-page spreads For SRF segment capex is not verified cash capex and segment CFO remains unavailable |
| SKF-AR26 | 2026-09-08 [Annual report FY2025–26](https://archives.nseindia.com/annual_reports/SME_AR_31851_SHREEKARNI_2025_2026_A_7707609_08092026130825.pdf) | Printed97–105 parent;133–154 group;14 rating;36–37 AOC1;80/118 opinion/EOM;86 CARO bank returns. Printed page+3 = PDF page.  |
| SKF-AR25 | 2025-09-08 [Annual report FY2024–25](https://archives.nseindia.com/annual_reports/SME_AR_28942_SHREEKARNI_2024_2025_A_11564635_08092025185428.pdf) | Consolidated balance/P&L/cashflow PDF153–155; notes following. See page index metadata.  |
| SKF-AR24 | 2024-09-05 [Annual report FY2023–24](https://archives.nseindia.com/annual_reports/SME_AR_25895_SHREEKARNI_2023_2024_05092024193034.pdf) | Printed86–88 parent;116–119 group, predecessor split.  |
| SKF-PROS | 2024-03 IPO; restatement report2023-12-12 [Final IPO prospectus with restated FY21–23 accounts](https://skflindia.com/wp-content/uploads/2023/12/Shree_Karni_Fabcom_Limited-PROSPECTUS.pdf) | PDF170–174 restated statements;PDF201 tax shelter/restatement bridge.  |
| SKF-H126 | 2025-11-13 [Unaudited half-year results to30September2025](https://nsearchives.nseindia.com/corporate/SHREEKARNI_13112025181922_Outcome_Financials_Signed.pdf) | PDF8 consolidated P&L visually checked; page heading is2025 despite extracted OCR2026.  |
| SKFL-AR24 | 2024-09-05 [Annual report FY2023–24](https://archives.nseindia.com/annual_reports/SME_AR_25895_SHREEKARNI_2023_2024_05092024193034.pdf) | Printed86–88 parent;116–119 group, predecessor split.  |
| SKFL-AR25 | 2025-09-08 [Annual report FY2024–25](https://archives.nseindia.com/annual_reports/SME_AR_28942_SHREEKARNI_2024_2025_A_11564635_08092025185428.pdf) | Consolidated balance/P&L/cashflow PDF153–155; notes following. See page index metadata.  |
| NSE-MARKET | 2026-10-19 [NSE dated bhavcopy and security master; validated 60-session archive](https://nsearchives.nseindia.com/content/cm/BhavCopy_NSE_CM_0_0_0_20261019_F_0000.csv.zip) | Raw issuer rows and hashes retained in market_inputs.json Two issuer rows missing and unknown, not zero turnover; security master issued capital differs from actual completed allotments. |
| SKFL-PARTNER26 | 2026-05-06 [Exclusive Italian agency](https://skflindia.com/wp-content/uploads/2026/05/Press_Release.pdf) | PDF1–2; AR26printed6 identifies partner Document has no date printed; 6May2026 official statutory listing supplies date; terms and minimum revenue not disclosed |

V = verified disclosure; C = reproducible calculation; M = management statement; A = analyst assumption. Source snapshots and original hashes are identified in the accompanying ledgers, not substituted for original filings. Original PDFs are excluded from the source-safe delivery.

The next decisive documents are a reconciled post-warrant cash/debt and use-of-proceeds statement, current lender limits and maturity schedule, closure/redeployment costs and recoveries, operating-unit profitability and cash attribution, and current order-book depth. Missing trading rows remain unknown, not presumed zero-volume sessions. Source-reproduced numbers do not certify forecasts or guarantee the absence of misconduct. The report preserves clean audit conclusions, management explanations, limitations and adverse evidence together. The remaining gap list is issuer-specific; it does not imply that every missing disclosure is a critical failure or that every analytical scenario is a factual claim.

| Required check | Implementation |
|---|---|
| 1. Identity and scope | NSE ISIN and actual company filings identify Shree Karni Fabcom Limited. Consolidated, standalone, predecessor LLP and acquired LLP periods are kept separate; current issued shares differ from the trading master. |
| 2. Primary evidence and attribution | Annual reports, prospectus, dated allotments, issuer presentations and official exchange tape underpin material facts. Guidance is attributed and scenarios are analyst assumptions. |
| 3. Audit, related parties and financing | Clean main audit and internal-controls opinions, bank-return differences and management explanations, deferred costs, LLP relationships and preference-conversion proceeds are all distinguished. |
| 4. Periods and units | All financial values are crore rupees unless labeled. The FY24 predecessor period is added only where compatible. Interim halves are not called quarters; no quarterly CFO is fabricated. |
| 5. Revenue versus profit growth | COVID-distorted five-year sales growth is shown but the preselected comparable three-year revenue basis is scored; subsidiary acquisition and the stitching closure are explicit. |
| 6. Cash conversion and capex | Cash conversion is a ratio of sums. Operating cash absorption is traced separately from investing capex, and cash-flow regroupings are symmetric. |
| 7. Incremental capital returns | NOPAT changes and total committed capital changes, including CWIP, are shown with scope and maturation limitations. An accounting return is not a project IRR. |
| 8. Valuation ownership and claims | Owner PAT, subsidiary minority claims, associate value, nonoperating investments, current shares and historical weighted EPS are not mixed. Completed warrants are not future cash. |
| 9. Linked scenarios | Monthly collections, inventory, purchases, payable settlement, capex, tax, interest, debt maturities and cash reserves reconcile. Funding failure suppresses ordinary return outputs. |
| 10. Canonical factors | Thirteen canonical factors are assigned once; BQS, GQS and IAS use the published weights without renormalizing missing evidence. |
| 11. Missingness and bounds | Unknown issuer trading rows are not zero. NS factors retain original-weight coverage and mathematical bounds, not artificial midpoints. |
| 12. Caps and classification | Raw, half-up displayed and overridden scores are separated; persistent cash or capital-return caps are explained and not applied again as generic haircuts. |
| 13. Complete classification matrix | The gate and evidence state takes precedence over numerical classification. No unsupported compounder designation or personal buy/sell instruction is given. |
| 14. Liquidity implementation | The ₹5 lakh reference, 150-share board lot, dated price, observed 20/60-session data and missing rows are explicit. No guaranteed spread or exit is claimed. |
| 15. Falsification | The permanent-loss path links weaker textile economics, stalled redeployment, inventory/collections and financing; closure losses and debt pressure are not equated with proven default. |
| 16. Batch consistency | The record uses v3.0 and common cutoffs. Unfinished evidence remains visibly unfinished; no overall universe winner or portfolio exit count is declared. |
