from pathlib import Path
from decimal import Decimal as D
import json,hashlib,re,gzip,statistics
P=Path(__file__).resolve().parent
read=lambda n:json.loads((P/n).read_text(),parse_float=D)
def main():
 r=read('company_record.json');report=(P/'report.md').read_text();assert re.findall(r'^## (\d+)\. ',report,re.M)==list(map(str,range(1,16)));assert len(read('quality_checks.json')['checks'])==16;assert len(r['factors'])==13
 assert r['isin']=='INE0S4Y01010'and D(r['price'])==418
 for n,h in r['authored_input_sha256'].items():assert hashlib.sha256((P/n).read_bytes()).hexdigest()==h,n
 for n,h in r['output_sha256'].items():assert hashlib.sha256((P/n).read_bytes()).hexdigest()==h,n
 assert D(r['scores']['BQS']['final'])==D('4.64');assert D(r['scores']['GQS']['raw'])==D('5.15');assert D(r['scores']['GQS']['final'])==5;assert r['scores']['IAS']['final']is None
 assert r['scores']['BQS']['ranking_eligible']and r['scores']['GQS']['ranking_eligible']and not r['scores']['IAS']['ranking_eligible']
 m=read('market_inputs.json');assert len(m['sessions'])==60 and sum(v['present']for v in m['sessions'])==58;assert m['lot_size']==150 and m['windows']['60']['missing_dates']==['2026-07-24','2026-07-28'];assert m['issued_shares']==7543750 and m['master_issued_shares']==7228750
 vals=[D(x['row']['TtlTrfVal'])for x in m['sessions']if x['present']];assert D(m['windows']['60']['mean_traded_value_inr'])==sum(vals)/58;assert D(m['windows']['60']['median_traded_value_inr'])==statistics.median(vals)
 assert D(m['market_cap_crore'])==D(m['quote']['close'])*m['issued_shares']/10**7
 f=read('financial_inputs.json');met=read('report_metrics.json')
 for row in met['series']['consolidated']:
  assert abs(D(row['revenue'])-D(row['ebitda'])/D(row['ebitda_margin']))<D('1e-20')
  if'ebitda_change'in row:assert abs(D(row['ebitda_change'])-D(row['sales_effect'])-D(row['margin_effect']))<D('1e-20')
 c=json.load(gzip.open(P/'canonical_paths.json.gz','rt'));assert len(c['paths'])==r['path_count']==162
 assert sum(bool(x['failure'])for x in c['paths'])==129
 for x in c['paths']:
  if x['failure']:assert x['terminal']is None
 assert '{{'not in report and '/workspace/'not in report
 assert 'Textron' in report and '45%' in report and 'Final EXEC: 4/10' in report
 html=(P/'report.html').read_text();assert html.count('<h2>')==15;assert '<table>'in html and 'overflow-x:auto'in html
 for n in ['model_audit.json','independent_replay_results.json','model_mutation_results.json']:assert read(n)['status']=='PASS'
 result={'status':'PASS','sections':15,'checks':16,'factors':13,'paths':r['path_count'],'source_eligible_paths':r['source_eligible_path_count'],'html_static':{'headings':15,'tables':html.count('<table>'),'links':html.count('<a href=')},'browser_pixel_qa':'See browser_qa.json for separately attempted renderer result; structural HTML checks do not imply pixel review.'}
 (P/'verification.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n');print(json.dumps(result))
if __name__=='__main__':main()
