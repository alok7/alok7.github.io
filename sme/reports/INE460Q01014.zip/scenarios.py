"""All diagnostic scenarios, sensitivity grids and bounded funded target tests."""
from decimal import Decimal as D
import copy
from model import run

def specifications(x):
 out=[]
 for n,s in x['scenarios'].items():
  for f,v in x['funding_modes'].items():out.append((n+'__'+f,s|v,5,'canonical'))
 base=x['scenarios']['base']|x['funding_modes']['authorized_ceiling_equity']
 for g in ['.04','.07','.10','.13','.16']:
  for margin in ['.10','.12','.14','.16','.18']:
   out.append(('grid_growth_'+g+'_margin_'+margin,base|{'growth':[g]*10,'ebitda_margin':[margin]*10},5,'growth_margin'))
 for wacc in ['.125','.145','.165']:
  for g in ['.02','.03','.04']:out.append(('terminal_wacc_'+wacc+'_g_'+g,base|{'wacc':wacc,'terminal_growth':g},5,'terminal'))
 for price in ['50','75','94.80','125','150']:out.append(('entry_'+price,base|{'entry_price':price},5,'entry'))
 for label,patch in [
 ('zero_warrant_capex_overlap',{'warrant_capex_overlap':'0'}),
 ('cash_CARE_less_March_restricted',{'opening_available_cash':'1.5131'}),
 ('cash_CARE_all_free_upper_bound',{'opening_available_cash':'11.42'}),
 ('credit_recall',{'line_maturity_month':6}),
 ('late_conversion',{'conversion_month':20}),
 ('early_conversion',{'conversion_month':6}),
 ('zero_project_loan',{'project_loan':'0'}),
 ('slow_commissioning',{'commissioning_delay':12}),
 ('capex_15_remaining',{'initial_capex':'15'}),
 ('capex_45_remaining',{'initial_capex':'45'}),
 ('all_initial_capex_upfront',{'initial_capex_months':1}),
 ('inventory_stress',{'dio_delta':'30','dso_delta':'20','dpo_delta':'-10'}),
 ('interest_14pct',{'interest_rate':'.14'}),
 ('LC_crystallizes',{'lc_crystallization_month':4})]:out.append(('stress_'+label,base|patch,5,'linked_stress'))
 # These are feasibility searches within fixed share authorization and financing bounds, not targets.
 for years in [5,10]:
  for margin in ['.125','.15','.175']:
   for k in range(2,25):
    g=D(k)*D('.025');s=base|{'growth':[str(g)]*10,'ebitda_margin':[margin]*10};out.append((f'funded_{years}y_growth_{g}_margin_{margin}',s,years,'funded_target'))
 return out

def summarize(path,kind):
 q={k:v for k,v in path.items()if k!='monthly'};q['kind']=kind
 return q

def target_results(paths):
 out=[]
 for yr in [5,10]:
  candidates=[p for p in paths if p['kind']=='funded_target'and p['years']==yr]
  for multiple in [D(5),D(10)]:
   survivors=[p for p in candidates if not p['ordinary_return_suppressed']];hits=[p for p in survivors if p['terminal']['price_multiple']>=multiple]
   hits.sort(key=lambda p:D(p['specification']['growth'][0]));closest=max(survivors,key=lambda p:p['terminal']['price_multiple'])if survivors else None
   out.append({'years':yr,'target_multiple':multiple,'required_price_CAGR':multiple**(D(1)/yr)-1,'tested_paths':len(candidates),'funded_earned_survivors':len(survivors),'qualifying_paths':len(hits),'minimum_tested_growth_hit':hits[0]['specification']['growth'][0]if hits else None,'first_qualifying_path':hits[0]['path_id']if hits else None,'best_surviving_path':closest['path_id']if closest else None,'best_surviving_multiple':closest['terminal']['price_multiple']if closest else None,'classification':'Speculative / unsupported','reason':'Even a qualifying diagnostic would depend on unverified current cash, new lending, share issuance and capacity costs. No supported current investment forecast is established. No hit means none within the explicit tested financing/capacity bounds, not mathematical impossibility.'})
 reverse=[]
 for hurdle in [D('.12'),D('.15'),D('.18')]:
  cand=[p for p in paths if p['kind']=='funded_target'and p['years']==5 and not p['ordinary_return_suppressed']and p['terminal']['IRR']>=hurdle];cand.sort(key=lambda p:D(p['specification']['growth'][0]));reverse.append({'hurdle':hurdle,'first_grid_hit':cand[0]['path_id']if cand else None,'minimum_tested_growth':cand[0]['specification']['growth'][0]if cand else None,'not_interpolated_across_funding_failure':True,'not_a_supported_R_score':True})
 return {'funded_multiple_tests':out,'reverse_hurdle_tests':reverse,'grid_definition':'2.5 percentage-point growth increments from5% to60%, margins12.5/15/17.5%,5/10years; share cap21m and prospective funded schedule remain binding.'}
