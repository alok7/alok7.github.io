"""Independent package/output consistency validator. No producer imports."""
from pathlib import Path
from decimal import Decimal as D
from html.parser import HTMLParser
import hashlib,json,gzip,csv,re
P=Path(__file__).resolve().parents[1]
checks=[]
def h(b):return hashlib.sha256(b).hexdigest()
def load(n):return json.loads((P/n).read_text())
def ck(k,ok):
 checks.append(k);assert ok,k
rec=load('company_record.json');raw=load('financial_inputs.json');metrics=load('metrics.json');scores=load('scores.json');summary=load('model_summary.json');j=load('judgments.json')
ck('identity',rec['position']==362 and rec['symbol']=='SCML' and rec['isin']=='INE460Q01014')
ck('cutoffs',rec['information_cutoff']=='2026-10-20'and rec['market_cutoff']=='2026-10-19')
ck('unranked_hold',rec['classification']=='Hold — unresolved'and rec['ranking_eligible']is False and rec['compounder']is False)
for file,expected in rec['authored_input_sha256'].items():ck('authored_hash:'+file,h((P/file).read_bytes())==expected)
fp=h(json.dumps(rec['authored_input_sha256'],sort_keys=True,ensure_ascii=False,separators=(',',':')).encode());ck('aggregate_hash',fp==rec['authored_input_aggregate_sha256'])
report=(P/'report.md').read_text();html=(P/'report.html').read_text();reporthash=h(report.encode());recordhash=h((P/'company_record.json').read_bytes())
ck('distinct_report_record_aggregate',len({reporthash,recordhash,fp})==3)
ck('report_hash',reporthash==rec['report_sha256']);ck('reader_hash',h(html.encode())==rec['reader_sha256'])
ck('exact_ISIN_in_report','INE460Q01014' in report and 'INE460 Q01014' not in report)
ck('no_unlinked_IPO_tag','[IPO_USE]' not in report.replace('[IPO_USE](',''))
ck('no_template_placeholders',not re.search(r'\{\{[A-Z_]+\}\}',report));ck('fifteen_sections',all(re.search(r'^##\s+'+str(i)+r'[.)]?\s',report,re.M)for i in range(1,16)))
quality=(P/'quality_checks.md').read_text();ck('sixteen_quality_checks',len(re.findall(r'^\d+\.',quality,re.M))==16)
ck('factor_count',len(j['factors'])==13 and set(scores['factors'])==set(j['factors']))
weights={'BQS':{'GOV':'.20','MOAT':'.20','REV':'.12','DUR':'.10','CAP':'.12','CASH':'.10','BAL':'.08','EXEC':'.08'},'GQS':{'REV':'.40','DUR':'.20','EARN':'.15','CAP':'.15','CASH':'.10'},'IAS':{'BQS':'.25','R':'.35','D':'.20','P':'.10','L':'.10'}}
for score,ww in weights.items():
 out=scores['composites'][score];ck(score+':weights',ww==out['weights'] and sum(D(v)for v in ww.values())==1);known=D(0);coverage=D(0)
 for factor,weight in ww.items():
  val=None if factor=='BQS'else j['factors'][factor]['score'];v=None if val is None else D(val)*D(weight);ck(score+':contribution:'+factor,(out['contributions'][factor] is None)if v is None else D(out['contributions'][factor])==v)
  if v is not None:known+=v;coverage+=D(weight)
 ck(score+':coverage',D(out['coverage'])==coverage);ck(score+':known',D(out['known_contribution'])==known);ck(score+':bound',[D(v)for v in out['mathematical_bound']]==[known+1-coverage,known+10*(1-coverage)]);ck(score+':NS',out['raw']is None and out['final']is None and out['display']=='NS'and out['ranking_eligible']is False)
ck('GQS_only_cap',scores['composites']['GQS']['cap']=='5' and scores['composites']['BQS']['cap']is None and scores['composites']['IAS']['cap']is None)
ck('IAS_dependency',[D(v)for v in scores['composites']['IAS']['dependency_aware_bound']]==[D('2.22'),D('7.44')])
by={y['year']:y for y in raw['years']}
for y in metrics['history']:
 orig=by[y['year']]
 for k in ('revenue','pat','cfo','cash_capex','finance_cost','equity','debt_lt','debt_st','current_maturities','inventory','receivables','payables','cash_available','cash_restricted'):
  ck('history:'+str(y['year'])+':'+k,D(y[k])==D(orig[k])/100)
 ck('CFO_finance:'+str(y['year']),D(y['CFO_after_finance_paid'])==D(y['cfo'])-D(y['finance_cost']))
 ck('FCF_finance:'+str(y['year']),D(y['cash_after_capex_and_finance'])==D(y['cfo'])-D(y['finance_cost'])-D(y['cash_capex']))
sums={k:sum(D(by[yr][k])/100 for yr in (2024,2025,2026))for k in ['pat','cfo','finance_cost','cash_capex']}
ck('cash_ratio_of_sums',D(metrics['three_year_cash']['CFO_PAT_ratio_of_sums'])==sums['cfo']/sums['pat'])
ck('market_cap',D(metrics['valuation']['market_cap'])==D('94.80')*14496792/10000000)
traceblob=(P/'canonical_paths.json.gz').read_bytes();paths=json.loads(gzip.decompress(traceblob));ck('trace_hash',h(traceblob)==rec['canonical_sha256']);ck('summary_count',len(paths)==summary['path_count']==rec['path_count'])
for path in summary['paths']:
 original=paths[path['path_id']]
 for k,v in path.items():
  if k!='kind':ck('summary:'+path['path_id']+':'+k,original[k]==v)
with (P/'trial_index.csv').open()as f:
 rows=list(csv.DictReader(f));ck('trial_count',len(rows)==len(paths))
 for row in rows:
  q=paths[row['path_id']];ck('trial_fail:'+row['path_id'],row['failed']==str(q['failed']));ck('trial_shares:'+row['path_id'],int(row['ending_shares'])==q['ending_shares']);ck('trial_source_eligible:'+row['path_id'],row['source_eligible']=='False')
  if q['ordinary_return_suppressed']:ck('trial_suppressed_IRR:'+row['path_id'],row['IRR']=='')
class Reader(HTMLParser):
 def __init__(self):super().__init__();self.href=[];self.table=0
 def handle_starttag(self,tag,attrs):
  if tag=='a':self.href.extend(v for k,v in attrs if k=='href')
  if tag=='table':self.table+=1
p=Reader();p.feed(html);ck('HTML_tables',p.table>=15);ck('HTML_primary_links',len(p.href)>20 and all(not url.startswith(('file:','/workspace','/tmp'))for url in p.href))
result={'status':'PASS','checks':len(checks),'report_sha256':reporthash,'company_record_sha256':recordhash,'authored_input_aggregate_sha256':fp,'canonical_trace_sha256':h(traceblob),'checks_run':checks}
(P/'verification'/'deliverable_audit.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items()if k!='checks_run'}))
