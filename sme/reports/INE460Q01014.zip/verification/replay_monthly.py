"""Independent monthly cash-source / physical / claims replay. No producer imports.
Consumes original authored input and emitted trace only as the comparison target.
"""
from pathlib import Path
from decimal import Decimal as D, ROUND_CEILING
from datetime import date
import json,gzip,calendar,hashlib,csv,re
P=Path(__file__).resolve().parents[1]
Z=D(0);U=D(1);CR=D(10000000);EPS=D('1e-16');NUM_EPS=D('1e-18');count=0

def num(v):return D(str(v))
def read(n):return json.loads((P/n).read_text())
def cmp(label,a,b):
 global count
 count+=1
 if isinstance(a,(D,int)) and not isinstance(a,bool):
  assert b is not None and abs(num(a)-num(b))<=EPS*max(U,abs(num(a))), (label,str(a),str(b))
 else: assert a==b,(label,a,b)
def dto(m):
 absolute=2026*12+9+m;y,mo=divmod(absolute,12);return date(y,mo+1,calendar.monthrange(y,mo+1)[1])
def chosen(s,key,m):
 v=s[key];return num(v[min(len(v)-1,(m-1)//12)])

def replay(raw,path):
 o=raw['opening'];a=raw['assumptions'];w=raw['warrant'];s=path['specification'];pid=path['path_id'];N=int(path['years'])*12
 A=lambda k:num(a[k]);O=lambda k:num(o[k]);S=lambda k,d=0:num(s.get(k,d))
 cash=S('opening_available_cash',o['cash_available'])-O('ipo_escrow');cc=O('working_capital_debt');term=O('term_debt');share=int(o['issued_shares']);auth=int(o['authorized_shares']);pending=0;deadline=0
 wc=[O('receivables'),O('inventory'),O('payables'),O('net_other_operating_wc')];days=[wc[0]/O('revenue')*365,wc[1]/(O('revenue')*A('production_cost_ratio'))*365,wc[2]/(O('revenue')*A('production_cost_ratio'))*365]
 capacity=[O('casting_capacity'),O('machining_capacity'),O('forging_capacity')];volume=O('annual_casting_equivalent_tonnes');price=O('revenue')/volume;fixed=O('operating_fixed_assets');addition=Z
 programme=S('initial_capex',a['disclosed_capex_plan']);paymonths=int(s.get('initial_capex_months',12));commission=paymonths+int(s.get('commissioning_delay',3));cap_orders=[];commissions=[(commission,programme*A('plan_capacity_expansion_fraction'))]
 loan_day=int(s.get('project_loan_month',1));loan=S('project_loan');newloan_balance=Z;projectbalance=Z;taxbal=Z;firstfail=None;linecap=cc+S('incremental_line');buckets={k:Z for k in w['objects_crore']if k!='general'}
 amounts={'total_capex':Z,'total_finance_cash':Z,'total_cfo_before_finance':Z,'new_equity_gross':Z,'equity_fees':Z};emergency=0;mincash=cash;maxneed=Z;history=[]
 for m in range(1,N+1):
  actual=path['monthly'][m-1];dt=dto(m);pref=pid+':'+str(m)+':'
  cmp(pref+'date',str(dt),actual['date'])
  if firstfail:
   cmp(pref+'suppressed','SUPPRESSED_AFTER_FAILURE',actual['status']);cmp(pref+'frozen_cash',cash,actual['cash']);cmp(pref+'frozen_shares',share,actual['shares']);continue
  prior_cash=cash;prior_cc=cc;prior_term=term;prior_share=share;eq=Z;fees=Z;reserved=Z;release=Z;warrantcapex=Z;issued=0;authfail=False
  receipts=[]
  if s.get('warrants') and m==int(s.get('warrant_allotment_month',1)):
   pending=int(w['count']);deadline=m+int(w['exercise_months']);receipts.append(num(pending)*num(w['price'])*num(w['upfront_fraction'])/CR)
  if pending and m==int(s.get('conversion_month',18)):
   if m>deadline or share+pending>auth:authfail=True
   else:
    receipts.append(num(pending)*num(w['price'])*(1-num(w['upfront_fraction']))/CR);issued+=pending;share+=pending;pending=0
  if pending and m>deadline:pending=0
  for receipt in receipts:
   eq+=receipt;fees+=receipt*A('equity_fee')
   for purpose in buckets:
    restrict=receipt*num(w['objects_crore'][purpose])/num(w['full_cash_crore']);buckets[purpose]+=restrict;reserved+=restrict
  cash+=eq-fees-reserved
  draw=loan if m==loan_day else Z;loanfee=draw*A('new_debt_fee');projectbalance+=draw;cash-=loanfee;term+=draw;newloan_balance+=draw
  for cm,capital in commissions:
   if cm==m:
    tonnes=capital*A('casting_tonnes_per_crore');capacity=[capacity[0]+tonnes,capacity[1]+tonnes*A('machining_capacity_ratio'),capacity[2]+tonnes*A('forging_capacity_ratio')]
  growth=chosen(s,'growth',m);inflation=S('price_growth',a['price_growth']);volume*=((1+growth)/(1+inflation))**(U/12);price*=(1+inflation)**(U/12);demand=volume/12
  if m<=int(s.get('customer_loss_months',0)):demand*=1-S('customer_loss_fraction')
  limit=min(capacity[0],capacity[1]/A('machining_load_ratio'),capacity[2]/A('forging_load_ratio'))*A('maximum_utilization')/12;sold=min(limit,demand);rev=sold*price;util=sold*12/capacity[0]
  margin=chosen(s,'ebitda_margin',m)-max(Z,D('.7')-util)*A('fixed_cost_penalty');ebitda=rev*margin
  transition=min(U,num(m)/S('wc_transition_months',12));newwc=[rev*12*(days[0]+S('dso_delta')*transition)/365,rev*A('production_cost_ratio')*12*(days[1]+S('dio_delta')*transition)/365,rev*A('production_cost_ratio')*12*(days[2]+S('dpo_delta')*transition)/365,rev*12*O('net_other_operating_wc')/O('revenue')]
  change=[newwc[k]-wc[k]for k in range(4)];dwc=change[0]+change[1]-change[2]+change[3];wc=newwc
  instalment=programme/paymonths if m<=paymonths else Z
  eligible={'working_capital':max(Z,dwc)}|{k:instalment*num(w['objects_crore'][k])/A('disclosed_capex_plan')*S('warrant_capex_overlap',1)for k in ['land','facility','tools']}
  for purpose,spend in eligible.items():
   used=min(spend,buckets[purpose]);buckets[purpose]-=used;release+=used
   if purpose!='working_capital':warrantcapex+=used
  cash+=release
  expansion=sum((cost/num(a['expansion_payment_months'])for start,cost in cap_orders if start<=m<start+int(a['expansion_payment_months'])),Z)
  if s.get('auto_expand') and (m-1)%6==0:
   required=volume*(1+max(Z,growth))**A('expansion_lead_years')/A('maximum_utilization');committed=capacity[0]+sum((capital*A('casting_tonnes_per_crore')for cm,capital in commissions if cm>m),Z)
   if required>committed:
    cost=(required-committed)/A('casting_tonnes_per_crore');cap_orders.append((m,cost));commissions.append((m+int(a['expansion_lead_months']),cost));expansion+=cost/num(a['expansion_payment_months'])
  projectrelease=min(projectbalance,max(Z,instalment+expansion-warrantcapex));projectbalance-=projectrelease;cash+=projectrelease
  maintenance=rev*S('maintenance_ratio',a['maintenance_ratio']);capex=instalment+expansion+maintenance;da=O('da')/12+addition/A('new_asset_life_years')/12;addition+=instalment+expansion;fixed=max(Z,fixed+capex-da)
  interest=(prior_cc+prior_term+draw)*S('interest_rate',a['interest_rate'])/12;bank=O('bank_fees_annual')/4 if m%3==0 else Z;tax=max(Z,ebitda-da-interest-bank)*A('tax_rate');taxbal+=tax;paidtax=taxbal if dt.month in (3,6,9,12) else Z;taxbal-=paidtax;oldtax=O('net_opening_tax_payable')if m==int(a['opening_tax_settlement_month'])else Z
  principal=Z
  for start,stop,key in [(1,5,'maturity_FY27'),(6,17,'maturity_FY28'),(18,29,'maturity_FY29'),(30,41,'maturity_FY30plus')]:
   if start<=m<=stop:principal+=O(key)/(stop-start+1)
  principal=min(term,principal)
  if m>=loan_day+12 and newloan_balance>0:
   portion=min(loan/36,newloan_balance);newloan_balance-=portion;principal+=portion
  principal=min(term,principal);term-=principal;lc=O('lc_contingent')if m==int(s.get('lc_crystallization_month',0))else Z;cfo=ebitda-dwc-paidtax-oldtax
  cash+=cfo-capex-interest-bank-principal-lc;repay=Z
  if m==int(s.get('line_maturity_month',0)):repay=cc;cash-=cc;cc=Z;linecap=Z
  drawcc=min(max(Z,A('minimum_cash_reserve')-cash),max(Z,linecap-cc));cash+=drawcc;cc+=drawcc
  if cash<A('minimum_cash_reserve')-NUM_EPS and s.get('emergency_equity'):
   countshare=min(max(0,auth-share-pending),int(((A('minimum_cash_reserve')-cash-NUM_EPS)*CR/(S('equity_price',a['emergency_equity_price'])*(1-A('equity_fee')))).to_integral_value(rounding=ROUND_CEILING)))
   receipt=num(countshare)*S('equity_price',a['emergency_equity_price'])/CR;fee=receipt*A('equity_fee');cash+=receipt-fee;share+=countshare;issued+=countshare;emergency+=countshare;eq+=receipt;fees+=fee
  if cash>A('minimum_cash_reserve') and cc>O('working_capital_debt'):
   r=min(cash-A('minimum_cash_reserve'),cc-O('working_capital_debt'));cash-=r;cc-=r;repay+=r
  if cash<-NUM_EPS or authfail:firstfail=m
  expected={'status':'FAILED'if firstfail else'ACTIVE','opening_cash':prior_cash,'revenue':rev,'demand_tonnes':demand,'sold_tonnes':sold,'lost_sales_tonnes':demand-sold,'unit_price_crore_per_tonne':price,'casting_capacity':capacity[0],'machining_capacity':capacity[1],'forging_capacity':capacity[2],'utilization':util,'ebitda':ebitda,'ebitda_margin':margin,'depreciation':da,'ebit':ebitda-da,'interest':interest,'bank_fee':bank,'tax_expense':tax,'cash_tax':paidtax,'prior_tax_settlement':oldtax,'receivables':wc[0],'inventory':wc[1],'payables':wc[2],'other_wc':wc[3],'d_receivables':change[0],'d_inventory':change[1],'d_payables':change[2],'d_other_wc':change[3],'delta_onwc':dwc,'cfo_before_finance':cfo,'maintenance_capex':maintenance,'initial_programme_capex':instalment,'expansion_capex':expansion,'total_capex':capex,'term_principal':principal,'term_debt':term,'new_debt':draw,'new_debt_fee':loanfee,'project_restricted_receipt':draw,'project_capex_release':projectrelease,'project_restricted_balance':projectbalance,'cc_draw':drawcc,'cc_repayment':repay,'cc':cc,'cc_authorized_capacity_assumption':linecap,'cash':cash,'restricted_cash':O('restricted_cash'),'ipo_escrow':O('ipo_escrow'),'lc_paid':lc,'equity_cash_gross':eq,'equity_fee':fees,'warrant_restricted_receipt':reserved,'warrant_eligible_release':release,'warrant_restricted_balance':sum(buckets.values(),Z),'issued_shares_month':issued,'shares':share,'warrants_outstanding':pending,'unpaid_tax':taxbal,'net_operating_fixed_assets':fixed}
  for key,value in expected.items():cmp(pref+key,value,actual[key])
  for key,value in buckets.items():cmp(pref+'bucket:'+key,value,actual['warrant_buckets'][key])
  cmp(pref+'cash_identity',prior_cash+eq-fees-reserved+release-loanfee+projectrelease+cfo-capex-interest-bank-principal-lc+drawcc-repay,cash)
  cmp(pref+'whole_share_identity',prior_share+issued,share);assert share+pending<=auth
  for key,value in [('total_capex',capex),('total_finance_cash',interest+bank),('total_cfo_before_finance',cfo),('new_equity_gross',eq),('equity_fees',fees)]:amounts[key]+=value
  mincash=min(mincash,cash);maxneed=max(maxneed,A('minimum_cash_reserve')-cash);history.append(expected)
 cmp(pid+':first_fail',firstfail,path['first_failure_month']);cmp(pid+':ending_shares',share,path['ending_shares']);cmp(pid+':emergency_shares',emergency,path['emergency_new_shares']);cmp(pid+':minimum_cash',mincash,path['minimum_cash']);cmp(pid+':max_reserve_need',maxneed,path['max_unfunded_cash_reserve_need'])
 for key,value in amounts.items():cmp(pid+':'+key,value,path[key])
 if firstfail:
  cmp(pid+':failed_terminal',None,path['terminal']);cmp(pid+':failed_suppression',True,path['ordinary_return_suppressed']);return
 tail=history[-12:];rev=sum(r['revenue']for r in tail);ebitda=sum(r['ebitda']for r in tail);da=sum(r['depreciation']for r in tail);ebit=ebitda-da;nopat=ebit-max(Z,ebit)*A('tax_rate');growth=S('terminal_growth',a['terminal_growth']);discount=S('wacc',a['wacc']);replacement=max(da,rev*A('terminal_replacement_ratio'));growthfixed=rev*growth/A('terminal_incremental_sales_to_capital');growthwc=(wc[0]+wc[1]-wc[2]+wc[3])*growth;growthcash=rev*growth*A('terminal_operating_cash_ratio');fcff=(nopat+da-replacement)*(1+growth)-growthfixed-growthwc-growthcash
 requiredcash=rev*A('terminal_operating_cash_ratio');topup=max(Z,requiredcash-cash);unpaid=sum((cost*max(0,start+int(a['expansion_payment_months'])-1-N)/num(a['expansion_payment_months'])for start,cost in cap_orders),Z)+max(0,paymonths-N)*programme/paymonths;senior=cc+term+O('director_claim')+taxbal+O('unfunded_employee_claim')+topup+unpaid;surplus=max(Z,cash-requiredcash);ev=max(Z,fcff)/(discount-growth);equity=max(Z,ev+surplus-senior);exitprice=equity*CR/share;cross=ebitda*S('exit_multiple');crossprice=max(Z,cross+surplus-senior)*CR/share;holding=num((dto(N)-date(2026,10,19)).days)/D('365.25');irr=(exitprice/S('entry_price',o['price']))**(1/holding)-1 if exitprice else D(-1);needed=max(Z,sum(r['sold_tonnes']for r in tail)*(1+growth)/(1+A('price_growth'))/A('maximum_utilization')-capacity[0])/A('casting_tonnes_per_crore');earned=fcff>0 and discount>growth and growthfixed>=needed
 terminal={'revenue':rev,'EBITDA':ebitda,'EBIT':ebit,'NOPAT':nopat,'DA':da,'terminal_g':growth,'wacc':discount,'replacement_capex':replacement,'growth_fixed_reinvestment':growthfixed,'growth_wc_reinvestment':growthwc,'growth_operating_cash':growthcash,'operating_cash_topup':topup,'unpaid_committed_capex':unpaid,'unused_warrant_restricted':sum(buckets.values(),Z),'unused_project_restricted':projectbalance,'forward_FCFF':fcff,'physical_growth_cost_required':needed,'DCF_terminal_EV':ev,'multiple_crosscheck_EV':cross,'senior_claims':senior,'tax_claim':taxbal,'operating_cash_retained':min(cash,requiredcash),'surplus_cash_added':surplus,'restricted_cash_added':Z,'equity':equity,'shares':share,'price':exitprice,'multiple_crosscheck_price':crossprice,'holding_years':holding,'IRR':irr if earned else None,'earned':earned,'price_multiple':exitprice/S('entry_price',o['price']) if earned else None,'ordinary_return_suppressed':not earned}
 for key,value in terminal.items():cmp(pid+':terminal:'+key,value,path['terminal'][key])
 for hurdle in ['.12','.15','.18']:
  if earned:cmp(pid+':hurdle:'+hurdle,exitprice/(1+num(hurdle))**holding,path['terminal']['entry_prices_at_hurdles'][str(num(hurdle))])
 cmp(pid+':return_suppression',not earned,path['ordinary_return_suppressed'])

def expected_specs(raw):
 result={};base=raw['scenarios']['base']|raw['funding_modes']['authorized_ceiling_equity']
 for scen,sv in raw['scenarios'].items():
  for funding,fv in raw['funding_modes'].items():result[scen+'__'+funding]=(sv|fv,5)
 for growth in ['.04','.07','.10','.13','.16']:
  for margin in ['.10','.12','.14','.16','.18']:result['grid_growth_'+growth+'_margin_'+margin]=(base|{'growth':[growth]*10,'ebitda_margin':[margin]*10},5)
 for discount in ['.125','.145','.165']:
  for growth in ['.02','.03','.04']:result['terminal_wacc_'+discount+'_g_'+growth]=(base|{'wacc':discount,'terminal_growth':growth},5)
 for price in ['50','75','94.80','125','150']:result['entry_'+price]=(base|{'entry_price':price},5)
 changes={'zero_warrant_capex_overlap':{'warrant_capex_overlap':'0'},'cash_CARE_less_March_restricted':{'opening_available_cash':'1.5131'},'cash_CARE_all_free_upper_bound':{'opening_available_cash':'11.42'},'credit_recall':{'line_maturity_month':6},'late_conversion':{'conversion_month':20},'early_conversion':{'conversion_month':6},'zero_project_loan':{'project_loan':'0'},'slow_commissioning':{'commissioning_delay':12},'capex_15_remaining':{'initial_capex':'15'},'capex_45_remaining':{'initial_capex':'45'},'all_initial_capex_upfront':{'initial_capex_months':1},'inventory_stress':{'dio_delta':'30','dso_delta':'20','dpo_delta':'-10'},'interest_14pct':{'interest_rate':'.14'},'LC_crystallizes':{'lc_crystallization_month':4}}
 for label,patch in changes.items():result['stress_'+label]=(base|patch,5)
 for years in [5,10]:
  for margin in ['.125','.15','.175']:
   for step in range(2,25):
    growth=str(num(step)*D('.025'));result[f'funded_{years}y_growth_{growth}_margin_{margin}']=(base|{'growth':[growth]*10,'ebitda_margin':[margin]*10},years)
 return result

def main():
 raw=read('model_inputs.json');blob=(P/'canonical_paths.json.gz').read_bytes();paths=json.loads(gzip.decompress(blob));summary=read('model_summary.json')
 expected=expected_specs(raw);cmp('path_ids',set(expected),set(paths))
 for pid,path in paths.items():
  cmp(pid+':raw_specification',expected[pid][0],path['specification']);cmp(pid+':horizon',expected[pid][1],path['years']);replay(raw,path)
 with (P/'annual_model.csv').open() as f:
  for row in csv.DictReader(f):
   p=paths[row['path_id']];start=(int(row['year'])-1)*12;months=p['monthly'][start:start+12];live=[r for r in months if r['status']!='SUPPRESSED_AFTER_FAILURE']
   for k,v in row.items():
    if k in ('path_id','year'):continue
    expectedv=months[-1]['status'] if k=='year_end_status' else num(months[-1][k]) if k in ('cash','shares') else sum((num(r[k])for r in live),Z)
    cmp('annual:'+row['path_id']+':'+row['year']+':'+k,expectedv,v)
 cmp('path_count',len(paths),summary['path_count']);cmp('failed_count',sum(p['failed']for p in paths.values()),summary['failed_count']);cmp('suppressed_count',sum(p['ordinary_return_suppressed']for p in paths.values()),summary['ordinary_returns_suppressed_count'])
 for item in summary['funded_multiple_tests']:
  candidates=[p for pid,p in paths.items()if pid.startswith('funded_')and p['years']==item['years']];survivors=[p for p in candidates if not p['ordinary_return_suppressed']];hits=[p for p in survivors if num(p['terminal']['price_multiple'])>=num(item['target_multiple'])]
  cmp('target_tested',len(candidates),item['tested_paths']);cmp('target_survivors',len(survivors),item['funded_earned_survivors']);cmp('target_hits',len(hits),item['qualifying_paths']);cmp('target_required_CAGR',num(item['target_multiple'])**(U/item['years'])-1,item['required_price_CAGR'])
 result={'status':'PASS','paths':len(paths),'checks':count,'raw_input_sha256':hashlib.sha256((P/'model_inputs.json').read_bytes()).hexdigest(),'trace_sha256':hashlib.sha256(blob).hexdigest(),'independence':'No imports of producer modules. Every active month replayed from authored opening/source/physical/funding inputs; no emitted numeric value used as a state input. Emitted path specifications identify authored sensitivity variants. All failed subsequent months checked frozen and suppressed; all terminal, hurdle and target-survival results replayed.'}
 (P/'verification'/'monthly_replay.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
if __name__=='__main__':main()
