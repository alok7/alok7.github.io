"""Independent verifier: reads authored raw inputs/original sources, never producer imports."""
import json,gzip,hashlib,csv,io,zipfile
from pathlib import Path
from decimal import Decimal as D, ROUND_HALF_UP
from statistics import median
P=Path(__file__).resolve().parents[1]; M=P.parent/'shared_market_20261022'
def h(b):return hashlib.sha256(b).hexdigest()
def load(f):return json.loads((P/f).read_text(),parse_float=D)
def s(x):return str(x) if isinstance(x,D) else x
checks=[]
def ck(name,ok,details=None):
 checks.append({'name':name,'pass':bool(ok),'details':details});assert ok,(name,details)
audit=load('audit_inputs.json')
for name,source in audit['sources'].items():
 blob=gzip.decompress((P/'private_sources'/f'{name}.pdf.gz').read_bytes())
 ck('original_source_'+name,h(blob)==source['sha256'] and len(blob)==source['bytes'],{'sha256':h(blob),'bytes':len(blob)})
peers=load('peer_inputs.json')
for source in peers['sources']:
 if source.get('file'):
  blob=gzip.decompress((P/source['file']).read_bytes());ck('peer_original_'+source['id'],h(blob)==source['sha256'] and len(blob)==source['bytes'],h(blob))
market=load('market_inputs.json');values=[];absent=[]
for session in market['sessions']:
 blob=(M/(session['date']+'.zip')).read_bytes();ck('bhavcopy_hash_'+session['date'],h(blob)==session['sha256'])
 z=zipfile.ZipFile(io.BytesIO(blob));raw=z.read(z.namelist()[0]);ck('bhavcopy_csv_'+session['date'],h(raw)==session['csv_sha256'])
 rows=list(csv.DictReader(io.StringIO(raw.decode('utf-8-sig'))));issuer=[r for r in rows if r.get('ISIN')=='INE460Q01014'];
 ck('issuer_match_'+session['date'],(issuer==[session['row']]) if session['row'] else len(issuer)==0)
 if issuer:values.append((session['date'],D(issuer[0]['TtlTrfVal'])))
 else:absent.append(session['date'])
ck('market_calendar',len(market['sessions'])==60 and len(values)==55 and len(absent)==5,absent)
master=(M/'security_19102026.csv.gz').read_bytes();ck('security_master_compressed',h(master)==market['master_source']['compressed_sha256'])
masterraw=gzip.decompress(master);ck('security_master_csv',h(masterraw)==market['master_source']['csv_sha256'])
mr=list(csv.DictReader(io.StringIO(masterraw.decode('utf-8-sig'))));issuer=[r for r in mr if r.get('ISIN')=='INE460Q01014'];ck('all_security_rows',issuer==market['master_rows'])
active=[r for r in issuer if r.get('SctySrs')=='SM'];ck('security_lot_shares',len(active)==1 and D(active[0]['IssdCptl'])==14496792 and active[0]['NewBrdLotQty']=='1000')
fin=load('financial_inputs.json');yy={y['year']:y for y in fin['years']};f=lambda y,k:D(yy[y][k])/100
revenue_cagr=(f(2026,'revenue')/f(2021,'revenue'))**(D(1)/5)-1
sums={k:sum(f(y,k)for y in (2024,2025,2026))for k in ('pat','cfo','finance_cost','cash_capex')}
calc={'revenue_CAGR_5y':revenue_cagr,'revenue_CAGR_3y':(f(2026,'revenue')/f(2023,'revenue'))**(D(1)/3)-1,'cash_ratio':sums['cfo']/sums['pat'],'three_year_CFO_after_finance':sums['cfo']-sums['finance_cost'],'three_year_post_finance_FCF':sums['cfo']-sums['finance_cost']-sums['cash_capex'],'inventory_to_equity':f(2026,'inventory')/f(2026,'equity'),'market_cap':D('94.80')*14496792/10000000,'net_debt_including_directors':sum(f(2026,k)for k in ['debt_lt','debt_st','current_maturities','director_loans'])-f(2026,'cash_available'),'EPS_growth':D(yy[2026]['eps'])/D(yy[2025]['eps'])-1,'share_growth':D(yy[2026]['shares'])/D(yy[2025]['shares'])-1}
for y in (2025,2026):
 bridge=sum(D(v)for v in fin[f'cashflow_bridge_FY{y}_lakh'].values());ck('cashflow_bridge_'+str(y),abs(bridge-D(yy[y]['cfo']))<=D('.02'),str(bridge))
for row in audit['vintage_reconciliation']['pat_original_and_restated']:
 ck('PAT_bridge_'+str(row['fy']),D(str(row['original']))+D(str(row['restatement_adjustment']))==D(str(row['restated'])))
j=load('judgments.json');weights={'BQS':{'GOV':D('.20'),'MOAT':D('.20'),'REV':D('.12'),'DUR':D('.10'),'CAP':D('.12'),'CASH':D('.10'),'BAL':D('.08'),'EXEC':D('.08')},'GQS':{'REV':D('.40'),'DUR':D('.20'),'EARN':D('.15'),'CAP':D('.15'),'CASH':D('.10')}};scores={}
for name,ww in weights.items():
 cov=sum(v for k,v in ww.items()if j['factors'][k]['score'] is not None);known=sum(v*D(j['factors'][k]['score'])for k,v in ww.items()if j['factors'][k]['score'] is not None);scores[name]={'coverage':cov,'known':known,'raw':None,'bound':[known+1-cov,known+10*(1-cov)],'final':None}
 # Do not normalize known terms; CASH cap may constrain bound but cannot cure missing CAP.
ck('exact_BQS',scores['BQS']['coverage']==D('.88')and scores['BQS']['bound']==[D('4.28'),D('5.36')],scores['BQS'])
ck('exact_GQS',scores['GQS']['coverage']==D('.85')and scores['GQS']['bound']==[D('5'),D('6.35')],scores['GQS'])
known=D('.2')*j['factors']['D']['score'];scores['IAS']={'coverage':D('.2'),'known':known,'generic_bound':[D('1.4'),D('8.6')],'dependency_bound':[known+D('.25')*scores['BQS']['bound'][0]+D('.55'),known+D('.25')*scores['BQS']['bound'][1]+D('5.5')],'final':None};ck('thirteen_factors',len(j['factors'])==13)
peer_calc={}
for peer in peers['peers']:
 p={y:{k:D(v)for k,v in v.items()}for y,v in peer['periods'].items()};a=p['2025'];b=p['2026'];ebit=b.get('PBT_before_exceptional',b['PBT'])+b['finance']-b['other_income'];ebitda=ebit+b['DA'];avgcap=((a['equity']+a['debt']-a['cash'])+(b['equity']+b['debt']-b['cash']))/2
 q={'revenue_growth_percent':(b['revenue']/a['revenue']-1)*100,'operating_EBIT':ebit,'operating_EBITDA':ebitda,'operating_EBITDA_margin_percent':ebitda/b['revenue']*100,'reported_CFO_to_PAT':b['CFO']/b['PAT'],'reported_CFO_less_gross_cash_capex':b['CFO']-b['cash_capex'],'debt_to_equity':b['debt']/b['equity'],'net_debt':b['debt']-b['cash'],'pretax_operating_return_on_average_net_financial_capital_percent':ebit/avgcap*100,'operating_EBIT_to_finance_cost':ebit/b['finance']}
 for k,v in q.items():ck(peer['symbol']+'_'+k,v.quantize(D('.0001'),rounding=ROUND_HALF_UP)==D(peer['derived_FY26'][k]),str(v))
 peer_calc[peer['symbol']]=q
result={'input_sha256':{n:h((P/n).read_bytes())for n in ['financial_inputs.json','audit_inputs.json','peer_inputs.json','market_inputs.json','judgments.json']},'status':'PASS','module_imports':'stdlib only; no producer model, metrics, scoring or scenario imports','checks':checks,'calculations':calc,'scores':scores,'peer_calculations':peer_calc,'liquidity_absences_remain_unknown':absent}
(P/'verification'/'input_audit.json').write_text(json.dumps(result,default=s,indent=2)+'\n');print(json.dumps({'checks':len(checks),'calculations':calc,'scores':scores},default=s,indent=2))
