"""Author-written monthly conditional cash/physical-capacity engine. Standard library only.
All amounts INR crore except whole shares, tonnes, per-share rupees and ratios.
This is a diagnostic, not a claim about unobserved October 2026 balances.
"""
from decimal import Decimal as D, ROUND_CEILING
from datetime import date
import calendar,copy
ZERO=D(0);ONE=D(1);CR=D(10000000);CASH_EPS=D("1e-18")
def dec(x): return x if isinstance(x,D) else D(str(x))
def monthdate(m):
 y=2026+(9+m)//12;mo=(9+m)%12+1
 return date(y,mo,calendar.monthrange(y,mo)[1])
def seq(x,m): return dec(x[min((m-1)//12,len(x)-1)])
def run(inp,spec,years=5,path_id='path',trace=True):
 s=copy.deepcopy(spec);o=inp['opening'];a=inp['assumptions'];N=years*12
 cash=dec(s.get('opening_available_cash',o['cash_available']))-dec(o['ipo_escrow']); restricted=dec(o['restricted_cash']);ipo=dec(o['ipo_escrow']);cc=dec(o['working_capital_debt']);term=dec(o['term_debt']);director=dec(o['director_claim']);sh=int(o['issued_shares']);authorized=int(o['authorized_shares'])
 ar=dec(o['receivables']);inv=dec(o['inventory']);ap=dec(o['payables']);otherwc=dec(o['net_other_operating_wc']);initialwc=ar+inv-ap+otherwc
 cap={'casting':dec(o['casting_capacity']),'machining':dec(o['machining_capacity']),'forging':dec(o['forging_capacity'])};origin_cap=cap.copy();assets=dec(o['operating_fixed_assets']);cumulative_added=ZERO; annualrev=dec(o['revenue']);unitprice=annualrev/dec(o['annual_casting_equivalent_tonnes']);unitbase=unitprice
 dso0=ar/annualrev*365;dio0=inv/(annualrev*dec(a['production_cost_ratio']))*365;dpo0=ap/(annualrev*dec(a['production_cost_ratio']))*365
 annual_volume=dec(o['annual_casting_equivalent_tonnes']);feesannual=dec(o['bank_fees_annual']);upfront_received=ZERO;equitygross=ZERO;equityfees=ZERO;warrants_out=0;warrant_deadline=None;warrant_buckets={k:ZERO for k in inp["warrant"]["objects_crore"] if k!="general"};project_restricted=ZERO;newloans=[];capqueue=[];expansion_orders=[];history=[];failures=[];first_fail=None;tax_accrual=ZERO;futuredues={};emergency_shares=0;cc_cap=cc+dec(s.get('incremental_line',0));maxcashneed=ZERO;maxdraw=ZERO;cumcapex=ZERO;cuminterest=ZERO;cumcfo=ZERO;mincash=cash
 # The audited maturity schedule is advanced conservatively into the remaining fiscal windows;
 # actual Apr-Oct payments are ND, hence this entire balance transfer is assumption A.
 maturity=[('2027',1,5,dec(o['maturity_FY27'])),('2028',6,17,dec(o['maturity_FY28'])),('2029',18,29,dec(o['maturity_FY29'])),('2030',30,41,dec(o['maturity_FY30plus']))]
 base_principal={m:ZERO for m in range(1,N+1)}
 for fy,start,end,total in maturity:
  for m in range(start,min(end,N)+1):base_principal[m]+=total/dec(end-start+1)
 plan_total=dec(s.get('initial_capex',a['disclosed_capex_plan']));planmonths=int(s.get('initial_capex_months',12));plancommission=planmonths+int(s.get('commissioning_delay',3));planexpansionfrac=dec(a['plan_capacity_expansion_fraction'])
 capqueue.append({'month':plancommission,'investment':plan_total*planexpansionfrac,'reason':'conditional commissioning of stated capex programme; size/output conversion assumption'})
 loan_draw_month=int(s.get('project_loan_month',1));loan_amount=dec(s.get('project_loan',0));capex_to_tonnes=dec(a['casting_tonnes_per_crore']);line_maturity=int(s.get('line_maturity_month',0));locloss=int(s.get('lc_crystallization_month',0))
 for m in range(1,N+1):
  dt=monthdate(m);open_cash=cash;open_cc=cc;open_term=term;open_sh=sh;events=[];issued=0;eqgross=ZERO;eqfee=ZERO;newdebt=ZERO;newdebtfee=ZERO;wc_draw=ZERO;wc_repay=ZERO;principal=ZERO;interest=ZERO;warrant_restricted_receipt=ZERO;warrant_release=ZERO;warrant_capex_release=ZERO;project_release=ZERO;project_restricted_receipt=ZERO
  if first_fail is not None:
   history.append({'month':m,'date':str(dt),'status':'SUPPRESSED_AFTER_FAILURE','first_failure_month':first_fail,'cash':cash,'shares':sh});continue
  # Cash and securities events happen before operations only on the modeled date.
  if s.get('warrants') and m==int(s.get('warrant_allotment_month',1)):
   warrants_out=int(inp['warrant']['count']);warrant_deadline=m+18;eqgross=dec(warrants_out)*dec(inp['warrant']['price'])*dec(inp['warrant']['upfront_fraction'])/CR;eqfee=eqgross*dec(a['equity_fee']);
   for k in warrant_buckets:
    z=eqgross*dec(inp['warrant']['objects_crore'][k])/dec('32.4');warrant_buckets[k]+=z;warrant_restricted_receipt+=z
   cash+=eqgross-eqfee-warrant_restricted_receipt;upfront_received=eqgross;events.append('hypothetical pending warrants approved/allotted; no shares before conversion')
  if warrants_out and m==int(s.get('conversion_month',18)):
   if m>warrant_deadline or sh+warrants_out>authorized:
    failures.append({'month':m,'type':'warrant_authorization_or_expiry','amount':'0'});first_fail=m
   else:
    receipt=dec(warrants_out)*dec(inp['warrant']['price'])*(ONE-dec(inp['warrant']['upfront_fraction']))/CR;fee=receipt*dec(a['equity_fee']);eqgross+=receipt;eqfee+=fee
    added_restricted=ZERO
    for k in warrant_buckets:
     z=receipt*dec(inp['warrant']['objects_crore'][k])/dec('32.4');warrant_buckets[k]+=z;added_restricted+=z
    warrant_restricted_receipt+=added_restricted;cash+=receipt-fee-added_restricted;sh+=warrants_out;issued+=warrants_out;events.append('whole warrants converted; final75%cash received');warrants_out=0
  if warrants_out and m>warrant_deadline:
   events.append('warrants lapsed; upfront remains cash received, no shares');warrants_out=0
  if m==loan_draw_month and loan_amount>0:
   newdebt=loan_amount;newdebtfee=newdebt*dec(a['new_debt_fee']);project_restricted+=newdebt;project_restricted_receipt=newdebt;cash-=newdebtfee;term+=newdebt;newloans.append({'draw':m,'balance':newdebt,'amort':newdebt/36});events.append('conditional uncommitted project loan draw')
  for q in capqueue:
   if q['month']==m:
    tons=q['investment']*capex_to_tonnes
    cap['casting']+=tons;cap['machining']+=tons*dec(a['machining_capacity_ratio']);cap['forging']+=tons*dec(a['forging_capacity_ratio']);events.append('paid expansion commissioned, capex='+str(q['investment']))
  ng=seq(s['growth'],m);pg=dec(s.get('price_growth',a['price_growth']));vg=(ONE+ng)/(ONE+pg)-ONE;annual_volume*=((ONE+vg)**(ONE/12));unitprice*=((ONE+pg)**(ONE/12));demand=annual_volume/12
  if m<=int(s.get('customer_loss_months',0)):demand*=ONE-dec(s.get('customer_loss_fraction',0))
  physical_limit=min(cap['casting'],cap['machining']/dec(a['machining_load_ratio']),cap['forging']/dec(a['forging_load_ratio']))*dec(a['maximum_utilization'])/12
  sold=min(demand,physical_limit);lost=demand-sold;revenue=sold*unitprice
  utilization=sold*12/cap['casting'];margin=seq(s['ebitda_margin'],m)-max(ZERO,dec('.70')-utilization)*dec(a['fixed_cost_penalty']);ebitda=revenue*margin
  productioncost=revenue*dec(a['production_cost_ratio']);dso=dso0+dec(s.get('dso_delta',0));dio=dio0+dec(s.get('dio_delta',0));dpo=dpo0+dec(s.get('dpo_delta',0))
  ramp=min(ONE,dec(m)/dec(s.get('wc_transition_months',12)))
  targetar=revenue*12*(dso0+(dso-dso0)*ramp)/365;targetinv=productioncost*12*(dio0+(dio-dio0)*ramp)/365;targetap=productioncost*12*(dpo0+(dpo-dpo0)*ramp)/365;targetother=revenue*12*dec(o['net_other_operating_wc'])/dec(o['revenue'])
  deltaar=targetar-ar;deltainv=targetinv-inv;deltaap=targetap-ap;deltaother=targetother-otherwc;dwc=deltaar+deltainv-deltaap+deltaother;ar,inv,ap,otherwc=targetar,targetinv,targetap,targetother
  initialplan=plan_total/planmonths if m<=planmonths else ZERO
  # Source/use eligibility: earmarked proceeds can reimburse only this month's matching use.
  z=min(max(ZERO,dwc),warrant_buckets['working_capital']);warrant_buckets['working_capital']-=z;warrant_release+=z
  for k in ['land','facility','tools']:
   eligible=initialplan*dec(inp['warrant']['objects_crore'][k])/dec(a['disclosed_capex_plan'])*dec(s.get('warrant_capex_overlap',1));z=min(eligible,warrant_buckets[k]);warrant_buckets[k]-=z;warrant_release+=z;warrant_capex_release+=z
  cash+=warrant_release
  # Expansion is paid before it becomes physical capacity; no growth at zero capital.
  expansionpayment=ZERO
  for q in expansion_orders:
   if q['order']<=m<q['order']+int(a['expansion_payment_months']):expansionpayment+=q['cost']/dec(a['expansion_payment_months'])
  if s.get('auto_expand') and m%6==1:
   needed=(annual_volume*(ONE+max(ng,ZERO))**dec(a['expansion_lead_years']))/(dec(a['maximum_utilization']))
   committed=cap['casting']+sum(q['investment']*capex_to_tonnes for q in capqueue if q['month']>m)
   if needed>committed:
    cost=(needed-committed)/capex_to_tonnes;order={'order':m,'cost':cost};expansion_orders.append(order);capqueue.append({'month':m+int(a['expansion_lead_months']),'investment':cost,'reason':'demand-triggered capacity expansion'});expansionpayment+=cost/dec(a['expansion_payment_months']);events.append('new funded expansion order, cost='+str(cost))
  project_release=min(project_restricted,max(ZERO,initialplan+expansionpayment-warrant_capex_release));project_restricted-=project_release;cash+=project_release
  maintenance=revenue*dec(s.get('maintenance_ratio',a['maintenance_ratio']));capex=initialplan+expansionpayment+maintenance;cumcapex+=capex;assets+=capex;da=dec(o['da'])/12+cumulative_added/dec(a['new_asset_life_years'])/12;cumulative_added+=initialplan+expansionpayment;assets=max(ZERO,assets-da)
  interest=(open_cc*dec(s.get('interest_rate',a['interest_rate']))+open_term*dec(s.get('interest_rate',a['interest_rate'])))/12
  # New loans drawn at month start accrue the full month; incremental CC drawn at close accrues next month.
  interest+=newdebt*dec(s.get('interest_rate',a['interest_rate']))/12
  bankfee=feesannual/4 if m%3==0 else ZERO;taxable=max(ZERO,ebitda-da-interest-bankfee);taxexpense=taxable*dec(a['tax_rate']);tax_accrual+=taxexpense;cash_tax=tax_accrual if dt.month in (3,6,9,12)else ZERO
  if cash_tax:tax_accrual=ZERO
  prior_tax=dec(o['net_opening_tax_payable']) if m==int(a['opening_tax_settlement_month']) else ZERO
  principal=min(term,base_principal[m])
  for loan in newloans:
   if m>=loan['draw']+12 and loan['balance']>0:
    p=min(loan['amort'],loan['balance']);loan['balance']-=p;principal+=p
  principal=min(principal,term);term-=principal
  lc=dec(o['lc_contingent']) if m==locloss else ZERO
  cfobefore=ebitda-dwc-cash_tax-prior_tax;cash+=cfobefore-capex-interest-bankfee-principal-lc
  if m==line_maturity:
   cash-=cc;wc_repay+=cc;cc=ZERO;cc_cap=ZERO;events.append('stress: existing on-demand credit not renewed; full claim paid')
  reserve=dec(a['minimum_cash_reserve']);need=max(ZERO,reserve-cash);headroom=max(ZERO,cc_cap-cc)
  wc_draw=min(need,headroom);cc+=wc_draw;cash+=wc_draw;maxdraw=max(maxdraw,cc)
  # Optional analyst financing case only: issue integer common shares before gap, fee-adjusted.
  if cash<reserve-CASH_EPS and s.get('emergency_equity'):
   need=reserve-cash;price=dec(s.get('equity_price',a['emergency_equity_price']));count=int(((need-CASH_EPS)*CR/(price*(ONE-dec(a['equity_fee'])))).to_integral_value(rounding=ROUND_CEILING));available=max(0,authorized-sh-warrants_out);count=min(count,available)
   if count:
    receipt=dec(count)*price/CR;fee=receipt*dec(a['equity_fee']);cash+=receipt-fee;sh+=count;issued+=count;emergency_shares+=count;eqgross+=receipt;eqfee+=fee;events.append('hypothetical unapproved emergency equity, integer shares='+str(count))
  if cash>reserve and cc>dec(o['working_capital_debt']):
   repayment=min(cash-reserve,cc-dec(o['working_capital_debt']));cc-=repayment;cash-=repayment;wc_repay+=repayment
  equitygross+=eqgross;equityfees+=eqfee;cuminterest+=interest+bankfee;cumcfo+=cfobefore;mincash=min(mincash,cash);maxcashneed=max(maxcashneed,max(ZERO,reserve-cash))
  if cash<-CASH_EPS or first_fail is not None:
   failures.append({'month':m,'type':'cash_shortfall'if cash<-CASH_EPS else'authorization','amount':str(max(ZERO,-cash))});first_fail=m
  identity=open_cash+eqgross-eqfee-warrant_restricted_receipt+warrant_release+newdebt-newdebtfee-project_restricted_receipt+project_release+cfobefore-capex-interest-bankfee-principal-lc+wc_draw-wc_repay
  assert abs(identity-cash)<D('.0000000001'),(path_id,m,identity,cash)
  assert sh==open_sh+issued and sh+warrants_out<=authorized and isinstance(sh,int)
  assert sold<=physical_limit and capex>=ZERO and wc_draw<=headroom
  history.append({'month':m,'date':str(dt),'status':'FAILED'if first_fail else'ACTIVE','events':events,'opening_cash':open_cash,'revenue':revenue,'demand_tonnes':demand,'sold_tonnes':sold,'lost_sales_tonnes':lost,'unit_price_crore_per_tonne':unitprice,'casting_capacity':cap['casting'],'machining_capacity':cap['machining'],'forging_capacity':cap['forging'],'utilization':utilization,'ebitda':ebitda,'ebitda_margin':margin,'depreciation':da,'ebit':ebitda-da,'interest':interest,'bank_fee':bankfee,'tax_expense':taxexpense,'cash_tax':cash_tax,'prior_tax_settlement':prior_tax,'receivables':ar,'inventory':inv,'payables':ap,'other_wc':otherwc,'d_receivables':deltaar,'d_inventory':deltainv,'d_payables':deltaap,'d_other_wc':deltaother,'delta_onwc':dwc,'cfo_before_finance':cfobefore,'maintenance_capex':maintenance,'initial_programme_capex':initialplan,'expansion_capex':expansionpayment,'total_capex':capex,'term_principal':principal,'term_debt':term,'new_debt':newdebt,'new_debt_fee':newdebtfee,'project_restricted_receipt':project_restricted_receipt,'project_capex_release':project_release,'project_restricted_balance':project_restricted,'cc_draw':wc_draw,'cc_repayment':wc_repay,'cc':cc,'cc_authorized_capacity_assumption':cc_cap,'cash':cash,'restricted_cash':restricted,'ipo_escrow':ipo,'lc_paid':lc,'equity_cash_gross':eqgross,'equity_fee':eqfee,'warrant_restricted_receipt':warrant_restricted_receipt,'warrant_eligible_release':warrant_release,'warrant_restricted_balance':sum(warrant_buckets.values(),ZERO),'warrant_buckets':warrant_buckets.copy(),'issued_shares_month':issued,'shares':sh,'warrants_outstanding':warrants_out,'balance_identity_error':cash-identity,'unpaid_tax':tax_accrual,'net_operating_fixed_assets':assets})
 active=[r for r in history if r['status']=='ACTIVE'];failed=first_fail is not None;last12=history[-12:];valid=not failed and all(r['status']=='ACTIVE'for r in last12)
 terminal=None
 if valid:
  rev=sum((r['revenue']for r in last12),ZERO);ebitda=sum((r['ebitda']for r in last12),ZERO);da=sum((r['depreciation']for r in last12),ZERO);ebit=ebitda-da;nopat=ebit-max(ZERO,ebit)*dec(a['tax_rate']);g=dec(s.get('terminal_growth',a['terminal_growth']));wacc=dec(s.get('wacc',a['wacc']));repl=max(da,rev*dec(a['terminal_replacement_ratio']));growthfixed=rev*g/dec(a['terminal_incremental_sales_to_capital']);onwc=ar+inv-ap+otherwc;growthwc=onwc*g;growthcash=rev*g*dec(a['terminal_operating_cash_ratio']);fcff_next=(nopat+da-repl)*(ONE+g)-growthfixed-growthwc-growthcash
  senior=cc+term+director+tax_accrual+dec(o['unfunded_employee_claim']);operatingcash=rev*dec(a['terminal_operating_cash_ratio']);cash_topup=max(ZERO,operatingcash-cash);pending_capex=sum((q['cost']*max(0,q['order']+int(a['expansion_payment_months'])-1-N)/dec(a['expansion_payment_months']) for q in expansion_orders),ZERO)+max(0,planmonths-N)*plan_total/planmonths;senior+=cash_topup+pending_capex;addablecash=max(ZERO,cash-operatingcash);ev=max(ZERO,fcff_next)/(wacc-g);eq=max(ZERO,ev+addablecash-senior);terminalprice=eq*CR/sh;cross_ev=ebitda*dec(s['exit_multiple']);cross_eq=max(ZERO,cross_ev+addablecash-senior);holding=dec((monthdate(N)-date(2026,10,19)).days)/D('365.25');entry=dec(s.get('entry_price',o['price']));irr=(terminalprice/entry)**(ONE/holding)-ONE if terminalprice>0 else D(-1);futureunits=sum((r['sold_tonnes'] for r in last12),ZERO)*(ONE+g)/(ONE+dec(a['price_growth']));futurephysneed=max(ZERO,futureunits/dec(a['maximum_utilization'])-cap['casting']);physical_growth_cost=futurephysneed/capex_to_tonnes
  earned=(fcff_next>ZERO and wacc>g and growthfixed>=physical_growth_cost)
  terminal={'revenue':rev,'EBITDA':ebitda,'EBIT':ebit,'NOPAT':nopat,'DA':da,'terminal_g':g,'wacc':wacc,'replacement_capex':repl,'growth_fixed_reinvestment':growthfixed,'growth_wc_reinvestment':growthwc,'growth_operating_cash':growthcash,'operating_cash_topup':cash_topup,'unpaid_committed_capex':pending_capex,'unused_warrant_restricted':sum(warrant_buckets.values(),ZERO),'unused_project_restricted':project_restricted,'forward_FCFF':fcff_next,'physical_growth_cost_required':physical_growth_cost,'DCF_terminal_EV':ev,'multiple_crosscheck_EV':cross_ev,'senior_claims':senior,'tax_claim':tax_accrual,'operating_cash_retained':min(cash,operatingcash),'surplus_cash_added':addablecash,'restricted_cash_added':ZERO,'equity':eq,'shares':sh,'price':terminalprice,'multiple_crosscheck_price':cross_eq*CR/sh,'holding_years':holding,'IRR':irr,'earned':earned,'entry_prices_at_hurdles':{str(h):terminalprice/((ONE+h)**holding)for h in [D('.12'),D('.15'),D('.18')]},'price_multiple':terminalprice/entry}
  if not earned:terminal['ordinary_return_suppressed']=True;terminal['IRR']=None;terminal['entry_prices_at_hurdles']={};terminal['price_multiple']=None
  else:terminal['ordinary_return_suppressed']=False
 return {'path_id':path_id,'specification':s,'years':years,'source_eligible':False,'source_eligibility_reason':'October balance bridge unavailable; conditional funding/capacity assumptions are explicit. No path is an executable current forecast.','failed':failed,'first_failure_month':first_fail,'failure_register':failures,'ordinary_return_suppressed':failed or not terminal or terminal['ordinary_return_suppressed'],'max_unfunded_cash_reserve_need':maxcashneed,'minimum_cash':mincash,'total_capex':cumcapex,'total_finance_cash':cuminterest,'total_cfo_before_finance':cumcfo,'new_equity_gross':equitygross,'equity_fees':equityfees,'emergency_new_shares':emergency_shares,'ending_shares':sh,'terminal':terminal,'monthly':history if trace else []}
