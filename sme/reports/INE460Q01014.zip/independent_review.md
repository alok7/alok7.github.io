# Independent source and input review

Scope: Sharp Chucks and Machines Limited, SCML, INE460Q01014; Master Prompt v3.0; information cutoff 20 October 2026 and market cutoff 19 October 2026. This dated source review is distinct from final model/recovery acceptance. The final independent acceptance receipt, if present, identifies the exact reviewed artifact hashes and remaining limitations.

The actual complete v3.0 methodology was reviewed, including the 15 standard output sections, 16 quality checks, 13 factors, exact score weights, missingness bounds, gates and caps. Original financial/audit PDFs were inspected directly, including independent OCR of scanned FY20–24 audit pages. Original market archives and peer financial statements were independently read rather than substituting prior company conclusions.

The initial independent input audit passed 251 checks covering retained original source bytes, 60 complete NSE session archives and the security master, PAT restatement bridges, cash-flow arithmetic, all three peer comparison calculations and exact Decimal score missingness. The raw verifier imports no producer calculation modules.

Substantive confirmations:
- Seven original annual statutory opinions are unmodified. FY24 inventory note and FY25–26 continued WIP/PPE methodology limitations remain material evidence questions, not a qualified-opinion or fraud allegation.
- CARE’s adequate-liquidity/positive-outlook assessment and regular service sinceApril 2024 are substantive counterevidence. The same rationale discloses 98%working-capital utilization and 30 crore capex. Its June cash/investment figure does not verify unrestricted October cash.
- FY26 detailed cash/bank residual is 0.5167 crore, versus cash-flow closing balance 0.5166 crore. Preserve the 0.0001 crore presentation discrepancy. Security FDs 9.9069 crore are unavailable for immediate use; possible IPO-escrow overlap is an additional explicitly conservative assumption.
- FY24–26 reported CFO/PAT1.2703777 is before financing-classified interest. Cash after financing is−5.4517 crore; after cash capex/financing−54.7161 crore. Reclassifying capital advances affects the CFO diagnosis but not total reinvestment cash.
- Original-to-restated PAT bridges are disclosed. The FY23 power rebate’s classification change is not additional PAT. Any nonrecurrence exclusion is a separate analytical assumption.
- The April financing was withdrawn 4 June 2026. October 4 million warrants at 81 rupees remain proposed at cutoff; no receipt is committed. Their stated purpose restrictions and staged 25%/75%receipts must survive the financing model.
- The 19 October 94.80 rupee close, 1, 000-share lot and 14, 496, 792 issued shares are verified. Five absent issuer rows across 60 complete exchange archives remain unknown, not automatically zero-trade sessions.
- Pritika consolidated, Nelcast consolidated including NCI, and Talbros Engineering standalone comparison inputs were checked against their original financial statements. Their cash-flow interest/tax classifications and differing scope prevent naive comparison.

Exact score arithmetic at this review: BQS88%coverage, known 4.16, bound 4.28–5.36; GQS85%, known 4.85, bound 5.00–6.35 before the CASH3 growth cap; IAS20%, known 0.60, generic bound 1.40–8.60 and dependency-aware 2.22–7.44. All composites remain NS. A cap cannot substitute a numeric final score for missing evidence. G2/G3 unresolved holds do not establish current default or severe governance abuse.

Corrections requested and accepted during review include source-purpose financing segregation, terminal operating-cash top-up and growth, committed-capex treatment, loss-preserving terminal NOPAT, duties/taxes working capital inclusion, detailed cash arithmetic and explicit historical normalization. Final replay must test the implemented results, not rely on this acknowledgement.

Remaining final-review scope: independently replay every monthly source/use, interest/fee/maturity, credit limit, capacity/working capital, whole-share funding and terminal claim; verify failed-path suppression, 12%/15%/18%hurdles and 5×/10×tests; read all 15 rendered sections and 16 quality checks; verify guarded cold reconstruction and current compact/full Library identities and hashes. No investment conclusion is upgraded by successful software reconstruction. Original financial reliability, current funding and execution-data gaps remain.
