# Sharp Chucks and Machines Limited — SME research #362

Master Prompt v 3.0. Information cutoff: 20 October 2026, end of day India. Valuation reference: official NSE close 19 October 2026. Research assembled 24 October 2026. ₹ crore unless stated otherwise. This is research, not individualized investment advice.

## 1. Executive Verdict

Sharp Chucks and Machines manufactures castings, machined/forged components and machine-tool accessories, mainly for concentrated tractor and industrial OEM customers. A long operating history, real revenue expansion and improved credit assessment are strengths. The decisive limitation is accounting and funding reliability: persistent work-in-progress valuation/asset reconciliation gaps, highly restricted cash, thin interest cover and an unverified current funding bridge prevent a supported investable return. At ₹94.80, the approximately 15× FY2026 PAT multiple is neither a sufficient margin of safety nor proof of overvaluation. Classification: **Hold — unresolved**, with Business Quality, Growth Quality and Investment Attractiveness all **NS**. This is a cyclical, capital-intensive expansion thesis, not an established compounder. Verified inventory valuation and current funded cash/capacity economics could change the decision; a lower price alone cannot cure them. [AR26 pp 41–78] [CARE2609]

## 2. Research Header, Gates and Data Confidence

Original-universe fields are retained unchanged: position 362, name “Sharp Chucks and”, symbol SCML, ISIN INE460Q01014. Verified legal issuer is **Sharp Chucks and Machines Limited**, NSE Emerge SME, listed 12 October 2023. The investable reporting perimeter is standalone; no subsidiary, associate or joint venture is reported. Indian GAAP Accounting Standards under Companies Act section 133 apply, not assumed Ind AS. Current verified issued shares are 14,496,792, face value ₹10; market capitalization at the reference close is ₹137.4296 crore. The original list’s pending research status is not the subsequently verified issuer conclusion. [PROS] [AR26] [EGM2610]

The closing price and last transaction price are both ₹94.80 on 19 October, with 8,000 shares, ₹789,450 actual turnover and eight trades. The current master identifies series SM and a 1,000-share lot. That is not a live bid or an executable ₹5 lakh position.

{{LIQUIDITY}}

Five complete official session archives omit the issuer row, without independent no-trade confirmation. Observed-only means and medians are not full-window statistics; absent-as-zero calculations are conditional sensitivities only. Five lots cost ₹474,000 and six ₹568,800, so the reference ₹500,000 cannot be purchased exactly in whole lots. On the final observed session even 10% of shares is 800, below one 1,000-share lot; an aggregate turnover ratio does not ensure participation-size execution. The security master’s end-of-day price range is not used as proof of that session’s intraday circuit regime. Detailed exchange archive URLs and SHA256/CRC/date checks are retained in market_inputs.json.

Core investment horizon: five years, with ten-year feasibility diagnostics. Illustrative nominal equity hurdle: 15%, tested at 12% and 18%, before personal tax and investor trading costs. Model WACC is separate from that hurdle. Liquidity reference: ₹5 lakh, not a recommended allocation. Financial confidence is high that primary reported numbers and opinions were retrieved accurately, medium on underlying earnings and growth composition, low on inventory reliability, incremental returns and current unrestricted funding. Historical share count and reference price have high retrieval confidence; liquidity implementation is low confidence because missing issuer rows, live spread and surveillance are unresolved.

{{GATES}}

A Hold is not a proved fraud/default Fail. Unmodified financial and IFC opinions and the credit-agency improvement are meaningful counterevidence. They do not supply the missing inventory reconciliation or current cash bridge. G2 blocks favorable numeric ranking; G3 unresolved does not trigger the separate cap reserved for evidenced funding failure.

## 3. Scorecard and Calculation Audit

{{SCORES}}

BQS is Business Quality Score; **GQS is Growth Quality Score**, not governance. IAS is Investment Attractiveness Score. Every missing factor remains NS at its original weight. No missing score is set to zero, midpoint-filled or redistributed. Mathematical bounds are not confidence intervals or investable rankings. The dependency-aware IAS bound propagating BQS is **{{IAS_BOUND}}**. Exact Decimal arithmetic is preserved; display rounding is half-up to one decimal only after aggregation, while classification uses unrounded values.

{{CONTRIBUTIONS}}

{{FACTORS}}

The CASH score of 3 triggers the conditional Growth Quality ceiling of 5 because the weakness is recurrent cash realization/working-capital control, not simply investment capex. The uncapped GQS bound and capped bound are both in scores.json. CAP remains NS, so GQS remains NS even if its capped bounds coincide at 5. No governance cap applies: GOV is 4 and G1 has no evidenced severe failure. No funding cap applies: G3 is unresolved, not a proved current failure. G2 independently forces IAS NS and excludes numerical quality ranking. MOAT ±1 changes known BQS by ±0.20; CASH ±1 changes BQS and GQS by ±0.10. Joint BQS sensitivity is ±0.30, without curing missing evidence.

## 4. Business Overview

The company sells engineered castings, machining and forging work, tractor/industrial components, chucks and machine-tool accessories. Revenue depends on approved product supply and purchase orders, not a recurring software-like subscription. Earnings arise from metal conversion, machining, tooling/quality and reliable OEM supply after raw material, power, labour, subcontracting, freight, interest and customer credit costs. Collection follows sales: inventory and trade receivables are economically necessary but consume capital. A customer relationship is not equivalent to a guaranteed backlog. [PROS pp 137–155]

At FY2023, castings accounted for 86.07% of revenue. FY2026 reports one manufacturing segment, so current product mix, unit margins and profit by casting/forging/chuck product are ND. Do not use the old mix as the current sales split. September 2026 CARE repeats nameplate capacities of 30,000 casting, 14,400 machining and 3,600 forging tonnes per annum. These are linked process stages, not 48,000 interchangeable tonnes of saleable product. FY2026 production and utilization by stage are not disclosed in the reviewed material. [PROS pp 134,147–149] [AR26] [CARE2609]

Verified FY2021/FY2022/FY2023 casting production was 15,051/15,823/19,606 tonnes, while installed casting capacity rose from 18,000 to 30,000. FY2023 machining output was 7,690 of 14,400 tonnes and forging 1,730 of 3,600. The expansion created physical room, but old spare capacity is not proof that current demand can grow profitably without tooling, labor or working capital. FY2026 exports were ₹4.4212 crore, only about 1.61% of operating sales; the business remains predominantly domestic. [PROS p 148] [AR26]

## 5. Moat / Industry Position

The plausible advantage is approved OEM access, accumulated product/process knowledge and integrated casting/machining capabilities developed over three decades. Those are useful operating assets. Evidence of durable pricing power is weaker: concentrated customers have bargaining power, orders are purchase-order based, and raw-material pass-through can lag about one quarter. The failure mechanisms are OEM loss, price pressure, casting quality/rejection, unfavorable product mix, delayed cost recovery, power disruption and financed capacity that fails to earn an adequate spread over capital cost. A certification, long history or factory photograph is not independent proof of a moat. [PROS pp 140–153] [CARE2609]

FY2023 top-five customers represented 73.78% of sales; the September 2026 rating commentary still places major OEM concentration around 74%. No verified current retention cohort, product-level price premium, independent market share or long-term contracted backlog was found. Industry exposure is cyclical tractor, commercial/industrial equipment demand, with material and power costs affecting cash even where eventual price pass-through exists. The source-supported conclusion is a contestable manufacturing franchise, not immunity from competition.

{{PEERS}}

The comparison uses current FY2026 original audited accounts, not a transplanted sector multiple. Pritika Engineering is the closest smaller casting/machining comparison, but its parent supplied about 88% of sales and material advance funding. Its headline CFO includes a large other-noncurrent-liability inflow; that is not pure cash earnings. Nelcast provides a larger iron-casting comparison with broader customer exposure and cash generation, but its March “no major capex” rating assumption was overtaken by the 5 October ₹75 crore machining approval. Talbros Engineering makes forged axle shafts, has different product/export economics, and is BSE 538987, not Talbros Automotive. Its reported CFO already includes interest, so interest is not deducted twice. All-peer operating EBITDA excludes all other income; Sharp’s normalized EBITDA retains operating FX/export income, so small definition differences remain explicit. A consistent pretax book-capital proxy is shown, not claimed economic ROIC. No synchronized peer P/E median is fabricated: Pritika has a current-issuance bridge gap and Talbros’ reference-date price is unavailable. Full primary sources, formulae and exceptions appear in the peer appendix.

## 6. Revenue Growth & Scale

{{GROWTH}}

{{CAGR}}

The preselected five-year FY2021–FY2026 operating-revenue CAGR is 15.11%, versus 15.77% over FY2023–FY2026. FY2026 sales increased about 11.50%, slower than the preceding year. The initial pandemic-affected period and capacity additions affect interpretation. The final prospectus restatement did not change operating revenue, but changed profit/tax classifications. Reported sales growth is not equated with organic volume: metal realizations, mix, new-component content and utilization are not fully reconciled. No acquisition-led revenue addition was identified, but a clean price/volume split remains ND. REV 7 uses the preselected reported comparable-scope CAGR with medium confidence and no upward trajectory adjustment; it is not a measured physical-volume CAGR.

Ten-year CAGR is ND because eleven comparable observations are unavailable. CARE’s June-quarter FY2027 sales of ₹60.73 crore are management information, with no matched prior-quarter/cash-flow set. It is neither annualized nor spliced into an invented TTM. New-business LOI language does not change recognized revenue or create binding backlog. [CARE2609]

## 7. Growth Quality & Reinvestment Runway

Growth can come from more components per existing OEM, higher casting and machining throughput, reduced subcontracting and qualified new customers. The credible bottom-up requirements are orders, production/yield, operating staffing, tooling, paid and commissioned capacity, receivable/inventory funding and finance costs. CARE identifies a ₹30 crore capex programme and a new-segment LOI, but definitive orders, counterparty, value, conversion schedule and project-level returns are not verified. These are opportunities, not an accessible addressable market quantified by a large automotive headline. [CARE2609]

The model therefore starts with explicit assumed 24,000 annual casting-equivalent tonnes, not falsely reported FY2026 output. The 30,000/14,400/3,600 nameplate stages constrain monthly physical output, with machining/forging load assumptions. Half the initial programme is assumed to add capacity and half to automate existing activity; commissioning is delayed until spending precedes output. Future capacity expansion needs paid capex, lead time and working capital. Unit capex of 400 annual casting-equivalent tonnes per ₹1 crore is an analyst sensitivity, not a sourced engineering quote. Revenue never exceeds the most restrictive modeled process stage.

Reported normalized NOPAT growth and descriptive capital returns are positive, but they do not prove returns attributable to new capital. Inventory valuation uncertainty, incomplete full operating-capital reconciliation and utilization/mix effects prevent CAP scoring. GQS consequently remains NS. The cash-quality cap does not mean all growth is bad; it means sales expansion has not yet demonstrated a sufficiently reliable cash and financing path. The primary countercase is that FY2026 inventory stabilized, CFO recovered and CARE improved liquidity, while further automation and better collections could release working capital.

## 8. Management, Governance & Execution

The October notice’s promoter-group holding is 9,230,542 shares, 63.67% of current issued shares. Full proposed warrant conversion would give 11,230,542 promoter-group shares out of 18,496,792, or 60.72%; percentage dilution is not loss of control. Two million proposed warrants are for promoter group and two million for other investors. FY2026 director remuneration was ₹0.72 crore versus PAT ₹9.1901 crore. Related Sharp Precision sales of ₹11.9721 crore and purchases of ₹6.9852 crore require terms/settlement review but do not, by themselves, establish abuse. Current promoter pledge status has not been independently established and is ND, not silently zero. [EGM2610 pp 19–24] [AR26 related-party note]

{{AUDITS}}

The original statutory audit/IFC vintages were read before the restated offering accounts. All seven financial opinions and IFC opinions are unmodified. Material findings are nevertheless present in notes and CARO: PPE discrepancies recur from FY2023, stagewise WIP methodology remains unimplemented, FY2024–25 audit-trail exceptions recur, and old short-term finance used for long-term assets is disclosed. FY2026 omission of an earlier paragraph is not evidence of remediation. The change from Sharp & Tannan to V. P. Bhalla followed term expiry; it is not presented as opinion shopping. [AR20] [AR21] [AR22] [AR23] [AR24] [AR25] [AR26]

| Dated record or commitment | Observed outcome by cutoff | Interpretation |
|---|---|---|
| FY2023–FY2026 inventory/PPE remediation | Stagewise WIP methodology and PPE reconciliation remain unresolved | Repeated control weakness, not an allegation that all inventory is fictitious |
| FY2024/25 audit-trail compliance | Exceptions stated; FY2026 paragraph absent | Request affirmative remediation, not an assumed cure |
| Prior 2,412,000 warrants at ₹76.12 | Converted 17 November 2025; listed 3 July 2026 | Already in 14,496,792 shares; proceeds not future cash |
| April 2026 equity/warrant proposal | Cancelled 4 June 2026 | Do not include withdrawn 2.637 m shares or 3.063 m warrants as active dilution |
| Separate authorized-capital increase | May 6 resolution approved to 21 m shares | Corporate approval not proof of receipt or all future issuance permissions; ROC effectiveness ND |
| October 2026 proposal | 4 m warrants at ₹81, EGM scheduled 31 October | Still proposed at cutoff, not committed cash |
| In-house machining/automation narrative | Job-work cost rose from ₹2.44 cr to ₹4.53 cr in FY2026 | Savings not yet demonstrated; mix and volume can explain cost change |
| New business segment | CARE records LOI, definitive orders awaited | Not a booked order or already missed contractual delivery |

FY2025 included an NSE fine of ₹519,200 relating to delayed preferential listing; FY2026 includes a ₹2,000 Regulation 34 fine. These are disclosure/execution signals, not quantitatively major profit deductions or proof of fraud. CARE identified actual debt-service delays in December 2023 and March 2024 and subsequently regular servicing from April 2024. The FY2024 CARO “no default” statement needs a reasoned chronology reconciliation. The 2024 D/noncooperating rating must not be explained away as noncooperation alone, and the later cure must not be omitted. [CARE2401] [CARE2502] [CARE2601] [CARE2609]

## 9. Financial Forensics

{{HISTORY}}

All figures above are ₹ crore, except margins and ratios. Operating EBITDA removes interest income, asset gains and conservatively excludes FY2023 power rebate and FY2026 insurance recovery; it is not a reported segment EBITDA. Disclosed tax rates and normalization uncertainties remain visible. Gross profit is ND as a consistently reported audited subtotal: material-only contribution is not mislabeled gross profit. Detailed production-cost proxies and ingredients are available in financial_inputs.json and metrics.json.

{{BALANCES}}

Original versus restated PAT in ₹ lakh is preserved: FY2020 314.63→298.35; FY2021 380.52→330.96; FY2022 453.97→452.62; FY2023 473.39→506.50. The final prospectus FY2023 adjustment of +₹33.11 lakh reconciles through GST/MSME interest, tax/MAT/deferred-tax and IPO professional-fee/reversal items; it is not unexplained sales growth. The FY2023 ₹218 lakh PSPCL power rebate moved from direct expense to other income. We conservatively remove it from normalized earnings because no comparable rebate occurred in the previous two years, not merely because its presentation changed. Draft and final FY2021–22 equity differ by ₹12.08 lakh despite unchanged PAT; final prospectus values control the core series. Original FY2024 PAT ₹610.47 lakh versus later comparative ₹610.46 is retained as rounding/vintage, not manufactured precision. [DRAFT pp 210–212,226] [PROS pp 191–208]

The FY2026 cash-flow statement prints closing cash ₹51.66 lakh whereas detailed cash/bank items sum to ₹51.67 lakh. The model uses the item-sum balance, retaining the ₹0.01 lakh display discrepancy rather than denying the alternative source. The apparently huge FY2022 “cash in hand” cash-flow label is resolved by the detailed note: ₹2,528.52 lakh comprises ₹5.52 lakh physical cash and ₹2,523 lakh cheques/drafts. Clearing availability is ND. This is not evidence of a vault full of currency and is not a current available-cash proxy. Two FY2026 printed-note errors are retained rather than silently corrected: depreciation ₹0.01 lakh in note 27 versus ₹795.14 lakh in the P&L, and prior-year maturity ₹0.01 lakh in the debt note versus ₹1,114.07 lakh in the balance sheet. Main statements control; these are disclosure errors, not qualifications invented by the researcher.

{{EARNINGS}}

FY2026 illustrative normalized PAT removes ₹83.83 lakh interest, ₹1.92 lakh asset gain and ₹8.73 lakh insurance recovery at an assumed 25% tax effect, then reverses ₹14.34 lakh prior-year tax. Other operating FX/export income remains. FY2020–22 interest income is consistently removed from historical normalized earnings and starting NOPAT. No conjectured inventory/GST adjustment is booked as fact. FY2026 reported EPS of ₹7.09 rose only about 0.85% versus FY2025 ₹7.03, while PAT rose about 15.69%; weighted-average shares differ from the current outstanding count. All valuation claims use actual current shares. No future warrant proceeds or old converted-warrant proceeds are counted twice.

{{CASH}}

FY2024–FY2026 CFO/PAT, calculated as a ratio of sums, is **{{CASH_RATIO}}**: reported CFO ₹29.5218 crore / PAT ₹23.2386 crore. The positive reported ratio is retained. Because financing interest is outside CFO, after interest the three-year cash surplus is negative ₹5.4517 crore; after ₹49.2644 crore cash capex it is negative ₹54.7161 crore. This is not the same as claiming reported CFO was negative in all years. FY2025 CFO was negative; FY2026 recovered to ₹19.7872 crore. Capital-advance movements are partly within reported CFO: reclassifying their net FY2024–26 increase of ₹2.6088 crore to investing raises post-interest operating cash to negative ₹2.8429 crore, still negative, while total post-reinvestment cash remains unchanged. This classification sensitivity is retained before attributing all reported CFO weakness to operations. Finance cost is a cash-interest proxy subject to accrual/fee timing, with source cash-flow classification documented. Maintenance/growth capex is not disclosed separately, so the historical split is ND rather than retrospectively invented.

FY2026 cash generation benefited from slower inventory accumulation and increased trade payables, while receivables rose substantially. Income-tax cash payment lag and creditor funding are not recurring free cash by default. At March 2026 inventory ₹107.3997 crore was roughly 100.6% of equity and 36.6% of total assets. Receivables of ₹52.6931 crore include ₹1.8588 crore over three years, versus ₹0.2643 crore previously; no provision is reported because balances are considered good. External confirmations for debtors, advances and creditors remain pending. WIP is not stagewise tracked; an independent cost-accountant valuation does not replace the missing methodology evidence. [AR26 pp 59–78]

{{WC}}

Inventory/payable days use disclosed material, stores, inventory change, manufacturing and employee costs as a production-cost proxy. Receivable days use average AR / operating revenue. A raw-purchase denominator alternative is retained where available; total supplier purchases are not invented. These are comparability tools, not precise cash-conversion forecasts. The stated growth does not excuse recurrent verification weaknesses.

{{CAPITAL}}

{{INCREMENTAL}}

Core operating capital is AR + inventory − trade payables + PPE + intangibles + CWIP + capital advances + security deposits. The historical funding proxy is equity + bank/director debt − total reported cash. Because restricted FDs are not truly surplus, metrics.json also retains the higher denominator subtracting available cash only and including FY2025 ₹4.59 crore warrant-application money outside ordinary equity. Neither proxy is canonical invested capital. The visible difference is not forced to zero: tax, other assets/liabilities, restricted cash classifications and incomplete operating attribution matter. Incremental NOPAT uses normalized EBIT ×75%; Δcore capital and cash-capex-minus-depreciation/working-capital bridges are displayed. Neither a near-reconciled bridge nor positive quotient establishes new-project ROIC. CAP is NS because denominator completeness/reliability and profit attribution are insufficient. No favorable window is substituted to force a high score.

March bank borrowings are ₹120.9665 crore, comprising ₹15.1070 crore long-term, ₹96.0822 crore short-term and ₹9.7773 crore current maturities. Adding ₹0.1682 crore director claims gives ₹121.1347 crore; current maturities are counted once. Bank term debt totals ₹24.8843 crore. Source maturity buckets FY2027/FY2028/FY2029/FY2030+ are ₹9.7773/8.6992/5.2778/1.1299 crore, with ₹0.0001 crore rounding residual. Detailed lender-note sublines have an unresolved ₹0.2232 crore gap to aggregate term debt. This is disclosed, not repaired by imaginary lending.

Cash and bank balances total ₹10.4236 crore, of which ₹9.9069 crore are restricted security deposits; ₹0.5167 crore is cash/bank availability before the separately disclosed ₹0.0125 crore IPO escrow. The model conservatively excludes that escrow again because its overlap/location is not fully bridged, with the potential small double-restriction explicitly disclosed. The ₹0.9091 crore LC margin is within restricted deposits, not another cash deduction. CARE’s June ₹11.42 crore cash/liquid-investment statement and September “adequate liquidity” are important later evidence, but do not identify the unrestricted October balance. CARE’s ~98% working-capital utilization and projected ₹29 crore FY2027 accruals against ₹9.78 crore debt repayment are management/rating assessments, not bank confirmations. [AR26] [CARE2609]

IPO fresh shares were 975,484 at ₹58, or ₹5.6578072 crore; the 1,928,516-share OFS was seller cash, not company funding. Issue expenses and already deployed objects leave only the small disclosed escrow, not a second IPO windfall. Historical corporate cash is not reproduced as a future event. Indian GAAP lease treatment is preserved; no unsupported lease capitalization or omitted IFRS adjustment is fabricated. Employee claims and unpaid taxes remain in terminal claims or modeled settlements. [PROS] [IPO_USE] [AR26]

## 10. Valuation & Market Expectations

{{VALUATION}}

The price is verified; these multiples combine it with March audited claims and therefore are stale-balance historical diagnostics, not current enterprise value or fair value. Available cash only is netted. The normalized P/E includes an analyst tax assumption and no invented inventory adjustment. Price/book is weak protection when inventory approximates equity. Negative post-reinvestment cash yield is not transformed into a yield by omitting interest or growth finance. A peer multiple range is not used without comparable current share counts and price data.

The valuation laboratory is monthly and event based, starting with an explicitly synthetic 31 October carry-forward of March balances. The unknown April–October debt, cash and capex bridge prevents any path from being source-eligible as a current forecast. All hypothetical warrant approvals, subscriptions, new loans and extra equity remain assumptions. In contrast with a price-target spreadsheet, every sale must fit paid/commissioned capacity, growth needs working capital, cash pays interest/fees/tax/principal, equity is whole shares within authorized capacity, and a cash failure suppresses later ordinary returns.

Bear demand assumes −12%, 0%, 3%, 5%, 5% annual growth with a further temporary customer loss, slower commissioning, worse collections/inventory and 9–10.5% EBITDA margins. Base assumes 8%, 10%, 10%, 8%, 7% and 12–13% margins with modest working-capital improvement. Bull assumes 15%, 18%, 18%, 15%, 12% and 13–15% margins with stronger inventory/collection release. These are analyst scenarios, not promised guidance. Each is run without rescue, with proposed warrants only, with conditional ₹20 crore new project debt plus ₹10 crore extra revolving capacity, and with additional hypothetical equity bounded by 21 m authorized shares. Unknown sanctioned headroom is never represented as observed cash. New project debt is restricted to eligible project/growth capex, after subtracting warrant-funded costs; it cannot pay maintenance, old debt or operating gaps. Loan fees come from general cash, and interest applies to the full draw.

{{CANONICAL}}

The October warrants have six distinct objects; their ₹32.4 crore potential receipts are not treated as freely spendable money. The model allocates each hypothetical receipt proportionally among working capital ₹6.5 crore, land/development ₹4.5 crore, manufacturing facility ₹3 crore, tools/equipment ₹6.65 crore, strategic investment ₹3.75 crore and general corporate ₹8 crore. General cash pays issuance fees. Other buckets release only against modeled eligible current-month uses; unused strategic or unmatched capital proceeds remain restricted with no terminal cash addition. This proportional timing and project matching are assumptions, not an allocation schedule promised by management. CARE’s ₹30 crore programme is not proven identical to the warrant-object capex: the mapping is optimistic and the zero-overlap stress disallows every warrant-capex release. Initial 25% cash arrives only on hypothetical allotment, balance 75% only on optional exercise within 18 months. No conversion means no additional shares; late exercise is not permitted. The base exercise month is a scenario, not a known legal expiry date. [EGM2610 pp 19–24]

This is a retained-cash terminal-return model: all investor proceeds occur at the final sale, so 100% of the modeled investor cash receipt is terminal. It is not a conventional present DCF with interim FCFF distributed to shareholders; those cash flows are retained, reinvested, used for debt service or reflected in actual ending cash. No interim cash flow is both discounted to the investor and retained at exit. Terminal enterprise value is earned unlevered forward FCFF / (WACC − g), with a 14.5% WACC base and 3% growth. It funds replacement at the larger of modeled depreciation or 3% sales, incremental fixed capital at 2× sales/capital, working-capital growth and operating-cash growth. It deducts bank/director debt, unpaid taxes, employee claims, unpaid expansion commitments and any gap to required operating cash. Only cash above required operating cash is additive; restricted deposits, IPO escrow and unused earmarked warrant money are not. A physical-capacity check validates the next growth step. A separate 5×/6×/8× EBITDA exit comparison is disclosed but does not override the earned-cash terminal claim. No dividends are assumed, so no cash is counted both as a payout and exit cash.

{{HURDLES}}

These conditional entry values solve the same funded path’s terminal proceeds for 12%, 15% and 18% over actual elapsed holding time. They are not recommended buy ranges because no path has a verified current anchor. Failure or unearned terminal economics suppresses entry values. The financing issue price is an independent explicit ₹75.84 assumption, not secretly linked to the investor entry-price sensitivity; changing this financing assumption is a separate risk.

{{REVERSE}}

The following two-way cells show conditional exit price / IRR, or the actual funding-failure month. They never hide a failed cell behind a valuation.

{{GROWTH_GRID}}

{{DCF_GRID}}

Full grids retain 25 growth/margin combinations, nine WACC/g combinations, five investor entry prices, linked stresses and all 5/10-year funded target paths. Reverse expectations show the first tested growth step meeting each hurdle without interpolating through funding failure. No unsupported smooth DCF or arbitrary rerating converts failed cash into a target. R and P remain NS.

## 11. Bear Case & Permanent-Loss Path

The strongest bear case is not “small companies are risky.” A concentrated OEM order setback or unrecovered input-cost rise lowers margin while longer customer credit and unresolved WIP absorb cash. Restricted deposits cannot pay the bills; almost fully used bank lines constrain relief. Debt maturities and a live capital programme arrive before optional warrant exercise. New shares at a discount dilute the investor, and authorization or object restrictions can still leave a cash gap. If stock/receivables are impaired, book-value support shrinks exactly when lenders need repayment. The linked stress path, rather than an isolated lower exit multiple, captures this loss mechanism.

{{STRESS}}

{{RECOVERY}}

These accounting haircuts are analyst stresses, not liquidation estimates: moderate inventory/AR/fixed/restricted-cash haircuts are 10%/10%/20%/5%; severe 25%/25%/40%/10%. They reduce existing book equity without deducting its liabilities twice; no tax shield is assumed. Sale costs, claims priority and actual realizability remain unresolved, so the displayed residual is not guaranteed recovery. Unknown downside is not assigned a floor of zero percent.

The disconfirming case is real: regular debt service since April 2024, improved credit outlook, FY2026 positive CFO, stable inventory growth, established OEM relationships and potential automation benefits can rebuild cash and returns. The critical thesis-break variable is **verified post-interest operating cash after working-capital requirements, together with unrestricted funding through maturities**. Any material inventory impairment, renewed payment delay, withheld source confirmation, adverse audit qualification or unfinanced committed spending would strengthen a negative conclusion. Current evidence supports a research hold, not an allegation of impending default.

## 12. 5× / 10× Feasibility

{{TARGETS}}

{{TARGET_ARITHMETIC}}

The arithmetic table is an optimistic necessary-revenue diagnostic, not a forecast: required price =₹94.80×target; equity value =price×whole shares; at 15% EBITDA margin and a lower 6× exit EBITDA multiple, revenue =equity value/(0.15×6), assuming zero terminal net claims. Actual debt, fees, cash restrictions or a lower earned cash valuation require more revenue, while verified surplus cash could lower it. Current, fully converted and authorized-ceiling shares explicitly show dilution. Required sold tonnes assume 2% annual price growth from the unverified 24,000-tonne opening calibration. Extra capacity cost uses 400 annual tonnes per₹crore and 95% utilization; working capital retains the calibrated operating-capital/sales ratio. These are incremental capital needs before financing, not assumed free funds or a claim that source capex engineering is proven. Accessible market share is ND because no reliable addressable product-market denominator is available. A multiple/revenue identity cannot prove demand access or sustainable profits. The fully funded monthly grid above then tests physical capacity, financing, share limits and earned terminal returns and finds no 5× or 10× hit under its stated bounds.

A 5× price requires 37.97% annual appreciation over five years or 17.46% over ten; 10× requires 58.49% or 25.89%. The full search runs 5–60% sales growth in 2.5-percentage-point increments with 12.5%, 15% and 17.5% EBITDA margins over both horizons, retaining actual modeled capex, demand/capacity, working capital, debt service, fees, integer dilution, 21 m share authorization and earned terminal cash. A mathematical hit is still **speculative / unsupported** because the cash anchor, new finance and engineering cost assumptions are unverified. No hit means none within these explicit bounds, not impossibility across every conceivable future. Revenue or market-cap multiplication without funding and per-share dilution is rejected.

## 13. Monitoring Plan

This is a suggested research cadence, not an activated recurring task.

| KPI / evidence | Baseline | Milestone or warning threshold |
|---|---|---|
| WIP valuation and physical reconciliation | FY2026 stagewise method not implemented; inventory ₹107.40 cr | Obtain audited stagewise cost/yield reconciliation; any material unexplained write-down breaks reliability thesis |
| Receivables and confirmations | AR ₹52.69 cr; over-three-year ₹1.86 cr | Next results must show confirmed balances/collections; renewed ageing increase without allowance is adverse |
| Cash conversion after finance | FY24–26 CFO after finance negative ₹5.45 cr | Positive rolling-year post-interest operating cash without unusual creditor/tax support, not CFO headline alone |
| Current unrestricted funding | March ₹0.5167 cr before escrow; later cash composition ND | Bank-confirmed cash/undrawn sanctions and 12–18-month maturity funding; renewed servicing delay is a stop signal |
| October warrant legal/cash events | Proposed 4 m at ₹81; EGM31 Oct pending | Check actual resolution, exchange approval, allotment, object account, 25% receipt and optional exercise; no cash credit before receipt |
| Capex and operating capacity | ₹30 cr programme; FY26 output ND | Quarterly source/use and commissioned output/yield; cost overrun or unfinanced commitment requires model reset |
| Customer concentration / new LOI | ~74% major OEM concentration; no definitive new orders | New signed economic orders and collection terms; loss of major customer without funded replacement is thesis-breaking |
| Earnings per share | FY26 PAT ₹9.19 cr, EPS ₹7.09, issued 14.497 m | Growth in normalized earnings per diluted share, not merely PAT financed by issuance |
| Audit/control disclosures | PPE discrepancies; prior audit-trail and GST-interest questions | Explicit remediation and settlement chronology; silence is not cure |
| Tradability | 1,000-share lot, five unconfirmed archive absences | Current surveillance/spread/depth and official no-trade confirmation before any implementation |

## 14. Final Classification & Conditional Action

**Hold — unresolved; no numeric rank and no compounder designation.** G2 and critical unscored factors prevent the complete quality/attractiveness matrix from being meaningfully populated. The company is not forced into “high quality but expensive,” “value” or “avoid” from a partial weighted sum. Positive reported revenue growth and an approximately 15× earnings multiple do not override the reliability gate. Conversely, historical servicing problems and unmodified audit-note weaknesses are not escalated into a fabricated current-default or fraud conclusion.

The appropriate action category is further evidence-led research, not a portfolio purchase or exit instruction. Obtain reliable inventory/asset/confirmation evidence and a current source-eligible cash/debt/capex bridge; then rebuild share issuance, capacity and returns at the actual price. A lower price could improve return only after these constraints are understood. This company is researched separately as SME #362 and is not part of the frozen #341–359 release. No Git, public website or existing batch manifest is changed by this deliverable.

## 15. Sources, Assumptions & Open Questions

The ledger preserves exact URLs, source dates, original document hashes, page locators, all verified source extracts, management claims, calculations and assumptions. Original compressed PDFs and private extraction artifacts remain outside the source-safe deliverable; authored extracted inputs and reproduction code are included. The report’s physical PDF page references are one based; printed page labels may differ. Full original/restated bridges, audit counterevidence and peer caveats are appended, not replaced by a generic bibliography.

{{SOURCES}}

Critical unresolved questions are inventory cost verification; the historical CARO/default chronology; unpaid GST-interest treatment/settlement; complete FY2026 signed audit-trail reporting; current unrestricted bank cash and sanctioned headroom; April–October principal/capex movements; detailed loan subtotal reconciliation; latest physical output and project cost per capacity unit; full capital-return attribution; actual warrant approval/allotment/use; current promoter pledge and market restrictions; and independent no-trade confirmations. None is filled by an invented zero, assumed cure or sector median.

There are **{{COUNT}} full monthly paths**, of which **{{FAILCOUNT}} fail** under their stated conditional assumptions. All paths, including failures and grids, are retained in canonical_paths.json.gz. Every input, monthly event, share count, cash bucket, annual aggregation, formula and assumption is reproducible offline from authored inputs. No path is source-eligible as a current forecast. Canonical compressed trace SHA256: {{TRACE_HASH}}. Authored input aggregate SHA256: {{INPUT_FP}}. These bind distinct roles and are not substituted for report, archive or Library-version hashes.

### Sixteen quality checks

{{QUALITY}}

### Appendix A: Original audit, restatement and capital evidence

{{AUDIT_APPENDIX}}

### Appendix B: Primary economic peers

{{PEER_APPENDIX}}

### Appendix C: Business evidence and vintage-specific limits

{{BUSINESS_APPENDIX}}

### Appendix D: Reproduction and monthly model specification

{{MODEL_SPEC}}
