"""Package two complete source-safe variants without deleting any file.
Run only after current producer and independent prearchive verification PASS.
"""
from pathlib import Path
import json,hashlib,zipfile,ast
P=Path(__file__).resolve().parent
def sha(b):return hashlib.sha256(b).hexdigest()
def declared():
 tree=ast.parse((P/'build.py').read_text());result={}
 for n in tree.body:
  if isinstance(n,ast.Assign):
   for t in n.targets:
    if isinstance(t,ast.Name)and t.id in ('INPUTS','OUTPUTS'):result[t.id]=ast.literal_eval(n.value)
 return result

def main():
 d=declared();extra=['verification.json','guard_attestation.json','verification/monthly_replay.json','verification/deliverable_audit.json','verification/verify_inputs.py','verification/input_audit.json','package_recovery.py','prearchive_independent_acceptance.json'];names=sorted(set(d['INPUTS']+d['OUTPUTS']+extra));assert all((P/n).is_file()for n in names)
 for n in names:
  assert '..'not in Path(n).parts and not Path(n).is_absolute() and 'private_sources'not in Path(n).parts and not any(z.startswith('private_library')for z in Path(n).parts)
  assert Path(n).suffix.lower()in('.json','.py','.md','.html','.csv','.gz')
  assert not n.endswith('.gz')or n=='canonical_paths.json.gz'
 for n in ['verification.json','guard_attestation.json','prearchive_independent_acceptance.json']:assert json.loads((P/n).read_text())['status']=='PASS'
 record=json.loads((P/'company_record.json').read_text());guard=json.loads((P/'guard_attestation.json').read_text());assert guard['canonical_sha256']==record['canonical_sha256'];assert all(sha((P/n).read_bytes())==h for n,h in record['authored_input_sha256'].items());assert all(sha((P/n).read_bytes())==h for n,h in guard['outputs_sha256'].items())
 manifest={'company':'Sharp Chucks and Machines Limited','position':362,'information_cutoff':'2026-10-20','market_cutoff':'2026-10-19','complete_runtime_inputs':d['INPUTS'],'complete_runtime_outputs':d['OUTPUTS'],'included_attestations':['verification.json','guard_attestation.json','verification/monthly_replay.json','verification/deliverable_audit.json','prearchive_independent_acceptance.json'],'source_safe':True,'excluded':'Original PDFs, OCR, private helper/transfer code, credentials, caches and unrelated prior-company research. Independent source-verification script has disclosed external-original dependencies and is not cold runtime.','files':{n:{'bytes':(P/n).stat().st_size,'sha256':sha((P/n).read_bytes())}for n in names},'canonical_sha256':record['canonical_sha256'],'authored_input_aggregate_sha256':record['authored_input_aggregate_sha256'],'report_sha256':record['report_sha256'],'reader_sha256':record['reader_sha256'],'complete_variant_policy':'Both archives contain identical complete files. Only ZIP compression differs; compact omits nothing.'}
 payload=(json.dumps(manifest,indent=2,ensure_ascii=False)+'\n').encode();(P/'archive_manifest.json').write_bytes(payload);dest=P/'delivery';dest.mkdir(exist_ok=True);receipts=[]
 for variant,level in [('full',6),('compact',9)]:
  path=dest/f'Sharp_Chucks_and_Machines_362_v3_{variant}_20261020.zip';assert not path.exists(),'Archive already exists; use explicit versioned filename instead of silently replacing a delivered file.'
  with zipfile.ZipFile(path,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=level)as z:
   for n in names+['archive_manifest.json']:
    info=zipfile.ZipInfo(n,(2026,10,24,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o600<<16;data=payload if n=='archive_manifest.json'else(P/n).read_bytes();z.writestr(info,data,compress_type=zipfile.ZIP_DEFLATED,compresslevel=level)
  with zipfile.ZipFile(path)as z:
   assert z.testzip()is None and set(z.namelist())==set(names+['archive_manifest.json'])
   for n,meta in manifest['files'].items():assert sha(z.read(n))==meta['sha256']
  receipts.append({'variant':variant,'path':str(path.resolve()),'bytes':path.stat().st_size,'sha256':sha(path.read_bytes()),'members':len(names)+1,'complete':True})
 (P/'delivery'/'package_receipts.json').write_text(json.dumps(receipts,indent=2)+'\n');print(json.dumps(receipts,indent=2))
if __name__=='__main__':main()
