"""Canonical Master Prompt v3.0 weights and exact Decimal missingness rules."""
from decimal import Decimal as D, ROUND_HALF_UP
Z=D(0);ONE=D(1)
WEIGHTS={'BQS':{'GOV':'.20','MOAT':'.20','REV':'.12','DUR':'.10','CAP':'.12','CASH':'.10','BAL':'.08','EXEC':'.08'},'GQS':{'REV':'.40','DUR':'.20','EARN':'.15','CAP':'.15','CASH':'.10'},'IAS':{'BQS':'.25','R':'.35','D':'.20','P':'.10','L':'.10'}}
def calculate(j):
 f=j['factors'];out={'factors':f,'composites':{},'display_rule':'Conventional half-up, one decimal; classification uses unrounded totals','GQS_expansion':'Growth Quality Score'}
 governance=(f['GOV']['score']is not None and f['GOV']['score']<=3)or j['gates']['G1']['status']=='Fail — evidenced';funding=j['gates']['G3']['status']=='Fail — evidenced';poor_growth=j['persistent_growth_override']
 for name,weights in WEIGHTS.items():
  values={k:out['composites']['BQS']['final']if k=='BQS'else f[k]['score']for k in weights};con={k:None if values[k]is None else D(str(values[k]))*D(w)for k,w in weights.items()};coverage=sum((D(weights[k])for k,v in con.items()if v is not None),Z);known=sum((v for v in con.values()if v is not None),Z);raw=known if coverage==ONE else None;bound=[known+ONE-coverage,known+10*(ONE-coverage)];cap=D(3)if(governance and name in('BQS','IAS'))or(funding and name=='IAS')else D(5)if poor_growth and name=='GQS'else None;final=None if raw is None else min(raw,cap)if cap is not None else raw
  if name=='IAS'and any(j['gates'][g]['status'].startswith(('Hold','Fail'))for g in('G2','G4')):final=None
  out['composites'][name]={'weights':weights,'contributions':con,'coverage':coverage,'known_contribution':known,'raw':raw,'final':final,'display':'NS'if final is None else str(final.quantize(D('.1'),rounding=ROUND_HALF_UP)),'mathematical_bound':bound,'cap':cap,'capped_bound':[min(v,cap)for v in bound]if cap else bound,'ranking_eligible':final is not None and not j['gates']['G2']['status'].startswith(('Hold','Fail'))}
 b=out['composites']['BQS']['capped_bound'];ias=out['composites']['IAS'];known=ias['known_contribution'];othermiss=sum((D(w)for k,w in WEIGHTS['IAS'].items()if k!='BQS'and f[k]['score']is None),Z);ias['dependency_aware_bound']=[known+D('.25')*b[0]+othermiss,known+D('.25')*b[1]+10*othermiss]if out['composites']['BQS']['final']is None else ias['mathematical_bound']
 out['overrides']=j['overrides'];out['uncertain_factors']={'MOAT_plus_minus_one_BQS':'.20','CASH_plus_minus_one_BQS':'.10','CASH_plus_minus_one_GQS':'.10','joint_BQS':'.30','point_scores_remain_NS':True}
 return out
