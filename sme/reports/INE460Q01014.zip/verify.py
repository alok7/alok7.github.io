"""Recompute source-safe calculations, exact scores and monthly identity checks."""
from pathlib import Path
from decimal import Decimal as D
import json,gzip,re,hashlib,importlib.util
import build,metrics,scoring,model_audit
from html.parser import HTMLParser
from render import js,sha
P=Path(__file__).resolve().parent
sp=importlib.util.spec_from_file_location('independent_monthly_replay',P/'verification'/'replay_monthly.py');replay=importlib.util.module_from_spec(sp);sp.loader.exec_module(replay)
def read(n):return json.loads((P/n).read_text())
def verify():
 checks=0
 def ck(name,test):
  nonlocal checks
  assert test,name;checks+=1
 f=read('financial_inputs.json');m=read('market_inputs.json');j=read('judgments.json');i=read('model_inputs.json');s=read('scores.json');met=read('metrics.json');record=read('company_record.json');summary=read('model_summary.json')
 ck('metrics recomputation',json.loads(js(metrics.calculate(f,m)))==met);ck('score recomputation',json.loads(js(scoring.calculate(j)))==s)
 ck('13 canonical factors',list(j['factors'])==['GOV','MOAT','REV','DUR','CAP','CASH','BAL','EXEC','EARN','R','D','P','L'])
 for name,w in scoring.WEIGHTS.items():ck('weight sum '+name,sum(D(z)for z in w.values())==1)
 for v in j['factors'].values():ck('valid score',v['score']is None or isinstance(v['score'],int)and 1<=v['score']<=10)
 ck('BQS exact',s['composites']['BQS']['known_contribution']=='4.16'and s['composites']['BQS']['coverage']=='0.88');ck('GQS exact',s['composites']['GQS']['known_contribution']=='4.85'and s['composites']['GQS']['coverage']=='0.85');ck('all NS',all(v['final']is None for v in s['composites'].values()));ck('dependency bound',[D(z)for z in s['composites']['IAS']['dependency_aware_bound']]==[D('2.22'),D('7.44')]);ck('GQS cap no missing cure',s['composites']['GQS']['cap']=='5'and s['composites']['GQS']['final']is None)
 ck('cash parts',D('1042.36')-D('990.69')==D(next(x for x in f['years']if x['year']==2026)['cash_available']));ck('capital advance reclass identity',D(met['three_year_cash']['after_interest_and_total_reinvestment_reclassified'])==D(met['three_year_cash']['cash_after_capex_and_finance']))
 ck('no false missing-row zero',sum(r['row']is None for r in m['sessions'])==5 and len(m['sessions'])==60)
 ck('market price and cap',D(m['last_row']['ClsPric'])==D('94.8')and D(met['valuation']['market_cap'])==D('137.42958816'));ck('full input fingerprint',record['authored_input_sha256']=={n:sha((P/n).read_bytes())for n in build.INPUTS});ck('report hash',record['report_sha256']==sha((P/'report.md').read_bytes()));ck('reader hash',record['reader_sha256']==sha((P/'report.html').read_bytes()))
 blob=(P/'canonical_paths.json.gz').read_bytes();paths=json.loads(gzip.decompress(blob));ck('trace hash',sha(blob)==record['canonical_sha256']);ck('path count',len(paths)==summary['path_count']);ck('no source eligible',summary['source_eligible_count']==0 and not any(p['source_eligible']for p in paths.values()));ledger=model_audit.audit(paths,i)
 report=(P/'report.md').read_text();ck('15 substantive main sections',len(re.findall(r'^## (?:[1-9]|1[0-5])\. ',report,re.M))==15);ck('no template holes','{{'not in report);ck('16 quality checks',len(build.QC)==16);ck('all factors evidenced',all(set(v['evidence_ids'])<=set(read('evidence_ledger.json')['evidence_ids'])for v in j['factors'].values()));ck('not ranked',record['ranking_eligible']is False)
 # Independent replay does not import producer model, metrics, scoring or scenarios.
 replay.count=0;replay.main();replayed=read('verification/monthly_replay.json');ck('independent replay',replayed['status']=='PASS'and replayed['trace_sha256']==sha(blob))
 exec(compile((P/'verification/verify_deliverables.py').read_text(),str(P/'verification/verify_deliverables.py'),'exec'),{'__file__':str(P/'verification/verify_deliverables.py'),'__name__':'independent_deliverable_audit'})
 deliverable=read('verification/deliverable_audit.json');ck('independent deliverable audit',deliverable['status']=='PASS')
 result={'independent_deliverable_audit':deliverable,'status':'PASS','checks':checks,'monthly_identity_audit':ledger,'independent_monthly_replay':replayed,'canonical_sha256':sha(blob),'generated_sha256':{n:sha((P/n).read_bytes())for n in build.OUTPUTS},'authored_input_aggregate_sha256':record['authored_input_aggregate_sha256'],'source_scope':'Offline authored inputs; original-source audit is separately documented, not needed for runtime.','limits_not_cured':True}
 (P/'verification.json').write_text(js(result,True)+'\n');return result
if __name__=='__main__':
 q=verify();print(js({'status':q['status'],'checks':q['checks'],'paths':q['monthly_identity_audit']['paths'],'canonical_sha256':q['canonical_sha256']}))
