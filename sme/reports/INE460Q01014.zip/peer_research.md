# Sharp Chucks and Machines: economic peer comparison

Information cutoff: 20 October 2026. Share-price reference: 19 October 2026. Financial comparison: common audited FY26, not TTM. All amounts below are ₹ crore unless indicated. This is an independently authored extraction of original reports, not a reuse of previous peer conclusions.

## Bottom line

These peers do not support awarding Sharp a generic “precision engineering” multiple. They illustrate three different ways manufacturing profits can fail to become shareholder cash: Pritika's group-funded expansion, Nelcast's heavy installed capital and export/cycle sensitivity, and Talbros' specialized forging growth that still consumes more cash capex than reported CFO. The useful benchmark is sustainable return on all financial capital and cash remaining after investment and interest, not headline EBITDA margin or one year's CFO/PAT.

## Comparable FY26 measures

Operating EBITDA excludes all other income and exceptional gains for a consistent baseline. This strips out FX gains too, although some are operationally related; it is a measurement convention, not a claim all other income is non-recurring. Pretax operating return below is operating EBIT divided by average equity plus interest-bearing debt less cash. It is a common book-capital proxy, not company-reported ROCE or economic ROIC. Group equity includes NCI where present. Cash capex is gross asset-purchase cash outflow without deducting disposals.

| Metric | Pritika Engineering | Nelcast | Talbros Engineering |
|---|---:|---:|---:|
| Financial perimeter | Consolidated | Consolidated | Standalone FY26 |
| Revenue | 161.87 | 1,328.40 | 535.76 |
| Revenue growth | 37.90% | 6.13% | 20.10% |
| Operating EBITDA | 21.51 | 110.50 | 60.43 |
| Operating EBITDA margin | 13.29% | 8.32% | 11.28% |
| Same-basis FY25 margin | 15.56% | 7.07% | 11.16% |
| PAT | 7.31 | 48.43 | 29.16 |
| Reported CFO | 22.97 | 91.58 | 44.56 |
| Reported CFO/PAT | 3.14x | 1.89x | 1.53x |
| Gross cash capex | 42.49 | 17.74 | 52.64 |
| Cash capex/revenue | 26.25% | 1.34% | 9.82% |
| Reported CFO less gross capex | -19.52 | 73.84 | -8.08 |
| CFO less interest and gross capex | -25.67 | 41.31 | -8.08, as reported* |
| Debt/equity, all BS borrowings | 1.85x | 0.43x | 0.81x |
| Operating EBIT/finance cost | 2.37x | 2.57x | 3.87x |
| Revenue/average total assets | 0.85x | 1.12x | 1.49x |
| Pretax operating return, common formula | 10.90% | 10.82% | 15.67% |
| Verified 19 October close, ₹ | 80.00 | 133.79 | ND |

*Talbros' CFO already deducts interest; its statement has no separately labelled cash-tax payment. The result is not presented as normalized after-tax free cash flow. Pritika and Nelcast classify interest in financing, so comparing their unadjusted CFO-minus-capex directly with Talbros would overstate their relative cash generation. Pritika's reported CFO is additionally dependent on related-party customer advances.

Sources: Pritika annual report printed pp176–178; Nelcast pp146–149; Talbros pp84–86. Exact inputs, source hashes and formulas are in `peer_inputs.json`; `build_peer_inputs.py` regenerates the derived measures.

## Pritika Engineering: closest tractor casting exposure, but financing through the parent matters

Pritika manufactures machined/cast tractor and commercial-vehicle components, with Meeta Castings consolidated. Its listed parent, Pritika Auto Industries, remains outside this consolidation. Sales to the parent were ₹143.03 crore, 88.36% of consolidated FY26 revenue. The parent's distribution relationship, guarantees and funding are meaningful support, not an independent-customer moat to apply to Sharp.

Growth of 37.90% came with operating EBITDA margin compression from 15.56% to 13.29%. Gross cash capex of ₹42.49 crore, 26.25% of revenue, exceeded reported CFO by ₹19.52 crore even before ₹6.15 crore interest. Debt increased from ₹71.15 crore to ₹98.16 crore. Installed capital is still ramping: PPE, CWIP and development balances together were ₹137.49 crore at year end. Asset turnover of 0.85x and pretax book-capital return of 10.90% qualify the apparently high EBITDA margin.

Cash quality is the crucial distinction. FY26 CFO includes ₹27.39 crore of inflow from other non-current liabilities. Note19 identifies the dominant balance as related-party advances against supplies, which increased from ₹21.77 crore to ₹49.37 crore. Simply removing the cash-flow statement's other-non-current-liability inflow produces a diagnostic -₹4.42 crore CFO. This is not a restatement or proof that customer advances are illegitimate financing: it isolates dependence on continued group support. The advances' balance-sheet movement is not exactly the cash-flow line, so they must not be treated as interchangeable.

CARE's 28 November 2025 rationale confirms low OEM bargaining power, quarter-lag raw-material pass-through and significant parent links. Its reported FY25 standalone gearing is not substituted for the FY26 consolidated ratio here. No current P/E is published: the 17 October securities allotment and warrant dilution need a separate current-share bridge.

Primary sources: [FY26 report](https://archives.nseindia.com/annual_reports/SME_AR_30579_PRITIKA_2025_2026_A_2593334_25082026110408.pdf), [CARE rationale](https://www.careratings.com/upload/CompanyFiles/PR/202511141136_Pritika_Engineering_Components_Limited.pdf).

## Nelcast: scale, diversification and cash release, not automatically superior returns

Nelcast is a larger ductile/grey iron foundry with three facilities and 160,000 MTPA capacity. More than50 customers and an export/domestic mix diversify it beyond a single captive parent relationship. ICRA's March 2026 report gives 9M FY26 shares of 39.6% domestic M&HCV, 25.7% tractors and 29.4% exports; its largest customer contributed 17%. Those are period-specific rating data, not invented FY26 full-year segment figures.

FY26 revenue grew 6.13%, operating EBITDA margin rose to 8.32%, and reported CFO was ₹91.58 crore against gross asset cash purchases of ₹17.74 crore. The positive cash spread remains ₹41.31 crore after interest. Total borrowings declined from ₹294.45 crore to ₹257.19 crore, while balance-sheet cash rose to ₹84.77 crore. Yet the common pretax operating return is only 10.82%, despite the capital base being far more mature than Pritika's. Good current-year cash release and credit quality do not establish a high-return compounder.

Two safeguards matter. First, the investing statement separately shows ₹1.68 crore positive CWIP movement in FY26 and₹54.50 crore in FY25. Gross cash-purchase lines are preserved without netting those movements; FY25's apparent ₹93.21 crore gross purchases must not be interpreted as wholly new economic investment without reconciling transfers out of CWIP. Second, the cash-flow statement nets cash-credit balances into its closing cash; our net-debt calculation instead uses positive BS cash with cash credit retained in debt, avoiding double counting.

Most importantly, ICRA's March expectation of no major debt-funded capex was overtaken before the cutoff. On 5 October 2026, the board approved approximately ₹75 crore for a Gudur machining division, funded by internal accruals and borrowings. That is a new investment phase, about 4.2x FY26 gross cash asset purchases. Do not mechanically extrapolate the unusually low FY26 capex burden or cite the old rating assumption as current. US/export exposure, raw-material pass-through and CV cycles remain relevant.

Primary sources: [FY26 report](https://nsearchives.nseindia.com/annual_reports/AR_29497_NELCAST_2025_2026_A_3754478_30062026181223.pdf), [ICRA5March 2026 rationale](https://www.icra.in/Rating/ShowRationalReportFilePdfViewer/141407), [5 October 2026 expansion approval](https://nsearchives.nseindia.com/corporate/NELCAST1_05102026175723_BMGENERALUPDATE.pdf).

## Talbros Engineering: specialized forged axles, better asset productivity, material growth investment

This is BSE 538987, not Talbros Automotive Components/TALBROAUTO. It makes forged axle shafts rather than Sharp's mix of castings, forgings and machine-tool chucks. FY26 was standalone; Talbros Nextgen was incorporated on 12 May 2026, after the fiscal year. Company claims of about 90% domestic SUV axle-shaft share describe a narrow product market and are not independently validated here.

Revenue grew 20.10% to ₹535.76 crore with an 11.28% operating EBITDA margin. Exports increased from ₹76.98 crore to ₹145.69 crore, reaching 28.15% of product sales. That explains part of the growth but brings foreign-customer/FX exposure. The common pretax operating return of 15.67% and 1.49x asset turnover are better than the casting peers, consistent with different process economics. This is not evidence that Sharp can earn the same returns without its own capital-efficiency improvement.

Reported CFO of ₹44.56 crore was after ₹12.46 crore interest, but cash asset purchases of ₹52.64 crore still left a ₹8.08 crore deficit. FY26 capex nearly doubled from ₹26.91 crore. The planned eighth 10-acre unit in Madhya Pradesh adds execution and funding requirements. The AR ratio table's debt/equity 0.41 and ROCE 28.39% are not comparable with our formulas: debt/equity using all reported borrowings is 0.81x, while 28.39% arithmetically resembles PBT-plus-interest divided by closing equity, rather than the full average-capital denominator used here. No allegation is inferred; the figures simply cannot be transplanted.

The cash-flow statement begins at PBT and has no separately labelled cash-tax line. Preserve its reported CFO and make this limitation explicit rather than silently substituting the tax provision. BSE 19 October close could not be verified, so price and multiples are ND. A current quote from another date is not a substitute.

Primary source: [FY26 report](https://talbrosaxles.com/storage/document/annual-report-2025-26-020926060928.pdf).

## Use in Sharp's valuation

- Separate recurring operating profitability from other income and normalized capital needs. These peers span 8.32–13.29% same-basis FY26 EBITDA margins, but only 10.82–15.67% pretax book-capital returns.
- A high CFO/PAT ratio can coexist with dependence on parent advances or with capex deficits. Test cash after interest and realistic investment over several years, not one ratio.
- Nelcast's FY26 cash advantage is real on the reported basis but the October ₹75 crore project prevents treating low capex as permanent. Talbros' product specialization is not equivalent to Sharp's casting/forging/chuck mix. Pritika's captive-parent economics are not a clean independent-customer comparable.
- No “peer median P/E” is asserted. Verified prices are included for date integrity, not to bypass dilution, capital structure, product mix, liquidity or source-quality differences.
