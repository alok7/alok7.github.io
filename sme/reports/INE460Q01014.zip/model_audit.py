"""Independent ledger identities and mutation rejection; no model import."""
from decimal import Decimal as D
import copy
Z=D(0);EPS=D('1e-12')
def n(x):return D(str(x))
def close(a,b):assert abs(n(a)-n(b))<=EPS*max(D(1),abs(n(a))),(a,b)
def row_check(r,previous_shares,authorized):
 identity=n(r['opening_cash'])+n(r['equity_cash_gross'])-n(r['equity_fee'])-n(r['warrant_restricted_receipt'])+n(r['warrant_eligible_release'])+n(r['new_debt'])-n(r['new_debt_fee'])-n(r['project_restricted_receipt'])+n(r['project_capex_release'])+n(r['cfo_before_finance'])-n(r['total_capex'])-n(r['interest'])-n(r['bank_fee'])-n(r['term_principal'])-n(r['lc_paid'])+n(r['cc_draw'])-n(r['cc_repayment'])
 close(identity,r['cash']);close(n(r['ebitda'])-n(r['delta_onwc'])-n(r['cash_tax'])-n(r['prior_tax_settlement']),r['cfo_before_finance']);close(n(r['d_receivables'])+n(r['d_inventory'])-n(r['d_payables'])+n(r['d_other_wc']),r['delta_onwc']);assert isinstance(r['shares'],int)and r['shares']==previous_shares+r['issued_shares_month'];assert r['shares']+r['warrants_outstanding']<=authorized;close(sum((n(z)for z in r['warrant_buckets'].values()),Z),r['warrant_restricted_balance']);assert n(r['project_restricted_balance'])>=0
 assert n(r['sold_tonnes'])<=n(r['casting_capacity'])*D('.95')/12+EPS
 return 8

def terminal_check(p,inp):
 t=p['terminal'];r=p['monthly'][-1];a=inp['assumptions'];o=inp['opening'];cash=n(r['cash']);rev=n(t['revenue']);cashreq=rev*n(a['terminal_operating_cash_ratio']);close(max(Z,cashreq-cash),t['operating_cash_topup']);close(max(Z,cash-cashreq),t['surplus_cash_added']);close(n(t['EBIT'])-max(Z,n(t['EBIT']))*n(a['tax_rate']),t['NOPAT']);claims=n(r['cc'])+n(r['term_debt'])+n(o['director_claim'])+n(r['unpaid_tax'])+n(o['unfunded_employee_claim'])+n(t['operating_cash_topup'])+n(t['unpaid_committed_capex']);close(claims,t['senior_claims']);close(max(Z,n(t['DCF_terminal_EV'])+n(t['surplus_cash_added'])-claims),t['equity']);close(n(t['equity'])*10000000/r['shares'],t['price']);assert n(t['restricted_cash_added'])==0
 if p['ordinary_return_suppressed']:assert t['IRR']is None and t['price_multiple']is None and not t['entry_prices_at_hurdles']
 return 7

def audit(paths,inp):
 checks=0;first=None;survivor=None;failure=None
 for p in paths.values():
  assert not p['source_eligible'];checks+=1;prev=inp['opening']['issued_shares'];failed=False
  for r in p['monthly']:
   if r['status']=='SUPPRESSED_AFTER_FAILURE':assert failed and p['ordinary_return_suppressed'];checks+=1;continue
   checks+=row_check(r,prev,inp['opening']['authorized_shares']);prev=r['shares']
   if first is None:first=(copy.deepcopy(r),inp['opening']['issued_shares'])
   if r['status']=='FAILED':failed=True
  if p['failed']:assert p['terminal']is None and p['ordinary_return_suppressed'];failure=p;checks+=1
  elif p['terminal']:
   checks+=terminal_check(p,inp);survivor=p
 mutations=[]
 def reject(name,fn):
  try:fn()
  except AssertionError:mutations.append({'test':name,'status':'REJECTED'})
  else:raise AssertionError('Mutation accepted: '+name)
 r,pr=first;x=copy.deepcopy(r);x['cash']=str(n(x['cash'])+1);reject('cash event changed by1crore',lambda:row_check(x,pr,inp['opening']['authorized_shares']))
 x=copy.deepcopy(r);x['shares']+=1;reject('whole share changed by1',lambda:row_check(x,pr,inp['opening']['authorized_shares']))
 x=copy.deepcopy(r);x['warrant_restricted_balance']=str(n(x['warrant_restricted_balance'])+1);reject('restricted bucket changed by1',lambda:row_check(x,pr,inp['opening']['authorized_shares']))
 if survivor:
  x=copy.deepcopy(survivor);x['terminal']['senior_claims']=str(n(x['terminal']['senior_claims'])-1);reject('terminal claim omitted',lambda:terminal_check(x,inp))
 if failure:
  def badfailure():
   x=copy.deepcopy(failure);x['ordinary_return_suppressed']=False;assert not x['failed']or x['ordinary_return_suppressed']
  reject('failed path ordinary return unsuppressed',badfailure)
 return {'status':'PASS','checks':checks,'paths':len(paths),'mutations':mutations}
