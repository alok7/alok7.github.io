# Sharp Chucks and Machines: business economics and evidence quality

Information cutoff: 20 October 2026. This note uses retained original filings and rating rationales. “Verified disclosure” means the statement is present in the identified primary document, not that customer contracts, factory output or management representations have been independently audited by this research. Page references below are 1-based physical PDF pages, not printed labels. Raw financial amounts are ₹ lakh unless stated otherwise.

## 1. What the company actually sells

**Verified disclosure.** Sharp manufactures customized castings, forging products and machine-tool accessories in two Jalandhar units. Casting products include tractor housings, hubs, carriers and related components; forging includes gears, clutches and striking/DIY tools; machine-tool products include power, lathe and drill chucks. Its process spans foundry work, forging, machining and inspection. The September 2023 prospectus described customer-specific sample/mould development and quality approval. [Prospectus, PDF 132–134, 143, 145, 148–150](https://archives.nseindia.com/emerge/corporates/content/SharpChucks_PROSP.pdf).

The last verified product-revenue split is FY 23: castings ₹151.87 cr/86.07%, forging ₹20.18 cr/11.43%, machine tools ₹4.40 cr/2.49%. That mix is historical, not FY 26. The FY 26 accounts combine customized casting, machine tools and forging into one business segment and provide no product margins. [Prospectus, PDF 134](https://archives.nseindia.com/emerge/corporates/content/SharpChucks_PROSP.pdf); [FY 26 report, PDF 34 and 69](https://sharpchucks.com/wp-content/uploads/2026/09/annual-report-2025-26.pdf).

**Inference.** The useful economic description is an integrated, predominantly tractor/automotive-exposed component supplier, not a proven proprietary-technology franchise. Application lists mention railways, defence, machine tools and DIY, but do not quantify current end-market diversification. CARE itself uses “solely automotive” in its cycle discussion while listing other applications in its company profile. We therefore do not assert either pure-auto revenue or substantial non-auto revenue. [September 2026 CARE, PDF 2–3](https://www.careratings.com/upload/CompanyFiles/PR/202609140922_Sharp_Chucks_and_Machines_Limited.pdf).

## 2. Revenue quality, costs and cash conversion

**Verified disclosure.** FY 26 net operating revenue was ₹273.77 cr, up 11.50%, with ₹9.19 cr PAT. Domestic revenue was ₹269.35 cr and exports ₹4.42 cr, only 1.61% of net revenue; exports declined 5.26% from FY 25. All assets are in India. Goods revenue is generally recognized at dispatch after transfer of significant risks and rewards; exports use the on-board bill-of-lading date. An LOI or order announcement is not recognized revenue. [FY 26 report, PDF 53, 63, 70 and 72](https://sharpchucks.com/wp-content/uploads/2026/09/annual-report-2025-26.pdf).

The P&L explicitly bridges FY26 gross operating revenue of ₹316.2132 cr, less GST of ₹42.4458 cr, to net operating revenue of ₹273.7675 cr, with a ₹0.01 lakh rounding difference. FY25 gross ₹292.5687 cr less GST ₹47.0374 cr equals net ₹245.5313 cr. Note 22 reports gross sales; the geographical disclosure reports net revenue. Operating ratios therefore use revenue excluding GST, not the gross figure. [FY 26 report, PDF 53, 61, 70 and 72](https://sharpchucks.com/wp-content/uploads/2026/09/annual-report-2025-26.pdf).

FY 26 costs included raw materials ₹151.16 cr, stores/spares/tools ₹29.35 cr, power/fuel ₹25.68 cr, employees ₹18.88 cr and job work ₹4.53 cr. Calculated against net revenue, these are 55.22%,10.72%,9.38%,6.90% and 1.65%, respectively. All raw-material consumption is disclosed as indigenous. CARE reports OEM material-price pass-through with a one-quarter lag. [FY 26 report, PDF 61–62 and 72](https://sharpchucks.com/wp-content/uploads/2026/09/annual-report-2025-26.pdf); [September 2026 CARE, PDF 2](https://www.careratings.com/upload/CompanyFiles/PR/202609140922_Sharp_Chucks_and_Machines_Limited.pdf).

**Inference.** Material timing, energy, yield, tooling and labour efficiency matter more than the word “precision.” Scrap reuse helps recovery economics but does not eliminate external commodity exposure. Neither unit contribution margins nor a volume/price/mix bridge is available. Historical top 10 suppliers represented 69.61% of purchases in FY 23; that is not a current supplier-concentration statistic. [Prospectus, PDF 27 and 149](https://archives.nseindia.com/emerge/corporates/content/SharpChucks_PROSP.pdf).

Working capital remains intrinsic to the model. CARE reports FY 26 operating cycle about 157 days versus 145 days in FY 25, receivable days about 50 versus 42, inventory held about 4–5 months, and working-capital utilization near 98% over the 12 months to July 2026. These agency ratios must not be mixed with differently calculated model ratios. [September 2026 CARE, PDF 2–3](https://www.careratings.com/upload/CompanyFiles/PR/202609140922_Sharp_Chucks_and_Machines_Limited.pdf).

Inventory was ₹107.40 cr, including ₹48.81 cr WIP, or 45.44% of stock. The accounts disclose no stage-wise WIP tracking methodology and reliance on an independent cost accountant's valuation. The prospectus says finished-goods quantities incorporate both confirmed and expected orders. **Inference:** reputable customers do not make anticipated inventory immediately saleable or collectible; stage, quantity, valuation and order linkage need reconciliation. This is a control concern, not a fraud conclusion. [FY 26 report, PDF 59 and 74](https://sharpchucks.com/wp-content/uploads/2026/09/annual-report-2025-26.pdf); [Prospectus, PDF 149](https://archives.nseindia.com/emerge/corporates/content/SharpChucks_PROSP.pdf).

## 3. Customers, repeat business and contracts

**Verified disclosures with distinct vintages.** FY 23's top 5 customers contributed 73.78% of sales, versus 65.58% in FY 22 and 68.55% in FY 21. Separately, January and September 2026 CARE name Mahindra & Mahindra, International Tractors, Swaraj Engines and Escorts among OEM relationships representing approximately 74% of sales. The older top 5 set and the newer major-OEM set are not identical measures. Current largest-customer share is unavailable. [Prospectus, PDF 27, 143 and 222](https://archives.nseindia.com/emerge/corporates/content/SharpChucks_PROSP.pdf); [September 2026 CARE, PDF 2](https://www.careratings.com/upload/CompanyFiles/PR/202609140922_Sharp_Chucks_and_Machines_Limited.pdf).

At IPO, sales were purchase-order based with no long-term supply agreement or minimum-purchase obligation. The risk factors note a bank-guarantee-backed exception involving Ammunition Factory, Khadki, a Munitions India unit. Updated 2026 contract terms, enforceable backlog and cancellation protections were not verified. The historical defence-related exception is not a current defence order-book claim. [Prospectus, PDF 27 and 149](https://archives.nseindia.com/emerge/corporates/content/SharpChucks_PROSP.pdf).

**Inference.** Engineering approval, delivery reliability and repeated OEM relationships create retention advantages. They do not make revenue subscription-like or provide strong supplier bargaining power. Strong customer credit can coexist with extended payment terms and purchase-volume cuts.

## 4. Capacity: keep physical vintages separate

The original prospectus table reports the following. Utilization is the source's rounded percentage, not a time-weighted practical-capacity calculation. [Prospectus, PDF 133, 144 and 148–149](https://archives.nseindia.com/emerge/corporates/content/SharpChucks_PROSP.pdf).

| Process | FY 21 capacity / output, tonnes | FY 22 capacity / output | FY 23 capacity / output | FY 23 reported utilization |
|---|---:|---:|---:|---:|
| Casting | 18,000 / 15,051 | 18,000 / 15,823 | 30,000 / 19,606 | 65% |
| Machining | 7,200 / 6,600 | 9,600 / 7,800 | 14,400 / 7,690 | 53% |
| Forging | 1,800 / 1,200 | 1,800 / 1,500 | 3,600 / 1,730 | 48% |

September 2026 CARE repeats nominal capacities of 30,000/14,400/3,600 MTPA. It does not provide updated FY 26 output/utilization. [September 2026 CARE, PDF 3](https://www.careratings.com/upload/CompanyFiles/PR/202609140922_Sharp_Chucks_and_Machines_Limited.pdf).

**Inference and limits.** Do not sum casting and machining capacities as unique saleable tonnes because they can be successive processes. Do not project FY 23's utilization into FY 26. Capacity installed during a year also makes annual output divided by year-end capacity an imperfect measure. Current bottlenecks, yields, machine-hours, saleable tonnage and commissioned incremental throughput remain ND.

## 5. Growth already earned versus growth still promised

The audited 11.50% FY 26 revenue increase is realized. January 2026 CARE linked growth to tractor demand, increased OEM content and new crankcase/cylinder-head products; September CARE mentioned new forging components. Those explanations are plausible evidence of product wins, but not an audited product-growth bridge. [FY 26 report, PDF 53](https://sharpchucks.com/wp-content/uploads/2026/09/annual-report-2025-26.pdf); [January 2026 CARE, PDF 2](https://www.careratings.com/upload/CompanyFiles/PR/202601150152_Sharp_Chucks_and_Machines_Limited.pdf); [September 2026 CARE, PDF 2](https://www.careratings.com/upload/CompanyFiles/PR/202609140922_Sharp_Chucks_and_Machines_Limited.pdf).

Three prospective claims need separation:

1. **In-house processing and automation.** CARE expects margin improvement from reduced outsourcing and lower rejection. But FY 26 job-work expense rose 85.52%, from₹2.44 cr to₹4.53 cr. Volume/mix or timing may explain it; it neither proves failure nor proves savings. The savings case requires unit-cost, yield and commissioning evidence. [January 2026 CARE, PDF 1–2](https://www.careratings.com/upload/CompanyFiles/PR/202601150152_Sharp_Chucks_and_Machines_Limited.pdf); [September 2026 CARE, PDF 2–3](https://www.careratings.com/upload/CompanyFiles/PR/202609140922_Sharp_Chucks_and_Machines_Limited.pdf); [FY 26 report, PDF 61](https://sharpchucks.com/wp-content/uploads/2026/09/annual-report-2025-26.pdf).
2. **New segment LOI.** On 7 September, CARE explicitly said conversion of the LOI into definitive purchase orders remained a key monitorable. No counterparty, segment definition, contracted value, delivery timetable, minimum volumes or project margin is verified. Treat it as uncontracted upside, not base-case backlog. [September 2026 CARE, PDF 1–2](https://www.careratings.com/upload/CompanyFiles/PR/202609140922_Sharp_Chucks_and_Machines_Limited.pdf).
3. **Investment and funding.** January CARE expected roughly₹3 cr recurring capex and no medium-term debt-funded project; September described an ongoing approximately₹30 cr programme with nearer-term debt/flexibility pressure. The later evidence supersedes the earlier low-capex premise. The October proposal to raise up to₹32.4 cr through warrants is conditional and has an EGM after the cutoff. Its land, machinery, working-capital, strategic-investment and general-purpose uses are not proof the LOI is funded or executable. Do not double-count that raise with the separately described project or include the April proposal cancelled on 4 June. [January 2026 CARE, PDF 2–3](https://www.careratings.com/upload/CompanyFiles/PR/202601150152_Sharp_Chucks_and_Machines_Limited.pdf); [September 2026 CARE, PDF 3](https://www.careratings.com/upload/CompanyFiles/PR/202609140922_Sharp_Chucks_and_Machines_Limited.pdf); [October notice, PDF 18–21 and 24](https://sharpchucks.com/wp-content/uploads/2026/10/Notice-of-EGM-31-10-2026.pdf); [June cancellation, PDF 1–2](https://nsearchives.nseindia.com/corporate/SHARPCHUCKS_04062026181638_Intimation_30_04062026.pdf).

CARE's Q 1 FY 27 figures, marked unaudited, are₹60.73 cr TOI, ₹10.98 cr PBILDT and₹4.52 cr PAT. These are preliminary upside evidence, not an annual earnings run rate or an exchange-result reconciliation. [September 2026 CARE, PDF 3](https://www.careratings.com/upload/CompanyFiles/PR/202609140922_Sharp_Chucks_and_Machines_Limited.pdf).

## 6. Ownership, remuneration and related parties

The October notice's 2 October baseline reports 9,230,542 promoter-group shares,63.67% of 14,496,792 outstanding shares. The separate 1 October allottee table lists Ajay Sikka at 43.52% and Gopika Sikka at 12.31%. The individual holdings are not the aggregate promoter group. Full proposed warrant conversion would reduce the group percentage to 60.72%, still control; that is not the current cap table. Reasons for holding changes from March, and current pledges/encumbrances, were not independently established. [October notice, PDF 22 and 24](https://sharpchucks.com/wp-content/uploads/2026/10/Notice-of-EGM-31-10-2026.pdf).

Ajay is MD and Gopika director/CFO; the prospectus identifies them as spouses. FY 26 remuneration was₹48 lakh and₹24 lakh respectively, unchanged fromFY 25. Their combined₹72 lakh equals 0.263% of net revenue and 7.83% of PAT, but these ratios alone do not establish pay fairness. The report lists 486 permanent employees and leaves meaningful employee-median pay comparison unavailable. [Prospectus, PDF 167](https://archives.nseindia.com/emerge/corporates/content/SharpChucks_PROSP.pdf); [FY 26 report, PDF 22, 37–38 and 70](https://sharpchucks.com/wp-content/uploads/2026/09/annual-report-2025-26.pdf).

FY 26 newly discloses₹11.97 cr sales to Sharp Precision Private Limited,4.37% of net revenue, and₹6.99 cr purchases from it. Director/promoter loan balance was only₹16.82 lakh, interest-free. Pricing, product flows, settlements and trade balances deserve verification; no circular trading or diversion is inferred. [FY 26 report, PDF 57 and 70–71](https://sharpchucks.com/wp-content/uploads/2026/09/annual-report-2025-26.pdf).

## 7. Seasonality, cycle and competitive position

The 2023 prospectus says the business is not seasonal. That does not contradict cyclical dependence on automotive/tractor demand and OEM schedules, nor prove even quarterly sales. No verified multi-year quarterly production series supports annualizing a strong quarter or estimating a stable seasonal factor. [Prospectus, PDF 221](https://archives.nseindia.com/emerge/corporates/content/SharpChucks_PROSP.pdf); [September 2026 CARE, PDF 2](https://www.careratings.com/upload/CompanyFiles/PR/202609140922_Sharp_Chucks_and_Machines_Limited.pdf).

Competition is fragmented across organized and unorganized suppliers; the issuer identifies quality, range and price as key parameters. Integrated processes, approved parts and longstanding relationships support retention, but current market share, pricing premium and independently measured technical superiority are unavailable. Quality certifications are cited by September CARE; underlying current renewals were not independently checked. The 2023 prospectus recorded abandoned trademark applications and no other registered IP at that date. That is historical, not a finding about the current IP register. [Prospectus, PDF 150, 152 and 239](https://archives.nseindia.com/emerge/corporates/content/SharpChucks_PROSP.pdf); [September 2026 CARE, PDF 3](https://www.careratings.com/upload/CompanyFiles/PR/202609140922_Sharp_Chucks_and_Machines_Limited.pdf).

Both units' regional concentration adds physical risk. FY 26 accounts record a₹8.73 lakh insurance recovery for flood damage to a factory wall, with repair expense to be booked later. Do not infer factory shutdowns or lost sales from that limited disclosure. [FY 26 report, PDF 74](https://sharpchucks.com/wp-content/uploads/2026/09/annual-report-2025-26.pdf).

## 8. Peer implications and unresolved proof points

The separately sourced peer work supplies the financial inputs. Pritika's captive-parent customer and advance-funding model is not Sharp's bank-funded independent-OEM model. Nelcast offers larger scale and customer/geographic diversity but only moderate book-capital returns, with a new October machining project. Talbros Engineering's specialized forged axles and better asset productivity are not a directly transferable casting/chuck return target; its growth capex still exceeds reported CFO. No peer median multiple substitutes for company-specific evidence.

Before awarding a durable growth/quality premium, establish:
- Current product and end-market revenue/margin mix, saleable tonnage and practical utilization.
- Contracted orders and LOI conversion, with counterparty, economics and delivery milestones.
- Commissioned capacity, rejection/yield improvement and actual in-house processing savings.
- Inventory-stage/valuation/order reconciliation and conversion into unrestricted cash.
- Remaining project spend, financing headroom and the actual status of proposed securities.
- Related-party trade pricing/settlements, current pledges and updated ownership details.

`business_inputs.json` preserves 33 individually sourced facts, inference labels, exact URLs, physical pages, capacity vintages, metric formulas and explicit unavailable data. No missing quantity, margin, backlog, contractual commitment or FY 26 utilization is filled with an estimate disguised as fact.
