# Sharp Chucks and Machines Limited | SME #362

Research at 20 October 2026, market close 19 October 2026, under actual Master Prompt v 3.0. Read report.html or report.md first. Conclusion: Hold pending evidence; BQS/GQS/IAS NS. GQS means Growth Quality. This is not the frozen 341–359 publication packet.

Rebuild: Python 3 standard library only. Run python build.py, then python verify.py. Generated results depend only on declared authored inputs in build.INPUTS. No source PDFs, OCR, credentials, helper code or live data are needed. Every full scenario path is preserved in canonical_paths.json.gz; model_spec.md explains cash source/use eligibility, assumptions and suppression. CSV files are optional views, not an alternate model.

Cold isolation: create a fresh empty directory and copy/extract only build.INPUTS into it, preserving relative paths. Run python guarded_rebuild.py --fresh. It requires all generated outputs and attestations to be absent, blocks undeclared/stale reads, external writes, network and subprocesses, runs both build and verification under guard, and writes verification.json plus guard_attestation.json. It never deletes preexisting files. Archive integrity and current Library identity/version recovery are recorded separately by the independent reviewer.

verification/verify_inputs.py is an independent original-source audit script, not part of offline runtime: its primary-PDF and original-market-archive dependencies are intentionally excluded from source-safe archives. Its captured findings/hash record remains available. verification/replay_monthly.py is an independent standard-library trace replay and may be run after rebuild; it has no producer-module imports. Independent final acceptance is separate from a machine PASS and does not cure source limitations.

Source-safe archives contain authored facts/definitions, exact primary URLs, hashes and source-page maps, report and reader, runtime source, full traces, summary data, both rebuild attestations and independent review. Full and compact archives are both complete, not truncated variants. Do not infer Git or website publication from Library storage.
