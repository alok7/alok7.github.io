# Sixteen substantive quality checks

1. Correct security, legal issuer, standalone scope, cutoff and source-vintage dates.
2. Primary material, original annuals and prospectus vintages reviewed; facts, management claims, assumptions and inferences separated.
3. Audit, CARO, IFC, related parties, prior defaults and dilution reviewed with resolved counterevidence.
4. Comparable periods, units and revenue definitions; no invented TTM or annualized quarter.
5. Revenue growth and scale separated from PAT, price, mix, capacity and a small-base effect.
6. CFO/PAT is ratio of sums; interest classification, tax lag and working-capital drivers reconciled.
7. Incremental capital numerator, denominator, bridge, attribution and NS limitation explicit.
8. Earnings normalization, claims, cash restrictions, share issuance and leases consistent.
9. Monthly operating cash, capacity, capex, debt, fees, tax and whole-share financing reconcile.
10. Thirteen canonical factors reused, exact Decimal weights sum to one.
11. Missing factors are NS, never zero or renormalized; coverage and dependency-aware bounds shown.
12. Raw scores, caps and gates reconcile without inventing adverse evidence.
13. Classification and compounder label obey evidence and gates, not a low valuation multiple.
14. Liquidity uses verified official archives, ₹5 lakh reference and whole lots; missing rows are not zero-filled facts.
15. Strongest bear case, disconfirming evidence and thesis-break monitor are actionable.
16. Same framework and tie policy; this unresolved company is excluded from numeric rankings and frozen publication.

These are checks of treatment, not claims that source limitations are cured. Machine execution is recorded in verification.json.
