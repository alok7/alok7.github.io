# Sharp Chucks and Machines Limited — SME research #362

Master Prompt v 3.0. Information cutoff: 20 October 2026, end of day India. Valuation reference: official NSE close 19 October 2026. Research assembled 24 October 2026. ₹ crore unless stated otherwise. This is research, not individualized investment advice.

## 1. Executive Verdict

Sharp Chucks and Machines manufactures castings, machined/forged components and machine-tool accessories, mainly for concentrated tractor and industrial OEM customers. A long operating history, real revenue expansion and improved credit assessment are strengths. The decisive limitation is accounting and funding reliability: persistent work-in-progress valuation/asset reconciliation gaps, highly restricted cash, thin interest cover and an unverified current funding bridge prevent a supported investable return. At ₹94.80, the approximately 15× FY2026 PAT multiple is neither a sufficient margin of safety nor proof of overvaluation. Classification: **Hold — unresolved**, with Business Quality, Growth Quality and Investment Attractiveness all **NS**. This is a cyclical, capital-intensive expansion thesis, not an established compounder. Verified inventory valuation and current funded cash/capacity economics could change the decision; a lower price alone cannot cure them. [AR26 pp 41–78](https://archives.nseindia.com/annual_reports/SME_AR_31861_SCML_2025_2026_A_3090667_08092026144726.pdf) [CARE2609](https://www.careratings.com/upload/CompanyFiles/PR/202609140922_Sharp_Chucks_and_Machines_Limited.pdf)

## 2. Research Header, Gates and Data Confidence

Original-universe fields are retained unchanged: position 362, name “Sharp Chucks and”, symbol SCML, ISIN INE460Q01014. Verified legal issuer is **Sharp Chucks and Machines Limited**, NSE Emerge SME, listed 12 October 2023. The investable reporting perimeter is standalone; no subsidiary, associate or joint venture is reported. Indian GAAP Accounting Standards under Companies Act section 133 apply, not assumed Ind AS. Current verified issued shares are 14,496,792, face value ₹10; market capitalization at the reference close is ₹137.4296 crore. The original list’s pending research status is not the subsequently verified issuer conclusion. [PROS](https://archives.nseindia.com/emerge/corporates/content/SharpChucks_PROSP.pdf) [AR26](https://archives.nseindia.com/annual_reports/SME_AR_31861_SCML_2025_2026_A_3090667_08092026144726.pdf) [EGM2610](https://sharpchucks.com/wp-content/uploads/2026/10/Notice-of-EGM-31-10-2026.pdf)

The closing price and last transaction price are both ₹94.80 on 19 October, with 8,000 shares, ₹789,450 actual turnover and eight trades. The current master identifies series SM and a 1,000-share lot. That is not a live bid or an executable ₹5 lakh position.

| Sessions | Observed rows / missing | Observed mean turnover ₹ | Observed median ₹ | Conditional all-session median if absences=0 | Conditional ₹5 lakh days at 2% / 5% / 10% |
|---|---|---|---|---|---|
| 20 | 18 / 2 | 2,142,200.00 | 1,548,575.00 | 1,019,575.00 | 24.52 / 9.81 / 4.90 |
| 60 | 55 / 5 | 2,734,207.27 | 1,847,450.00 | 1,472,975.00 | 16.97 / 6.79 / 3.39 |

Five complete official session archives omit the issuer row, without independent no-trade confirmation. Observed-only means and medians are not full-window statistics; absent-as-zero calculations are conditional sensitivities only. Five lots cost ₹474,000 and six ₹568,800, so the reference ₹500,000 cannot be purchased exactly in whole lots. On the final observed session even 10% of shares is 800, below one 1,000-share lot; an aggregate turnover ratio does not ensure participation-size execution. The security master’s end-of-day price range is not used as proof of that session’s intraday circuit regime. Detailed exchange archive URLs and SHA256/CRC/date checks are retained in market_inputs.json.

Core investment horizon: five years, with ten-year feasibility diagnostics. Illustrative nominal equity hurdle: 15%, tested at 12% and 18%, before personal tax and investor trading costs. Model WACC is separate from that hurdle. Liquidity reference: ₹5 lakh, not a recommended allocation. Financial confidence is high that primary reported numbers and opinions were retrieved accurately, medium on underlying earnings and growth composition, low on inventory reliability, incremental returns and current unrestricted funding. Historical share count and reference price have high retrieval confidence; liquidity implementation is low confidence because missing issuer rows, live spread and surveillance are unresolved.

| Gate | Status | Finding / resolution |
|---|---|---|
| G1 | Conditional | No evidenced severe diversion or minority abuse in reviewed material. Recurrent control and disclosure concerns require resolution. Complete remediation and fair-capital-allocation evidence. |
| G2 | Hold — unresolved | Material inventory valuation/stage tracking and fixed-asset reconciliation limitations persist, confirmations are pending, and historical debt-delay versus CARO statement is unresolved. Unmodified opinions do not erase these particulars. Verified inventory methodology/reconciliation, asset register reconciliation, confirmed balances, and reasoned audit/default chronology. |
| G3 | Hold — unresolved | October unrestricted cash, line availability, loan repayment roll-forward and funded capex commitment are not verified. Diagnostic shortfalls are not proof of current default. Current unrestricted bank balance, sanctioned undrawn lines, maturity servicing and approved capex funding bridge. |
| G4 | Conditional | Recent trade exists, but lot size and incomplete independent no-trade/spread/surveillance verification limit implementation. Current restriction status, official zero/no-trade confirmation and actual bid-depth at intended position. |

A Hold is not a proved fraud/default Fail. Unmodified financial and IFC opinions and the credit-agency improvement are meaningful counterevidence. They do not supply the missing inventory reconciliation or current cash bridge. G2 blocks favorable numeric ranking; G3 unresolved does not trigger the separate cap reserved for evidenced funding failure.

## 3. Scorecard and Calculation Audit

| Composite | Result | Coverage | Known contribution | Uncapped mathematical bounds | Applicable cap |
|---|---|---|---|---|---|
| BQS | NS | 88.00% | 4.1600 | 4.2800 to 5.3600 | ND / NS |
| GQS | NS | 85.00% | 4.8500 | 5.0000 to 6.3500 | 5.00 |
| IAS | NS | 20.00% | 0.6000 | 1.4000 to 8.6000 | ND / NS |

BQS is Business Quality Score; **GQS is Growth Quality Score**, not governance. IAS is Investment Attractiveness Score. Every missing factor remains NS at its original weight. No missing score is set to zero, midpoint-filled or redistributed. Mathematical bounds are not confidence intervals or investable rankings. The dependency-aware IAS bound propagating BQS is **2.2200 to 7.4400**. Exact Decimal arithmetic is preserved; display rounding is half-up to one decimal only after aggregation, while classification uses unrounded values.

| Composite | Factor | Weight | Contribution |
|---|---|---|---|
| BQS | GOV | 20.00% | 0.8000 |
| BQS | MOAT | 20.00% | 1.0000 |
| BQS | REV | 12.00% | 0.8400 |
| BQS | DUR | 10.00% | 0.5000 |
| BQS | CAP | 12.00% | ND / NS |
| BQS | CASH | 10.00% | 0.3000 |
| BQS | BAL | 8.00% | 0.3200 |
| BQS | EXEC | 8.00% | 0.4000 |
| GQS | REV | 40.00% | 2.8000 |
| GQS | DUR | 20.00% | 1.0000 |
| GQS | EARN | 15.00% | 0.7500 |
| GQS | CAP | 15.00% | ND / NS |
| GQS | CASH | 10.00% | 0.3000 |
| IAS | BQS | 25.00% | ND / NS |
| IAS | R | 35.00% | ND / NS |
| IAS | D | 20.00% | 0.6000 |
| IAS | P | 10.00% | ND / NS |
| IAS | L | 10.00% | ND / NS |

| Factor | Score / confidence | Reason | Counterevidence | Evidence |
|---|---|---|---|---|
| GOV | 4 / Medium | Repeated accounting-control gaps and disclosure inconsistencies, historical payment delays and listing penalties justify a weak stewardship assessment. No proven diversion or minority abuse is inferred. | Unmodified audits/IFC, cured term-debt delays and ordinary auditor rotation are retained; pending financing is not itself misconduct. | A01, A02, A03, A04 |
| MOAT | 5 / Medium | Long OEM qualification and integrated foundry/machining are useful but contestable capabilities. Customer bargaining power, quarterly cost pass-through lag and purchase-order selling limit demonstrated excess economics. | Three decades of operations and repeated OEM business are genuine advantages; no independently measured market share or switching-cost premium establishes a stronger moat. | B01, B02, B03 |
| REV | 7 / Medium | Preselected FY2021–26 revenue CAGR 15.1104% maps to 7. Final restatement does not alter revenue. Organic volume/price split remains incomplete; CARE attributes expansion to components and demand. No additional trajectory adjustment. | FY2026 growth 11.50% is slower; one unaudited Q1 number cannot justify a downgrade or upgrade. No acquisition-driven growth was identified. | F01, F02, B04 |
| DUR | 5 / Medium | Existing OEM access, product additions and spare physical capacity support a runway, but demand is cyclical and the new-segment LOI has not become definitive orders. Funded expansion and customer qualification remain constraints. | Multiple end-use claims and automation provide opportunity, but a large headline automotive market does not prove accessible profitable demand. | B01, B04, M01 |
| CAP | NS / Low | Three- and five-year descriptive incremental proxies can be computed, but inventory reliability, complete capital reconciliation and attribution between new capacity and old-asset utilization are not established. Leave CAP NS, not a low or average invented score. | Positive operating profit growth and near-reconciled cash investment bridges are useful; they do not establish causal returns on new capital. | F03, A01, M02 |
| CASH | 3 / Medium | The audited FY2024–26 ratio of CFO/PAT is 1.2704 before financing interest, but cash after interest is negative ₹ 5.45 crore and after capex/interest negative ₹ 54.72 crore. Inventory and collection control weaknesses persist; the same issue is not explained solely by capex. | FY2026 CFO rebounded to ₹ 19.79 crore, inventories grew only 2.59%, and reported cumulative CFO is positive. These positives are retained; tax-payment lag and payable support limit the cure. | F04, F05, A01 |
| BAL | 4 / Medium | Near-full working-capital use, high restricted balances, interest coverage below 2 x and a sizeable capex programme constrain resilience. Current default is not evidenced, and unknown headroom is not made up. | CARE reports regular term-debt service since April  2024 and adequate September 2026 liquidity, with scheduled repayment coverage from projected accruals. This materially tempers, but does not resolve, the cash bridge. | A03, F06, M01 |
| EXEC | 5 / Medium | Sales and operating earnings have grown and old warrants were converted. Long-running inventory/PPE remediation and an aborted April fundraising show uneven delivery and financial flexibility. | Withdrawn fundraising can be prudent in adverse markets, not necessarily an execution failure. A new LOI is not treated as a missed binding order. | B04, A04, M01 |
| EARN | 5 / Medium | PAT growth is mostly operating, but FY2026 reported EPS rose only 0.85% while PAT rose 15.69% and shares increased. Normalization removes FD interest, small asset gain and insurance recovery pending repair spending. | Other income is only 0.47% of sales, and operating profit increased. Dilution raised cash and cannot be treated as pure value destruction without deployment evidence. | F02, F07, A05 |
| R | NS / Low | No supported base-case investor IRR is available because the October balance bridge, incremental sanctioned capacity and expansion economics are unverified. Conditional stress paths cannot be promoted into an R score. | Transparent funded diagnostic paths permit comparison without claiming current forecast validity. | M01, M02, M03 |
| D | 3 / Medium | Conditional linked stress produces funding gaps even with proposed warrant cash, and working-capital write-downs erode limited equity protection. No guaranteed liquidation recovery is assumed. | Book equity and operating OEM relationships provide value, and recent credit stabilization is real. A scenario shortfall is not a claim of actual default. | M03, F06, A01 |
| P | NS / Low | Stale balance inputs and unresolved capital needs prevent a supported price-implied expectation score. Current observed price and simple historical multiples are shown separately. | A roughly 15 x audited PAT multiple is not by itself extreme or cheap; funded returns depend on capital needs, claims and dilution. | M03, F07 |
| L | NS / Low | Complete official exchange archives identify 55 issuer observations across 60 sessions, but five absent rows lack independent no-trade confirmation. Order-book spread and current surveillance are also unverified. Preserve conditional liquidity calculations without assigning a score. | The 19 October trade and 1,000-share lot are verified. The security is not treated as suspended or wholly untradeable. | L01, L02 |

The CASH score of 3 triggers the conditional Growth Quality ceiling of 5 because the weakness is recurrent cash realization/working-capital control, not simply investment capex. The uncapped GQS bound and capped bound are both in scores.json. CAP remains NS, so GQS remains NS even if its capped bounds coincide at 5. No governance cap applies: GOV is 4 and G1 has no evidenced severe failure. No funding cap applies: G3 is unresolved, not a proved current failure. G2 independently forces IAS NS and excludes numerical quality ranking. MOAT ±1 changes known BQS by ±0.20; CASH ±1 changes BQS and GQS by ±0.10. Joint BQS sensitivity is ±0.30, without curing missing evidence.

## 4. Business Overview

The company sells engineered castings, machining and forging work, tractor/industrial components, chucks and machine-tool accessories. Revenue depends on approved product supply and purchase orders, not a recurring software-like subscription. Earnings arise from metal conversion, machining, tooling/quality and reliable OEM supply after raw material, power, labour, subcontracting, freight, interest and customer credit costs. Collection follows sales: inventory and trade receivables are economically necessary but consume capital. A customer relationship is not equivalent to a guaranteed backlog. [PROS pp 137–155](https://archives.nseindia.com/emerge/corporates/content/SharpChucks_PROSP.pdf)

At FY2023, castings accounted for 86.07% of revenue. FY2026 reports one manufacturing segment, so current product mix, unit margins and profit by casting/forging/chuck product are ND. Do not use the old mix as the current sales split. September 2026 CARE repeats nameplate capacities of 30,000 casting, 14,400 machining and 3,600 forging tonnes per annum. These are linked process stages, not 48,000 interchangeable tonnes of saleable product. FY2026 production and utilization by stage are not disclosed in the reviewed material. [PROS pp 134,147–149](https://archives.nseindia.com/emerge/corporates/content/SharpChucks_PROSP.pdf) [AR26](https://archives.nseindia.com/annual_reports/SME_AR_31861_SCML_2025_2026_A_3090667_08092026144726.pdf) [CARE2609](https://www.careratings.com/upload/CompanyFiles/PR/202609140922_Sharp_Chucks_and_Machines_Limited.pdf)

Verified FY2021/FY2022/FY2023 casting production was 15,051/15,823/19,606 tonnes, while installed casting capacity rose from 18,000 to 30,000. FY2023 machining output was 7,690 of 14,400 tonnes and forging 1,730 of 3,600. The expansion created physical room, but old spare capacity is not proof that current demand can grow profitably without tooling, labor or working capital. FY2026 exports were ₹4.4212 crore, only about 1.61% of operating sales; the business remains predominantly domestic. [PROS p 148](https://archives.nseindia.com/emerge/corporates/content/SharpChucks_PROSP.pdf) [AR26](https://archives.nseindia.com/annual_reports/SME_AR_31861_SCML_2025_2026_A_3090667_08092026144726.pdf)

## 5. Moat / Industry Position

The plausible advantage is approved OEM access, accumulated product/process knowledge and integrated casting/machining capabilities developed over three decades. Those are useful operating assets. Evidence of durable pricing power is weaker: concentrated customers have bargaining power, orders are purchase-order based, and raw-material pass-through can lag about one quarter. The failure mechanisms are OEM loss, price pressure, casting quality/rejection, unfavorable product mix, delayed cost recovery, power disruption and financed capacity that fails to earn an adequate spread over capital cost. A certification, long history or factory photograph is not independent proof of a moat. [PROS pp 140–153](https://archives.nseindia.com/emerge/corporates/content/SharpChucks_PROSP.pdf) [CARE2609](https://www.careratings.com/upload/CompanyFiles/PR/202609140922_Sharp_Chucks_and_Machines_Limited.pdf)

FY2023 top-five customers represented 73.78% of sales; the September 2026 rating commentary still places major OEM concentration around 74%. No verified current retention cohort, product-level price premium, independent market share or long-term contracted backlog was found. Industry exposure is cyclical tractor, commercial/industrial equipment demand, with material and power costs affecting cash even where eventual price pass-through exists. The source-supported conclusion is a contestable manufacturing franchise, not immunity from competition.

| Peer / scope | FY26 sales | Growth | Operating EBITDA margin | PAT | CFO | Capex | Post-interest / capex cash | Common pretax capital return |
|---|---|---|---|---|---|---|---|---|
| Pritika Engineering Components Limited / Consolidated Ind AS, includes wholly owned Meeta Castings. Pritika Auto is the external listed parent and is not consolidated in this perimeter. | 161.87 | 37.90% | 13.29% | 7.31 | 22.97 | 42.49 | -25.67 | 10.90% |
| Nelcast Limited / Consolidated Ind AS with NC Energy. Total equity includes disclosed non-controlling interest of 2.71 crore in both years; group PAT used consistently. | 1,328.40 | 6.13% | 8.32% | 48.43 | 91.58 | 17.74 | 41.31 | 10.82% |
| Talbros Engineering Limited / Standalone Ind AS FY26. Do not confuse with Talbros Automotive Components/TALBROAUTO. New wholly owned Talbros Nextgen incorporated12May2026, after FY26 year end. | 535.76 | 20.10% | 11.28% | 29.16 | 44.56 | 52.64 | -8.08 | 15.67% |

The comparison uses current FY2026 original audited accounts, not a transplanted sector multiple. Pritika Engineering is the closest smaller casting/machining comparison, but its parent supplied about 88% of sales and material advance funding. Its headline CFO includes a large other-noncurrent-liability inflow; that is not pure cash earnings. Nelcast provides a larger iron-casting comparison with broader customer exposure and cash generation, but its March “no major capex” rating assumption was overtaken by the 5 October ₹75 crore machining approval. Talbros Engineering makes forged axle shafts, has different product/export economics, and is BSE 538987, not Talbros Automotive. Its reported CFO already includes interest, so interest is not deducted twice. All-peer operating EBITDA excludes all other income; Sharp’s normalized EBITDA retains operating FX/export income, so small definition differences remain explicit. A consistent pretax book-capital proxy is shown, not claimed economic ROIC. No synchronized peer P/E median is fabricated: Pritika has a current-issuance bridge gap and Talbros’ reference-date price is unavailable. Full primary sources, formulae and exceptions appear in the peer appendix.

## 6. Revenue Growth & Scale

| FY | Operating revenue ₹ crore | Addition | Growth | Vintage |
|---|---|---|---|---|
| 2020 | 112.81 | ND / NS | NS | restated-draft |
| 2021 | 135.46 | 22.65 | 20.08% | restated-final |
| 2022 | 151.91 | 16.45 | 12.14% | restated-final |
| 2023 | 176.45 | 24.54 | 16.16% | restated-final |
| 2024 | 201.66 | 25.21 | 14.29% | original |
| 2025 | 245.53 | 43.87 | 21.75% | original |
| 2026 | 273.77 | 28.24 | 11.50% | original |

| Window | Start / end ₹ crore | CAGR |
|---|---|---|
| 2021–2026 | 135.46 / 273.77 | 15.11% |
| 2023–2026 | 176.45 / 273.77 | 15.77% |
| 2020–2026 | 112.81 / 273.77 | 15.92% |

The preselected five-year FY2021–FY2026 operating-revenue CAGR is 15.11%, versus 15.77% over FY2023–FY2026. FY2026 sales increased about 11.50%, slower than the preceding year. The initial pandemic-affected period and capacity additions affect interpretation. The final prospectus restatement did not change operating revenue, but changed profit/tax classifications. Reported sales growth is not equated with organic volume: metal realizations, mix, new-component content and utilization are not fully reconciled. No acquisition-led revenue addition was identified, but a clean price/volume split remains ND. REV 7 uses the preselected reported comparable-scope CAGR with medium confidence and no upward trajectory adjustment; it is not a measured physical-volume CAGR.

Ten-year CAGR is ND because eleven comparable observations are unavailable. CARE’s June-quarter FY2027 sales of ₹60.73 crore are management information, with no matched prior-quarter/cash-flow set. It is neither annualized nor spliced into an invented TTM. New-business LOI language does not change recognized revenue or create binding backlog. [CARE2609](https://www.careratings.com/upload/CompanyFiles/PR/202609140922_Sharp_Chucks_and_Machines_Limited.pdf)

## 7. Growth Quality & Reinvestment Runway

Growth can come from more components per existing OEM, higher casting and machining throughput, reduced subcontracting and qualified new customers. The credible bottom-up requirements are orders, production/yield, operating staffing, tooling, paid and commissioned capacity, receivable/inventory funding and finance costs. CARE identifies a ₹30 crore capex programme and a new-segment LOI, but definitive orders, counterparty, value, conversion schedule and project-level returns are not verified. These are opportunities, not an accessible addressable market quantified by a large automotive headline. [CARE2609](https://www.careratings.com/upload/CompanyFiles/PR/202609140922_Sharp_Chucks_and_Machines_Limited.pdf)

The model therefore starts with explicit assumed 24,000 annual casting-equivalent tonnes, not falsely reported FY2026 output. The 30,000/14,400/3,600 nameplate stages constrain monthly physical output, with machining/forging load assumptions. Half the initial programme is assumed to add capacity and half to automate existing activity; commissioning is delayed until spending precedes output. Future capacity expansion needs paid capex, lead time and working capital. Unit capex of 400 annual casting-equivalent tonnes per ₹1 crore is an analyst sensitivity, not a sourced engineering quote. Revenue never exceeds the most restrictive modeled process stage.

Reported normalized NOPAT growth and descriptive capital returns are positive, but they do not prove returns attributable to new capital. Inventory valuation uncertainty, incomplete full operating-capital reconciliation and utilization/mix effects prevent CAP scoring. GQS consequently remains NS. The cash-quality cap does not mean all growth is bad; it means sales expansion has not yet demonstrated a sufficiently reliable cash and financing path. The primary countercase is that FY2026 inventory stabilized, CFO recovered and CARE improved liquidity, while further automation and better collections could release working capital.

## 8. Management, Governance & Execution

The October notice’s promoter-group holding is 9,230,542 shares, 63.67% of current issued shares. Full proposed warrant conversion would give 11,230,542 promoter-group shares out of 18,496,792, or 60.72%; percentage dilution is not loss of control. Two million proposed warrants are for promoter group and two million for other investors. FY2026 director remuneration was ₹0.72 crore versus PAT ₹9.1901 crore. Related Sharp Precision sales of ₹11.9721 crore and purchases of ₹6.9852 crore require terms/settlement review but do not, by themselves, establish abuse. Current promoter pledge status has not been independently established and is ND, not silently zero. [EGM2610 pp 19–24](https://sharpchucks.com/wp-content/uploads/2026/10/Notice-of-EGM-31-10-2026.pdf) [AR26 related-party note](https://archives.nseindia.com/annual_reports/SME_AR_31861_SCML_2025_2026_A_3090667_08092026144726.pdf)

| Original FY | Auditor / date | FS opinion / IFC | Specific observations |
|---|---|---|---|
| 2020 | Sharp & Tannan / 2020-12-08 | unmodified / adequate and operating effectively | PPE no material discrepancies; inventory differences immaterial and dealt with; no loan default reported; statutory-dues delay in a few cases. |
| 2021 | Sharp & Tannan / 2021-11-30 | unmodified / adequate and operating effectively | No material PPE discrepancies; inventory differences immaterial and dealt with; no loan default reported. |
| 2022 | Sharp & Tannan / 2022-09-19 | unmodified / adequate and operating effectively | No material PPE/inventory discrepancies; bank quarterly returns agreed to books; short-term funds prima facie not used for long-term purposes; no resignation. |
| 2023 | Sharp & Tannan / 2023-09-07 | unmodified / adequate and operating effectively | PPE discrepancies; INR608.41 lakh short-term funds used for plant and machinery; CSR INR10.49 lakh booked but unspent at audit date; income-tax dispute INR38.25 lakh net of predeposit. |
| 2024 | Sharp & Tannan / 2024-05-29 | unmodified / adequate and operating effectively | Accounting software lacked audit-trail feature; PPE discrepancies; INR523.38 lakh short-term funds used for long-term purposes; no lender default stated, conflicting with later CARE account of Dec2023/Mar2024 delays. |
| 2025 | V.P. Bhalla & Associates / 2025-05-30 | unmodified / adequate and operating effectively | Audit-trail limitation persists; PPE discrepancies; INR523.38 lakh short-term funding of long-term use repeated; no lender default. |
| 2026 | V.P. Bhalla & Associates / 2026-05-30 | unmodified / adequate and operating effectively | PPE discrepancies persist. No corresponding audit-trail paragraph or explicit short-term-versus-long-term financing paragraph was found; omission is not evidence of cure. Inventory methodology and confirmations limitations remain in notes. |

The original statutory audit/IFC vintages were read before the restated offering accounts. All seven financial opinions and IFC opinions are unmodified. Material findings are nevertheless present in notes and CARO: PPE discrepancies recur from FY2023, stagewise WIP methodology remains unimplemented, FY2024–25 audit-trail exceptions recur, and old short-term finance used for long-term assets is disclosed. FY2026 omission of an earlier paragraph is not evidence of remediation. The change from Sharp & Tannan to V. P. Bhalla followed term expiry; it is not presented as opinion shopping. [AR20](https://sharpchucks.com/report-19-20.pdf) [AR21](https://sharpchucks.com/report-20-21.pdf) [AR22](https://sharpchucks.com/report-21-22.pdf) [AR23](https://sharpchucks.com/report-22-23.pdf) [AR24](https://www.sharpchucks.com/pdf/annual-report-23-24.pdf) [AR25](https://archives.nseindia.com/annual_reports/SME_AR_28998_SCML_2024_2025_A_2423168_09092025151324.pdf) [AR26](https://archives.nseindia.com/annual_reports/SME_AR_31861_SCML_2025_2026_A_3090667_08092026144726.pdf)

| Dated record or commitment | Observed outcome by cutoff | Interpretation |
|---|---|---|
| FY2023–FY2026 inventory/PPE remediation | Stagewise WIP methodology and PPE reconciliation remain unresolved | Repeated control weakness, not an allegation that all inventory is fictitious |
| FY2024/25 audit-trail compliance | Exceptions stated; FY2026 paragraph absent | Request affirmative remediation, not an assumed cure |
| Prior 2,412,000 warrants at ₹76.12 | Converted 17 November 2025; listed 3 July 2026 | Already in 14,496,792 shares; proceeds not future cash |
| April 2026 equity/warrant proposal | Cancelled 4 June 2026 | Do not include withdrawn 2.637 m shares or 3.063 m warrants as active dilution |
| Separate authorized-capital increase | May 6 resolution approved to 21 m shares | Corporate approval not proof of receipt or all future issuance permissions; ROC effectiveness ND |
| October 2026 proposal | 4 m warrants at ₹81, EGM scheduled 31 October | Still proposed at cutoff, not committed cash |
| In-house machining/automation narrative | Job-work cost rose from ₹2.44 cr to ₹4.53 cr in FY2026 | Savings not yet demonstrated; mix and volume can explain cost change |
| New business segment | CARE records LOI, definitive orders awaited | Not a booked order or already missed contractual delivery |

FY2025 included an NSE fine of ₹519,200 relating to delayed preferential listing; FY2026 includes a ₹2,000 Regulation 34 fine. These are disclosure/execution signals, not quantitatively major profit deductions or proof of fraud. CARE identified actual debt-service delays in December 2023 and March 2024 and subsequently regular servicing from April 2024. The FY2024 CARO “no default” statement needs a reasoned chronology reconciliation. The 2024 D/noncooperating rating must not be explained away as noncooperation alone, and the later cure must not be omitted. [CARE2401](https://www.careratings.com/upload/CompanyFiles/PR/202401130123_Sharp_Chucks_and_Machines_Limited.pdf) [CARE2502](https://www.careratings.com/upload/CompanyFiles/PR/202502140216_Sharp_Chucks_and_Machines_Limited.pdf) [CARE2601](https://www.careratings.com/upload/CompanyFiles/PR/202601150152_Sharp_Chucks_and_Machines_Limited.pdf) [CARE2609](https://www.careratings.com/upload/CompanyFiles/PR/202609140922_Sharp_Chucks_and_Machines_Limited.pdf)

## 9. Financial Forensics

| FY | Revenue | Normalized EBITDA | PAT | CFO before interest | Cash capex | D&A | EBITDA margin | ROE |
|---|---|---|---|---|---|---|---|---|
| 2020 | 112.81 | 13.34 | 2.98 | 7.04 | 6.23 | 3.57 | 11.83% | NS |
| 2021 | 135.46 | 15.00 | 3.31 | 6.63 | 10.46 | 3.97 | 11.08% | 8.04% |
| 2022 | 151.91 | 17.63 | 4.53 | 5.75 | 13.72 | 4.72 | 11.60% | 10.05% |
| 2023 | 176.45 | 19.09 | 5.06 | 15.09 | 19.00 | 5.69 | 10.82% | 10.17% |
| 2024 | 201.66 | 24.39 | 6.10 | 21.46 | 9.36 | 6.51 | 12.10% | 10.75% |
| 2025 | 245.53 | 29.23 | 7.94 | -11.73 | 16.07 | 6.97 | 11.91% | 11.31% |
| 2026 | 273.77 | 33.45 | 9.19 | 19.79 | 23.83 | 7.95 | 12.22% | 9.88% |

All figures above are ₹ crore, except margins and ratios. Operating EBITDA removes interest income, asset gains and conservatively excludes FY2023 power rebate and FY2026 insurance recovery; it is not a reported segment EBITDA. Disclosed tax rates and normalization uncertainties remain visible. Gross profit is ND as a consistently reported audited subtotal: material-only contribution is not mislabeled gross profit. Detailed production-cost proxies and ingredients are available in financial_inputs.json and metrics.json.

| FY | Equity | Gross bank debt | Available cash | Restricted cash | AR | Inventory | AP | PPE | CWIP |
|---|---|---|---|---|---|---|---|---|---|
| 2020 | 39.57 | 52.85 | 0.62 | 0.22 | 21.36 | 49.12 | 23.56 | 47.64 | 0.30 |
| 2021 | 42.76 | 63.05 | 0.65 | 0.23 | 21.34 | 51.94 | 17.93 | 53.96 | 0.51 |
| 2022 | 47.28 | 102.69 | 25.57 | 0.49 | 33.59 | 50.91 | 23.13 | 62.96 | 0.52 |
| 2023 | 52.35 | 90.34 | 1.08 | 0.28 | 29.10 | 64.65 | 23.19 | 72.95 | 3.90 |
| 2024 | 61.21 | 83.87 | 1.08 | 0.80 | 32.64 | 76.08 | 32.16 | 79.61 | 0.09 |
| 2025 | 79.24 | 117.60 | 0.20 | 9.17 | 35.87 | 104.68 | 30.88 | 82.90 | 5.90 |
| 2026 | 106.79 | 120.97 | 0.52 | 9.91 | 52.69 | 107.40 | 43.12 | 104.00 | 0.52 |

Original versus restated PAT in ₹ lakh is preserved: FY2020 314.63→298.35; FY2021 380.52→330.96; FY2022 453.97→452.62; FY2023 473.39→506.50. The final prospectus FY2023 adjustment of +₹33.11 lakh reconciles through GST/MSME interest, tax/MAT/deferred-tax and IPO professional-fee/reversal items; it is not unexplained sales growth. The FY2023 ₹218 lakh PSPCL power rebate moved from direct expense to other income. We conservatively remove it from normalized earnings because no comparable rebate occurred in the previous two years, not merely because its presentation changed. Draft and final FY2021–22 equity differ by ₹12.08 lakh despite unchanged PAT; final prospectus values control the core series. Original FY2024 PAT ₹610.47 lakh versus later comparative ₹610.46 is retained as rounding/vintage, not manufactured precision. [DRAFT pp 210–212,226](https://archives.nseindia.com/emerge/corporates/content/SharpChucks_DP.pdf) [PROS pp 191–208](https://archives.nseindia.com/emerge/corporates/content/SharpChucks_PROSP.pdf)

The FY2026 cash-flow statement prints closing cash ₹51.66 lakh whereas detailed cash/bank items sum to ₹51.67 lakh. The model uses the item-sum balance, retaining the ₹0.01 lakh display discrepancy rather than denying the alternative source. The apparently huge FY2022 “cash in hand” cash-flow label is resolved by the detailed note: ₹2,528.52 lakh comprises ₹5.52 lakh physical cash and ₹2,523 lakh cheques/drafts. Clearing availability is ND. This is not evidence of a vault full of currency and is not a current available-cash proxy. Two FY2026 printed-note errors are retained rather than silently corrected: depreciation ₹0.01 lakh in note 27 versus ₹795.14 lakh in the P&L, and prior-year maturity ₹0.01 lakh in the debt note versus ₹1,114.07 lakh in the balance sheet. Main statements control; these are disclosure errors, not qualifications invented by the researcher.

| FY | Reported PAT | Illustrative normalized PAT | Reported EPS | PAT / year-end shares | Interest cover |
|---|---|---|---|---|---|
| 2020 | 2.98 | 2.83 | 3.05 | 3.05 | 1.66 |
| 2021 | 3.31 | 3.24 | 3.38 | 3.38 | 1.72 |
| 2022 | 4.53 | 4.46 | 4.63 | 4.63 | 1.96 |
| 2023 | 5.06 | 3.34 | 5.18 | 5.18 | 1.57 |
| 2024 | 6.10 | 5.96 | 5.96 | 5.67 | 1.87 |
| 2025 | 7.94 | 7.66 | 7.03 | 6.57 | 1.81 |
| 2026 | 9.19 | 8.62 | 7.09 | 6.34 | 1.95 |

FY2026 illustrative normalized PAT removes ₹83.83 lakh interest, ₹1.92 lakh asset gain and ₹8.73 lakh insurance recovery at an assumed 25% tax effect, then reverses ₹14.34 lakh prior-year tax. Other operating FX/export income remains. FY2020–22 interest income is consistently removed from historical normalized earnings and starting NOPAT. No conjectured inventory/GST adjustment is booked as fact. FY2026 reported EPS of ₹7.09 rose only about 0.85% versus FY2025 ₹7.03, while PAT rose about 15.69%; weighted-average shares differ from the current outstanding count. All valuation claims use actual current shares. No future warrant proceeds or old converted-warrant proceeds are counted twice.

| FY | CFO | Cash interest proxy | CFO after interest | Capex | After capex / interest |
|---|---|---|---|---|---|
| 2020 | 7.04 | 5.89 | 1.15 | 6.23 | -5.08 |
| 2021 | 6.63 | 6.41 | 0.22 | 10.46 | -10.24 |
| 2022 | 5.75 | 6.59 | -0.84 | 13.72 | -14.56 |
| 2023 | 15.09 | 8.53 | 6.56 | 19.00 | -12.45 |
| 2024 | 21.46 | 9.55 | 11.91 | 9.36 | 2.55 |
| 2025 | -11.73 | 12.32 | -24.05 | 16.07 | -40.11 |
| 2026 | 19.79 | 13.11 | 6.68 | 23.83 | -17.15 |

FY2024–FY2026 CFO/PAT, calculated as a ratio of sums, is **1.2704**: reported CFO ₹29.5218 crore / PAT ₹23.2386 crore. The positive reported ratio is retained. Because financing interest is outside CFO, after interest the three-year cash surplus is negative ₹5.4517 crore; after ₹49.2644 crore cash capex it is negative ₹54.7161 crore. This is not the same as claiming reported CFO was negative in all years. FY2025 CFO was negative; FY2026 recovered to ₹19.7872 crore. Capital-advance movements are partly within reported CFO: reclassifying their net FY2024–26 increase of ₹2.6088 crore to investing raises post-interest operating cash to negative ₹2.8429 crore, still negative, while total post-reinvestment cash remains unchanged. This classification sensitivity is retained before attributing all reported CFO weakness to operations. Finance cost is a cash-interest proxy subject to accrual/fee timing, with source cash-flow classification documented. Maintenance/growth capex is not disclosed separately, so the historical split is ND rather than retrospectively invented.

FY2026 cash generation benefited from slower inventory accumulation and increased trade payables, while receivables rose substantially. Income-tax cash payment lag and creditor funding are not recurring free cash by default. At March 2026 inventory ₹107.3997 crore was roughly 100.6% of equity and 36.6% of total assets. Receivables of ₹52.6931 crore include ₹1.8588 crore over three years, versus ₹0.2643 crore previously; no provision is reported because balances are considered good. External confirmations for debtors, advances and creditors remain pending. WIP is not stagewise tracked; an independent cost-accountant valuation does not replace the missing methodology evidence. [AR26 pp 59–78](https://archives.nseindia.com/annual_reports/SME_AR_31861_SCML_2025_2026_A_3090667_08092026144726.pdf)

| FY | Average AR days | Average inventory days | Average payable days | CCC proxy |
|---|---|---|---|---|
| 2020 | ND / NS | ND / NS | ND / NS | ND / NS |
| 2021 | 57.53 | ND / NS | ND / NS | ND / NS |
| 2022 | 65.99 | ND / NS | ND / NS | ND / NS |
| 2023 | 64.84 | ND / NS | ND / NS | ND / NS |
| 2024 | 55.88 | 152.43 | 59.95 | 148.35 |
| 2025 | 50.93 | 159.95 | 55.78 | 155.10 |
| 2026 | 59.04 | 166.65 | 58.14 | 167.54 |

Inventory/payable days use disclosed material, stores, inventory change, manufacturing and employee costs as a production-cost proxy. Receivable days use average AR / operating revenue. A raw-purchase denominator alternative is retained where available; total supplier purchases are not invented. These are comparability tools, not precise cash-conversion forecasts. The stated growth does not excuse recurrent verification weaknesses.

| FY | Core operating capital | Financing-capital proxy | Unreconciled gap | Core ROIC proxy | Funding ROCE proxy |
|---|---|---|---|---|---|
| 2020 | 96.86 | 91.58 | -5.29 | NS | NS |
| 2021 | 112.26 | 104.92 | -7.34 | 7.91% | 11.23% |
| 2022 | 129.23 | 123.92 | -5.31 | 8.02% | 11.28% |
| 2023 | 151.10 | 141.33 | -9.77 | 7.17% | 10.11% |
| 2024 | 159.80 | 144.46 | -15.34 | 8.63% | 12.51% |
| 2025 | 202.35 | 187.57 | -14.79 | 9.22% | 13.41% |
| 2026 | 227.65 | 217.50 | -10.15 | 8.90% | 12.59% |

| Window | ΔNOPAT | Δcore IC | Observed proxy | Investment bridge residual | Canonical CAP |
|---|---|---|---|---|---|
| 2021–2026 | 10.85 | 115.39 | 9.40% | -0.1337 | NS |
| 2023–2026 | 9.07 | 76.55 | 11.85% | -0.1408 | NS |

Core operating capital is AR + inventory − trade payables + PPE + intangibles + CWIP + capital advances + security deposits. The historical funding proxy is equity + bank/director debt − total reported cash. Because restricted FDs are not truly surplus, metrics.json also retains the higher denominator subtracting available cash only and including FY2025 ₹4.59 crore warrant-application money outside ordinary equity. Neither proxy is canonical invested capital. The visible difference is not forced to zero: tax, other assets/liabilities, restricted cash classifications and incomplete operating attribution matter. Incremental NOPAT uses normalized EBIT ×75%; Δcore capital and cash-capex-minus-depreciation/working-capital bridges are displayed. Neither a near-reconciled bridge nor positive quotient establishes new-project ROIC. CAP is NS because denominator completeness/reliability and profit attribution are insufficient. No favorable window is substituted to force a high score.

March bank borrowings are ₹120.9665 crore, comprising ₹15.1070 crore long-term, ₹96.0822 crore short-term and ₹9.7773 crore current maturities. Adding ₹0.1682 crore director claims gives ₹121.1347 crore; current maturities are counted once. Bank term debt totals ₹24.8843 crore. Source maturity buckets FY2027/FY2028/FY2029/FY2030+ are ₹9.7773/8.6992/5.2778/1.1299 crore, with ₹0.0001 crore rounding residual. Detailed lender-note sublines have an unresolved ₹0.2232 crore gap to aggregate term debt. This is disclosed, not repaired by imaginary lending.

Cash and bank balances total ₹10.4236 crore, of which ₹9.9069 crore are restricted security deposits; ₹0.5167 crore is cash/bank availability before the separately disclosed ₹0.0125 crore IPO escrow. The model conservatively excludes that escrow again because its overlap/location is not fully bridged, with the potential small double-restriction explicitly disclosed. The ₹0.9091 crore LC margin is within restricted deposits, not another cash deduction. CARE’s June ₹11.42 crore cash/liquid-investment statement and September “adequate liquidity” are important later evidence, but do not identify the unrestricted October balance. CARE’s ~98% working-capital utilization and projected ₹29 crore FY2027 accruals against ₹9.78 crore debt repayment are management/rating assessments, not bank confirmations. [AR26](https://archives.nseindia.com/annual_reports/SME_AR_31861_SCML_2025_2026_A_3090667_08092026144726.pdf) [CARE2609](https://www.careratings.com/upload/CompanyFiles/PR/202609140922_Sharp_Chucks_and_Machines_Limited.pdf)

IPO fresh shares were 975,484 at ₹58, or ₹5.6578072 crore; the 1,928,516-share OFS was seller cash, not company funding. Issue expenses and already deployed objects leave only the small disclosed escrow, not a second IPO windfall. Historical corporate cash is not reproduced as a future event. Indian GAAP lease treatment is preserved; no unsupported lease capitalization or omitted IFRS adjustment is fabricated. Employee claims and unpaid taxes remain in terminal claims or modeled settlements. [PROS](https://archives.nseindia.com/emerge/corporates/content/SharpChucks_PROSP.pdf) [IPO_USE](https://www.sharpchucks.com/pdf/Statementofdeviation.pdf) [AR26](https://archives.nseindia.com/annual_reports/SME_AR_31861_SCML_2025_2026_A_3090667_08092026144726.pdf)

## 10. Valuation & Market Expectations

| Measure | Value |
|---|---|
| price | 94.8000 |
| market cap | 137.4296 |
| issued shares | 14,496,792.0000 |
| EV available cash only | 258.0476 |
| PE reported current claims | 14.9541 |
| PE normalized current claims | 15.9341 |
| EV EBITDA normalized | 7.7139 |
| price book | 1.2869 |
| reported FCF yield | -0.0294 |
| post finance FCF yield | -0.1248 |

The price is verified; these multiples combine it with March audited claims and therefore are stale-balance historical diagnostics, not current enterprise value or fair value. Available cash only is netted. The normalized P/E includes an analyst tax assumption and no invented inventory adjustment. Price/book is weak protection when inventory approximates equity. Negative post-reinvestment cash yield is not transformed into a yield by omitting interest or growth finance. A peer multiple range is not used without comparable current share counts and price data.

The valuation laboratory is monthly and event based, starting with an explicitly synthetic 31 October carry-forward of March balances. The unknown April–October debt, cash and capex bridge prevents any path from being source-eligible as a current forecast. All hypothetical warrant approvals, subscriptions, new loans and extra equity remain assumptions. In contrast with a price-target spreadsheet, every sale must fit paid/commissioned capacity, growth needs working capital, cash pays interest/fees/tax/principal, equity is whole shares within authorized capacity, and a cash failure suppresses later ordinary returns.

Bear demand assumes −12%, 0%, 3%, 5%, 5% annual growth with a further temporary customer loss, slower commissioning, worse collections/inventory and 9–10.5% EBITDA margins. Base assumes 8%, 10%, 10%, 8%, 7% and 12–13% margins with modest working-capital improvement. Bull assumes 15%, 18%, 18%, 15%, 12% and 13–15% margins with stronger inventory/collection release. These are analyst scenarios, not promised guidance. Each is run without rescue, with proposed warrants only, with conditional ₹20 crore new project debt plus ₹10 crore extra revolving capacity, and with additional hypothetical equity bounded by 21 m authorized shares. Unknown sanctioned headroom is never represented as observed cash. New project debt is restricted to eligible project/growth capex, after subtracting warrant-funded costs; it cannot pay maintenance, old debt or operating gaps. Loan fees come from general cash, and interest applies to the full draw.

| Path | Result | Exit-year sales | Total capex | Gross new equity | Ending shares | Conditional exit ₹ | IRR |
|---|---|---|---|---|---|---|---|
| bear__no_rescue | FAIL month 3 | ND / NS | 8.97 | 0.00 | 14496792 | Suppressed | NS |
| bear__warrant_only | FAIL month 3 | ND / NS | 8.97 | 8.10 | 14496792 | Suppressed | NS |
| bear__conditional_funded | FAIL month 7 | ND / NS | 20.87 | 8.10 | 14496792 | Suppressed | NS |
| bear__authorized_ceiling_equity | FAIL month 12 | ND / NS | 35.62 | 27.08 | 17000000 | Suppressed | NS |
| base__no_rescue | FAIL month 1 | ND / NS | 3.07 | 0.00 | 14496792 | Suppressed | NS |
| base__warrant_only | FAIL month 2 | ND / NS | 6.15 | 8.10 | 14496792 | Suppressed | NS |
| base__conditional_funded | FAIL month 15 | ND / NS | 39.01 | 8.10 | 14496792 | Suppressed | NS |
| base__authorized_ceiling_equity | Conditional survival | 400.88 | 73.45 | 37.91 | 19223009 | 34.96 | -17.98% |
| bull__no_rescue | FAIL month 1 | ND / NS | 3.08 | 0.00 | 14496792 | Suppressed | NS |
| bull__warrant_only | FAIL month 2 | ND / NS | 6.16 | 8.10 | 14496792 | Suppressed | NS |
| bull__conditional_funded | FAIL month 29 | ND / NS | 57.28 | 32.40 | 18496792 | Suppressed | NS |
| bull__authorized_ceiling_equity | Conditional survival | 534.94 | 118.31 | 51.38 | 21000000 | 92.64 | -0.46% |

The October warrants have six distinct objects; their ₹32.4 crore potential receipts are not treated as freely spendable money. The model allocates each hypothetical receipt proportionally among working capital ₹6.5 crore, land/development ₹4.5 crore, manufacturing facility ₹3 crore, tools/equipment ₹6.65 crore, strategic investment ₹3.75 crore and general corporate ₹8 crore. General cash pays issuance fees. Other buckets release only against modeled eligible current-month uses; unused strategic or unmatched capital proceeds remain restricted with no terminal cash addition. This proportional timing and project matching are assumptions, not an allocation schedule promised by management. CARE’s ₹30 crore programme is not proven identical to the warrant-object capex: the mapping is optimistic and the zero-overlap stress disallows every warrant-capex release. Initial 25% cash arrives only on hypothetical allotment, balance 75% only on optional exercise within 18 months. No conversion means no additional shares; late exercise is not permitted. The base exercise month is a scenario, not a known legal expiry date. [EGM2610 pp 19–24](https://sharpchucks.com/wp-content/uploads/2026/10/Notice-of-EGM-31-10-2026.pdf)

This is a retained-cash terminal-return model: all investor proceeds occur at the final sale, so 100% of the modeled investor cash receipt is terminal. It is not a conventional present DCF with interim FCFF distributed to shareholders; those cash flows are retained, reinvested, used for debt service or reflected in actual ending cash. No interim cash flow is both discounted to the investor and retained at exit. Terminal enterprise value is earned unlevered forward FCFF / (WACC − g), with a 14.5% WACC base and 3% growth. It funds replacement at the larger of modeled depreciation or 3% sales, incremental fixed capital at 2× sales/capital, working-capital growth and operating-cash growth. It deducts bank/director debt, unpaid taxes, employee claims, unpaid expansion commitments and any gap to required operating cash. Only cash above required operating cash is additive; restricted deposits, IPO escrow and unused earmarked warrant money are not. A physical-capacity check validates the next growth step. A separate 5×/6×/8× EBITDA exit comparison is disclosed but does not override the earned-cash terminal claim. No dividends are assumed, so no cash is counted both as a payout and exit cash.

| Path | 12% entry ₹ | 15% entry ₹ | 18% entry ₹ |
|---|---|---|---|
| bear__no_rescue | ND / NS | ND / NS | ND / NS |
| bear__warrant_only | ND / NS | ND / NS | ND / NS |
| bear__conditional_funded | ND / NS | ND / NS | ND / NS |
| bear__authorized_ceiling_equity | ND / NS | ND / NS | ND / NS |
| base__no_rescue | ND / NS | ND / NS | ND / NS |
| base__warrant_only | ND / NS | ND / NS | ND / NS |
| base__conditional_funded | ND / NS | ND / NS | ND / NS |
| base__authorized_ceiling_equity | 19.76 | 17.30 | 15.20 |
| bull__no_rescue | ND / NS | ND / NS | ND / NS |
| bull__warrant_only | ND / NS | ND / NS | ND / NS |
| bull__conditional_funded | ND / NS | ND / NS | ND / NS |
| bull__authorized_ceiling_equity | 52.38 | 45.85 | 40.28 |

These conditional entry values solve the same funded path’s terminal proceeds for 12%, 15% and 18% over actual elapsed holding time. They are not recommended buy ranges because no path has a verified current anchor. Failure or unearned terminal economics suppresses entry values. The financing issue price is an independent explicit ₹75.84 assumption, not secretly linked to the investor entry-price sensitivity; changing this financing assumption is a separate risk.

| Hurdle | First funded grid hit | Minimum tested growth |
|---|---|---|
| 12.00% | None | NS |
| 15.00% | None | NS |
| 18.00% | None | NS |

The following two-way cells show conditional exit price / IRR, or the actual funding-failure month. They never hide a failed cell behind a valuation.

| Sales growth / EBITDA margin | 10.00% | 12.00% | 14.00% | 16.00% | 18.00% |
|---|---|---|---|---|---|
| 4.00% | ₹0.00 / -100.00% | ₹11.05 / -34.77% | ₹47.57 / -12.80% | ₹83.64 / -2.46% | ₹119.69 / 4.74% |
| 7.00% | FAIL m42 | ₹14.49 / -31.15% | ₹54.84 / -10.31% | ₹95.25 / 0.09% | ₹135.55 / 7.36% |
| 10.00% | FAIL m30 | ₹17.17 / -28.79% | ₹55.48 / -10.10% | ₹101.19 / 1.31% | ₹146.14 / 8.98% |
| 13.00% | FAIL m25 | FAIL m33 | FAIL m50 | ₹103.62 / 1.78% | ₹153.78 / 10.09% |
| 16.00% | FAIL m17 | FAIL m26 | FAIL m32 | FAIL m49 | ₹161.25 / 11.13% |

| WACC / terminal growth | 2.00% | 3.00% | 4.00% |
|---|---|---|---|
| 12.50% | ₹60.23 / -8.62% | ₹53.47 / -10.76% | ₹45.11 / -13.72% |
| 14.50% | ₹42.12 / -14.89% | ₹34.96 / -17.98% | ₹26.43 / -22.42% |
| 16.50% | ₹29.00 / -20.97% | ₹21.93 / -25.24% | ₹13.72 / -31.89% |

Full grids retain 25 growth/margin combinations, nine WACC/g combinations, five investor entry prices, linked stresses and all 5/10-year funded target paths. Reverse expectations show the first tested growth step meeting each hurdle without interpolating through funding failure. No unsupported smooth DCF or arbitrary rerating converts failed cash into a target. R and P remain NS.

## 11. Bear Case & Permanent-Loss Path

The strongest bear case is not “small companies are risky.” A concentrated OEM order setback or unrecovered input-cost rise lowers margin while longer customer credit and unresolved WIP absorb cash. Restricted deposits cannot pay the bills; almost fully used bank lines constrain relief. Debt maturities and a live capital programme arrive before optional warrant exercise. New shares at a discount dilute the investor, and authorization or object restrictions can still leave a cash gap. If stock/receivables are impaired, book-value support shrinks exactly when lenders need repayment. The linked stress path, rather than an isolated lower exit multiple, captures this loss mechanism.

| Stress | Result | Exit-year sales | Capex | Equity | Shares | Exit ₹ | IRR |
|---|---|---|---|---|---|---|---|
| stress_zero_warrant_capex_overlap | Conditional survival | 400.88 | 73.45 | 41.61 | 19711250 | 34.09 | -18.39% |
| stress_cash_CARE_less_March_restricted | Conditional survival | 400.88 | 73.45 | 36.80 | 19076370 | 35.22 | -17.86% |
| stress_cash_CARE_all_free_upper_bound | Conditional survival | 400.88 | 73.45 | 32.40 | 18496792 | 40.65 | -15.49% |
| stress_credit_recall | FAIL month 6 | ND / NS | 18.50 | 27.08 | 17000000 | Suppressed | NS |
| stress_late_conversion | FAIL month 20 | ND / NS | 42.25 | 14.58 | 15351372 | Suppressed | NS |
| stress_early_conversion | Conditional survival | 400.88 | 73.45 | 32.40 | 18496792 | 38.01 | -16.61% |
| stress_zero_project_loan | Conditional survival | 400.88 | 73.45 | 51.22 | 20978255 | 41.18 | -15.27% |
| stress_slow_commissioning | Conditional survival | 400.88 | 73.45 | 37.91 | 19223009 | 34.96 | -17.98% |
| stress_capex_15_remaining | Conditional survival | 400.88 | 65.95 | 32.40 | 18496792 | 36.05 | -17.48% |
| stress_capex_45_remaining | FAIL month 33 | ND / NS | 66.27 | 51.38 | 21000000 | Suppressed | NS |
| stress_all_initial_capex_upfront | Conditional survival | 400.88 | 73.45 | 38.18 | 19258962 | 34.89 | -18.01% |
| stress_inventory_stress | FAIL month 6 | ND / NS | 18.50 | 27.08 | 17000000 | Suppressed | NS |
| stress_interest_14pct | Conditional survival | 400.88 | 73.45 | 46.54 | 20361089 | 31.49 | -19.67% |
| stress_LC_crystallizes | Conditional survival | 400.88 | 73.45 | 41.17 | 19653600 | 34.19 | -18.34% |

| Stress | Asset write-down | Residual book equity | Per share ₹ | Price downside |
|---|---|---|---|---|
| moderate | 37.41 | 69.37 | 47.85 | -49.52% |
| severe | 82.83 | 23.96 | 16.52 | -82.57% |

These accounting haircuts are analyst stresses, not liquidation estimates: moderate inventory/AR/fixed/restricted-cash haircuts are 10%/10%/20%/5%; severe 25%/25%/40%/10%. They reduce existing book equity without deducting its liabilities twice; no tax shield is assumed. Sale costs, claims priority and actual realizability remain unresolved, so the displayed residual is not guaranteed recovery. Unknown downside is not assigned a floor of zero percent.

The disconfirming case is real: regular debt service since April 2024, improved credit outlook, FY2026 positive CFO, stable inventory growth, established OEM relationships and potential automation benefits can rebuild cash and returns. The critical thesis-break variable is **verified post-interest operating cash after working-capital requirements, together with unrestricted funding through maturities**. Any material inventory impairment, renewed payment delay, withheld source confirmation, adverse audit qualification or unfinanced committed spending would strengthen a negative conclusion. Current evidence supports a research hold, not an allegation of impending default.

## 12. 5× / 10× Feasibility

| Target / horizon | Required price CAGR | Paths tested | Earned survivors | Hits | Minimum tested growth hitting target | Best survivor multiple |
|---|---|---|---|---|---|---|
| 5x / 5 years | 37.97% | 69 | 12 | 0 | NS | 1.54 |
| 10x / 5 years | 58.49% | 69 | 12 | 0 | NS | 1.54 |
| 5x / 10 years | 17.46% | 69 | 12 | 0 | NS | 4.01 |
| 10x / 10 years | 25.89% | 69 | 12 | 0 | NS | 4.01 |

| Target / horizon | Share basis | Necessary exit sales | Sales CAGR | Exit sold tonnes | Extra capacity capex proxy | Incremental operating capital |
|---|---|---|---|---|---|---|
| 5x / 5y | Current / 14496792 | 763.50 | 22.77% | 60,623 | 84.53 | 218.80 |
| 5x / 5y | Full proposed conversion / 18496792 | 974.16 | 28.90% | 77,350 | 128.55 | 312.91 |
| 5x / 5y | Authorized ceiling / 21000000 | 1,106.00 | 32.21% | 87,818 | 156.10 | 371.81 |
| 10x / 5y | Current / 14496792 | 1,527.00 | 41.02% | 121,246 | 244.07 | 559.90 |
| 10x / 5y | Full proposed conversion / 18496792 | 1,948.33 | 48.07% | 154,700 | 332.11 | 748.14 |
| 10x / 5y | Authorized ceiling / 21000000 | 2,212.00 | 51.87% | 175,636 | 387.20 | 865.94 |
| 5x / 10y | Current / 14496792 | 763.50 | 10.80% | 54,908 | 69.49 | 218.80 |
| 5x / 10y | Full proposed conversion / 18496792 | 974.16 | 13.53% | 70,058 | 109.36 | 312.91 |
| 5x / 10y | Authorized ceiling / 21000000 | 1,106.00 | 14.98% | 79,539 | 134.31 | 371.81 |
| 10x / 10y | Current / 14496792 | 1,527.00 | 18.75% | 109,816 | 213.99 | 559.90 |
| 10x / 10y | Full proposed conversion / 18496792 | 1,948.33 | 21.68% | 140,117 | 293.73 | 748.14 |
| 10x / 10y | Authorized ceiling / 21000000 | 2,212.00 | 23.24% | 159,079 | 343.63 | 865.94 |

The arithmetic table is an optimistic necessary-revenue diagnostic, not a forecast: required price =₹94.80×target; equity value =price×whole shares; at 15% EBITDA margin and a lower 6× exit EBITDA multiple, revenue =equity value/(0.15×6), assuming zero terminal net claims. Actual debt, fees, cash restrictions or a lower earned cash valuation require more revenue, while verified surplus cash could lower it. Current, fully converted and authorized-ceiling shares explicitly show dilution. Required sold tonnes assume 2% annual price growth from the unverified 24,000-tonne opening calibration. Extra capacity cost uses 400 annual tonnes per₹crore and 95% utilization; working capital retains the calibrated operating-capital/sales ratio. These are incremental capital needs before financing, not assumed free funds or a claim that source capex engineering is proven. Accessible market share is ND because no reliable addressable product-market denominator is available. A multiple/revenue identity cannot prove demand access or sustainable profits. The fully funded monthly grid above then tests physical capacity, financing, share limits and earned terminal returns and finds no 5× or 10× hit under its stated bounds.

A 5× price requires 37.97% annual appreciation over five years or 17.46% over ten; 10× requires 58.49% or 25.89%. The full search runs 5–60% sales growth in 2.5-percentage-point increments with 12.5%, 15% and 17.5% EBITDA margins over both horizons, retaining actual modeled capex, demand/capacity, working capital, debt service, fees, integer dilution, 21 m share authorization and earned terminal cash. A mathematical hit is still **speculative / unsupported** because the cash anchor, new finance and engineering cost assumptions are unverified. No hit means none within these explicit bounds, not impossibility across every conceivable future. Revenue or market-cap multiplication without funding and per-share dilution is rejected.

## 13. Monitoring Plan

This is a suggested research cadence, not an activated recurring task.

| KPI / evidence | Baseline | Milestone or warning threshold |
|---|---|---|
| WIP valuation and physical reconciliation | FY2026 stagewise method not implemented; inventory ₹107.40 cr | Obtain audited stagewise cost/yield reconciliation; any material unexplained write-down breaks reliability thesis |
| Receivables and confirmations | AR ₹52.69 cr; over-three-year ₹1.86 cr | Next results must show confirmed balances/collections; renewed ageing increase without allowance is adverse |
| Cash conversion after finance | FY24–26 CFO after finance negative ₹5.45 cr | Positive rolling-year post-interest operating cash without unusual creditor/tax support, not CFO headline alone |
| Current unrestricted funding | March ₹0.5167 cr before escrow; later cash composition ND | Bank-confirmed cash/undrawn sanctions and 12–18-month maturity funding; renewed servicing delay is a stop signal |
| October warrant legal/cash events | Proposed 4 m at ₹81; EGM31 Oct pending | Check actual resolution, exchange approval, allotment, object account, 25% receipt and optional exercise; no cash credit before receipt |
| Capex and operating capacity | ₹30 cr programme; FY26 output ND | Quarterly source/use and commissioned output/yield; cost overrun or unfinanced commitment requires model reset |
| Customer concentration / new LOI | ~74% major OEM concentration; no definitive new orders | New signed economic orders and collection terms; loss of major customer without funded replacement is thesis-breaking |
| Earnings per share | FY26 PAT ₹9.19 cr, EPS ₹7.09, issued 14.497 m | Growth in normalized earnings per diluted share, not merely PAT financed by issuance |
| Audit/control disclosures | PPE discrepancies; prior audit-trail and GST-interest questions | Explicit remediation and settlement chronology; silence is not cure |
| Tradability | 1,000-share lot, five unconfirmed archive absences | Current surveillance/spread/depth and official no-trade confirmation before any implementation |

## 14. Final Classification & Conditional Action

**Hold — unresolved; no numeric rank and no compounder designation.** G2 and critical unscored factors prevent the complete quality/attractiveness matrix from being meaningfully populated. The company is not forced into “high quality but expensive,” “value” or “avoid” from a partial weighted sum. Positive reported revenue growth and an approximately 15× earnings multiple do not override the reliability gate. Conversely, historical servicing problems and unmodified audit-note weaknesses are not escalated into a fabricated current-default or fraud conclusion.

The appropriate action category is further evidence-led research, not a portfolio purchase or exit instruction. Obtain reliable inventory/asset/confirmation evidence and a current source-eligible cash/debt/capex bridge; then rebuild share issuance, capacity and returns at the actual price. A lower price could improve return only after these constraints are understood. This company is researched separately as SME #362 and is not part of the frozen #341–359 release. No Git, public website or existing batch manifest is changed by this deliverable.

## 15. Sources, Assumptions & Open Questions

The ledger preserves exact URLs, source dates, original document hashes, page locators, all verified source extracts, management claims, calculations and assumptions. Original compressed PDFs and private extraction artifacts remain outside the source-safe deliverable; authored extracted inputs and reproduction code are included. The report’s physical PDF page references are one based; printed page labels may differ. Full original/restated bridges, audit counterevidence and peer caveats are appended, not replaced by a generic bibliography.

| ID | Exact primary URL | SHA256 / locator |
|---|---|---|
| AR20 | [AR20](https://sharpchucks.com/report-19-20.pdf) | c373742cf2316cab2b514a9a4b0eb3a8873c2fbcc1f41579c30c6283306e0803; Standalone original annual |
| AR21 | [AR21](https://sharpchucks.com/report-20-21.pdf) | a12870a6b4ceedb1fb04077177fb14b114bd290b8f819038d908fdfe6bb1647f; Standalone original annual |
| AR22 | [AR22](https://sharpchucks.com/report-21-22.pdf) | 6c5208e6af5d715020a40fe17a2941d0b2186e5c9303e071e92dcb34ce6e7c83; Standalone original annual |
| AR23 | [AR23](https://sharpchucks.com/report-22-23.pdf) | e9c68a84fe95fb9bb7c0db2ef60702f742f8e9147e369ac186ba1c8eb07319ec; Standalone original annual |
| AR24 | [AR24](https://www.sharpchucks.com/pdf/annual-report-23-24.pdf) | 8ffd1f2d790090b85eae22fae686734990c34a964260565eefb08c7e15706dfa; Standalone original annual |
| AR25 | [AR25](https://archives.nseindia.com/annual_reports/SME_AR_28998_SCML_2024_2025_A_2423168_09092025151324.pdf) | 83911606035f7a56e905b01b7a0395a09620d8337677887209bb72cab9d4000f; Standalone original annual |
| AR26 | [AR26](https://archives.nseindia.com/annual_reports/SME_AR_31861_SCML_2025_2026_A_3090667_08092026144726.pdf) | d051352619adf7cfe3cb8f3751591e0f7cd9dcce26dbcea336713dcbd4c4fec4; Standalone original annual |
| PROS | [PROS](https://archives.nseindia.com/emerge/corporates/content/SharpChucks_PROSP.pdf) | 387b7a7bb73458a81f939b0b7398eef7b8f6b540a29b3c8367d138bdb44185c5; FY2021–23 restated standalone |
| DRAFT | [DRAFT](https://archives.nseindia.com/emerge/corporates/content/SharpChucks_DP.pdf) | 52682714b1313c181a66204373fe6a993a7c777bd7d88a8cdac576fc8567ef0a; FY2020–22 and9MFY23 restated standalone |
| CARE2609 | [CARE2609](https://www.careratings.com/upload/CompanyFiles/PR/202609140922_Sharp_Chucks_and_Machines_Limited.pdf) | f773b600e1c69e4d88717a9550145c3c0610ca59f5ef6667ded5bb1ad37e06a3; Standalone credit opinion |
| CARE2601 | [CARE2601](https://www.careratings.com/upload/CompanyFiles/PR/202601150152_Sharp_Chucks_and_Machines_Limited.pdf) | 55d2260f30fa0a5fbb74fd3d24941aad7758051bae1ea7c53d62669b65115b85; Standalone credit opinion |
| CARE2502 | [CARE2502](https://www.careratings.com/upload/CompanyFiles/PR/202502140216_Sharp_Chucks_and_Machines_Limited.pdf) | b492dbb4fca0de9c7f52f1dba573a427190474b8d18e5704ddef46a7d1582f3b; Standalone credit opinion |
| CARE2401 | [CARE2401](https://www.careratings.com/upload/CompanyFiles/PR/202401130123_Sharp_Chucks_and_Machines_Limited.pdf) | 72e4ad43183b8b4f0324a0c97eb47903aff242d8f748aae619818ffd484834fc; Standalone credit opinion |
| EGM2610 | [EGM2610](https://sharpchucks.com/wp-content/uploads/2026/10/Notice-of-EGM-31-10-2026.pdf) | 4bf0b506e0d58cde8895e8e4b5f220232af3850136ef7e326c2d0d11d3b73f16; Proposed warrants, EGM after cutoff |
| WITHDRAW | [WITHDRAW](https://nsearchives.nseindia.com/corporate/SHARPCHUCKS_04062026181638_Intimation_30_04062026.pdf) | 26dff45db6348552cca612aad89e438e4f7ef9b0e5f445bee414a6e21759b7fd; April issue withdrawal |
| LIST2607 | [LIST2607](https://nsearchives.nseindia.com/content/circulars/CML75019.pdf) | e7153fff4e83611db80f9c904a16e4dfeff50a21ddf95f929c8c119c50c5f674; Further listing after old warrant conversion |
| IPO_USE | [IPO_USE](https://www.sharpchucks.com/pdf/Statementofdeviation.pdf) | cb77ec905214186f8a5cbfec85e02b01f158c0b28ed6128e8b95fab5bbd7085e; IPO use FY2024 |
| INDEX | [INDEX](https://sharpchucks.com/investors/) | See constituent register; Source discovery, not post-cutoff evidence |
| AR2024 | [AR2024](https://www.sharpchucks.com/pdf/annual-report-23-24.pdf) | 8ffd1f2d790090b85eae22fae686734990c34a964260565eefb08c7e15706dfa; Standalone original annual |
| AR2025 | [AR2025](https://sharpchucks.com/wp-content/uploads/2025/09/ANNUAL-REPORT-2024-25.pdf) | 83911606035f7a56e905b01b7a0395a09620d8337677887209bb72cab9d4000f; Standalone original annual |
| AR2026 | [AR2026](https://sharpchucks.com/wp-content/uploads/2026/09/annual-report-2025-26.pdf) | d051352619adf7cfe3cb8f3751591e0f7cd9dcce26dbcea336713dcbd4c4fec4; Standalone original annual |
| PROS2023 | [PROS2023](https://archives.nseindia.com/emerge/corporates/content/SharpChucks_PROSP.pdf) | 387b7a7bb73458a81f939b0b7398eef7b8f6b540a29b3c8367d138bdb44185c5; FY2021–23 restated standalone |
| EGM202610 | [EGM202610](https://sharpchucks.com/wp-content/uploads/2026/10/Notice-of-EGM-31-10-2026.pdf) | 4bf0b506e0d58cde8895e8e4b5f220232af3850136ef7e326c2d0d11d3b73f16; Proposed warrants, EGM after cutoff |
| VALUATION202610 | [VALUATION202610](https://sharpchucks.com/wp-content/uploads/2026/10/Valuation-Report-of-Preferential-Issue.pdf) | 0f80c358b5304814539d0976636a01c70de7c51f23e450490b3e4cd98d69604a; Registered-valuer report; price result crosschecked through October EGM notice, not full independent valuation review |
| EGM202604 | [EGM202604](https://sharpchucks.com/wp-content/uploads/2026/04/Notice_SCML.pdf) | 6d1a6a8f1c6729401f6636f00753bbb518803372d36964c30e63c53f0b01c1cb; Notice of 6 May 2026 EGM; capital increase and subsequently withdrawn financing |
| IPO_USE2024 | [IPO_USE2024](https://www.sharpchucks.com/pdf/Statementofdeviation.pdf) | cb77ec905214186f8a5cbfec85e02b01f158c0b28ed6128e8b95fab5bbd7085e; IPO use FY2024 |
| CARE202609 | [CARE202609](https://www.careratings.com/upload/CompanyFiles/PR/202609140922_Sharp_Chucks_and_Machines_Limited.pdf) | f773b600e1c69e4d88717a9550145c3c0610ca59f5ef6667ded5bb1ad37e06a3; Standalone credit opinion |
| CARE202601 | [CARE202601](https://www.careratings.com/upload/CompanyFiles/PR/202601150152_Sharp_Chucks_and_Machines_Limited.pdf) | 55d2260f30fa0a5fbb74fd3d24941aad7758051bae1ea7c53d62669b65115b85; Standalone credit opinion |
| CARE202502 | [CARE202502](https://www.careratings.com/upload/CompanyFiles/PR/202502140216_Sharp_Chucks_and_Machines_Limited.pdf) | b492dbb4fca0de9c7f52f1dba573a427190474b8d18e5704ddef46a7d1582f3b; Standalone credit opinion |
| CARE202401 | [CARE202401](https://www.careratings.com/upload/CompanyFiles/PR/202401130123_Sharp_Chucks_and_Machines_Limited.pdf) | 72e4ad43183b8b4f0324a0c97eb47903aff242d8f748aae619818ffd484834fc; Standalone credit opinion |
| DRHP2023 | [DRHP2023](https://archives.nseindia.com/emerge/corporates/content/SharpChucks_DP.pdf) | 52682714b1313c181a66204373fe6a993a7c777bd7d88a8cdac576fc8567ef0a; FY2020–22 and9MFY23 restated standalone |
| LIST202607 | [LIST202607](https://nsearchives.nseindia.com/content/circulars/CML75019.pdf) | e7153fff4e83611db80f9c904a16e4dfeff50a21ddf95f929c8c119c50c5f674; Further listing after old warrant conversion |
| CANCEL202606 | [CANCEL202606](https://nsearchives.nseindia.com/corporate/SHARPCHUCKS_04062026181638_Intimation_30_04062026.pdf) | 26dff45db6348552cca612aad89e438e4f7ef9b0e5f445bee414a6e21759b7fd; April issue withdrawal |
| CS202610 | [CS202610](https://sharpchucks.com/wp-content/uploads/2026/10/Certificate-under-Regulation-163-2-of-the-SEBI-ICDR-Regulations-2018.pdf) | 8949f960cd251d5e0059cdf7a21944bc20b7d77896a1f90635fd656c6a724ee6; Limited preferential-issue Chapter V compliance certificate; not evidence of receipt/allotment approval |
| VOTE202605 | [VOTE202605](https://nsearchives.nseindia.com/corporate/SHARPCHUCKS_06052026205229_SCML_Voting_results.pdf) | b12fc175c1c0148fad589299ae7f391f8ab24bba8f02fab4ffddf1726281e37b; NSE voting results confirming authorized-capital resolution and other EGM resolutions |
| ORIG2020 | [ORIG2020](https://sharpchucks.com/report-19-20.pdf) | c373742cf2316cab2b514a9a4b0eb3a8873c2fbcc1f41579c30c6283306e0803; Standalone original annual |
| ORIG2021 | [ORIG2021](https://sharpchucks.com/report-20-21.pdf) | a12870a6b4ceedb1fb04077177fb14b114bd290b8f819038d908fdfe6bb1647f; Standalone original annual |
| ORIG2022 | [ORIG2022](https://sharpchucks.com/report-21-22.pdf) | 6c5208e6af5d715020a40fe17a2941d0b2186e5c9303e071e92dcb34ce6e7c83; Standalone original annual |
| ORIG2023 | [ORIG2023](https://sharpchucks.com/report-22-23.pdf) | e9c68a84fe95fb9bb7c0db2ef60702f742f8e9147e369ac186ba1c8eb07319ec; Standalone original annual |

Critical unresolved questions are inventory cost verification; the historical CARO/default chronology; unpaid GST-interest treatment/settlement; complete FY2026 signed audit-trail reporting; current unrestricted bank cash and sanctioned headroom; April–October principal/capex movements; detailed loan subtotal reconciliation; latest physical output and project cost per capacity unit; full capital-return attribution; actual warrant approval/allotment/use; current promoter pledge and market restrictions; and independent no-trade confirmations. None is filled by an invented zero, assumed cure or sector median.

There are **203 full monthly paths**, of which **137 fail** under their stated conditional assumptions. All paths, including failures and grids, are retained in canonical_paths.json.gz. Every input, monthly event, share count, cash bucket, annual aggregation, formula and assumption is reproducible offline from authored inputs. No path is source-eligible as a current forecast. Canonical compressed trace SHA256: b764735393d48863c4b6bb02efe03f55aeb4ef6e5931e0f6ace9dae872b313a5. Authored input aggregate SHA256: de43c24363534a6844ac406ea798878341803079186047a4440db4a9d1ff98b9. These bind distinct roles and are not substituted for report, archive or Library-version hashes.

### Sixteen quality checks

1. Correct security, legal issuer, standalone scope, cutoff and source-vintage dates.
2. Primary material, original annuals and prospectus vintages reviewed; facts, management claims, assumptions and inferences separated.
3. Audit, CARO, IFC, related parties, prior defaults and dilution reviewed with resolved counterevidence.
4. Comparable periods, units and revenue definitions; no invented TTM or annualized quarter.
5. Revenue growth and scale separated from PAT, price, mix, capacity and a small-base effect.
6. CFO/PAT is ratio of sums; interest classification, tax lag and working-capital drivers reconciled.
7. Incremental capital numerator, denominator, bridge, attribution and NS limitation explicit.
8. Earnings normalization, claims, cash restrictions, share issuance and leases consistent.
9. Monthly operating cash, capacity, capex, debt, fees, tax and whole-share financing reconcile.
10. Thirteen canonical factors reused, exact Decimal weights sum to one.
11. Missing factors are NS, never zero or renormalized; coverage and dependency-aware bounds shown.
12. Raw scores, caps and gates reconcile without inventing adverse evidence.
13. Classification and compounder label obey evidence and gates, not a low valuation multiple.
14. Liquidity uses verified official archives, ₹5 lakh reference and whole lots; missing rows are not zero-filled facts.
15. Strongest bear case, disconfirming evidence and thesis-break monitor are actionable.
16. Same framework and tie policy; this unresolved company is excluded from numeric rankings and frozen publication.

### Appendix A: Original audit, restatement and capital evidence

#### Sharp Chucks and Machines Limited: audit, governance and capital reconciliation

**Security:** SCML, NSE SME; ISIN INE460Q01014. **Information cutoff:** 20 October 2026. Financial amounts below are ₹ lakh unless explicitly identified as ₹ crore or rupees. PDF page references are physical, one-based pages, not the page number printed on the report. This is a primary-source research assessment, not an allegation of fraud or a representation that the company is currently in default.

##### Decision-useful conclusion

An accounting-quality **Hold pending evidence** is justified, rather than either a clean governance pass or a fraud/default fail. Work-in-progress valuation methodology, fixed-asset reconciliation and external balance confirmations remain unresolved. GST-interest disclosures show cash-basis recognition in FY2024–25 without a traced FY2026 settlement bridge. CARE's report of December 2023 and March 2024 debt-service delays conflicts with FY2024 CARO's no-default statement. These are specific evidence requests, not proof of invented inventory, diverted cash, or current default.

Counterevidence must remain prominent: the original FY2020–FY2026 financial-statement opinions and internal-financial-control opinions are unmodified. CARE reports regular term-debt servicing from April 2024 and, in September 2026, rates the company BB+/Positive with adequate liquidity. The auditor transition was explained by term expiry, not a documented disputed dismissal. The large apparent FY2022 physical-cash balance is predominantly cheques/drafts, not currency. April 2026 proposed financing was withdrawn and must not be included as pending dilution.

The March 2026 cash figure is mostly restricted deposits. It cannot be treated as freely spendable cash, but it also cannot establish an October 2026 cash deficit. The October warrants were still proposed at the cutoff; no future approval, allotment, exercise, or proceeds should be presented as certain.

##### 1. Original audit opinions and changes in audit coverage

| Original period | Auditor and report date | Physical PDF pages | Finding and limitation |
|---|---|---|---|
| FY2020 | Sharp & Tannan; 8 December 2020 | [Original FY2020](https://sharpchucks.com/report-19-20.pdf), pp1,4–6,9 | Unmodified opinion and IFC. CARO reports no material PPE discrepancy, immaterial inventory discrepancies reconciled, and no debt default. |
| FY2021 | Sharp & Tannan; 30 November 2021 | [Original FY2021](https://sharpchucks.com/report-20-21.pdf), pp1,4–6,9 | Unmodified opinion and IFC; no material PPE/inventory discrepancy and no debt default reported. |
| FY2022 | Sharp & Tannan; 19 September 2022 | [Original FY2022](https://sharpchucks.com/report-21-22.pdf), pp1,4–5,7–9,11 | Unmodified opinion and IFC. Bank quarterly returns agree with books; no debt default or use of short-term funds for long-term purposes reported. |
| FY2023 | Sharp & Tannan; 7 September 2023 | [Original FY2023](https://sharpchucks.com/report-22-23.pdf), pp1,5–8,10,12 | Unmodified opinion and IFC. PPE discrepancies reported; ₹608.41 lakh of short-term funds used for plant/machinery. CSR ₹10.49 lakh provided but unspent through audit date. The inventory paragraph refers to additional notes, while reporting no material physical-count discrepancy. |
| FY2024 | Sharp & Tannan; 29 May 2024 | [AR2024](https://www.sharpchucks.com/pdf/annual-report-23-24.pdf), pp50,53–56,60 | Unmodified opinion and IFC. Audit-trail software exception, PPE discrepancies and ₹523.38 lakh short-term funds used for long-term purposes. CARO says no default to any lender. |
| FY2025 | V. P. Bhalla & Associates; 30 May 2025 | [AR2025](https://sharpchucks.com/wp-content/uploads/2025/09/ANNUAL-REPORT-2024-25.pdf), pp33,35–41 | Unmodified opinion and IFC. Audit-trail exception and PPE reconciliation issue persist. ₹523.38 lakh short-term funds used for long-term purposes is repeated. CARO reports no default. |
| FY2026 | V. P. Bhalla & Associates; 30 May 2026 | [AR2026](https://sharpchucks.com/wp-content/uploads/2026/09/annual-report-2025-26.pdf), pp41,43–49,51 | Unmodified opinion and IFC; PPE discrepancies persist and no default is reported. The audit-trail paragraph and the prior short-term-use paragraph are absent. Absence is not affirmative evidence of remediation. |

The FY2024 audit report's exception concerns software audit trails and the proper-books reporting paragraph, not a qualified financial-statement opinion. FY2025 repeats the exception. FY2026 omits the corresponding Rule 11(g) paragraph; request a complete signed report or explicit implementation/remediation evidence rather than interpreting silence as either continuing breach or cure.

The FY2024 AGM notice and directors' report explain that Sharp & Tannan's 2019–2024 term was expiring and propose V. P. Bhalla for 2024–2029 ([AR2024](https://www.sharpchucks.com/pdf/annual-report-23-24.pdf), pp5,18). FY2025 CARO says the outgoing auditor raised no concern. FY2026 front matter still lists Sharp & Tannan and CARO repeats the resignation narrative, although V. P. Bhalla signed both FY2025 and FY2026. These are stale-reference/control-quality issues, not evidence by themselves of opinion shopping.

###### Historical debt-service contradiction, with subsequent cure evidence

[CARE's 11 January 2024 release](https://www.careratings.com/upload/CompanyFiles/PR/202401130123_Sharp_Chucks_and_Machines_Limited.pdf), p1, assigns D/issuer-noncooperating and refers to public information about debt-service delays. This is not solely a missing-information rating. [CARE's 18 February 2025 release](https://www.careratings.com/upload/CompanyFiles/PR/202502140216_Sharp_Chucks_and_Machines_Limited.pdf), p2, and [9 January 2026 release](https://www.careratings.com/upload/CompanyFiles/PR/202601150152_Sharp_Chucks_and_Machines_Limited.pdf), p2, specify delays in December 2023 and March 2024, followed by regular term-debt servicing from April 2024. FY2024 CARO nevertheless reports no default in principal or interest to any lender ([AR2024](https://www.sharpchucks.com/pdf/annual-report-23-24.pdf), p56).

This requires a facility-level reconciliation of missed instalment/interest dates, amounts, days past due, regularisation and the CARO assessment. Do not state that default continues. [CARE's 7 September 2026 release](https://www.careratings.com/upload/CompanyFiles/PR/202609140922_Sharp_Chucks_and_Machines_Limited.pdf), pp1–3, is affirmative later counterevidence: BB+/Positive, adequate liquidity and projected FY2027 gross cash accruals of ₹29 crore against ₹9.78 crore repayments. It also retains financing constraints, including 98% working-capital utilisation over the twelve months through July 2026 and approximately ₹30 crore capex.

##### 2. Restatement vintage bridge: do not combine incompatible series

The final prospectus Annexure V supplies the following original-to-restated PAT bridge. FY2020 is available in the draft prospectus, not the final three-year restated set.

| Fiscal year | Original PAT | Restatement adjustment to PAT | Restated PAT | Primary locator |
|---|---:|---:|---:|---|
| 2020 | 314.63 | -16.28 | 298.35 | [Draft prospectus](https://archives.nseindia.com/emerge/corporates/content/SharpChucks_DP.pdf), p226, printed p224 |
| 2021 | 380.52 | -49.56 | 330.96 | [Final prospectus](https://archives.nseindia.com/emerge/corporates/content/SharpChucks_PROSP.pdf), p208, printed p207 |
| 2022 | 453.97 | -1.35 | 452.62 | Same |
| 2023 | 473.39 | +33.11 | 506.50 | Same |

Using expense signs, FY2023 adjustments comprise GST interest +10.05, deferred tax -1.67, tax/MAT -37.90, excess MSME-interest provision reversal -6.59 and IPO professional fees +3.00. The net expense adjustment is -33.11, hence PAT increases by 33.11. FY2022 is GST +7.39, deferred tax -0.12 and tax/MAT -5.92. FY2021 is MSME +7.09, GST +8.72, deferred tax +0.74 and tax/MAT +33.01. The draft FY2020 bridge is MSME +17.60, GST +10.42, deferred tax -14.61 and tax/MAT +2.87. See the same Annexure V pages above.

Final-prospectus net worth is 4,275.67 / 4,728.29 / 5,234.79 for FY2021/22/23, versus originals 4,284.20 / 4,738.17 / 5,211.56. Draft FY2021/22 restated net worth is 4,287.75 / 4,740.37, or 12.08 higher in each year than the final prospectus, despite the same restated PAT. The full journal explanation for that draft-to-final opening-equity difference was not located. Prefer the final prospectus consistently; identify any FY2020 draft-vintage number explicitly.

The final prospectus reclassifies director/promoter loans from other long-term liabilities to borrowings: FY2021 222.22, FY2022 328.22 and FY2023 316.32. Debt comparisons must include them on a common basis. The FY2023 PSPCL rebate of 218.00 moves from net power/fuel expense to other income. This is a presentation change, not another 218.00 of PAT. Original total revenue 17,706.86 becomes final restated 17,931.45 because of that 218.00 reclassification and 6.59 provision reversal. Sources: [Final prospectus](https://archives.nseindia.com/emerge/corporates/content/SharpChucks_PROSP.pdf), pp193,208; [Original FY2023](https://sharpchucks.com/report-22-23.pdf), pp22,33.

The final restatement auditor's report discusses the CSR exception and adjustments; it does not transform all original statutory opinions into qualified opinions ([Final prospectus](https://archives.nseindia.com/emerge/corporates/content/SharpChucks_PROSP.pdf), p187).

##### 3. Unresolved asset and earnings-quality evidence

###### Inventory and PPE

FY2024 note 30(O) reports inventory of 7,608.13 without stage-wise WIP tracking. An independent cost accountant valued it, but the basis was not provided for verification. FY2025 and FY2026 again say stage-wise tracking methodology is not followed and rely on the cost accountant. FY2026 inventory is 10,739.97, including WIP 4,880.54, against total assets 29,346.46. Fixed-asset physical/book reconciliation is described as still being upgraded. Sources: [AR2024](https://www.sharpchucks.com/pdf/annual-report-23-24.pdf), pp55,85; [AR2025](https://sharpchucks.com/wp-content/uploads/2025/09/ANNUAL-REPORT-2024-25.pdf), pp36–37,63; [AR2026](https://sharpchucks.com/wp-content/uploads/2026/09/annual-report-2025-26.pdf), pp46,59,74.

The material question is valuation/stage reconciliation, not a disclosed material physical-stock shortage. CARO reports no material inventory discrepancies, bank quarterly returns agreeing with books, and unmodified IFC opinions. Required evidence: product/stage quantities and ageing, cost-accountant valuation workings, reconciliation to general ledger and lender returns, audit testing that overcomes the stated limitation, and quantified PPE adjustments.

###### GST interest and confirmations

FY2024 note 30(N) identifies current-year GST interest of 7.71 plus 48.66 for FY2020–23, pending deposition and to be recorded on a cash basis. FY2025 note 30(M) discloses current-year 6.38 on a cash basis without the earlier cumulative balance. The equivalent FY2026 paragraph is absent. The prospectus had explicitly restated GST-interest accruals, making a year-by-year original/restated/booked/paid/reversed bridge essential. Do not automatically add the disclosed historical amounts to current debt or expenses because settlement and double counting are unresolved. Sources: [AR2024](https://www.sharpchucks.com/pdf/annual-report-23-24.pdf), p85; [AR2025](https://sharpchucks.com/wp-content/uploads/2025/09/ANNUAL-REPORT-2024-25.pdf), p63; [AR2026](https://sharpchucks.com/wp-content/uploads/2026/09/annual-report-2025-26.pdf), p74; [Final prospectus](https://archives.nseindia.com/emerge/corporates/content/SharpChucks_PROSP.pdf), p208.

FY2024 and FY2026 notes state that debtor, creditor and loan/advance balances are subject to confirmation and that differences will be dealt with in the reconciliation year. FY2026 receivables are 5,269.31, advances to parties 932.99 and trade payables 4,311.62. Request external confirmations and subsequent collection/payment testing. No quantified misstatement or disputed balance was established. Sources: [AR2024](https://www.sharpchucks.com/pdf/annual-report-23-24.pdf), p90; [AR2026](https://sharpchucks.com/wp-content/uploads/2026/09/annual-report-2025-26.pdf), pp58–59,78.

###### Related parties, insurance and compliance

FY2026 discloses sales of 1,197.21 and purchases of 698.52 with Sharp Precision Private Limited, versus zero in FY2025. Directors' remuneration is 72.00; director travel 12.03; new unsecured borrowing 6.90; total loan/advance payables to directors and others are 16.82. This is disclosed RPT activity, not proof of circular sales. The directors' claim of no materially significant conflicting RPTs does not mean there were no RPTs. CARO reports Sections 177/188 compliance. Seek ownership/control mapping, approval and pricing support, product flows and settlement/outstanding trade balances. Source: [AR2026](https://sharpchucks.com/wp-content/uploads/2026/09/annual-report-2025-26.pdf), pp21,48,70–71.

An 8.73 insurance receipt for a flood-damaged factory wall was credited against insurance expense in FY2026, with repairs to be expensed when incurred in the next year. Separate this credit and future repair cost in sustainable earnings; its size is less than 1% of FY2026 PAT before tax effect and it is expressly disclosed. Source: [AR2026](https://sharpchucks.com/wp-content/uploads/2026/09/annual-report-2025-26.pdf), p74, note 30(P).

FY2025 secretarial audit reports a ₹519,200 NSE fine for not applying for preferential-share listing within seven working days, paid 20 December 2024. FY2026 reports a paid ₹2,000 Regulation 34 fine and some late ROC forms. These matter to compliance quality but should not be described as major enforcement sanctions. Sources: [AR2025](https://sharpchucks.com/wp-content/uploads/2025/09/ANNUAL-REPORT-2024-25.pdf), p27; [AR2026](https://sharpchucks.com/wp-content/uploads/2026/09/annual-report-2025-26.pdf), p32.

FY2023 CSR of 10.49 was booked but unpaid at audit date; subsequent years report spending and FY2026 spent 17.50 against a 17.37 requirement. FY2023 CARO lists an income-tax dispute of 38.25 net of a 9.57 predeposit; later contingent-liability/CARO disclosures do not repeat it. Neither current unpaid CSR nor current adverse tax liability should be inferred without an updated case or payment status. Sources: [Original FY2023](https://sharpchucks.com/report-22-23.pdf), pp7,10; [AR2026](https://sharpchucks.com/wp-content/uploads/2026/09/annual-report-2025-26.pdf), pp60,76–77.

##### 4. Cash restrictions and debt schedule

As of 31 March 2026, cash/bank totals 1,042.36, but 990.69 comprises fixed deposits held as security and unavailable for immediate use. The remaining 51.67 is cash 33.94 plus bank balances 17.73. Treat 51.67 as a ceiling before any other restrictions, not assured free cash. Unutilised IPO escrow 1.25 is separately disclosed; its overlap with bank balances needs reconciliation, so do not subtract it twice. The 90.91 LC-margin deposit is not proven additional to the 990.69 restricted-deposit total. The 300.00 LC facility is contingent, not automatically drawn debt. Sources: [AR2026](https://sharpchucks.com/wp-content/uploads/2026/09/annual-report-2025-26.pdf), pp59–60,73–74.

FY2025 gross cash/bank 936.86 less restricted deposits 917.05 leaves 19.81; individual cash/bank components total 19.82, a 0.01 rounding difference. For later-period counterevidence, CARE reports ₹11.42 crore cash and liquid investments at 30 June 2026, but does not bridge these to the March restricted deposits. October cash requires an actual bank/deposit roll-forward, not merely extrapolation from the audited anchor. Source: [CARE September 2026](https://www.careratings.com/upload/CompanyFiles/PR/202609140922_Sharp_Chucks_and_Machines_Limited.pdf), pp2–3.

At 31 March 2026, term debt is 2,488.43, split into noncurrent 1,510.70 and current 977.73. Short-term borrowings are 9,608.22. Total debt excluding director loans is 12,096.65; including 16.82 interest-free director/other loans classified under other long-term liabilities gives 12,113.47. Maturities are FY2027 977.73; FY2028 869.92; FY2029 527.78; FY2030 onward 112.99. These sum to 2,488.42, within 0.01 of gross term debt, consistent with component rounding. Individual lender subtotals presented in the note add to 2,466.11, leaving an unexplained 22.32. Sources: [AR2026](https://sharpchucks.com/wp-content/uploads/2026/09/annual-report-2025-26.pdf), pp52,56–60.

Two FY2026 printed numbers are demonstrably wrong, not OCR artifacts: note 27 depreciation is printed as 0.01, whereas the P&L and PPE schedule support 795.14; note 8 prints FY2025 current term maturities as 0.01, whereas the balance sheet and borrowing note support 1,114.07. Several note headings say rupees even though the numbers reconcile in lakh. Use reconciled headline numbers and seek corrected signed schedules; do not let a unit-label error create an artificial insolvency or an automatic gate failure. Sources: [AR2026](https://sharpchucks.com/wp-content/uploads/2026/09/annual-report-2025-26.pdf), pp52–53,56,58,62,80. The actual rendered pages were inspected.

###### Resolved apparent FY2022 cash anomaly

The final prospectus cash-flow label shows 2,528.52 as cash in hand for FY2022, but note 20 splits that into actual currency of 5.52 and cheques/drafts of 2,523.00. FY2023 combined 89.69 similarly comprises 14.69 currency and 75.00 cheques. The original FY2023 note confirms the components. This resolves the allegation that ₹25.29 crore was literal physical cash; cheque clearance/collection dates remain a valid follow-up. Deposits of 48.97 / 28.18 in FY2022/23 have long-maturity/security restrictions. Sources: [Final prospectus](https://archives.nseindia.com/emerge/corporates/content/SharpChucks_PROSP.pdf), pp194,200; [Original FY2023](https://sharpchucks.com/report-22-23.pdf), p29.

##### 5. Issued capital, withdrawn issue and conditional October warrants

###### Current shares and authorisation

Issued capital is **14,496,792 shares**, not that number plus the old 2,412,000 warrants again. Those warrants converted on 17 November 2025 at ₹76.12. The NSE's July 2026 circular confirms the resulting shares and admitted them to dealings from 3 July 2026. Sources: [AR2026](https://sharpchucks.com/wp-content/uploads/2026/09/annual-report-2025-26.pdf), pp18,48,55–56; [NSE CML75019](https://nsearchives.nseindia.com/content/circulars/CML75019.pdf), pp1–2.

March 2026 authorised capital is 17,500,000 shares. The April notice proposed a separate increase to **21,000,000** shares and the May 6 voting result confirms that resolution passed with 99.97% votes in favour. June's cancellation of preferential financing does not state that the separate capital resolution was reversed. Therefore, do not claim that full October conversion exceeds the approved 21 million share authorisation; actual Registrar filing/effectiveness was not separately inspected. Sources: [April EGM notice](https://sharpchucks.com/wp-content/uploads/2026/04/Notice_SCML.pdf), pp1,25; [May 6 NSE voting results](https://nsearchives.nseindia.com/corporate/SHARPCHUCKS_06052026205229_SCML_Voting_results.pdf), p2.

###### April proposal cancelled

The April proposal comprised 2,637,000 equity shares and 3,063,000 warrants at ₹142.50, for potential proceeds of ₹81.225 crore. It was approved by shareholders in May but **withdrawn and cancelled on 4 June 2026**, citing market volatility and changed share price. Exclude all 5.7 million potential shares and all associated proceeds from active dilution/funding scenarios. The primary cancellation filing is decisive, not an inference from later share counts. Source: [NSE June 4 cancellation](https://nsearchives.nseindia.com/corporate/SHARPCHUCKS_04062026181638_Intimation_30_04062026.pdf), pp1–2.

###### October proposal remained unapproved at the cutoff

The board proposed 4,000,000 warrants at ₹81, totalling ₹32.40 crore if fully subscribed and exercised. The shareholder EGM was scheduled for 31 October 2026, after the cutoff. The October notice says there are no other outstanding convertibles. Half the warrants are for promoter/group members and half for public investors. Full conversion would create **18,496,792 shares**; promoter/group holding would rise from 9,230,542 shares (63.67%) to 11,230,542 shares (60.72%). Source: [October EGM notice](https://sharpchucks.com/wp-content/uploads/2026/10/Notice-of-EGM-31-10-2026.pdf), pp1,20–24.

The exact contractual timing is relative, not a calendar promise:

- 25%, or ₹8.10 crore at full subscription, is payable on warrant subscription/allotment.
- Remaining 75%, or ₹24.30 crore, is payable only on exercise.
- Warrants may be exercised in one or more tranches within **18 months of actual allotment**. No fixed first exercise date or known final calendar date exists at the cutoff.
- Warrant allotment is required within 15 days of the shareholder resolution, or within 15 days of the last pending regulatory approval. In-principle stock-exchange approval is expressly required.
- Shares after exercise are to be allotted within 15 days of exercise.
- Unexercised warrants lapse at 18 months, and the upfront amount is forfeited.

Sources: [October EGM notice](https://sharpchucks.com/wp-content/uploads/2026/10/Notice-of-EGM-31-10-2026.pdf), pp3–4,17–18,22. A model may use November 2026 allotment and May 2028 full exercise **only as a conditional scenario**. It must not label those dates legal certainties or treat optional exercise cash as a committed loan/refinancing source.

Proposed full proceeds allocations are working capital ₹6.50 crore, land/development rights ₹4.50 crore, manufacturing facilities ₹3.00 crore, equipment/tooling ₹6.65 crore, strategic investment ₹3.75 crore and general corporate purposes ₹8.00 crore. Management estimates use within 12 months of receipt of each tranche. The objects are not externally appraised; the notice says the issue is below the ₹100 crore threshold for mandatory monitoring-agency appointment. Source: [October EGM notice](https://sharpchucks.com/wp-content/uploads/2026/10/Notice-of-EGM-31-10-2026.pdf), pp18–20,27.

The notice states a regulatory floor of ₹80.41 (90-day VWAP; 10-day VWAP ₹74.04), registered-valuer result ₹80.32 and selected price ₹81. The [October company-secretary certificate](https://sharpchucks.com/wp-content/uploads/2026/10/Certificate-under-Regulation-163-2-of-the-SEBI-ICDR-Regulations-2018.pdf), pp1–2, is limited compliance assurance, not evidence that shareholders/exchange approved the issue or that money was received.

##### 6. Minimum evidence to resolve the Hold

1. Independent cost-accountant WIP workings and inventory/PPE quantity, stage, ageing and valuation reconciliations, with the auditor's explanation of how disclosed limitations were addressed.
2. FY2020–FY2026 GST-interest journal/payment bridge, including how original and prospectus-restated accruals were incorporated or reversed.
3. External bank evidence reconciling the CARE-described December 2023/March 2024 delays with FY2024 CARO, plus current sanction terms, lender confirmations and deposit restrictions.
4. Actual June-to-October 2026 bank/deposit/capex/debt roll-forward, including whether CARE's liquid investments are restricted; no funding conclusion should depend on an unlabelled stale March cash anchor.
5. Debtor/creditor/advance confirmations and subsequent settlement evidence; Sharp Precision ownership, pricing, product flow and settlement support.
6. Corrected audit-trail reporting, signed financial-note corrections and the 22.32 term-debt schedule reconciliation.
7. Registrar evidence for the authorised-capital increase; if the October raise is relied on, post-cutoff shareholder/exchange approvals, allotment dates, actual 25% receipts and later conversion receipts. Those future events are outside this historical cutoff.

##### Source and inspection limitations

The original FY2020–23 investor-page links under `/pdf/` returned 404, but the issuer's root-level `report-19-20.pdf` through `report-22-23.pdf` files were recovered and inspected. The FY2023 uploaded file includes the original audit and financial statements but the referenced accounting-policy/additional-note pages were not located; no claim is made that those missing original notes were reviewed. FY2024–25 scanned passages were OCRed and material anomalies visually checked. Exact URLs, source SHA-256 hashes, audit dates, numerical bridges and unresolved/counterevidence fields are preserved in the accompanying `audit_inputs.json`. No inference of misconduct rests solely on OCR, duplicated templates, a clean-opinion label, or a future modelled cash gap.


### Appendix B: Primary economic peers

#### Sharp Chucks and Machines: economic peer comparison

Information cutoff: 20 October 2026. Share-price reference: 19 October 2026. Financial comparison: common audited FY26, not TTM. All amounts below are ₹ crore unless indicated. This is an independently authored extraction of original reports, not a reuse of previous peer conclusions.

##### Bottom line

These peers do not support awarding Sharp a generic “precision engineering” multiple. They illustrate three different ways manufacturing profits can fail to become shareholder cash: Pritika's group-funded expansion, Nelcast's heavy installed capital and export/cycle sensitivity, and Talbros' specialized forging growth that still consumes more cash capex than reported CFO. The useful benchmark is sustainable return on all financial capital and cash remaining after investment and interest, not headline EBITDA margin or one year's CFO/PAT.

##### Comparable FY26 measures

Operating EBITDA excludes all other income and exceptional gains for a consistent baseline. This strips out FX gains too, although some are operationally related; it is a measurement convention, not a claim all other income is non-recurring. Pretax operating return below is operating EBIT divided by average equity plus interest-bearing debt less cash. It is a common book-capital proxy, not company-reported ROCE or economic ROIC. Group equity includes NCI where present. Cash capex is gross asset-purchase cash outflow without deducting disposals.

| Metric | Pritika Engineering | Nelcast | Talbros Engineering |
|---|---:|---:|---:|
| Financial perimeter | Consolidated | Consolidated | Standalone FY26 |
| Revenue | 161.87 | 1,328.40 | 535.76 |
| Revenue growth | 37.90% | 6.13% | 20.10% |
| Operating EBITDA | 21.51 | 110.50 | 60.43 |
| Operating EBITDA margin | 13.29% | 8.32% | 11.28% |
| Same-basis FY25 margin | 15.56% | 7.07% | 11.16% |
| PAT | 7.31 | 48.43 | 29.16 |
| Reported CFO | 22.97 | 91.58 | 44.56 |
| Reported CFO/PAT | 3.14x | 1.89x | 1.53x |
| Gross cash capex | 42.49 | 17.74 | 52.64 |
| Cash capex/revenue | 26.25% | 1.34% | 9.82% |
| Reported CFO less gross capex | -19.52 | 73.84 | -8.08 |
| CFO less interest and gross capex | -25.67 | 41.31 | -8.08, as reported* |
| Debt/equity, all BS borrowings | 1.85x | 0.43x | 0.81x |
| Operating EBIT/finance cost | 2.37x | 2.57x | 3.87x |
| Revenue/average total assets | 0.85x | 1.12x | 1.49x |
| Pretax operating return, common formula | 10.90% | 10.82% | 15.67% |
| Verified 19 October close, ₹ | 80.00 | 133.79 | ND |

*Talbros' CFO already deducts interest; its statement has no separately labelled cash-tax payment. The result is not presented as normalized after-tax free cash flow. Pritika and Nelcast classify interest in financing, so comparing their unadjusted CFO-minus-capex directly with Talbros would overstate their relative cash generation. Pritika's reported CFO is additionally dependent on related-party customer advances.

Sources: Pritika annual report printed pp176–178; Nelcast pp146–149; Talbros pp84–86. Exact inputs, source hashes and formulas are in `peer_inputs.json`; `build_peer_inputs.py` regenerates the derived measures.

##### Pritika Engineering: closest tractor casting exposure, but financing through the parent matters

Pritika manufactures machined/cast tractor and commercial-vehicle components, with Meeta Castings consolidated. Its listed parent, Pritika Auto Industries, remains outside this consolidation. Sales to the parent were ₹143.03 crore, 88.36% of consolidated FY26 revenue. The parent's distribution relationship, guarantees and funding are meaningful support, not an independent-customer moat to apply to Sharp.

Growth of 37.90% came with operating EBITDA margin compression from 15.56% to 13.29%. Gross cash capex of ₹42.49 crore, 26.25% of revenue, exceeded reported CFO by ₹19.52 crore even before ₹6.15 crore interest. Debt increased from ₹71.15 crore to ₹98.16 crore. Installed capital is still ramping: PPE, CWIP and development balances together were ₹137.49 crore at year end. Asset turnover of 0.85x and pretax book-capital return of 10.90% qualify the apparently high EBITDA margin.

Cash quality is the crucial distinction. FY26 CFO includes ₹27.39 crore of inflow from other non-current liabilities. Note19 identifies the dominant balance as related-party advances against supplies, which increased from ₹21.77 crore to ₹49.37 crore. Simply removing the cash-flow statement's other-non-current-liability inflow produces a diagnostic -₹4.42 crore CFO. This is not a restatement or proof that customer advances are illegitimate financing: it isolates dependence on continued group support. The advances' balance-sheet movement is not exactly the cash-flow line, so they must not be treated as interchangeable.

CARE's 28 November 2025 rationale confirms low OEM bargaining power, quarter-lag raw-material pass-through and significant parent links. Its reported FY25 standalone gearing is not substituted for the FY26 consolidated ratio here. No current P/E is published: the 17 October securities allotment and warrant dilution need a separate current-share bridge.

Primary sources: [FY26 report](https://archives.nseindia.com/annual_reports/SME_AR_30579_PRITIKA_2025_2026_A_2593334_25082026110408.pdf), [CARE rationale](https://www.careratings.com/upload/CompanyFiles/PR/202511141136_Pritika_Engineering_Components_Limited.pdf).

##### Nelcast: scale, diversification and cash release, not automatically superior returns

Nelcast is a larger ductile/grey iron foundry with three facilities and 160,000 MTPA capacity. More than50 customers and an export/domestic mix diversify it beyond a single captive parent relationship. ICRA's March 2026 report gives 9M FY26 shares of 39.6% domestic M&HCV, 25.7% tractors and 29.4% exports; its largest customer contributed 17%. Those are period-specific rating data, not invented FY26 full-year segment figures.

FY26 revenue grew 6.13%, operating EBITDA margin rose to 8.32%, and reported CFO was ₹91.58 crore against gross asset cash purchases of ₹17.74 crore. The positive cash spread remains ₹41.31 crore after interest. Total borrowings declined from ₹294.45 crore to ₹257.19 crore, while balance-sheet cash rose to ₹84.77 crore. Yet the common pretax operating return is only 10.82%, despite the capital base being far more mature than Pritika's. Good current-year cash release and credit quality do not establish a high-return compounder.

Two safeguards matter. First, the investing statement separately shows ₹1.68 crore positive CWIP movement in FY26 and₹54.50 crore in FY25. Gross cash-purchase lines are preserved without netting those movements; FY25's apparent ₹93.21 crore gross purchases must not be interpreted as wholly new economic investment without reconciling transfers out of CWIP. Second, the cash-flow statement nets cash-credit balances into its closing cash; our net-debt calculation instead uses positive BS cash with cash credit retained in debt, avoiding double counting.

Most importantly, ICRA's March expectation of no major debt-funded capex was overtaken before the cutoff. On 5 October 2026, the board approved approximately ₹75 crore for a Gudur machining division, funded by internal accruals and borrowings. That is a new investment phase, about 4.2x FY26 gross cash asset purchases. Do not mechanically extrapolate the unusually low FY26 capex burden or cite the old rating assumption as current. US/export exposure, raw-material pass-through and CV cycles remain relevant.

Primary sources: [FY26 report](https://nsearchives.nseindia.com/annual_reports/AR_29497_NELCAST_2025_2026_A_3754478_30062026181223.pdf), [ICRA5March 2026 rationale](https://www.icra.in/Rating/ShowRationalReportFilePdfViewer/141407), [5 October 2026 expansion approval](https://nsearchives.nseindia.com/corporate/NELCAST1_05102026175723_BMGENERALUPDATE.pdf).

##### Talbros Engineering: specialized forged axles, better asset productivity, material growth investment

This is BSE 538987, not Talbros Automotive Components/TALBROAUTO. It makes forged axle shafts rather than Sharp's mix of castings, forgings and machine-tool chucks. FY26 was standalone; Talbros Nextgen was incorporated on 12 May 2026, after the fiscal year. Company claims of about 90% domestic SUV axle-shaft share describe a narrow product market and are not independently validated here.

Revenue grew 20.10% to ₹535.76 crore with an 11.28% operating EBITDA margin. Exports increased from ₹76.98 crore to ₹145.69 crore, reaching 28.15% of product sales. That explains part of the growth but brings foreign-customer/FX exposure. The common pretax operating return of 15.67% and 1.49x asset turnover are better than the casting peers, consistent with different process economics. This is not evidence that Sharp can earn the same returns without its own capital-efficiency improvement.

Reported CFO of ₹44.56 crore was after ₹12.46 crore interest, but cash asset purchases of ₹52.64 crore still left a ₹8.08 crore deficit. FY26 capex nearly doubled from ₹26.91 crore. The planned eighth 10-acre unit in Madhya Pradesh adds execution and funding requirements. The AR ratio table's debt/equity 0.41 and ROCE 28.39% are not comparable with our formulas: debt/equity using all reported borrowings is 0.81x, while 28.39% arithmetically resembles PBT-plus-interest divided by closing equity, rather than the full average-capital denominator used here. No allegation is inferred; the figures simply cannot be transplanted.

The cash-flow statement begins at PBT and has no separately labelled cash-tax line. Preserve its reported CFO and make this limitation explicit rather than silently substituting the tax provision. BSE 19 October close could not be verified, so price and multiples are ND. A current quote from another date is not a substitute.

Primary source: [FY26 report](https://talbrosaxles.com/storage/document/annual-report-2025-26-020926060928.pdf).

##### Use in Sharp's valuation

- Separate recurring operating profitability from other income and normalized capital needs. These peers span 8.32–13.29% same-basis FY26 EBITDA margins, but only 10.82–15.67% pretax book-capital returns.
- A high CFO/PAT ratio can coexist with dependence on parent advances or with capex deficits. Test cash after interest and realistic investment over several years, not one ratio.
- Nelcast's FY26 cash advantage is real on the reported basis but the October ₹75 crore project prevents treating low capex as permanent. Talbros' product specialization is not equivalent to Sharp's casting/forging/chuck mix. Pritika's captive-parent economics are not a clean independent-customer comparable.
- No “peer median P/E” is asserted. Verified prices are included for date integrity, not to bypass dilution, capital structure, product mix, liquidity or source-quality differences.


### Appendix C: Business evidence and vintage-specific limits

#### Sharp Chucks and Machines: business economics and evidence quality

Information cutoff: 20 October 2026. This note uses retained original filings and rating rationales. “Verified disclosure” means the statement is present in the identified primary document, not that customer contracts, factory output or management representations have been independently audited by this research. Page references below are 1-based physical PDF pages, not printed labels. Raw financial amounts are ₹ lakh unless stated otherwise.

##### 1. What the company actually sells

**Verified disclosure.** Sharp manufactures customized castings, forging products and machine-tool accessories in two Jalandhar units. Casting products include tractor housings, hubs, carriers and related components; forging includes gears, clutches and striking/DIY tools; machine-tool products include power, lathe and drill chucks. Its process spans foundry work, forging, machining and inspection. The September 2023 prospectus described customer-specific sample/mould development and quality approval. [Prospectus, PDF 132–134, 143, 145, 148–150](https://archives.nseindia.com/emerge/corporates/content/SharpChucks_PROSP.pdf).

The last verified product-revenue split is FY 23: castings ₹151.87 cr/86.07%, forging ₹20.18 cr/11.43%, machine tools ₹4.40 cr/2.49%. That mix is historical, not FY 26. The FY 26 accounts combine customized casting, machine tools and forging into one business segment and provide no product margins. [Prospectus, PDF 134](https://archives.nseindia.com/emerge/corporates/content/SharpChucks_PROSP.pdf); [FY 26 report, PDF 34 and 69](https://sharpchucks.com/wp-content/uploads/2026/09/annual-report-2025-26.pdf).

**Inference.** The useful economic description is an integrated, predominantly tractor/automotive-exposed component supplier, not a proven proprietary-technology franchise. Application lists mention railways, defence, machine tools and DIY, but do not quantify current end-market diversification. CARE itself uses “solely automotive” in its cycle discussion while listing other applications in its company profile. We therefore do not assert either pure-auto revenue or substantial non-auto revenue. [September 2026 CARE, PDF 2–3](https://www.careratings.com/upload/CompanyFiles/PR/202609140922_Sharp_Chucks_and_Machines_Limited.pdf).

##### 2. Revenue quality, costs and cash conversion

**Verified disclosure.** FY 26 net operating revenue was ₹273.77 cr, up 11.50%, with ₹9.19 cr PAT. Domestic revenue was ₹269.35 cr and exports ₹4.42 cr, only 1.61% of net revenue; exports declined 5.26% from FY 25. All assets are in India. Goods revenue is generally recognized at dispatch after transfer of significant risks and rewards; exports use the on-board bill-of-lading date. An LOI or order announcement is not recognized revenue. [FY 26 report, PDF 53, 63, 70 and 72](https://sharpchucks.com/wp-content/uploads/2026/09/annual-report-2025-26.pdf).

The P&L explicitly bridges FY26 gross operating revenue of ₹316.2132 cr, less GST of ₹42.4458 cr, to net operating revenue of ₹273.7675 cr, with a ₹0.01 lakh rounding difference. FY25 gross ₹292.5687 cr less GST ₹47.0374 cr equals net ₹245.5313 cr. Note 22 reports gross sales; the geographical disclosure reports net revenue. Operating ratios therefore use revenue excluding GST, not the gross figure. [FY 26 report, PDF 53, 61, 70 and 72](https://sharpchucks.com/wp-content/uploads/2026/09/annual-report-2025-26.pdf).

FY 26 costs included raw materials ₹151.16 cr, stores/spares/tools ₹29.35 cr, power/fuel ₹25.68 cr, employees ₹18.88 cr and job work ₹4.53 cr. Calculated against net revenue, these are 55.22%,10.72%,9.38%,6.90% and 1.65%, respectively. All raw-material consumption is disclosed as indigenous. CARE reports OEM material-price pass-through with a one-quarter lag. [FY 26 report, PDF 61–62 and 72](https://sharpchucks.com/wp-content/uploads/2026/09/annual-report-2025-26.pdf); [September 2026 CARE, PDF 2](https://www.careratings.com/upload/CompanyFiles/PR/202609140922_Sharp_Chucks_and_Machines_Limited.pdf).

**Inference.** Material timing, energy, yield, tooling and labour efficiency matter more than the word “precision.” Scrap reuse helps recovery economics but does not eliminate external commodity exposure. Neither unit contribution margins nor a volume/price/mix bridge is available. Historical top 10 suppliers represented 69.61% of purchases in FY 23; that is not a current supplier-concentration statistic. [Prospectus, PDF 27 and 149](https://archives.nseindia.com/emerge/corporates/content/SharpChucks_PROSP.pdf).

Working capital remains intrinsic to the model. CARE reports FY 26 operating cycle about 157 days versus 145 days in FY 25, receivable days about 50 versus 42, inventory held about 4–5 months, and working-capital utilization near 98% over the 12 months to July 2026. These agency ratios must not be mixed with differently calculated model ratios. [September 2026 CARE, PDF 2–3](https://www.careratings.com/upload/CompanyFiles/PR/202609140922_Sharp_Chucks_and_Machines_Limited.pdf).

Inventory was ₹107.40 cr, including ₹48.81 cr WIP, or 45.44% of stock. The accounts disclose no stage-wise WIP tracking methodology and reliance on an independent cost accountant's valuation. The prospectus says finished-goods quantities incorporate both confirmed and expected orders. **Inference:** reputable customers do not make anticipated inventory immediately saleable or collectible; stage, quantity, valuation and order linkage need reconciliation. This is a control concern, not a fraud conclusion. [FY 26 report, PDF 59 and 74](https://sharpchucks.com/wp-content/uploads/2026/09/annual-report-2025-26.pdf); [Prospectus, PDF 149](https://archives.nseindia.com/emerge/corporates/content/SharpChucks_PROSP.pdf).

##### 3. Customers, repeat business and contracts

**Verified disclosures with distinct vintages.** FY 23's top 5 customers contributed 73.78% of sales, versus 65.58% in FY 22 and 68.55% in FY 21. Separately, January and September 2026 CARE name Mahindra & Mahindra, International Tractors, Swaraj Engines and Escorts among OEM relationships representing approximately 74% of sales. The older top 5 set and the newer major-OEM set are not identical measures. Current largest-customer share is unavailable. [Prospectus, PDF 27, 143 and 222](https://archives.nseindia.com/emerge/corporates/content/SharpChucks_PROSP.pdf); [September 2026 CARE, PDF 2](https://www.careratings.com/upload/CompanyFiles/PR/202609140922_Sharp_Chucks_and_Machines_Limited.pdf).

At IPO, sales were purchase-order based with no long-term supply agreement or minimum-purchase obligation. The risk factors note a bank-guarantee-backed exception involving Ammunition Factory, Khadki, a Munitions India unit. Updated 2026 contract terms, enforceable backlog and cancellation protections were not verified. The historical defence-related exception is not a current defence order-book claim. [Prospectus, PDF 27 and 149](https://archives.nseindia.com/emerge/corporates/content/SharpChucks_PROSP.pdf).

**Inference.** Engineering approval, delivery reliability and repeated OEM relationships create retention advantages. They do not make revenue subscription-like or provide strong supplier bargaining power. Strong customer credit can coexist with extended payment terms and purchase-volume cuts.

##### 4. Capacity: keep physical vintages separate

The original prospectus table reports the following. Utilization is the source's rounded percentage, not a time-weighted practical-capacity calculation. [Prospectus, PDF 133, 144 and 148–149](https://archives.nseindia.com/emerge/corporates/content/SharpChucks_PROSP.pdf).

| Process | FY 21 capacity / output, tonnes | FY 22 capacity / output | FY 23 capacity / output | FY 23 reported utilization |
|---|---:|---:|---:|---:|
| Casting | 18,000 / 15,051 | 18,000 / 15,823 | 30,000 / 19,606 | 65% |
| Machining | 7,200 / 6,600 | 9,600 / 7,800 | 14,400 / 7,690 | 53% |
| Forging | 1,800 / 1,200 | 1,800 / 1,500 | 3,600 / 1,730 | 48% |

September 2026 CARE repeats nominal capacities of 30,000/14,400/3,600 MTPA. It does not provide updated FY 26 output/utilization. [September 2026 CARE, PDF 3](https://www.careratings.com/upload/CompanyFiles/PR/202609140922_Sharp_Chucks_and_Machines_Limited.pdf).

**Inference and limits.** Do not sum casting and machining capacities as unique saleable tonnes because they can be successive processes. Do not project FY 23's utilization into FY 26. Capacity installed during a year also makes annual output divided by year-end capacity an imperfect measure. Current bottlenecks, yields, machine-hours, saleable tonnage and commissioned incremental throughput remain ND.

##### 5. Growth already earned versus growth still promised

The audited 11.50% FY 26 revenue increase is realized. January 2026 CARE linked growth to tractor demand, increased OEM content and new crankcase/cylinder-head products; September CARE mentioned new forging components. Those explanations are plausible evidence of product wins, but not an audited product-growth bridge. [FY 26 report, PDF 53](https://sharpchucks.com/wp-content/uploads/2026/09/annual-report-2025-26.pdf); [January 2026 CARE, PDF 2](https://www.careratings.com/upload/CompanyFiles/PR/202601150152_Sharp_Chucks_and_Machines_Limited.pdf); [September 2026 CARE, PDF 2](https://www.careratings.com/upload/CompanyFiles/PR/202609140922_Sharp_Chucks_and_Machines_Limited.pdf).

Three prospective claims need separation:

1. **In-house processing and automation.** CARE expects margin improvement from reduced outsourcing and lower rejection. But FY 26 job-work expense rose 85.52%, from₹2.44 cr to₹4.53 cr. Volume/mix or timing may explain it; it neither proves failure nor proves savings. The savings case requires unit-cost, yield and commissioning evidence. [January 2026 CARE, PDF 1–2](https://www.careratings.com/upload/CompanyFiles/PR/202601150152_Sharp_Chucks_and_Machines_Limited.pdf); [September 2026 CARE, PDF 2–3](https://www.careratings.com/upload/CompanyFiles/PR/202609140922_Sharp_Chucks_and_Machines_Limited.pdf); [FY 26 report, PDF 61](https://sharpchucks.com/wp-content/uploads/2026/09/annual-report-2025-26.pdf).
2. **New segment LOI.** On 7 September, CARE explicitly said conversion of the LOI into definitive purchase orders remained a key monitorable. No counterparty, segment definition, contracted value, delivery timetable, minimum volumes or project margin is verified. Treat it as uncontracted upside, not base-case backlog. [September 2026 CARE, PDF 1–2](https://www.careratings.com/upload/CompanyFiles/PR/202609140922_Sharp_Chucks_and_Machines_Limited.pdf).
3. **Investment and funding.** January CARE expected roughly₹3 cr recurring capex and no medium-term debt-funded project; September described an ongoing approximately₹30 cr programme with nearer-term debt/flexibility pressure. The later evidence supersedes the earlier low-capex premise. The October proposal to raise up to₹32.4 cr through warrants is conditional and has an EGM after the cutoff. Its land, machinery, working-capital, strategic-investment and general-purpose uses are not proof the LOI is funded or executable. Do not double-count that raise with the separately described project or include the April proposal cancelled on 4 June. [January 2026 CARE, PDF 2–3](https://www.careratings.com/upload/CompanyFiles/PR/202601150152_Sharp_Chucks_and_Machines_Limited.pdf); [September 2026 CARE, PDF 3](https://www.careratings.com/upload/CompanyFiles/PR/202609140922_Sharp_Chucks_and_Machines_Limited.pdf); [October notice, PDF 18–21 and 24](https://sharpchucks.com/wp-content/uploads/2026/10/Notice-of-EGM-31-10-2026.pdf); [June cancellation, PDF 1–2](https://nsearchives.nseindia.com/corporate/SHARPCHUCKS_04062026181638_Intimation_30_04062026.pdf).

CARE's Q 1 FY 27 figures, marked unaudited, are₹60.73 cr TOI, ₹10.98 cr PBILDT and₹4.52 cr PAT. These are preliminary upside evidence, not an annual earnings run rate or an exchange-result reconciliation. [September 2026 CARE, PDF 3](https://www.careratings.com/upload/CompanyFiles/PR/202609140922_Sharp_Chucks_and_Machines_Limited.pdf).

##### 6. Ownership, remuneration and related parties

The October notice's 2 October baseline reports 9,230,542 promoter-group shares,63.67% of 14,496,792 outstanding shares. The separate 1 October allottee table lists Ajay Sikka at 43.52% and Gopika Sikka at 12.31%. The individual holdings are not the aggregate promoter group. Full proposed warrant conversion would reduce the group percentage to 60.72%, still control; that is not the current cap table. Reasons for holding changes from March, and current pledges/encumbrances, were not independently established. [October notice, PDF 22 and 24](https://sharpchucks.com/wp-content/uploads/2026/10/Notice-of-EGM-31-10-2026.pdf).

Ajay is MD and Gopika director/CFO; the prospectus identifies them as spouses. FY 26 remuneration was₹48 lakh and₹24 lakh respectively, unchanged fromFY 25. Their combined₹72 lakh equals 0.263% of net revenue and 7.83% of PAT, but these ratios alone do not establish pay fairness. The report lists 486 permanent employees and leaves meaningful employee-median pay comparison unavailable. [Prospectus, PDF 167](https://archives.nseindia.com/emerge/corporates/content/SharpChucks_PROSP.pdf); [FY 26 report, PDF 22, 37–38 and 70](https://sharpchucks.com/wp-content/uploads/2026/09/annual-report-2025-26.pdf).

FY 26 newly discloses₹11.97 cr sales to Sharp Precision Private Limited,4.37% of net revenue, and₹6.99 cr purchases from it. Director/promoter loan balance was only₹16.82 lakh, interest-free. Pricing, product flows, settlements and trade balances deserve verification; no circular trading or diversion is inferred. [FY 26 report, PDF 57 and 70–71](https://sharpchucks.com/wp-content/uploads/2026/09/annual-report-2025-26.pdf).

##### 7. Seasonality, cycle and competitive position

The 2023 prospectus says the business is not seasonal. That does not contradict cyclical dependence on automotive/tractor demand and OEM schedules, nor prove even quarterly sales. No verified multi-year quarterly production series supports annualizing a strong quarter or estimating a stable seasonal factor. [Prospectus, PDF 221](https://archives.nseindia.com/emerge/corporates/content/SharpChucks_PROSP.pdf); [September 2026 CARE, PDF 2](https://www.careratings.com/upload/CompanyFiles/PR/202609140922_Sharp_Chucks_and_Machines_Limited.pdf).

Competition is fragmented across organized and unorganized suppliers; the issuer identifies quality, range and price as key parameters. Integrated processes, approved parts and longstanding relationships support retention, but current market share, pricing premium and independently measured technical superiority are unavailable. Quality certifications are cited by September CARE; underlying current renewals were not independently checked. The 2023 prospectus recorded abandoned trademark applications and no other registered IP at that date. That is historical, not a finding about the current IP register. [Prospectus, PDF 150, 152 and 239](https://archives.nseindia.com/emerge/corporates/content/SharpChucks_PROSP.pdf); [September 2026 CARE, PDF 3](https://www.careratings.com/upload/CompanyFiles/PR/202609140922_Sharp_Chucks_and_Machines_Limited.pdf).

Both units' regional concentration adds physical risk. FY 26 accounts record a₹8.73 lakh insurance recovery for flood damage to a factory wall, with repair expense to be booked later. Do not infer factory shutdowns or lost sales from that limited disclosure. [FY 26 report, PDF 74](https://sharpchucks.com/wp-content/uploads/2026/09/annual-report-2025-26.pdf).

##### 8. Peer implications and unresolved proof points

The separately sourced peer work supplies the financial inputs. Pritika's captive-parent customer and advance-funding model is not Sharp's bank-funded independent-OEM model. Nelcast offers larger scale and customer/geographic diversity but only moderate book-capital returns, with a new October machining project. Talbros Engineering's specialized forged axles and better asset productivity are not a directly transferable casting/chuck return target; its growth capex still exceeds reported CFO. No peer median multiple substitutes for company-specific evidence.

Before awarding a durable growth/quality premium, establish:
- Current product and end-market revenue/margin mix, saleable tonnage and practical utilization.
- Contracted orders and LOI conversion, with counterparty, economics and delivery milestones.
- Commissioned capacity, rejection/yield improvement and actual in-house processing savings.
- Inventory-stage/valuation/order reconciliation and conversion into unrestricted cash.
- Remaining project spend, financing headroom and the actual status of proposed securities.
- Related-party trade pricing/settlements, current pledges and updated ownership details.

`business_inputs.json` preserves 33 individually sourced facts, inference labels, exact URLs, physical pages, capacity vintages, metric formulas and explicit unavailable data. No missing quantity, margin, backlog, contractual commitment or FY 26 utilization is filled with an estimate disguised as fact.


### Appendix D: Reproduction and monthly model specification

#### Reproducible monthly model: definitions and limits

The engine is a conditional cash laboratory, not an executable October 2026 forecast. Every path has source_eligible=false. March balances are hypothetically carried to 31 October; actual April–October cash, loan and spending movements are unknown. The date convention is month end, November 2026 toOctober 2031/2036. Equity IRR uses actual days from 19 October 2026 divided by 365.25, not an assumed exact five years. Personal taxes and brokerage are excluded. No dividends are paid.

Amounts are INR crore, price INR/share, shares whole units and capacity tonnes/year. decimal.Decimal strings drive calculations, never binary float. Full inputs are model_inputs.json; scenario variants and grids are generated by scenarios.py. All monthly records, including suppressed months after failures, are retained in canonical_paths.json.gz, with index/annual summaries alongside.

Opening balances: cash 0.5167 less conservatively excluded 0.0125 IPO escrow; pledgedFD9.9069 excluded from general cash; CC96.0822; term 24.8843; director 0.1682; unfunded employee 1.8479. The cash-flow statement prints 0.5166 closing cash; detailed balance-sheet items support 0.5167, a 0.0001 crore discrepancy. Escrow overlap is unresolved and a bounded 0.0125 crore conservative double restriction is possible. Operating security deposits 3.1073 are not bank FDs; they are included with net other operating working capital 2.2264 to form 5.3337 and scale with sales. The duties/tax liability 1.4623 is netted here, not deducted again at exit. Net opening income tax 2.0447 settles separately inmonth 3. Capital advances are within opening fixed capital, not future free cash.

Actual October issued 14,496,792 shares; shareholder-approved authorized ceiling 21,000,000 remains conditional on effective statutory authorization, and does not authorize any particular future issue. Current shares already include 2,412,000 old converted warrants. Cancelled April equity/warrants contribute neither cash nor claims. The October 4 m warrants@81 are only a conditional prospective event, not current funding. Default hypothetical allotment ismonth 1 with 25%receipt, conversionmonth 18 with 75%receipt, deadline 18 months after actual assumed allotment. Whole shares arrive only at exercise. Unexercised warrants lapse; prior cash stays received, no extra shares. Reserved warrants count against headroom for hypothetical additional equity. Equity issuance costs 2%; emergency share issue price 75.84 is an independent assumption. Required share count is rounded up; the authorized cap cannot be breached. Investor-entry sensitivity does not secretly reprice corporate issuance.

Warrant objects are segregated: working capital 6.5, land 4.5, facility 3, tools 6.65, strategic 3.75 and general 8, totaling 32.4. Each receipt is allocated pro rata as an explicit assumption, not sourced allotment sequencing. Only general cash is unrestricted, and issue fees come from it. WC releases cover positive current-month incremental operating capital only. Land/facility/tools release only their proportional 14.15/30 share of initial programme spending, not retroactive reimbursement. CARE’s 30 crore programme is not verified to match those objects; the baseline overlap is an optimistic mapping. A zero-overlap stress blocks all warrant-capex release. Strategic/unmatched balances remain restricted with zero terminal addition. Existing IPO escrow and bankFD balances never enter these new receipt buckets.

The prospective 20 crore project loan has no verified sanction. In paths that assume it, the entire draw enters a project-purpose bucket, accrues interest from draw and pays 1%fee from unrestricted cash. Current initial programme and growth capex, less amounts already covered by warrant capital objects, release eligible money. It cannot fund maintenance, old principal, interest or operating deficits. Unused project cash has no additive terminal value while debt remains. Additional CC10 crore is an assumed revolving limit, not inferred from 98%utilization. CC draws only to cover the minimum 0.5 cash reserve; excess incremental CC is repaid. Historical baseCC is not assumed permanently undrawn. Recall stress demands repayment atmonth 6; no hidden refinancing.

The source term schedule 9.7773/8.6992/5.2778/1.1299 is mapped conservatively to remaining fiscal windowsmonths 1–5/6–17/18–29/30–41. The final bucket is increased 0.0001 to 1.1300 solely to match 24.8843 aggregate, not as a source fact. Actual Apr–Oct 2026 repayments are unknown, so allocating the fullFY27 bucket to remaining months is a conservative diagnostic. New project debt has 12 monthly principal-holiday periods and 36 equal amortizations. Opening debt and month-start new draws accrue 11.5%annual interest monthly; CC drawn at month end incurs interest from next month. Bank fees 1.0978 annual are paid quarterly. Interest-rate stresses are explicit.

Opening annual revenue 273.7675 is divided by assumed 24,000 casting-equivalent tonnes to calibrate price, not an observed selling price. Sales growth is split into 2%annual price and residual volume compounded monthly. Output cannot exceed the smallest of casting capacity, machining capacity/load 0.42, forging capacity/load 0.10, at 95%maximum utilization. Nameplates are 30,000/14,400/3,600; they are linked stages, not additive saleable tonnage. Lost demand is recorded, not sold. Below 70%casting utilization, an explicit fixed-cost margin penalty applies. Bear temporary customer loss is additional to its weaker growth assumption and is not accidentally treated as recovered sales.

AR/inventory/AP targets use calibrated closing-balance days and a production-cost proxy 86% of sales. Scenario day changes phase over 12 months. Other operating-capital balances scale with annualized realized monthly sales. Only month-to-month changes consume/release cash, avoiding duplicate full balances. Negative working-capital release is a scenario result, not an independent source of funding promised by management. Taxes apply 25%to positive EBITDA−DA−interest−bankfees; no negative tax credit. They accrue monthly and pay at fiscal quarter ends. Opening taxes pay separately; terminal accrued taxes remain claims.

The initial 30 crore capital programme is paid over 12 months (stress variants 1 month/15 or 45 crore) and commissions only after spending plus delay. Half is assumed capacity expansion; half automation. Expansion conversion 400 annual casting-equivalent tonnes per crore, with machining/forging added at 0.48/0.12 ratios, is unverified engineering economics. Demand-triggered future expansion is ordered every six months if needed after considering already committed capacity; cost is paid over six months and commissions after 12 months. Maintenance 2.5% of actual sales is paid separately. DA is original 7.9514/year plus added capital over 12 years; immediate added-capital DA is a conservative simplification, not audited commissioning accounting. No uncommissioned capacity produces sales.

Cash recurrence is opening unrestricted cash + equity gross − equity fees − earmarked equity receipts + eligible releases + loan gross −loan fees −project-restricted receipts +project releases + EBITDA −incremental operating capital −cash taxes −opening-tax settlement −capex −interest −bankfees −principal −LC crystallization +CCdraw −CCrepayment. Every month asserts recurrence, integer-share authorization and physical output constraints. Negative unrestricted cash freezes the path immediately; subsequent months show SUPPRESSED_AFTER_FAILURE, no forecast sales or ordinary IRR. A reserve shortfall while still positive is recorded separately; it is not silently claimed bankruptcy. Authorization or late-exercise failure also suppresses returns.

Terminal cash economics use the last 12 realized months, not an unfulfilled demand target. NOPAT=EBIT−max(0,EBIT)×25%, preserving losses without unusable tax credits. Replacement=max(DA,3%revenue). Growth fixed reinvestment=revenue×g/2, working-capital reinvestment=closing operating capital×g, operating-cash growth=revenue×g×1.5%. ForwardFCFF=(NOPAT+DA−replacement)×(1+g)−growth fixed−growth WC−growth cash. EV=max(0,FCFF)/(WACC−g), with positiveFCFF and WACC>g required for earned returns. Physical next-year growth must be supported by paid capacity or enough funded reinvestment; no free growth.

Equity claims deduct CC, term, directors, unpaid tax, employee obligations, unpaid committed expansion payments and shortfall to 1.5% of sales required operating cash. Only cash above that operating reserve is additive. RestrictedFDs, escrow, unspent warrant-object and project-purpose balances add zero. Committed but not yet paid capex is a liability; uncommissioned capacity earns no terminal production. A separate EBITDA-multiple exit crosscheck is retained, not used to manufacture a higher value. Earned=positiveFCFF, valid discount/growth spread and sufficient physical reinvestment. Otherwise ordinary IRR, price multiple and hurdle prices are suppressed.

All twelve canonical bear/base/bull funding modes,25 growth/margin points,9 terminalWACC/g points,5 entry prices,14 linked stress cases and 138 funded 5/10-year search paths remain available. The 5 x/10 x classification is speculative/unsupported even if a diagnostic hits the target. No-hit means no feasible hit within the stated bounds, not a theorem about every future. No probability weights are invented. Model results cannot determine R or P while current source eligibility is unresolved.

Numerical tolerance: 1e−18 crore is ignored before emergency-equity triggers and cash-failure tests, and subtracted from a positive funding need before whole-share ceiling. This prevents an economically zero Decimal rounding residue creating a share or default. Genuine deficits still issue whole ceiling shares and remain bounded by authorization; no material cash shortfall is forgiven.

