# Primary source register

| ID | Exact primary URL | SHA256 / locator |
|---|---|---|
| AR20 | [AR20](https://sharpchucks.com/report-19-20.pdf) | c373742cf2316cab2b514a9a4b0eb3a8873c2fbcc1f41579c30c6283306e0803; Standalone original annual |
| AR21 | [AR21](https://sharpchucks.com/report-20-21.pdf) | a12870a6b4ceedb1fb04077177fb14b114bd290b8f819038d908fdfe6bb1647f; Standalone original annual |
| AR22 | [AR22](https://sharpchucks.com/report-21-22.pdf) | 6c5208e6af5d715020a40fe17a2941d0b2186e5c9303e071e92dcb34ce6e7c83; Standalone original annual |
| AR23 | [AR23](https://sharpchucks.com/report-22-23.pdf) | e9c68a84fe95fb9bb7c0db2ef60702f742f8e9147e369ac186ba1c8eb07319ec; Standalone original annual |
| AR24 | [AR24](https://www.sharpchucks.com/pdf/annual-report-23-24.pdf) | 8ffd1f2d790090b85eae22fae686734990c34a964260565eefb08c7e15706dfa; Standalone original annual |
| AR25 | [AR25](https://archives.nseindia.com/annual_reports/SME_AR_28998_SCML_2024_2025_A_2423168_09092025151324.pdf) | 83911606035f7a56e905b01b7a0395a09620d8337677887209bb72cab9d4000f; Standalone original annual |
| AR26 | [AR26](https://archives.nseindia.com/annual_reports/SME_AR_31861_SCML_2025_2026_A_3090667_08092026144726.pdf) | d051352619adf7cfe3cb8f3751591e0f7cd9dcce26dbcea336713dcbd4c4fec4; Standalone original annual |
| PROS | [PROS](https://archives.nseindia.com/emerge/corporates/content/SharpChucks_PROSP.pdf) | 387b7a7bb73458a81f939b0b7398eef7b8f6b540a29b3c8367d138bdb44185c5; FY2021–23 restated standalone |
| DRAFT | [DRAFT](https://archives.nseindia.com/emerge/corporates/content/SharpChucks_DP.pdf) | 52682714b1313c181a66204373fe6a993a7c777bd7d88a8cdac576fc8567ef0a; FY2020–22 and9MFY23 restated standalone |
| CARE2609 | [CARE2609](https://www.careratings.com/upload/CompanyFiles/PR/202609140922_Sharp_Chucks_and_Machines_Limited.pdf) | f773b600e1c69e4d88717a9550145c3c0610ca59f5ef6667ded5bb1ad37e06a3; Standalone credit opinion |
| CARE2601 | [CARE2601](https://www.careratings.com/upload/CompanyFiles/PR/202601150152_Sharp_Chucks_and_Machines_Limited.pdf) | 55d2260f30fa0a5fbb74fd3d24941aad7758051bae1ea7c53d62669b65115b85; Standalone credit opinion |
| CARE2502 | [CARE2502](https://www.careratings.com/upload/CompanyFiles/PR/202502140216_Sharp_Chucks_and_Machines_Limited.pdf) | b492dbb4fca0de9c7f52f1dba573a427190474b8d18e5704ddef46a7d1582f3b; Standalone credit opinion |
| CARE2401 | [CARE2401](https://www.careratings.com/upload/CompanyFiles/PR/202401130123_Sharp_Chucks_and_Machines_Limited.pdf) | 72e4ad43183b8b4f0324a0c97eb47903aff242d8f748aae619818ffd484834fc; Standalone credit opinion |
| EGM2610 | [EGM2610](https://sharpchucks.com/wp-content/uploads/2026/10/Notice-of-EGM-31-10-2026.pdf) | 4bf0b506e0d58cde8895e8e4b5f220232af3850136ef7e326c2d0d11d3b73f16; Proposed warrants, EGM after cutoff |
| WITHDRAW | [WITHDRAW](https://nsearchives.nseindia.com/corporate/SHARPCHUCKS_04062026181638_Intimation_30_04062026.pdf) | 26dff45db6348552cca612aad89e438e4f7ef9b0e5f445bee414a6e21759b7fd; April issue withdrawal |
| LIST2607 | [LIST2607](https://nsearchives.nseindia.com/content/circulars/CML75019.pdf) | e7153fff4e83611db80f9c904a16e4dfeff50a21ddf95f929c8c119c50c5f674; Further listing after old warrant conversion |
| IPO_USE | [IPO_USE](https://www.sharpchucks.com/pdf/Statementofdeviation.pdf) | cb77ec905214186f8a5cbfec85e02b01f158c0b28ed6128e8b95fab5bbd7085e; IPO use FY2024 |
| INDEX | [INDEX](https://sharpchucks.com/investors/) | See constituent register; Source discovery, not post-cutoff evidence |
| AR2024 | [AR2024](https://www.sharpchucks.com/pdf/annual-report-23-24.pdf) | 8ffd1f2d790090b85eae22fae686734990c34a964260565eefb08c7e15706dfa; Standalone original annual |
| AR2025 | [AR2025](https://sharpchucks.com/wp-content/uploads/2025/09/ANNUAL-REPORT-2024-25.pdf) | 83911606035f7a56e905b01b7a0395a09620d8337677887209bb72cab9d4000f; Standalone original annual |
| AR2026 | [AR2026](https://sharpchucks.com/wp-content/uploads/2026/09/annual-report-2025-26.pdf) | d051352619adf7cfe3cb8f3751591e0f7cd9dcce26dbcea336713dcbd4c4fec4; Standalone original annual |
| PROS2023 | [PROS2023](https://archives.nseindia.com/emerge/corporates/content/SharpChucks_PROSP.pdf) | 387b7a7bb73458a81f939b0b7398eef7b8f6b540a29b3c8367d138bdb44185c5; FY2021–23 restated standalone |
| EGM202610 | [EGM202610](https://sharpchucks.com/wp-content/uploads/2026/10/Notice-of-EGM-31-10-2026.pdf) | 4bf0b506e0d58cde8895e8e4b5f220232af3850136ef7e326c2d0d11d3b73f16; Proposed warrants, EGM after cutoff |
| VALUATION202610 | [VALUATION202610](https://sharpchucks.com/wp-content/uploads/2026/10/Valuation-Report-of-Preferential-Issue.pdf) | 0f80c358b5304814539d0976636a01c70de7c51f23e450490b3e4cd98d69604a; Registered-valuer report; price result crosschecked through October EGM notice, not full independent valuation review |
| EGM202604 | [EGM202604](https://sharpchucks.com/wp-content/uploads/2026/04/Notice_SCML.pdf) | 6d1a6a8f1c6729401f6636f00753bbb518803372d36964c30e63c53f0b01c1cb; Notice of 6 May 2026 EGM; capital increase and subsequently withdrawn financing |
| IPO_USE2024 | [IPO_USE2024](https://www.sharpchucks.com/pdf/Statementofdeviation.pdf) | cb77ec905214186f8a5cbfec85e02b01f158c0b28ed6128e8b95fab5bbd7085e; IPO use FY2024 |
| CARE202609 | [CARE202609](https://www.careratings.com/upload/CompanyFiles/PR/202609140922_Sharp_Chucks_and_Machines_Limited.pdf) | f773b600e1c69e4d88717a9550145c3c0610ca59f5ef6667ded5bb1ad37e06a3; Standalone credit opinion |
| CARE202601 | [CARE202601](https://www.careratings.com/upload/CompanyFiles/PR/202601150152_Sharp_Chucks_and_Machines_Limited.pdf) | 55d2260f30fa0a5fbb74fd3d24941aad7758051bae1ea7c53d62669b65115b85; Standalone credit opinion |
| CARE202502 | [CARE202502](https://www.careratings.com/upload/CompanyFiles/PR/202502140216_Sharp_Chucks_and_Machines_Limited.pdf) | b492dbb4fca0de9c7f52f1dba573a427190474b8d18e5704ddef46a7d1582f3b; Standalone credit opinion |
| CARE202401 | [CARE202401](https://www.careratings.com/upload/CompanyFiles/PR/202401130123_Sharp_Chucks_and_Machines_Limited.pdf) | 72e4ad43183b8b4f0324a0c97eb47903aff242d8f748aae619818ffd484834fc; Standalone credit opinion |
| DRHP2023 | [DRHP2023](https://archives.nseindia.com/emerge/corporates/content/SharpChucks_DP.pdf) | 52682714b1313c181a66204373fe6a993a7c777bd7d88a8cdac576fc8567ef0a; FY2020–22 and9MFY23 restated standalone |
| LIST202607 | [LIST202607](https://nsearchives.nseindia.com/content/circulars/CML75019.pdf) | e7153fff4e83611db80f9c904a16e4dfeff50a21ddf95f929c8c119c50c5f674; Further listing after old warrant conversion |
| CANCEL202606 | [CANCEL202606](https://nsearchives.nseindia.com/corporate/SHARPCHUCKS_04062026181638_Intimation_30_04062026.pdf) | 26dff45db6348552cca612aad89e438e4f7ef9b0e5f445bee414a6e21759b7fd; April issue withdrawal |
| CS202610 | [CS202610](https://sharpchucks.com/wp-content/uploads/2026/10/Certificate-under-Regulation-163-2-of-the-SEBI-ICDR-Regulations-2018.pdf) | 8949f960cd251d5e0059cdf7a21944bc20b7d77896a1f90635fd656c6a724ee6; Limited preferential-issue Chapter V compliance certificate; not evidence of receipt/allotment approval |
| VOTE202605 | [VOTE202605](https://nsearchives.nseindia.com/corporate/SHARPCHUCKS_06052026205229_SCML_Voting_results.pdf) | b12fc175c1c0148fad589299ae7f391f8ab24bba8f02fab4ffddf1726281e37b; NSE voting results confirming authorized-capital resolution and other EGM resolutions |
| ORIG2020 | [ORIG2020](https://sharpchucks.com/report-19-20.pdf) | c373742cf2316cab2b514a9a4b0eb3a8873c2fbcc1f41579c30c6283306e0803; Standalone original annual |
| ORIG2021 | [ORIG2021](https://sharpchucks.com/report-20-21.pdf) | a12870a6b4ceedb1fb04077177fb14b114bd290b8f819038d908fdfe6bb1647f; Standalone original annual |
| ORIG2022 | [ORIG2022](https://sharpchucks.com/report-21-22.pdf) | 6c5208e6af5d715020a40fe17a2941d0b2186e5c9303e071e92dcb34ce6e7c83; Standalone original annual |
| ORIG2023 | [ORIG2023](https://sharpchucks.com/report-22-23.pdf) | e9c68a84fe95fb9bb7c0db2ef60702f742f8e9147e369ac186ba1c8eb07319ec; Standalone original annual |

All market URLs and constituent archive hashes are preserved in market_inputs.json. Source-safe authored extractions allow offline reproduction without source PDFs.
