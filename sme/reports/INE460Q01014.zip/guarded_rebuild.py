"""Fresh-directory build AND verification with explicit read/write/network guards.
No deletions: run only after extracting declared inputs into an empty recovery directory.
"""
from pathlib import Path
import sys,os,io,builtins,json,hashlib,socket,subprocess
sys.dont_write_bytecode=True
P=Path(__file__).resolve().parent
sys.path.insert(0,str(P))
import build,verify
ATTESTATIONS=['verification.json','guard_attestation.json','verification/monthly_replay.json','verification/deliverable_audit.json']
def main():
 if '--fresh'not in sys.argv:raise SystemExit('Use --fresh in an inputs-only fresh directory; no deletion is performed.')
 assert all(not(P/n).exists()for n in build.OUTPUTS+ATTESTATIONS),'Generated outputs must be absent. Use a new directory, never overwrite a cold-run attestation.'
 allowed={(P/n).resolve()for n in build.INPUTS};written=set();reads=set();denials=[];active_probe=None;probes=[]
 oldopen=builtins.open;oldio=io.open;oldos=os.open;oldsocket=socket.socket;oldprocess=subprocess.Popen
 def rel(p):
  try:return str(p.relative_to(P))
  except ValueError:return str(p)
 def deny(reason):denials.append({'probe':active_probe,'reason':reason});raise PermissionError(reason)
 def check(file,mode='r'):
  if isinstance(file,int):return
  p=Path(file).resolve();mode=str(mode);r='r'in mode or'+'in mode;w=any(x in mode for x in 'wax+')
  if r and p not in allowed and p not in written:deny('Undeclared or stale read: '+rel(p))
  if r:reads.add(rel(p))
  if w:
   if rel(p)not in build.OUTPUTS+ATTESTATIONS:deny('Undeclared write: '+rel(p))
   written.add(p)
 def op(f,m='r',*a,**k):check(f,m);return oldopen(f,m,*a,**k)
 def iop(f,m='r',*a,**k):check(f,m);return oldio(f,m,*a,**k)
 def osop(f,flags,*a,**k):check(f,'r+'if flags&os.O_RDWR else'w'if flags&(os.O_WRONLY|os.O_CREAT)else'r');return oldos(f,flags,*a,**k)
 def net(*a,**k):deny('Network forbidden')
 def proc(*a,**k):deny('Subprocess forbidden')
 builtins.open=op;io.open=iop;os.open=osop;socket.socket=net;subprocess.Popen=proc
 try:
  for label,action in [('undeclared_read',lambda:builtins.open(P/'undeclared_probe.json')),('stale_generated_read',lambda:io.open(P/'scores.json')),('network',lambda:socket.socket()),('process',lambda:subprocess.Popen(['not-executed']))]:
   active_probe=label
   try:action()
   except PermissionError:probes.append({'probe':label,'status':'DENIED_AS_REQUIRED'})
   else:raise AssertionError('Guard unexpectedly allowed '+label)
   active_probe=None
  result=build.main();assert set(build.OUTPUTS)=={rel(p)for p in written};checked=verify.verify();assert all(d['probe']is not None for d in denials)
  hashes={n:hashlib.sha256((P/n).read_bytes()).hexdigest()for n in build.OUTPUTS+['verification.json','verification/monthly_replay.json','verification/deliverable_audit.json']}
  record={'status':'PASS','all_generated_absent_before_build':True,'deletions':[],'declared_inputs':build.INPUTS,'reads':sorted(reads),'writes':sorted([rel(p)for p in written]+['guard_attestation.json']),'denial_probes':probes,'unexpected_denials':[],'external_data_dependency':False,'network_subprocess_forbidden':True,'verification_within_guard':True,'independent_replay_within_guard':True,'generated_reads_only_after_current_run_write':True,'rebuild':result,'canonical_sha256':checked['canonical_sha256'],'outputs_sha256':hashes}
  (P/'guard_attestation.json').write_text(json.dumps(record,indent=2)+'\n');assert set(build.OUTPUTS+ATTESTATIONS)=={rel(p)for p in written}
 finally:builtins.open=oldopen;io.open=oldio;os.open=oldos;socket.socket=oldsocket;subprocess.Popen=oldprocess
 print(json.dumps({'status':'PASS','paths':result['paths'],'canonical_sha256':record['canonical_sha256'],'guard_probes':len(probes)}))
if __name__=='__main__':main()
