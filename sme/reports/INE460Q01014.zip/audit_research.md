# Sharp Chucks and Machines Limited: audit, governance and capital reconciliation

**Security:** SCML, NSE SME; ISIN INE460Q01014. **Information cutoff:** 20 October 2026. Financial amounts below are ₹ lakh unless explicitly identified as ₹ crore or rupees. PDF page references are physical, one-based pages, not the page number printed on the report. This is a primary-source research assessment, not an allegation of fraud or a representation that the company is currently in default.

## Decision-useful conclusion

An accounting-quality **Hold pending evidence** is justified, rather than either a clean governance pass or a fraud/default fail. Work-in-progress valuation methodology, fixed-asset reconciliation and external balance confirmations remain unresolved. GST-interest disclosures show cash-basis recognition in FY2024–25 without a traced FY2026 settlement bridge. CARE's report of December 2023 and March 2024 debt-service delays conflicts with FY2024 CARO's no-default statement. These are specific evidence requests, not proof of invented inventory, diverted cash, or current default.

Counterevidence must remain prominent: the original FY2020–FY2026 financial-statement opinions and internal-financial-control opinions are unmodified. CARE reports regular term-debt servicing from April 2024 and, in September 2026, rates the company BB+/Positive with adequate liquidity. The auditor transition was explained by term expiry, not a documented disputed dismissal. The large apparent FY2022 physical-cash balance is predominantly cheques/drafts, not currency. April 2026 proposed financing was withdrawn and must not be included as pending dilution.

The March 2026 cash figure is mostly restricted deposits. It cannot be treated as freely spendable cash, but it also cannot establish an October 2026 cash deficit. The October warrants were still proposed at the cutoff; no future approval, allotment, exercise, or proceeds should be presented as certain.

## 1. Original audit opinions and changes in audit coverage

| Original period | Auditor and report date | Physical PDF pages | Finding and limitation |
|---|---|---|---|
| FY2020 | Sharp & Tannan; 8 December 2020 | [Original FY2020](https://sharpchucks.com/report-19-20.pdf), pp1,4–6,9 | Unmodified opinion and IFC. CARO reports no material PPE discrepancy, immaterial inventory discrepancies reconciled, and no debt default. |
| FY2021 | Sharp & Tannan; 30 November 2021 | [Original FY2021](https://sharpchucks.com/report-20-21.pdf), pp1,4–6,9 | Unmodified opinion and IFC; no material PPE/inventory discrepancy and no debt default reported. |
| FY2022 | Sharp & Tannan; 19 September 2022 | [Original FY2022](https://sharpchucks.com/report-21-22.pdf), pp1,4–5,7–9,11 | Unmodified opinion and IFC. Bank quarterly returns agree with books; no debt default or use of short-term funds for long-term purposes reported. |
| FY2023 | Sharp & Tannan; 7 September 2023 | [Original FY2023](https://sharpchucks.com/report-22-23.pdf), pp1,5–8,10,12 | Unmodified opinion and IFC. PPE discrepancies reported; ₹608.41 lakh of short-term funds used for plant/machinery. CSR ₹10.49 lakh provided but unspent through audit date. The inventory paragraph refers to additional notes, while reporting no material physical-count discrepancy. |
| FY2024 | Sharp & Tannan; 29 May 2024 | [AR2024](https://www.sharpchucks.com/pdf/annual-report-23-24.pdf), pp50,53–56,60 | Unmodified opinion and IFC. Audit-trail software exception, PPE discrepancies and ₹523.38 lakh short-term funds used for long-term purposes. CARO says no default to any lender. |
| FY2025 | V. P. Bhalla & Associates; 30 May 2025 | [AR2025](https://sharpchucks.com/wp-content/uploads/2025/09/ANNUAL-REPORT-2024-25.pdf), pp33,35–41 | Unmodified opinion and IFC. Audit-trail exception and PPE reconciliation issue persist. ₹523.38 lakh short-term funds used for long-term purposes is repeated. CARO reports no default. |
| FY2026 | V. P. Bhalla & Associates; 30 May 2026 | [AR2026](https://sharpchucks.com/wp-content/uploads/2026/09/annual-report-2025-26.pdf), pp41,43–49,51 | Unmodified opinion and IFC; PPE discrepancies persist and no default is reported. The audit-trail paragraph and the prior short-term-use paragraph are absent. Absence is not affirmative evidence of remediation. |

The FY2024 audit report's exception concerns software audit trails and the proper-books reporting paragraph, not a qualified financial-statement opinion. FY2025 repeats the exception. FY2026 omits the corresponding Rule 11(g) paragraph; request a complete signed report or explicit implementation/remediation evidence rather than interpreting silence as either continuing breach or cure.

The FY2024 AGM notice and directors' report explain that Sharp & Tannan's 2019–2024 term was expiring and propose V. P. Bhalla for 2024–2029 ([AR2024](https://www.sharpchucks.com/pdf/annual-report-23-24.pdf), pp5,18). FY2025 CARO says the outgoing auditor raised no concern. FY2026 front matter still lists Sharp & Tannan and CARO repeats the resignation narrative, although V. P. Bhalla signed both FY2025 and FY2026. These are stale-reference/control-quality issues, not evidence by themselves of opinion shopping.

### Historical debt-service contradiction, with subsequent cure evidence

[CARE's 11 January 2024 release](https://www.careratings.com/upload/CompanyFiles/PR/202401130123_Sharp_Chucks_and_Machines_Limited.pdf), p1, assigns D/issuer-noncooperating and refers to public information about debt-service delays. This is not solely a missing-information rating. [CARE's 18 February 2025 release](https://www.careratings.com/upload/CompanyFiles/PR/202502140216_Sharp_Chucks_and_Machines_Limited.pdf), p2, and [9 January 2026 release](https://www.careratings.com/upload/CompanyFiles/PR/202601150152_Sharp_Chucks_and_Machines_Limited.pdf), p2, specify delays in December 2023 and March 2024, followed by regular term-debt servicing from April 2024. FY2024 CARO nevertheless reports no default in principal or interest to any lender ([AR2024](https://www.sharpchucks.com/pdf/annual-report-23-24.pdf), p56).

This requires a facility-level reconciliation of missed instalment/interest dates, amounts, days past due, regularisation and the CARO assessment. Do not state that default continues. [CARE's 7 September 2026 release](https://www.careratings.com/upload/CompanyFiles/PR/202609140922_Sharp_Chucks_and_Machines_Limited.pdf), pp1–3, is affirmative later counterevidence: BB+/Positive, adequate liquidity and projected FY2027 gross cash accruals of ₹29 crore against ₹9.78 crore repayments. It also retains financing constraints, including 98% working-capital utilisation over the twelve months through July 2026 and approximately ₹30 crore capex.

## 2. Restatement vintage bridge: do not combine incompatible series

The final prospectus Annexure V supplies the following original-to-restated PAT bridge. FY2020 is available in the draft prospectus, not the final three-year restated set.

| Fiscal year | Original PAT | Restatement adjustment to PAT | Restated PAT | Primary locator |
|---|---:|---:|---:|---|
| 2020 | 314.63 | -16.28 | 298.35 | [Draft prospectus](https://archives.nseindia.com/emerge/corporates/content/SharpChucks_DP.pdf), p226, printed p224 |
| 2021 | 380.52 | -49.56 | 330.96 | [Final prospectus](https://archives.nseindia.com/emerge/corporates/content/SharpChucks_PROSP.pdf), p208, printed p207 |
| 2022 | 453.97 | -1.35 | 452.62 | Same |
| 2023 | 473.39 | +33.11 | 506.50 | Same |

Using expense signs, FY2023 adjustments comprise GST interest +10.05, deferred tax -1.67, tax/MAT -37.90, excess MSME-interest provision reversal -6.59 and IPO professional fees +3.00. The net expense adjustment is -33.11, hence PAT increases by 33.11. FY2022 is GST +7.39, deferred tax -0.12 and tax/MAT -5.92. FY2021 is MSME +7.09, GST +8.72, deferred tax +0.74 and tax/MAT +33.01. The draft FY2020 bridge is MSME +17.60, GST +10.42, deferred tax -14.61 and tax/MAT +2.87. See the same Annexure V pages above.

Final-prospectus net worth is 4,275.67 / 4,728.29 / 5,234.79 for FY2021/22/23, versus originals 4,284.20 / 4,738.17 / 5,211.56. Draft FY2021/22 restated net worth is 4,287.75 / 4,740.37, or 12.08 higher in each year than the final prospectus, despite the same restated PAT. The full journal explanation for that draft-to-final opening-equity difference was not located. Prefer the final prospectus consistently; identify any FY2020 draft-vintage number explicitly.

The final prospectus reclassifies director/promoter loans from other long-term liabilities to borrowings: FY2021 222.22, FY2022 328.22 and FY2023 316.32. Debt comparisons must include them on a common basis. The FY2023 PSPCL rebate of 218.00 moves from net power/fuel expense to other income. This is a presentation change, not another 218.00 of PAT. Original total revenue 17,706.86 becomes final restated 17,931.45 because of that 218.00 reclassification and 6.59 provision reversal. Sources: [Final prospectus](https://archives.nseindia.com/emerge/corporates/content/SharpChucks_PROSP.pdf), pp193,208; [Original FY2023](https://sharpchucks.com/report-22-23.pdf), pp22,33.

The final restatement auditor's report discusses the CSR exception and adjustments; it does not transform all original statutory opinions into qualified opinions ([Final prospectus](https://archives.nseindia.com/emerge/corporates/content/SharpChucks_PROSP.pdf), p187).

## 3. Unresolved asset and earnings-quality evidence

### Inventory and PPE

FY2024 note 30(O) reports inventory of 7,608.13 without stage-wise WIP tracking. An independent cost accountant valued it, but the basis was not provided for verification. FY2025 and FY2026 again say stage-wise tracking methodology is not followed and rely on the cost accountant. FY2026 inventory is 10,739.97, including WIP 4,880.54, against total assets 29,346.46. Fixed-asset physical/book reconciliation is described as still being upgraded. Sources: [AR2024](https://www.sharpchucks.com/pdf/annual-report-23-24.pdf), pp55,85; [AR2025](https://sharpchucks.com/wp-content/uploads/2025/09/ANNUAL-REPORT-2024-25.pdf), pp36–37,63; [AR2026](https://sharpchucks.com/wp-content/uploads/2026/09/annual-report-2025-26.pdf), pp46,59,74.

The material question is valuation/stage reconciliation, not a disclosed material physical-stock shortage. CARO reports no material inventory discrepancies, bank quarterly returns agreeing with books, and unmodified IFC opinions. Required evidence: product/stage quantities and ageing, cost-accountant valuation workings, reconciliation to general ledger and lender returns, audit testing that overcomes the stated limitation, and quantified PPE adjustments.

### GST interest and confirmations

FY2024 note 30(N) identifies current-year GST interest of 7.71 plus 48.66 for FY2020–23, pending deposition and to be recorded on a cash basis. FY2025 note 30(M) discloses current-year 6.38 on a cash basis without the earlier cumulative balance. The equivalent FY2026 paragraph is absent. The prospectus had explicitly restated GST-interest accruals, making a year-by-year original/restated/booked/paid/reversed bridge essential. Do not automatically add the disclosed historical amounts to current debt or expenses because settlement and double counting are unresolved. Sources: [AR2024](https://www.sharpchucks.com/pdf/annual-report-23-24.pdf), p85; [AR2025](https://sharpchucks.com/wp-content/uploads/2025/09/ANNUAL-REPORT-2024-25.pdf), p63; [AR2026](https://sharpchucks.com/wp-content/uploads/2026/09/annual-report-2025-26.pdf), p74; [Final prospectus](https://archives.nseindia.com/emerge/corporates/content/SharpChucks_PROSP.pdf), p208.

FY2024 and FY2026 notes state that debtor, creditor and loan/advance balances are subject to confirmation and that differences will be dealt with in the reconciliation year. FY2026 receivables are 5,269.31, advances to parties 932.99 and trade payables 4,311.62. Request external confirmations and subsequent collection/payment testing. No quantified misstatement or disputed balance was established. Sources: [AR2024](https://www.sharpchucks.com/pdf/annual-report-23-24.pdf), p90; [AR2026](https://sharpchucks.com/wp-content/uploads/2026/09/annual-report-2025-26.pdf), pp58–59,78.

### Related parties, insurance and compliance

FY2026 discloses sales of 1,197.21 and purchases of 698.52 with Sharp Precision Private Limited, versus zero in FY2025. Directors' remuneration is 72.00; director travel 12.03; new unsecured borrowing 6.90; total loan/advance payables to directors and others are 16.82. This is disclosed RPT activity, not proof of circular sales. The directors' claim of no materially significant conflicting RPTs does not mean there were no RPTs. CARO reports Sections 177/188 compliance. Seek ownership/control mapping, approval and pricing support, product flows and settlement/outstanding trade balances. Source: [AR2026](https://sharpchucks.com/wp-content/uploads/2026/09/annual-report-2025-26.pdf), pp21,48,70–71.

An 8.73 insurance receipt for a flood-damaged factory wall was credited against insurance expense in FY2026, with repairs to be expensed when incurred in the next year. Separate this credit and future repair cost in sustainable earnings; its size is less than 1% of FY2026 PAT before tax effect and it is expressly disclosed. Source: [AR2026](https://sharpchucks.com/wp-content/uploads/2026/09/annual-report-2025-26.pdf), p74, note 30(P).

FY2025 secretarial audit reports a ₹519,200 NSE fine for not applying for preferential-share listing within seven working days, paid 20 December 2024. FY2026 reports a paid ₹2,000 Regulation 34 fine and some late ROC forms. These matter to compliance quality but should not be described as major enforcement sanctions. Sources: [AR2025](https://sharpchucks.com/wp-content/uploads/2025/09/ANNUAL-REPORT-2024-25.pdf), p27; [AR2026](https://sharpchucks.com/wp-content/uploads/2026/09/annual-report-2025-26.pdf), p32.

FY2023 CSR of 10.49 was booked but unpaid at audit date; subsequent years report spending and FY2026 spent 17.50 against a 17.37 requirement. FY2023 CARO lists an income-tax dispute of 38.25 net of a 9.57 predeposit; later contingent-liability/CARO disclosures do not repeat it. Neither current unpaid CSR nor current adverse tax liability should be inferred without an updated case or payment status. Sources: [Original FY2023](https://sharpchucks.com/report-22-23.pdf), pp7,10; [AR2026](https://sharpchucks.com/wp-content/uploads/2026/09/annual-report-2025-26.pdf), pp60,76–77.

## 4. Cash restrictions and debt schedule

As of 31 March 2026, cash/bank totals 1,042.36, but 990.69 comprises fixed deposits held as security and unavailable for immediate use. The remaining 51.67 is cash 33.94 plus bank balances 17.73. Treat 51.67 as a ceiling before any other restrictions, not assured free cash. Unutilised IPO escrow 1.25 is separately disclosed; its overlap with bank balances needs reconciliation, so do not subtract it twice. The 90.91 LC-margin deposit is not proven additional to the 990.69 restricted-deposit total. The 300.00 LC facility is contingent, not automatically drawn debt. Sources: [AR2026](https://sharpchucks.com/wp-content/uploads/2026/09/annual-report-2025-26.pdf), pp59–60,73–74.

FY2025 gross cash/bank 936.86 less restricted deposits 917.05 leaves 19.81; individual cash/bank components total 19.82, a 0.01 rounding difference. For later-period counterevidence, CARE reports ₹11.42 crore cash and liquid investments at 30 June 2026, but does not bridge these to the March restricted deposits. October cash requires an actual bank/deposit roll-forward, not merely extrapolation from the audited anchor. Source: [CARE September 2026](https://www.careratings.com/upload/CompanyFiles/PR/202609140922_Sharp_Chucks_and_Machines_Limited.pdf), pp2–3.

At 31 March 2026, term debt is 2,488.43, split into noncurrent 1,510.70 and current 977.73. Short-term borrowings are 9,608.22. Total debt excluding director loans is 12,096.65; including 16.82 interest-free director/other loans classified under other long-term liabilities gives 12,113.47. Maturities are FY2027 977.73; FY2028 869.92; FY2029 527.78; FY2030 onward 112.99. These sum to 2,488.42, within 0.01 of gross term debt, consistent with component rounding. Individual lender subtotals presented in the note add to 2,466.11, leaving an unexplained 22.32. Sources: [AR2026](https://sharpchucks.com/wp-content/uploads/2026/09/annual-report-2025-26.pdf), pp52,56–60.

Two FY2026 printed numbers are demonstrably wrong, not OCR artifacts: note 27 depreciation is printed as 0.01, whereas the P&L and PPE schedule support 795.14; note 8 prints FY2025 current term maturities as 0.01, whereas the balance sheet and borrowing note support 1,114.07. Several note headings say rupees even though the numbers reconcile in lakh. Use reconciled headline numbers and seek corrected signed schedules; do not let a unit-label error create an artificial insolvency or an automatic gate failure. Sources: [AR2026](https://sharpchucks.com/wp-content/uploads/2026/09/annual-report-2025-26.pdf), pp52–53,56,58,62,80. The actual rendered pages were inspected.

### Resolved apparent FY2022 cash anomaly

The final prospectus cash-flow label shows 2,528.52 as cash in hand for FY2022, but note 20 splits that into actual currency of 5.52 and cheques/drafts of 2,523.00. FY2023 combined 89.69 similarly comprises 14.69 currency and 75.00 cheques. The original FY2023 note confirms the components. This resolves the allegation that ₹25.29 crore was literal physical cash; cheque clearance/collection dates remain a valid follow-up. Deposits of 48.97 / 28.18 in FY2022/23 have long-maturity/security restrictions. Sources: [Final prospectus](https://archives.nseindia.com/emerge/corporates/content/SharpChucks_PROSP.pdf), pp194,200; [Original FY2023](https://sharpchucks.com/report-22-23.pdf), p29.

## 5. Issued capital, withdrawn issue and conditional October warrants

### Current shares and authorisation

Issued capital is **14,496,792 shares**, not that number plus the old 2,412,000 warrants again. Those warrants converted on 17 November 2025 at ₹76.12. The NSE's July 2026 circular confirms the resulting shares and admitted them to dealings from 3 July 2026. Sources: [AR2026](https://sharpchucks.com/wp-content/uploads/2026/09/annual-report-2025-26.pdf), pp18,48,55–56; [NSE CML75019](https://nsearchives.nseindia.com/content/circulars/CML75019.pdf), pp1–2.

March 2026 authorised capital is 17,500,000 shares. The April notice proposed a separate increase to **21,000,000** shares and the May 6 voting result confirms that resolution passed with 99.97% votes in favour. June's cancellation of preferential financing does not state that the separate capital resolution was reversed. Therefore, do not claim that full October conversion exceeds the approved 21 million share authorisation; actual Registrar filing/effectiveness was not separately inspected. Sources: [April EGM notice](https://sharpchucks.com/wp-content/uploads/2026/04/Notice_SCML.pdf), pp1,25; [May 6 NSE voting results](https://nsearchives.nseindia.com/corporate/SHARPCHUCKS_06052026205229_SCML_Voting_results.pdf), p2.

### April proposal cancelled

The April proposal comprised 2,637,000 equity shares and 3,063,000 warrants at ₹142.50, for potential proceeds of ₹81.225 crore. It was approved by shareholders in May but **withdrawn and cancelled on 4 June 2026**, citing market volatility and changed share price. Exclude all 5.7 million potential shares and all associated proceeds from active dilution/funding scenarios. The primary cancellation filing is decisive, not an inference from later share counts. Source: [NSE June 4 cancellation](https://nsearchives.nseindia.com/corporate/SHARPCHUCKS_04062026181638_Intimation_30_04062026.pdf), pp1–2.

### October proposal remained unapproved at the cutoff

The board proposed 4,000,000 warrants at ₹81, totalling ₹32.40 crore if fully subscribed and exercised. The shareholder EGM was scheduled for 31 October 2026, after the cutoff. The October notice says there are no other outstanding convertibles. Half the warrants are for promoter/group members and half for public investors. Full conversion would create **18,496,792 shares**; promoter/group holding would rise from 9,230,542 shares (63.67%) to 11,230,542 shares (60.72%). Source: [October EGM notice](https://sharpchucks.com/wp-content/uploads/2026/10/Notice-of-EGM-31-10-2026.pdf), pp1,20–24.

The exact contractual timing is relative, not a calendar promise:

- 25%, or ₹8.10 crore at full subscription, is payable on warrant subscription/allotment.
- Remaining 75%, or ₹24.30 crore, is payable only on exercise.
- Warrants may be exercised in one or more tranches within **18 months of actual allotment**. No fixed first exercise date or known final calendar date exists at the cutoff.
- Warrant allotment is required within 15 days of the shareholder resolution, or within 15 days of the last pending regulatory approval. In-principle stock-exchange approval is expressly required.
- Shares after exercise are to be allotted within 15 days of exercise.
- Unexercised warrants lapse at 18 months, and the upfront amount is forfeited.

Sources: [October EGM notice](https://sharpchucks.com/wp-content/uploads/2026/10/Notice-of-EGM-31-10-2026.pdf), pp3–4,17–18,22. A model may use November 2026 allotment and May 2028 full exercise **only as a conditional scenario**. It must not label those dates legal certainties or treat optional exercise cash as a committed loan/refinancing source.

Proposed full proceeds allocations are working capital ₹6.50 crore, land/development rights ₹4.50 crore, manufacturing facilities ₹3.00 crore, equipment/tooling ₹6.65 crore, strategic investment ₹3.75 crore and general corporate purposes ₹8.00 crore. Management estimates use within 12 months of receipt of each tranche. The objects are not externally appraised; the notice says the issue is below the ₹100 crore threshold for mandatory monitoring-agency appointment. Source: [October EGM notice](https://sharpchucks.com/wp-content/uploads/2026/10/Notice-of-EGM-31-10-2026.pdf), pp18–20,27.

The notice states a regulatory floor of ₹80.41 (90-day VWAP; 10-day VWAP ₹74.04), registered-valuer result ₹80.32 and selected price ₹81. The [October company-secretary certificate](https://sharpchucks.com/wp-content/uploads/2026/10/Certificate-under-Regulation-163-2-of-the-SEBI-ICDR-Regulations-2018.pdf), pp1–2, is limited compliance assurance, not evidence that shareholders/exchange approved the issue or that money was received.

## 6. Minimum evidence to resolve the Hold

1. Independent cost-accountant WIP workings and inventory/PPE quantity, stage, ageing and valuation reconciliations, with the auditor's explanation of how disclosed limitations were addressed.
2. FY2020–FY2026 GST-interest journal/payment bridge, including how original and prospectus-restated accruals were incorporated or reversed.
3. External bank evidence reconciling the CARE-described December 2023/March 2024 delays with FY2024 CARO, plus current sanction terms, lender confirmations and deposit restrictions.
4. Actual June-to-October 2026 bank/deposit/capex/debt roll-forward, including whether CARE's liquid investments are restricted; no funding conclusion should depend on an unlabelled stale March cash anchor.
5. Debtor/creditor/advance confirmations and subsequent settlement evidence; Sharp Precision ownership, pricing, product flow and settlement support.
6. Corrected audit-trail reporting, signed financial-note corrections and the 22.32 term-debt schedule reconciliation.
7. Registrar evidence for the authorised-capital increase; if the October raise is relied on, post-cutoff shareholder/exchange approvals, allotment dates, actual 25% receipts and later conversion receipts. Those future events are outside this historical cutoff.

## Source and inspection limitations

The original FY2020–23 investor-page links under `/pdf/` returned 404, but the issuer's root-level `report-19-20.pdf` through `report-22-23.pdf` files were recovered and inspected. The FY2023 uploaded file includes the original audit and financial statements but the referenced accounting-policy/additional-note pages were not located; no claim is made that those missing original notes were reviewed. FY2024–25 scanned passages were OCRed and material anomalies visually checked. Exact URLs, source SHA-256 hashes, audit dates, numerical bridges and unresolved/counterevidence fields are preserved in the accompanying `audit_inputs.json`. No inference of misconduct rests solely on OCR, duplicated templates, a clean-opinion label, or a future modelled cash gap.
