from decimal import Decimal as D
import json,hashlib,html,re
def conv(x):
 if isinstance(x,D):return str(x)
 raise TypeError(type(x).__name__)
def js(x,pretty=False):return json.dumps(x,ensure_ascii=False,default=conv,sort_keys=True,indent=2 if pretty else None,separators=None if pretty else(',',':'))
def sha(b):return hashlib.sha256(b).hexdigest()
def fmt(x,d=2):
 if x is None:return 'ND / NS'
 if isinstance(x,bool):return 'Yes' if x else 'No'
 try:return f'{D(str(x)):,.{d}f}'
 except:return str(x)
def pct(x):return 'NS'if x is None else fmt(D(str(x))*100)+'%'
def cell(x):return str(x).replace('|',' / ').replace('\n',' ')
def table(head,rows):return '| '+' | '.join(head)+' |\n|'+ '|'.join(['---']*len(head))+'|\n'+'\n'.join('| '+' | '.join(cell(x)for x in r)+' |'for r in rows)
def mdhtml(s):
 def inline(t):
  t=html.escape(t);t=re.sub(r'\[([^\]]+)\]\(([^)]+)\)',r'<a href="\2">\1</a>',t);return re.sub(r'\*\*(.+?)\*\*',r'<strong>\1</strong>',t)
 out=[];lines=s.splitlines();i=0
 while i<len(lines):
  l=lines[i]
  if l.startswith('|'):
   seq=[]
   while i<len(lines)and lines[i].startswith('|'):seq.append(lines[i]);i+=1
   out.append('<div class="table"><table>')
   for k,row in enumerate(seq):
    if k==1 and set(row.replace('|','').replace('-','').replace(':','').strip())==set():continue
    tag='th'if k==0 else'td';out.append('<tr>'+''.join('<'+tag+'>'+inline(v.strip())+'</'+tag+'>'for v in row.strip('|').split('|'))+'</tr>')
   out.append('</table></div>');continue
  m=re.match(r'^(#{1,6}) (.*)',l)
  if m:tag='h'+str(len(m[1]));out.append('<'+tag+'>'+inline(m[2])+'</'+tag+'>')
  elif l.strip():out.append('<p>'+inline(l)+'</p>')
  i+=1
 return '<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Sharp Chucks and Machines | SME research 362</title><style>body{max-width:1120px;margin:40px auto;padding:0 22px;font:16px/1.55 system-ui;color:#172635;background:#fbfcfe}h1,h2{color:#123e59}h2{margin-top:2.5em;border-top:1px solid #d4dfe7;padding-top:1em}a{color:#05618c;overflow-wrap:anywhere}.table{overflow-x:auto;max-width:100%}table{border-collapse:collapse;width:100%;font-size:13px;margin:16px 0}th,td{border:1px solid #d4dfe7;padding:8px;vertical-align:top}th{background:#e9f0f5}tr:nth-child(even){background:#f3f6f9}@media print{body{margin:0;font-size:10pt}.table{overflow:visible}h2{break-before:auto}tr{break-inside:avoid}}</style><body>'+''.join(out)+'</body></html>\n'
