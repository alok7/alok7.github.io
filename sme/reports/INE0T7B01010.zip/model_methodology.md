# Shivalic Power Control: monthly model methodology

## Interpretation comes before the numbers

This is a standalone-core scenario and funding model, not a consolidated price target. Every ordinary common-equity IRR and total-company price is NS. A funded path can report the panel business's equity contribution per current or conditionally diluted share; it cannot tell us the value of Somaya Solar, Prima Solar, Religreen, Seedlab, their financing, or the recoverability of the parent's loans. Missing subsidiary value is not assigned zero. A core-only illustrative IRR is explicitly a sufficiency diagnostic: what the modeled core contribution alone would return against the entire quoted entry price. It is not a prediction of the shareholder's total return.

The valuation price is the verified NSE Emerge close of ₹63.15 on 19 October 2026. The model uses 24,115,754 issued shares, not the previous year's weighted-average EPS denominator. All monetary amounts in the model are ₹ crore, except per-share prices and explicitly identified rupee amounts. Decimal arithmetic uses 40-digit precision; JSON stores unrounded decimal strings.

## Date and entity boundaries

The source operating balance sheet is standalone 31 March 2026. Forecast months are labelled November 2026 onward: 60 months for the five-year model and 120 months for the ten-year model, each followed by 12 explicit terminal-transition months. There is no verified April–October operating, working-capital, cash or debt bridge. These are therefore conditional paths seeded with an old balance sheet, not reconstructed actual monthly accounts or verified October liquidity.

The ₹1.50 crore Prima loan disclosed after March and ₹0.0143 crore Seedlab consideration are separately charged in the first model month as a transparent pro forma funding stress. The first-month date is not asserted to be their actual payment date. The balance sheet and those later commitments are not silently mixed and presented as a current audited opening. A first-month shortfall is a model funding gap, not evidence of a default. The annual audit's reported absence of default is not overridden by the model.

Consolidated revenue, cash, inventory and debt are not inserted into standalone cash generation. The first FY2026 consolidated period includes acquisition-date results; it is not a full-year organic operating history for the subsidiaries. Group PAT of ₹13.1182 crore includes approximately ₹1.3496 crore of NCI profit. Owner PAT and EPS, rather than total group PAT divided by parent shares, are the applicable equity-earnings cross-check.

## Complete opening state

The source binding identifies the exact financial JSON and a hash-preserved input vintage. Lakh values are divided by 100 without editing the financial worker's original fields.

| Opening item | ₹ crore | Treatment |
|---|---:|---|
| Standalone annual revenue | 143.65930 | Operating anchor, not FY2027 forecast |
| Annual D&A | 1.74470 | Existing-asset depreciation anchor |
| Cash in hand | 0.39224 | Historical deployability floor only |
| Term deposits | 16.22970 | Separate asset; restriction and release dates unknown |
| Trade receivables | 47.69240 | Explicit collection queue |
| Inventory | 73.32660 | Explicit purchases and material consumption |
| Trade payables | 11.10990 | Explicit supplier-payment queue |
| Customer advances | 3.79842 | Separate receipts and application balance |
| Other operating current assets and imprest | 4.64150 | Includes ₹0.26749 crore employee imprest, not cash available for valuation |
| Other current cash claims | 2.03435 | Other current liabilities excluding customer advances, plus auditor payable |
| Current income-tax provision | 0 | Source-disclosed zero, not a missing-value substitution |
| PPE and intangible carrying amount | 19.22940 | Separate commissioned and paid-but-uncommissioned assets |
| Cash-credit debt | 24.27730 | On demand; current renewal terms not verified |
| Term debt | 3.25398 | Seven named facilities, individual interest and maturity treatment |
| Post-March Prima loan in opening | 0 | It is added as a later disclosed advance, not assumed already in March balances |
| Acquired investment historical cost | 6.5500782 | Memorandum record, never automatically added as fair value |

Short- and long-term employee-benefit claims of ₹1.15533 crore are separately retained for the core equity bridge. Uncertain deposit restrictions, unused lending limits, subsidiary fair values, NCI market value, parent-loan recoverability and separately capitalized lease claims remain null/ND/NS as applicable, not forced numeric zeros. A numeric zero draw under a closed financing gate means no assumed usable financing, not proof that the real facility has zero capacity.

The opening inventory notes distinguish raw materials ₹31.5304 crore, WIP ₹18.3316 crore and finished goods ₹23.4645 crore. Forecast inventory is an aggregate manufacturing working-capital proxy. Material expense of ₹110.14052 crore is raw-material consumption adjusted for the disclosed finished-goods/WIP change. Labor and other costs are separately modeled; the inventory-day denominator is not represented as a fully observed economic COGS schedule.

## Physical panel bridge and capex

The RHP disclosed 10,000 verticals of annual installed capacity on three shifts, with FY2023 production of 3,900. That is historical capacity, not a current output certificate. FY2023 revenue of ₹82.1568 crore divided by 3,900 gives a historical revenue-per-vertical proxy. Three years of explicitly assumed 3% price/mix escalation produce ₹0.02301921887 crore per panel-equivalent and approximately 6,240.84 panel-equivalents for the FY2026 standalone revenue anchor.

These are analytical equivalents, not reported FY2026 physical units. Standalone EPC and product mix may make the proxy inaccurate. The model exposes that limitation rather than silently applying a revenue CAGR unrelated to physical production. Revenue equals delivered panel-equivalents times assumed price. Delivery is capped by commissioned capacity. Unfulfilled demand and terminal lost units are retained.

Conditional expansion costs ₹0.0035 crore per unit of annual vertical capacity, has a six-month commissioning lag and seeks 20% capacity headroom. This is an analyst capital-intensity assumption, with a 50% cost-inflation case and a 12-month lag case. Source-bounded paths cannot assume additional installed capacity.

The March 2026 remaining IPO core-capex earmark is ₹5.7146 crore: ₹1.08 crore machinery and ₹4.6346 crore assembly work. It is spent over six scenario months and commissioned after the same lag. This remaining amount might have been spent before the research cutoff; completion is not verified. No quantified capacity uplift is invented for this IPO spending. Conditional incremental capacity is modeled and paid for separately. That is intentionally conservative but may overstate future required expenditure if the IPO work already created usable capacity; the uncertainty is not hidden.

Maintenance capex is 2% of sales in the reference path. Terminal maintenance must also cover the modeled replacement allowance, and terminal replacement capex cannot be less than D&A. Payments enter the cash flow when made, assets enter PPE only on commissioning, and D&A follows commissioned assets. Paid pipeline balances are not counted as freely available cash.

## Monthly operating cash mechanics

Opening receivables are collected over an explicit number of months, with recovery haircuts only in identified stresses. New credit sales enter a dated collection queue. Customer advances are both received and applied separately; the same sale cannot be collected twice. Opening supplier balances have their own payment queue. Material purchases equal material use plus the required inventory build, subject to no negative purchases. Supplier payments follow the selected payment lag.

The reference operating assumptions are 7% annual panel-equivalent volume growth, 2% price growth, 11% operating EBITDA margin, 210 inventory days, four-month new-receivable collection lag and one-month new-purchase supplier lag. Source-bounded base inventory is 240 days, close to the historical year-end proxy of 243 days. The improvement to 210 days is a conditional normalization, not established cash conversion. There is also a 245-day case and a six-month collections case.

The material ratio comes from FY2026 standalone disclosures. Other operating costs are split between 55% fixed and 45% sales-sensitive components. Thus customer loss affects utilization, operating leverage and cash generation, not merely the terminal multiple. Cash tax is 26% of positive post-interest profit; no loss tax asset is monetized. Operating FCFF removes financing and uses tax on positive operating EBIT. Other income, deposit interest and uncollected related-loan interest are not treated as recurring operating cash generation.

## Deposits, facilities and maturity gates

Deposit availability is unresolved. Source-bounded cases release no deposit and invent no new borrowing headroom. The conditional reference releases all ₹16.2297 crore, renews the existing cash-credit balance and permits up to ₹25 crore of hypothetical new debt, with a ₹50 crore cumulative new-money limit. The reference may not actually draw that capacity; realized draws are shown. The no-new-debt case tests whether the permission is necessary. Conditional facility existence or renewal is not an actual sanction or an authorisation.

Cash-credit interest is assumed at 10.5%; a demand-call stress repays its entire outstanding balance in month 12. That month is a stress convention, not a discovered expiry date. The old prospectus's ₹30 crore WCDL limit and 90-day tenor are historical context only and do not establish current available headroom.

Seven term facilities use their printed opening balances, rates, EMIs and stated maturity dates. Each month's principal is the lesser of balance and EMI less monthly interest. Any residual is paid at the stated maturity. The HDFC MSME EMI is ND, so the model retains interest and pays a bullet at its July 2027 maturity as a stress convention, not a verified contractual amortization schedule. The March-to-November missing bridge also affects these stale opening loans. A ₹0.001 lakh difference between summed facility balances and reported term debt is explicitly reconciled in the final facility, not silently discarded. A separate immediate-call stress is retained.

New debt bears 13.5% interest and 1.5% draw fees. Current-month interest is charged on the actual draw as well as opening debt. The draw calculation solves for the cash requirement including that interest and the available tax shield; it does not fund a deficit and then omit the financing cost that caused a new deficit. New-money limits, three-year maturities, renewals and fees are explicit. No new draw or equity rescue is allowed in the terminal transition. Any allowed pre-terminal refinancing is distinctly conditional.

The minimum operating reserve is the greater of ₹0.50 crore and 15% of a month's material and cash operating cost. A path stops at its first unmet reserve or liquidity obligation. Its failure row, negative or positive remaining cash and exact shortfall remain in the canonical archive. No ordinary investor return is emitted for failed paths.

## Acquisitions, loans, guarantees and options

Somaya's 51.64% ownership and Prima's 51.22% reported actual allotment are distinct from 100% group assets and profits. Prima's 51% approval wording conflicts with the 10,500-of-20,500 actual allotment and AOC percentage; the discrepancy remains visible. Seedlab is a separately disclosed 51% acquisition. The ₹6.5500782 crore historical acquisition cost is neither added to core value as if a verified market price nor treated as the subsidiaries' future cash flow.

The Prima loan is a separate parent financial claim. ₹1.50 crore is disclosed as already advanced after March; the ₹20 crore maximum is not assumed paid. The full-limit stress substitutes ₹20 crore total for the ₹1.50 crore case, so it does not add the first advance twice. The specific approval states 9% interest, but collection and principal-repayment timing are not established. The model assumes no receipt without a separate condition and leaves recoverable loan value NS. That is a cash-flow permission boundary, not a conclusion that the loan is worthless.

The ₹100 crore related-party transaction authorizations for Somaya and Prima are limits, not revenues, completed payments or separate lending facilities. They are not included as operating assets or funding.

Disclosed guarantees are contingent, not ordinary funded debt. The ₹8.632 crore HDFC grid-connection BG and ₹20.9115 crore older standalone guarantee disclosure each have their own called-guarantee stress. Their overlap is not resolved, so they are not summed as distinct debt or paid capex. A call reduces cash only in its selected scenario and is not also subtracted as outstanding debt in the terminal bridge.

The approved ESOP pool is 300,000 options, not 600,000 and not already issued capital. Approval alone supplies no cash. The full-pool exercise sensitivity adds 300,000 shares and ₹0.30 crore cash at the ₹10 strike in month 48. Vesting and grants are not assumed to have occurred in the source-bounded scenarios. This is an explicit dilution stress, not a forecast issuance schedule.

## Earned terminal value and no cash/debt double count

The engine runs another full year after each investment horizon. Terminal growth is normally 4%; WACC is 16%. A 13–17% range is the reference cost-of-capital discussion, while the 19% grid point is an adverse-rate stress. The WACC/g grid tests 13%, 15%, 17%, 19% against 2%, 4%, 6%. Equity-hurdle tests are separate at 12%, 15% and 18%.

Terminal operating NOPAT is earned from this extra year, not mechanically extrapolated from reported PAT. Replacement capex is at least D&A. Growth reinvestment is the larger of physical growth capex plus positive operating-working-capital growth and NOPAT × terminal growth / terminal ROIC. Terminal ROIC is a conditional 14% recovery assumption, not achieved historical performance; 8% and 10% cases test weaker reinvestment economics. Terminal FCFF equals NOPAT plus D&A less replacement and growth reinvestment. Terminal EV is FCFF divided by WACC less growth, floored at zero only for the limited-liability core claim calculation.

The model computes the largest cash requirement over every transition month, including any additional replacement and reinvestment not already paid in the monthly cash schedule. A terminal value is suppressed if that requirement is not funded or if the extra year cannot meet demand with physical capacity. No exit distribution can leave the transition below the reserve.

Funding reserves and valuation operating reserves are different. Cash earmarked for debt principal, interest net of tax shield, or other separately deducted senior claims is added back when calculating the operating reserve. The equity bridge then adds cash above that operating reserve and subtracts debt and remaining senior claims exactly once. It does not deduct debt-service cash from assets and the same debt again from equity. Restricted or uncertain deposits are not automatically added. No modeled dividends are distributed during the horizon, so retained cash is not counted twice as both dividends and terminal cash.

An EBITDA multiple cross-check uses 8× in the reference, with 6× normalization. These are analytical multiples, not verified peer trading medians. The explicit operating FCFF DCF and terminal share of that DCF are separately retained; terminal dependence can exceed 100% when the explicit investment period consumes cash.

## Scenario families, reverse expectations and targets

Bear, base and bull preserve source-bounded financing gates and differ in customer loss, volume, pricing, margins, collections, inventory and capex timing. They are not assigned probabilities or averaged into an expected return.

Conditional cases separately test FD release, new-debt permission, CC renewal, new-debt renewal, inventory normalization, collections, commissioning delays, capex inflation, Prima funding, called guarantees, option exercise, IPO-only deposit release, later subsidiary outflows, maturity acceleration, lower exit multiples and terminal reinvestment returns. Both five- and ten-year horizons are run.

The growth/margin grid uses volume growth of 0%, 5%, 10%, 15% and 20% and EBITDA margins of 8%, 11% and 14%. Reverse expectations use a saved 0–40% volume-growth grid in two-percentage-point steps. A wider target envelope tests 10%, 20%, 30%, 40%, 60% growth and 11%, 14%, 17% margins, with larger but entirely hypothetical capacity and financing limits. The full tested grid, including failed funding paths, is retained. A selected crossing is only the least tested grid point; it is not an exact continuous threshold or an achievable forecast.

Targets include 12%, 15%, 18% annual hurdles and 3×, 5×, 10× net wealth over five and ten years. They ask whether the core contribution alone would be sufficient. They do not silently declare the subsidiaries worthless or value their upside. For funded reference paths, the model also calculates the additional owner-attributable non-core exit equity required to meet each hurdle. A negative residual means the modeled core contribution alone is sufficient under those conditions, not that a negative subsidiary valuation is predicted.

## Reproduction and validation

Run `python run_model.py`, then `python independent_replay.py`, `python summarize_model.py` and `python model_mutation_tests.py`, from this folder. The first script builds source-bound inputs, predeclared scenarios, the full canonical archive, readable annual paths and summary, and producer recurrence checks. The second script imports neither the engine nor its audit and independently rebuilds monthly physical delivery, collections, supplier payments, inventory, debt, individual facilities, fees, current-draw interest, cash, shares, terminal reinvestment, reserves and core claims from saved inputs and rules.

The canonical gzip contains every scenario specification, every monthly scalar and facility record, all failures, terminal attempts, valuation bridges, and target selectors. Its gzip timestamp is fixed for deterministic reproduction. Input files are hash-bound and preserved before updates. Complete previous generated paths and contemporaneous code are retained in model vintages; the first complete trial summary is never overwritten. Computational PASS does not certify the unsupported funding assumptions or turn a core contribution into a consolidated price target.

Prior distinct vintages can be reproduced with `python rebuild_model_vintage.py <vintage folder>`. The cold-rebuild proofs compare the entire deterministic gzip byte hash, not just selected rounded outputs. A compact package may map byte-identical current-vintage copies to root originals and omit prior large generated gzip copies only when frozen inputs, contemporaneous code and exact checksum proofs are retained. The on-disk original vintages are not deleted.
