"""Exact cold rebuild of a frozen model vintage without original PDFs or current finance.
Usage: python rebuild_model_vintage.py <vintage folder> [--write <output gzip>]
Uses frozen model_inputs.json, scenario_inputs.json and contemporaneous Python modules.
"""
from pathlib import Path
import sys,json,gzip,hashlib,importlib.util
from decimal import Decimal as D

def exact(x):
    if isinstance(x,D):return format(x,'f')
    if isinstance(x,dict):return {k:exact(v) for k,v in x.items()}
    if isinstance(x,list):return [exact(v) for v in x]
    return x

def module(path,name):
    spec=importlib.util.spec_from_file_location(name,path);mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod);return mod

def rebuild(folder,write=None):
    folder=Path(folder).resolve();engine=module(folder/'model.py','frozen_model');scenarios=module(folder/'scenarios.py','frozen_scenarios');inputs=json.loads((folder/'model_inputs.json').read_text());specs=json.loads((folder/'scenario_inputs.json').read_text());paths=[engine.run(inputs,s['spec'],s['years'],s['path_id']) for s in specs]
    payload=dict(format='Canonical unrounded Decimal strings. Every scenario, failed trial, monthly scalar, terminal reserve and selector is retained.',inputs=inputs,paths=paths,target_tests=scenarios.target_tests(paths,inputs),code_sha256={file:hashlib.sha256((folder/file).read_bytes()).hexdigest() for file in ['model.py','scenarios.py','run_model.py','model_audit.py','build_model_inputs.py']})
    raw=json.dumps(exact(payload),sort_keys=True,separators=(',',':'),ensure_ascii=False).encode();compressed=gzip.compress(raw,compresslevel=9,mtime=0);digest=hashlib.sha256(compressed).hexdigest();existing=folder/'canonical_paths.json.gz';expected=hashlib.sha256(existing.read_bytes()).hexdigest() if existing.exists() else (json.loads((folder/'cold_rebuild_proof.json').read_text())['expected_sha256'] if (folder/'cold_rebuild_proof.json').exists() else None)
    proof=dict(vintage=folder.name,generated_sha256=digest,expected_sha256=expected,exact_match=expected==digest if expected else None,compressed_bytes=len(compressed),uncompressed_sha256=hashlib.sha256(raw).hexdigest(),paths=len(paths),months=sum(len(p['monthly']) for p in paths),inputs='Frozen JSON inputs and contemporaneous code only; no original PDFs or current financial data needed.')
    if write:Path(write).write_bytes(compressed)
    return proof
if __name__=='__main__':
    out=sys.argv[sys.argv.index('--write')+1] if '--write' in sys.argv else None;print(json.dumps(rebuild(sys.argv[1],out),indent=2))
