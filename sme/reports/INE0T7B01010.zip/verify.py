"""Structural and financial reproducibility checks; no network or deletion."""
from pathlib import Path
from decimal import Decimal as D
import json,re,gzip,hashlib
P=Path(__file__).resolve().parent
read=lambda n:json.loads((P/n).read_text(),parse_float=D)
def main():
 r=read('company_record.json');report=(P/'report.md').read_text();headings=re.findall(r'^## (\d+)\. ',report,re.M);assert headings==list(map(str,range(1,16))),headings
 assert len(read('quality_checks.json')['checks'])==16
 assert len(r['factors'])==13
 assert r['isin']=='INE0T7B01010'and r['price']=='63.15'
 for n,h in r['authored_input_sha256'].items():assert hashlib.sha256((P/n).read_bytes()).hexdigest()==h,n
 for n,h in r['output_sha256'].items():assert hashlib.sha256((P/n).read_bytes()).hexdigest()==h,n
 assert r['scores']['BQS']['final']is None and r['scores']['IAS']['final']is None
 assert D(r['scores']['GQS']['raw'])==D('5.25') and D(r['scores']['GQS']['final'])==5
 assert not any(x['ranking_eligible']for x in r['scores'].values())
 m=read('market_inputs.json');assert len(m['sessions'])==60 and all(x['present']for x in m['sessions']);assert m['lot_size']==600
 vals=[D(x['row']['TtlTrfVal'])for x in m['sessions']];median=sum(sorted(vals)[29:31])/2;mean=sum(vals)/60;assert D(m['windows']['60']['mean_traded_value_inr'])==mean;assert D(m['windows']['60']['median_traded_value_inr'])==median
 f=read('financial_inputs.json');a=f['annual_standalone'];rows=[x for x in a if x['fy']>=2024];cf=sum(D(str(x['cfo']))for x in rows);pat=sum(D(str(x['pat']))for x in rows);met=read('metrics.json');assert abs(D(met['cash_conversion']['3']['cfo_pat'])-cf/pat)<D('1e-25')
 group=f['consolidated_fy2026'];assert abs(D(str(group['owner_pat']))+D(str(group['nci_pat']))-D(str(group['pat'])))<=D('.02')
 with gzip.open(P/'canonical_paths.json.gz','rt')as z:c=json.load(z)
 assert len(c['paths'])==r['path_count']
 for x in c['paths']:
  assert not x['source_eligible'];assert x['summary']['common_equity_irr']is None;assert x['summary']['total_company_price']is None
  if x['failure']:assert x['terminal']is None and x['summary']['core_only_illustrative_irr']is None
 assert '{{'not in report and '/workspace/'not in report and 'source_id'not in report
 html=(P/'report.html').read_text();assert html.count('<h2>')==15;assert '<table>'in html and 'overflow-x:auto'in html
 result={'status':'PASS','sections':15,'checks':16,'factors':13,'paths':r['path_count'],'source_eligible_paths':0,'research_complete_not_investment_complete':True,'html_static':{'headings':15,'tables':html.count('<table>'),'links':html.count('<a href=')},'pixel_qa':'Unavailable: ordinary installed Chromium launch failed at socket() with Operation not permitted before loading the report. No browser-render claim and no permission workaround attempted; structural HTML checks passed.'}
 (P/'verification.json').write_text(json.dumps(result,sort_keys=True,indent=2)+'\n');print(json.dumps(result))
if __name__=='__main__':main()
