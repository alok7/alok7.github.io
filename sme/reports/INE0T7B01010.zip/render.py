from decimal import Decimal as D
import json,hashlib,html,re
def js(x,pretty=False):return json.dumps(x,ensure_ascii=False,default=lambda v:str(v)if isinstance(v,D)else str(v),sort_keys=True,indent=2 if pretty else None,separators=None if pretty else(',',':'))
def sha(b):return hashlib.sha256(b).hexdigest()
def fmt(x,n=2):
 if x is None:return 'ND'
 try:return f'{D(str(x)):,.{n}f}'
 except:return str(x)
def pct(x):return 'NS'if x is None else fmt(D(str(x))*100)+'%'
def humanize(value):
 t=str(value);saved=[]
 for a,b in {'13whole':'13 whole','whole-company5×or10×':'whole-company 5× or 10×','overfive':'over five','overten':'over ten','addone':'add one','orderbookdepth':'order-book depth','source-eligible':'source-eligible'}.items():t=t.replace(a,b)
 def keep(m):
  saved.append(m.group(0));return '@@TOKEN'+str(len(saved)-1)+'@@'
 t=re.sub(r'https?://[^\s)]+|\bv[0-9]+\.[0-9]+\b|[A-Za-z0-9][A-Za-z0-9_.-]*_[A-Za-z0-9_.-]+|\b[0-9a-f]{64}\b|\bINE[A-Z0-9]+\b|\bResults26\b|\b[A-Z]{2,}[0-9]+\b',keep,t)
 t=re.sub(r'(?<=[a-z])(?=[0-9])',' ',t)
 t=re.sub(r'(?<=[0-9])(cr|crore|lakh)\b',lambda m:' '+('crore'if m.group(1)=='cr'else m.group(1)),t)
 t=re.sub(r'(?<=[A-Za-z])(?=₹)',' ',t)
 t=re.sub(r'(?<=[0-9])(?=(?:January|February|March|April|May|June|July|August|September|October|November|December|Jan|Feb|Mar|Apr|Jun|Jul|Aug|Sep|Oct|Nov|Dec)\b)',' ',t)
 for k,v in enumerate(saved):t=t.replace('@@TOKEN'+str(k)+'@@',v)
 return t

def table(head,rows):return '| '+' | '.join(head)+' |\n|'+ '|'.join(['---']*len(head))+'|\n'+'\n'.join('| '+' | '.join(humanize(x).replace('|',' / ').replace('\n',' ')for x in r)+' |'for r in rows)
def mdhtml(s):
 def inline(t):
  t=html.escape(t);t=re.sub(r'\[([^\]]+)\]\(([^)]+)\)',r'<a href="\2">\1</a>',t);return re.sub(r'\*\*(.+?)\*\*',r'<strong>\1</strong>',t)
 out=[];lines=s.splitlines();i=0
 while i<len(lines):
  l=lines[i]
  if l.startswith('|'):
   a=[]
   while i<len(lines)and lines[i].startswith('|'):a.append(lines[i]);i+=1
   out.append('<div class="table"><table>')
   for k,r in enumerate(a):
    if k==1 and not r.replace('|','').replace('-','').replace(':','').strip():continue
    tag='th'if k==0 else'td';out.append('<tr>'+''.join('<'+tag+'>'+inline(v.strip())+'</'+tag+'>'for v in r.strip('|').split('|'))+'</tr>')
   out.append('</table></div>');continue
  h=re.match(r'^(#{1,6}) (.*)',l)
  if h:out.append('<h'+str(len(h[1]))+'>'+inline(h[2])+'</h'+str(len(h[1]))+'>')
  elif l.strip():out.append('<p>'+inline(l)+'</p>')
  i+=1
 return '<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Shivalic Power Control SME research 367</title><style>body{max-width:1160px;margin:40px auto;padding:0 22px;font:16px/1.55 system-ui;color:#172635;background:#fbfcfe}h1,h2{color:#123e59}h2{margin-top:2.4em}a{color:#05618c;overflow-wrap:anywhere}.table{overflow-x:auto;max-width:100%}table{border-collapse:collapse;width:100%;font-size:13px;margin:16px 0}th,td{border:1px solid #d4dfe7;padding:8px;vertical-align:top}th{background:#e9f0f5}tr:nth-child(even){background:#f3f6f9}</style><body>'+''.join(out)+'</body></html>\n'

def readable(s):
 return s
