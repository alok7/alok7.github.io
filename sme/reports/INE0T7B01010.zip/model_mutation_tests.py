"""Confirm independent replay rejects material saved-output corruption."""
import json,gzip,copy,hashlib
from pathlib import Path
from decimal import Decimal as D,localcontext
from independent_replay import replay
P=Path(__file__).resolve().parent

def main():
    raw=(P/'canonical_paths.json.gz').read_bytes();data=json.loads(gzip.decompress(raw));inputs=data['inputs'];funded=next(p for p in data['paths'] if p['terminal'] is not None);drawpath=next(p for p in data['paths'] if any(D(str(r['new_draw']))>0 for r in p['monthly']));optionpath=next(p for p in data['paths'] if any(r['esop_issued']>0 for r in p['monthly']));tests=[]
    def test(name,source,mutation):
        x=copy.deepcopy(source);mutation(x)
        try:replay(x,inputs)
        except (AssertionError,KeyError):tests.append(dict(name=name,status='PASS: corrupted path rejected'));return
        raise AssertionError('Mutation was not rejected: '+name)
    def bump(x,field):x['monthly'][0][field]=str(D(x['monthly'][0][field])+1)
    with localcontext() as c:
        c.prec=40
        test('Cash bridge',funded,lambda p:bump(p,'cash_close'))
        test('Gross customer collections',funded,lambda p:bump(p,'collections'))
        test('Supplier queue',funded,lambda p:bump(p,'supplier_cash'))
        test('Inventory consumption',funded,lambda p:bump(p,'material'))
        test('Facility opening debt',funded,lambda p:p['monthly'][0]['facility_schedule'][0].update(opening='100'))
        test('Current-draw interest',drawpath,lambda p:next(r for r in p['monthly'] if D(str(r['new_draw']))>0).update(current_draw_interest='0'))
        test('ESOP exercise cash',optionpath,lambda p:next(r for r in p['monthly'] if r['esop_issued']>0).update(esop_cash='30'))
        test('Terminal equity bridge',funded,lambda p:p['terminal'].update(core_equity_contribution='99999'))
        test('Unsupported source eligibility',funded,lambda p:p.update(source_eligible=True))
    output=dict(status='PASS',canonical_sha256=hashlib.sha256(raw).hexdigest(),tests=tests)
    (P/'model_mutation_results.json').write_text(json.dumps(output,indent=2)+'\n');print('PASS:',len(tests),'mutation controls')
if __name__=='__main__':main()
