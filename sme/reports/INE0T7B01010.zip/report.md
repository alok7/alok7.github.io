# Shivalic Power Control Limited

Detailed SME research 367 | Information available by 20 October 2026 | NSE close 19 October 2026 | Master Prompt v3.0

## 1. Executive Verdict

Thesis type: working-capital-intensive industrial business with a conditional cash-conversion turnaround and unproven solar diversification, not an established compounder. Hold — unresolved. Shivalic Power Control is an established electrical-panel manufacturer moving into solar EPC and project subsidiaries, not yet an evidence-backed high-return compounder. Historical core revenue expansion is real and engineered/OEM-qualified products offer useful customer access. The decisive weakness is that working-capital investment has grown much faster than operating profit: three successive years of negative parent CFO and low incremental capital returns contradict a cash-generative scaling thesis. The ₹63.15 NSE close implies about 12.94× FY26 owner-attributable group earnings, not the superficially cheaper multiple using all group profit. It is not enough to establish an attractive entry. Conflicting cash/FD and guarantee disclosures, a missing current funding bridge and unvalued new subsidiary commitments leave BQS and IAS NS. GQS is computable but capped at 5.0 for weak cash realization and incremental returns, and is excluded from quality rankings while G2 remains unresolved. A corrected liquidity/claims bridge, sustained collections and demonstrated owner-level returns from both core and subsidiaries would change the assessment.

## 2. Research Header, Gates and Data Confidence

| Item | Basis |
|---|---|
| Issuer | Shivalic Power Control Limited / NSE Emerge SPCL / INE0T7B01010 |
| Original list position | 367 / original name Shivalic Power / original symbol SPCL |
| Cutoffs | Information 20 October 2026; market 19 October 2026; no later results |
| Primary valuation price | ₹63.15 closing price; last trade ₹62.75 separately recorded; executable price not guaranteed |
| Issued shares / lot | 24,115,754 /600; one lot ₹37,890 |
| Market capitalization | ₹152.29 crore |
| Scope | FY26 consolidated investable entity with explicit owner/NCI; historical comparable parent core shown separately |
| Accounting | Stated Indian GAAP AS; inconsistent IndAS labels retained in source notes |
| Units / horizon | ₹ crore unless noted;5-year scenarios with 10-year optional core-contribution tests |
| Equity hurdle / WACC | 15% nominal before personal taxes; WACC16% model base,13–17% judgment range and 19% adverse stress; distinct concepts |
| Reference position | ₹5 lakh;13 whole board lots cost ₹492,570; not a recommended allocation |

| Gate | Status | Finding / evidence needed |
|---|---|---|
| G1 | Conditional | IPO object ratification, related-party capital allocation and disclosure quality require scrutiny; no substantiated severe minority abuse established in reviewed records. Verify continuing cash use, commercial terms and reconciliation; do not infer misconduct from approval or related-party status alone. |
| G2 | Hold — unresolved | Cash and bank/FD allocation, parent-versus-group guarantees and acquisition cash-flow bridges are not reconciled; owner/NCI profit must be distinguished. Obtain reconciled lender/FD/guarantee schedules and corrected or explained presentation; retain clean audit counterevidence. |
| G3 | Hold — unresolved | Current unrestricted cash, facility headroom and post-March subsidiary commitments are insufficiently supported for a whole-company stress bridge. Dated cash restrictions, lender limits/renewals/maturities and project obligations; modeled reserve breaches are not observed defaults. |
| G4 | Conditional | Verified 60-day traded history supports a reference liquidity estimate, but SME lot size and order-depth/circuit uncertainty limit execution. Reassess current spread, depth, restrictions and actual position before implementation. |

| Subject | Confidence and limit |
|---|---|
| identity and market | High for security identity and 60 dated issuer rows; Medium for practical execution |
| historical core financials | Medium; main audited series retained with restated/original vintage reconciliation |
| cash and guarantee reliability | Low until conflicting allocation and scope notes are reconciled |
| growth and moat | Medium; underlying core sales observable but current physical-unit bridge incomplete |
| incremental core returns | Medium; both disclosed operating-capital proxies are weak, with timing and acquisition limits |
| valuation and current funding | Low; no supported full-company return |
| overall | Low for investment conclusion, not a denial that the research is complete |

## 3. Scorecard and Calculation Audit

| Measure | Raw | Final | Coverage | Mathematical missing-data bounds | After cap / dependency-aware bounds | Rank eligible |
|---|---|---|---|---|---|---|
| BQS | NS | NS | 92.00% | 4.4800 to 5.2000 | 4.4800 to 5.2000 | False |
| GQS | 5.2500 | 5.0 | 100.00% | 5.2500 to 5.2500 | 5.0000 to 5.0000 | False |
| IAS | NS | NS | 10.00% | 1.4000 to 9.5000 | 2.2700 to 8.3000 | False |

| Canonical factor | Score / confidence | Evidence and contrary evidence | Boundary / weighted contributions BQS GQS IAS |
|---|---|---|---|
| GOV | 5 / Medium | The February 2026 shareholder process explicitly ratified and reallocated IPO objects after interim changes [EGM20260218; Results 20260529](https://shivalic.com/wp-content/uploads/2026/01/Shivalic-EGM-Notice.pdf). The FY26 opinion and internal-control findings are unmodified; the former auditor cited preoccupation, not denied access [AR2026; Auditor 20260905](https://archives.nseindia.com/annual_reports/SME_AR_31631_SPCL_2025_2026_A_10534668_05092026224234.pdf). Contrary: Related-party subsidiary transactions, new loan/guarantee exposure and internally inconsistent disclosures require continuing scrutiny; approval is not proof of commercial fairness. | Mixed stewardship; disclosed ratification and clean audit counterevidence prevent an unsupported fraud or governance-avoid conclusion. Contributions: 1.000 / NA / NA |
| MOAT | 5 / Medium | OEM authorizations, engineered panels and customer qualification create useful relationships and know-how [RHP2024; AR2026](https://shivalic.com/wp-content/uploads/2024/06/RHP-1.pdf). Panel manufacturing and integrated engineering have a long operating history, rather than merely an announced business [RHP2024](https://shivalic.com/wp-content/uploads/2024/06/RHP-1.pdf). Contrary: Concentration, annually renewable technology/vendor relationships, contestable panel supply and falling standalone operating margins limit proof of pricing power. | Useful but contestable capabilities; certifications and customer names alone do not establish a durable structural moat. Contributions: 1.000 / NA / NA |
| REV | 7 / Medium | Comparable standalone revenue increased from ₹52.2244 crore in FY21 to ₹143.6593 crore in FY26, 22.43% CAGR; the predetermined five-year starting score is 8 [RHP2024; AR2026](https://shivalic.com/wp-content/uploads/2024/06/RHP-1.pdf). FY26 grew 8.54%; its two comparable halves grew approximately 1.32% and 13.44%, respectively [H12026; AR2025; AR2026](https://shivalic.com/wp-content/uploads/2025/11/Outcome.pdf). Contrary: FY23–26 standalone revenue CAGR remains 20.47%; current slowing does not erase real historical scaling. | A single disclosed -1 current-trajectory adjustment reflects two comparable halves below the longer-run pace. Acquired group growth is not substituted for organic core growth; historical unit/price decomposition remains incomplete. Contributions: 0.840 / 2.800 / NA |
| DUR | 6 / Medium | Industrial electrification and customer engineering access offer an operating runway; old installed capacity evidence shows room rather than a wholly new plant thesis [RHP2024; AR2026](https://shivalic.com/wp-content/uploads/2024/06/RHP-1.pdf). Solar EPC and project subsidiaries broaden the accessible opportunity but require further funding and execution [AR2026; Acquisition 20260919](https://archives.nseindia.com/annual_reports/SME_AR_31631_SPCL_2025_2026_A_10534668_05092026224234.pdf). Contrary: The 50 MW project narrative is not funded, commissioned cash generation; the addressable-market share and current utilization are not independently established. | Some credible customer and capacity access, with material funding and diversification constraints; no TAM or order-book bonus. Contributions: 0.600 / 1.200 / NA |
| CAP | 3 / Medium | FY23–26 parent-core incremental NOPAT/IC proxy is approximately 2.5%, using 25% normalized tax and endpoint change in matched-scope operating capital (ΔNOPAT/ΔIC, not average IC) [calculated from RHP2024; AR2026]. FY21–26 proxy is approximately 8.8%; both simple and broader working-capital definitions are below the stated 13–17% cost-of-capital sensitivity [calculation]. Contrary: Parent operating profits are positive and some capital may not yet be mature; these accounting proxies are not project IRRs or proof every new project destroys value. | Meaningful additional capital has so far earned weak incremental returns. Cash/FD classification uncertainty is not used to fabricate a high return; acquisition and solar returns remain a separate unproven claim. Contributions: 0.360 / 0.450 / NA |
| CASH | 2 / High | Standalone operating cash is negative in each of FY24, FY25 and FY26 [AR2025; AR2026](https://shivalic.com/wp-content/uploads/2025/09/SHIVALIC_2025_REPORT-1_compressed.pdf). FY24–26 CFO totals -₹34.77675 crore against ₹33.95981 crore PAT, a -1.0241 ratio of sums; receivables and inventories absorb capital [calculation]. Contrary: FY22 and FY23 restated CFO were positive; new growth can legitimately require working capital. | The three-year persistence and magnitude are materially weak, not just a one-quarter seasonal build. Capex is separately deducted in FCF, not used to explain negative CFO. Contributions: 0.200 / 0.200 / NA |
| BAL | NS / Low | Cash totals are disclosed, but current bank/FD allocations and restrictions do not support an exact unrestricted-cash bridge [AR2026](https://archives.nseindia.com/annual_reports/SME_AR_31631_SPCL_2025_2026_A_10534668_05092026224234.pdf). Parent and group customer-guarantee disclosures differ materially, while new subsidiary financing/guarantees add exposure [AR2026; Guarantee 20260919](https://archives.nseindia.com/annual_reports/SME_AR_31631_SPCL_2025_2026_A_10534668_05092026224234.pdf). Contrary: Reported net worth, unmodified audit and absence of reported loan default are meaningful positive evidence. | Current available liquidity, guarantee scope, renewal limits and post-March cash deployment need reconciliation; unknown resilience is NS, not zero or a fabricated default. Contributions: NS / NA / NA |
| EXEC | 5 / Medium | The core business scaled revenue and completed disclosed corporate acquisitions [RHP2024; AR2026; Acquisition 20260919](https://shivalic.com/wp-content/uploads/2024/06/RHP-1.pdf). IPO object changes and new project plans were put through disclosed shareholder processes, while the annual report identifies expansion as in progress [EGM20260218; AR2026](https://shivalic.com/wp-content/uploads/2026/01/Shivalic-EGM-Notice.pdf). Contrary: Capacity, commissioning and cash collection have not yet demonstrated the full intended diversification outcome; falling margins challenge execution quality. | Mixed delivery; credit for completed steps without counting approvals, branch openings or planned solar capacity as commissioned profits. Contributions: 0.400 / NA / NA |
| EARN | 4 / Medium | Standalone operating EBITDA declines from approximately ₹19.46 crore in FY24 to ₹18.82 crore in FY25 and ₹15.78 crore in FY26 despite rising sales [AR2025; AR2026](https://shivalic.com/wp-content/uploads/2025/09/SHIVALIC_2025_REPORT-1_compressed.pdf). FY26 owner-attributable group PAT is ₹11.7687 crore and EPS about ₹4.88, not the ₹5.44 figure obtained from total group PAT; standalone PAT and per-share earnings decline [AR2026](https://archives.nseindia.com/annual_reports/SME_AR_31631_SPCL_2025_2026_A_10534668_05092026224234.pdf). Contrary: Profits remain mostly operating and positive; other income is not the majority of FY26 PBT. | Two-year margin erosion and weak per-share progress limit earnings quality; this is distinct from the separately scored cash-conversion weakness. Contributions: NA / 0.600 / NA |
| R | NS / Low | The core monthly model tests gross working-capital and financing cash requirements, rather than valuing profit alone. Subsidiary/solar value, restrictions and financing availability are not sufficiently established for a supported full-company owner return. Contrary: Conditional funded core contributions can be useful sensitivities. | No conditional core-only return is promoted to a supported whole-company base IRR. Contributions: NA / NA / NS |
| D | NS / Low | Negative operating cash and rising working-capital debt create a clear impairment channel [AR2026](https://archives.nseindia.com/annual_reports/SME_AR_31631_SPCL_2025_2026_A_10534668_05092026224234.pdf). Unreconciled guarantee/cash scopes and subsidiary funding commitments prevent a reliable current whole-company survival bridge. Contrary: The annual audit reports no observed loan default and the company retains positive reported net worth. | Specific stress outcomes are shown, but incomplete recovery and funding evidence prevents a point downside-resilience score. Contributions: NA / NA / NS |
| P | NS / Low | The owner-PAT multiple differs from the superficially cheaper total-group-profit multiple. Core reverse expectations and the subsidiary residual needed at the current market value are tested separately. Contrary: At ₹63.15, a successful collection and cash-release case can be materially different from an ongoing absorption case. | A low quoted P/E alone does not establish undemanding expectations when full shareholder cash economics are unresolved. Contributions: NA / NA / NS |
| L | 5 / Medium | All 60 NSE sessions through 19 October 2026 contain an issuer row with positive turnover, and 600-share board lots are verified in the dated master. At 5% of the more conservative 60-day mean and median turnover, the illustrative ₹5 lakh exit takes 8.846 days; one lot costs ₹37,890. Contrary: Spreads, depth, market impact and future one-sided circuits are not established; daily fractional capacity is not an executable order. | Lower point in the >5-to-10-day framework band. No upper-band uplift for unverified orderly execution; whole-lot constraints are disclosed. Contributions: NA / NA / 0.500 |

GQS means Growth Quality Score, not governance. GOV is the governance factor. Exact Decimal arithmetic and half-up one-decimal display are used; unrounded scores govern classification. Missing bounds are arithmetic limits, not confidence intervals. Persistent weak CASH2 and incremental CAP3 cap GQS at 5; a computable raw score is retained. Missing BAL makes BQS NS without weight redistribution. Missing R/D/P and BQS make IAS NS. G2 unresolved source reliability excludes numeric quality ranking even where GQS is computable. No governance or default override is asserted. Moving MOAT or GOV by±1 changes the known BQS contribution by±0.20 each but cannot cure missing BAL. Moving REV by±1 changes raw GQS by±0.40; at REV6/7/8 the raw GQS values are 4.85/5.25/5.65 and final values 4.85/5.0/5.0 under the existing cap. No rank is created from these bounds.

## 4. Business Overview

### What the company actually sells

The historical core is engineered-to-order low-tension and high-tension electrical panels: power-control centres, motor-control centres, intelligent MCCs, DG synchronisation, APFC, VFD, distribution boards and bus ducts. It designs, fabricates, powder-coats, assembles, wires and tests at its owned Faridabad facility. It buys much of the expensive switchgear and electrical content rather than inventing or manufacturing all of it. The RHP lists switchgears, CRCA sheet, aluminium/copper bars, wire and paint among inputs, and direct billing with switchgear OEMs. LT panels were 93.93% and HT 6.07% of revenue in the nine months to December 2023, versus 97.88%/2.12% in FY23. The RHP's table calls the stub '2023-24'; its total matches the nine-month revenue, not the full FY24 revenue. Do not present the 93.93% as audited full-year FY24 mix. [S1 pp 105-109,120](https://shivalic.com/wp-content/uploads/2024/06/RHP-1.pdf)

Three routes to market in the December 2024 investor deck are partner-branded panels, work routed by EPC contractors, and Shivalic-branded panels. The company says technical partners provide warranties on the first category whereas Shivalic carries warranty responsibility on its own brand. It presents 1,000-plus installations, 500-plus clients, 20-plus sectors, and a 50% customer-retention rate. These are management operating claims, not independently audited market-share or repeat-revenue measures. [S5 PDF6,16-17](https://nsearchives.nseindia.com/corporate/SPCL_04122024131901_Shivalic_-_Updated_investor_presentation.pdf)

The core economic engine is gross profit on custom panels less engineering, selling and assembly costs, not recurring software/service subscriptions. The RHP specifically says no after-sales services; the later deck proposes an AMC approach. No material audited AMC revenue or recurring-services base was found by cutoff, so recurring revenue is ND rather than assumed. [S1 p 122; S5 PDF30](https://shivalic.com/wp-content/uploads/2024/06/RHP-1.pdf)

From late FY26, the business has broadened into solar EPC, power infrastructure, EHV and proposed energy storage. Consolidation changes comparability: the FY26 group includes two acquired companies only from their acquisition dates, while FY25 comparatives are SPCL alone. Core standalone performance must remain visible. [S4 NSE PDF259](https://archives.nseindia.com/annual_reports/SME_AR_31631_SPCL_2025_2026_A_10534668_05092026224234.pdf)

## 5. Moat and Industry Position

### Advantage and its boundaries

The real advantages evidenced are execution capability, technical approvals, integrated fabrication/test processes, reference projects and relationships. The RHP states licensed/franchise or EcoXpert relationships with L&T Electrical & Automation, Siemens, Schneider Electric and TDK for type-tested panels. The deck shows product-specific IEC/IS testing and fully bolted modular design, allowing expansion and configurability. Those attributes can help win specification-sensitive industrial and data-centre projects, and direct OEM buying can lower purchase prices. [S1 pp 108-109,120-121; S5 PDF18-21](https://shivalic.com/wp-content/uploads/2024/06/RHP-1.pdf)

This does not establish a proprietary or exclusive moat. The RHP itself warns that OEM forward integration, cancellation or non-renewal could interrupt sales. Some supplier tie-ups require annual renewal; the company otherwise has no long-term supply agreements. Customer business is purchase-order based, without long-term customer contracts. Neither a protected patent franchise, exclusive territory, quantified switching costs, persistent pricing premium nor independent market share has been demonstrated. Treat homepage 'only company' or 'exclusive' language as unverified marketing, not evidence of monopoly. [S1 pp 29-32](https://shivalic.com/wp-content/uploads/2024/06/RHP-1.pdf)

Direct OEM sourcing is not a free margin gain: the company explicitly links the improved prices/discounts obtained since FY23 to earlier payment than dealers, lower payable days and greater funding requirements. Its move to large corporate orders similarly trades potential margin/scale benefits for longer receivables and on-floor order cycles. Thus the relevant moat test is cash return on the additional capital, not merely EBITDA percentage. [S1 p 75](https://shivalic.com/wp-content/uploads/2024/06/RHP-1.pdf)

Management's FY26 MD&A still lists price competition from unorganised players, raw-material volatility, long government-linked payment cycles and dependence on a few large customers/EPC contractors. These are issuer counterevidence against a strong-pricing-power narrative. [S4 NSE PDF151-152](https://archives.nseindia.com/annual_reports/SME_AR_31631_SPCL_2025_2026_A_10534668_05092026224234.pdf)

### Customer and supplier concentration

The RHP reports top-ten customer shares of revenue of 82.97% FY21, 56.78% FY22, 53.02% FY23 and 40.77% for nine months to December 2023. FY23's largest disclosed customer, DCM Shriram, was 7.80%; the stub's largest, Crest Steel & Power, was 8.49%. The December 2024 deck then reports H1FY25 top-five concentration of 66.1% and top-ten of 81.6%. The last observation is a half-year, not a matched annual trend, but it demonstrates that the broad client-logo list does not imply diversified current revenue. FY25/FY26 named customer concentration percentages were not found in the original annual reports. Current dependence therefore remains unresolved, not presumed to have improved. [S1 pp 27-28,123-124; S5 PDF25](https://shivalic.com/wp-content/uploads/2024/06/RHP-1.pdf)

The large RBI data-centre project was through Hewlett Packard/HPE, not evidence of a direct recurring RBI contract. The RHP calls it approximately ₹28 crore, elsewhere ₹27.38 crore executed in FY24. Against FY24 operating revenue approximately ₹102.18 crore, the latter is about 26.8%. This is a reference credential but also explains a material one-off order/mix risk. It should not be rolled forward as recurring annual demand. [S1 pp 75,105](https://shivalic.com/wp-content/uploads/2024/06/RHP-1.pdf)

Top-five suppliers represented 63.12% FY21, 63.51% FY22, 61.85% FY23 and 62.35% for the nine-month December-2023 period. Top-ten supplier purchases were 76.86% FY23 and 76.81% in the stub. Rameshwaram Traders was 24.18%/22.92%; L&T 13.97%/11.28%; Siemens 7.82%/10.03% in FY23/stub respectively. The counterparties and denominators are purchases, not revenue. Contemporary supplier concentration and fixed-price pass-through terms are ND. [S1 pp 30-31,124](https://shivalic.com/wp-content/uploads/2024/06/RHP-1.pdf)

Domestic revenue was 98.05% in FY23 and 99.01% in the December-2023 stub. Export share was only 1.95%/0.99%, despite a multi-country footprint. Haryana contributed 29.21% FY23 and 44.69% stub, with the top-five states collectively 79.80%/72.30%. A globe of historic installations is not evidence of a diversified export business. [S1 pp 122-123](https://shivalic.com/wp-content/uploads/2024/06/RHP-1.pdf)

### Capacity, orders and conversion

The RHP's engineer-certified January 4, 2024 table gives installed annual capacity of 10,000 units/verticals on an eight-hour, three-shift assumption. Actual output: FY21 2,618; FY22 2,750; FY23 3,900; nine-month December-2023 stub 3,056. Published utilisation is respectively 26.18%, 27.50%, 39.00%, 30.56%; do not treat the stub percentage as a normalised annual run rate. [S1 p 106](https://shivalic.com/wp-content/uploads/2024/06/RHP-1.pdf)

The updated December 4, 2024 deck still gives capacity 10,000 verticals on three shifts, but says approximately 75% utilisation on one shift or 25% on three. This differs from the older RHP output base, and an exact reconciled current-output series was not supplied. It demonstrates why loose utilisation claims can be misleading. A model may use disclosed historical capacity, but current units, product-mix equivalent capacity and incremental certified output are ND. [S5 PDF21](https://nsearchives.nseindia.com/corporate/SPCL_04122024131901_Shivalic_-_Updated_investor_presentation.pdf)

The FY26 annual report describes work underway at the existing Faridabad plant, not a fully commissioned second facility. It says capacity expansion will support panels, EPC, EHV, solar and BESS, but provides no quantified new annual capacity, incremental dispatch schedule or commissioning certificate. No dated pre-cutoff primary announcement establishing full commissioning was found in this review. A later 'commencement' label for sales branches must not be converted into manufacturing commissioning. [S4 NSE PDF12](https://archives.nseindia.com/annual_reports/SME_AR_31631_SPCL_2025_2026_A_10534668_05092026224234.pdf)

No quantified current order-book value, cancellation-adjusted executable backlog, margin, advance coverage or clientwise delivery schedule was found in FY25/FY26 annual reports. The RHP refers to first-two-quarter orders without a rupee figure; the later MD&A says strengthening order book. These are directional claims, not backlog cash-flow evidence. [S1 p 75; S3 PDF112; S4 NSE PDF151](https://shivalic.com/wp-content/uploads/2024/06/RHP-1.pdf)

Panels enter customer projects near their final stage. The RHP explains that customers frequently defer scheduled deliveries, leaving finished/custom inventory at Shivalic. It also says large orders require material procurement before dispatch. Therefore inventory accumulation can be operationally plausible, but recoverability, customer acceptance, advances and realisation still require verification. It is not automatically fraud, nor automatically harmless growth inventory. [S1 p 26](https://shivalic.com/wp-content/uploads/2024/06/RHP-1.pdf)

#### Shivalic Power Control: economic peer evidence

Research cutoff: 20 October 2026. Prepared 24 October 2026. Currency: INR crore unless stated. FY25/FY26 mean years ended 31 March 2025/2026. All core financial comparisons below are **standalone with standalone**, using FY25 comparatives within the same FY26 source. This is a business-economics comparison, not a valuation ranking.

#### Executive judgment

**Vivid Electromech is the closest product/economic comparator of the four researched. Marine Electricals' Industry segment is the most useful scaled operating comparator, but its company-level cash flow also contains marine/defence activities. Saakshi is a legitimate control-panel manufacturing comparator with a materially different product mix. RMC belongs in the adjacent, lower-weight reference set, not a panel-maker valuation median.**

The common lesson is not that a high margin proves superior economics. Cash conversion and working-capital funding matter: FY26 operating EBITDA was positive at all four, but CFO after tax was negative at Marine and RMC, weak relative to EBITDA at Vivid, and much stronger at Saakshi. Every company in this set spent more on the selected gross capex cash-flow lines than it generated in CFO in FY26. This is a one-year observation, not proof of permanent poor economics or insolvency.

#### Comparable method and numerical snapshot

Operating EBIT = profit before exceptional items and tax + finance cost - other income. Operating EBITDA = that EBIT + depreciation/amortisation. Divide both by **revenue from operations**, not total income. These are analyst calculations, not management-adjusted EBITDA. They retain all items recorded within operating expenses, including litigation costs. This removes the most obvious inconsistent treatment of interest/other income but does not homogenise product mix, leasing, accounting standards or expenses.

| Company / scope | FY25 revenue | FY26 revenue | FY25 op. EBITDA margin | FY26 op. EBITDA margin | FY25 CFO | FY26 CFO | FY25 capex cash | FY26 capex cash |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| Marine, standalone | 700.58 | 746.94 | 8.91% | 10.85% | 45.56 | -28.87 | 16.76 | 15.54 |
| Vivid, standalone | 155.32 | 200.14 | 18.09% | 22.59% | 6.74 | 9.31 | 1.64 | 35.55 |
| Saakshi, standalone | 92.43 | 115.51 | 11.16% | 19.24% | 3.02 | 17.58 | 15.20 | 25.67 |
| RMC, standalone | 315.88 | 303.47 | 16.36% | 12.50% | 11.77 | -18.63 | 9.89 | 14.59 |

Full EBIT, borrowings, cash, receivables, inventory, payables, simple working capital and calculations are in `peer_metrics.csv`. Each raw input is traced in `peer_source_ledger.csv`; primary documents and dated provenance are in `peer_source_register.csv`.

#### Cash and capital definitions

- CFO is the reported net operating cash flow **after tax**, before financing interest where separately classified. CFO/EBITDA is a directional conversion measure, not a fully comparable cash-tax/interest-adjusted return.
- Capex is gross cash spent on PPE/intangibles/CWIP and explicit capital-advance lines, not the entire investing cash flow. Marine's line includes investment property and movements in capital creditors/advances; Vivid includes PPE, intangibles and CWIP but not its separately described loans/advances; Saakshi includes fixed-asset purchases/CWIP plus capital advances; RMC uses its PPE/CWIP purchase line. These differences are material and disclosed, not silently netted.
- Gross borrowings sums current and non-current borrowings. Separately reported lease liabilities are excluded. Reported cash equivalents and other bank balances are separate: bank deposits cannot all be treated as freely available net-debt offsets.
- Simple operating working capital = receivables + inventory - trade payables. It intentionally excludes contract assets, advances, other operating assets/liabilities and taxes. Closing receivable days = year-end receivables/revenue × 365, a snapshot proxy, **not collection DSO based on average balances**.
- Do not rank reported ROCE: definitions differ and some omit an explicit averaging convention.

#### 1. Vivid Electromech: closest product comparison, weak cash conversion

Vivid's FY26 mix is 79.84% LV panels and 15.07% MV panels of product/trading/service sales, with LV ArTu K-design panels alone 64.52%. Its data-centre/technology customers are 49.95% of that sales base, versus 35.80% in FY25. This makes it a strong panel-engineering comparator but one with a concentrated end-market and product/OEM-architecture mix. The mix denominator is ₹200.07 crore, slightly below ₹200.14 crore operating revenue, because other operating revenue is excluded. [Vivid presentation, cover letter 5 June 2026; PDF pp 29-30, printed slides 24-25](https://nsearchives.nseindia.com/corporate/VIVID_09062026115012_Intimation_and_Presentation.pdf)

Audited revenue increased from ₹155.32 crore to ₹200.14 crore. Normalised operating EBITDA increased from ₹28.10 crore to ₹45.21 crore; operating EBIT margin rose from 16.88% to 21.89%. CFO of ₹9.31 crore was only 20.6% of operating EBITDA, versus 24.0% in FY25. Receivables rose from ₹60.55 crore to ₹116.50 crore, taking the closing receivable-days proxy from 142 to 212 days. Gross borrowings rose from ₹4.23 crore to ₹33.30 crore. These are real capital-absorption signals, not merely a margin story. [Audited results, approved/signed 14 May 2026; PDF pp 4-7](https://vividgroup.in/wp-content/uploads/2026/06/Audited-Financial-Results_H2_2025-26.pdf)

**Avoid three traps.** (1) The presentation's ₹201.09 crore headline is total income; its ₹46.15 crore EBITDA includes other income and its 22.95% margin divides by total income. (2) Audited cash capex is ₹22.1693 crore PPE + ₹0.0163 crore intangibles + ₹13.3646 crore CWIP = ₹35.5502 crore, not just the presentation's approximately ₹22 crore investment headline. (3) FY26 reported cash equivalents of ₹0.5574 crore include ₹0.2564 crore deposits held as margin/security. Total cash-and-bank balances are ₹2.2677 crore; do not equate either subtotal with unrestricted cash. The presentation itself also contains inconsistent growth percentages, unit labels and a listing-date sentence that places an April 2026 event 'during' FY26. Prefer audited base numbers. [Results PDF pp 5-7; presentation PDF pp 4,37-39]

The presentation reports ROCE of 84.75%/48.32% for FY25/FY26 and notes exclusion of revaluation reserves, but does not provide enough denominator detail on that slide for a matched ROCE ranking. [Presentation PDF p 35, slide 28]

#### 2. Marine Electricals: use Industry segment for operations, not group cash attribution

The Industry segment supplies power-distribution solutions to data centres, industrial facilities and large buildings. Its revenue was ₹371.04 crore in FY25 and ₹412.77 crore in FY26; segment result was ₹24.95 crore and ₹39.98 crore. Result/revenue therefore improved from **6.72% to 9.68%**. This is a segment-result margin, not EBITDA: finance costs, exceptional items and unallocable income/expenses sit below the segment-result total. The company explicitly says the CODM does not separately review segment assets/liabilities, so segment ROCE and cash conversion cannot be produced from this disclosure. [FY26 annual report, note 49, printed 214-215 / company-PDF219-220](https://www.marineelectricals.com/images/report/Marine-Electricals-Annual-Report-2026.pdf)

At the standalone-company level, op. EBITDA margin rose to 10.85%, but CFO moved from +₹45.56 crore to -₹28.87 crore. FY26 operating cash flow includes a ₹94.70 crore outflow from receivables and ₹20.83 crore from other assets. Closing receivables rose to ₹375.40 crore, and gross borrowings to ₹57.54 crore from ₹28.83 crore. Those company-wide cash flows must **not** be represented as Industry-segment cash flows. [Printed 167-171 / PDF172-176]

The table retains ₹16.41 crore arbitration-claim expense in FY26 and ₹10.78 crore provision against legal contingency in FY25, both within other expenses. A separately labelled ₹1.21 crore FY26 exceptional loss is excluded by the pre-exception method. Reported standalone ROCE is 16.78%/17.65%, with capital employed defined as tangible net worth + total debt + deferred-tax liability. It is not the same denominator as an operating invested-capital calculation. [Printed 169,204,224 / PDF174,209,229]

Annual report transmission is verified by the company letter dated **5 September 2026**, whose NSE filename records 6 September. [NSE cover PDF p 1](https://nsearchives.nseindia.com/corporate/MARINE_06092026000501_Signed_Regulation_30_Annual_Report_2026.pdf)

#### 3. Saakshi: genuine control-panel OEM supplier, diversified and capital intensive

Integrated Control Systems & EV Solutions contributed 54.68% of FY26 sales, versus 56.40% in FY25. Engineered Mechanical Assemblies were 40.44%, wire harness 2.18%, precision medtech 0.63%, and others 2.07%. The company makes control panels/cabinets for industrial OEM applications, but a substantial and growing mechanical-assembly business prevents treating total-company margins as pure panel margins. Segment-profit allocation is unavailable: audited results use one 'Manufacturing' reporting segment. [Annual report printed/PDF14,24; notice 8 September 2026](https://smtpl.co/files/SMPL_Detailed%20Annual%20Report%202025-26.pdf); [audited results 26 May 2026, PDF8](https://smtpl.co/files/Saakshi_2526.pdf)

Revenue from operations rose from ₹92.4311 crore to ₹115.5064 crore. Op. EBITDA rose from ₹10.3115 crore to ₹22.2191 crore; margin improved from 11.16% to 19.24%. CFO rose from ₹3.0226 crore to ₹17.5836 crore, substantially stronger conversion than the other three in FY26, but gross capex including capital advances was ₹25.6711 crore. Gross borrowings increased from ₹17.8235 crore to ₹25.4535 crore; cash equivalents fell from ₹3.2646 crore to ₹1.7961 crore. This is a cleaner FY26 collection/cash-conversion outcome, not evidence that growth is capital-free. [Audited results PDF5-7]

**Source discrepancy to preserve:** the annual-report corporate summary compares FY26 operating revenue ₹115.5064 crore with FY25 total income ₹93.0033 crore, and reports FY25 EBITDA ₹10.1168 crore/10.95%. The audited P&L instead gives PBT ₹6.5885 crore + finance ₹0.4052 crore + D&A ₹3.89 crore - other income ₹0.5722 crore = **₹10.3115 crore operating EBITDA**. FY26 reconciles exactly to the corporate summary's ₹22.2191 crore using the same operating definition. Use the audited, consistently defined series; do not silently propagate the summary's FY25 number. Financial scans have OCR errors, so the clean company-hosted results PDF5-7 is the numerical source. [Annual report PDF22-23; audited results PDF6]

#### 4. RMC Switchgears: adjacent grid/EPC reference, not a pure panel peer

RMC's FY26 standalone revenue comprised ₹234.06 crore works-contract services and ₹67.55 crore product sales, plus scrap/other operating items. Works-contract services therefore represented roughly 77% of total operating revenue, versus roughly 56% in FY25. EPC revenue is recognised over time using a cost-to-cost input method. This customer-contract model has different execution, receivable, subcontractor and working-capital economics from a predominantly industrial panel supplier. [FY26 annual report, printed 96-97,114 / PDF49,58](https://rmcindia.in/wp-content/uploads/2026/09/RMC-AR-2025-26.pdf)

Standalone revenue fell from ₹315.88 crore to ₹303.47 crore; op. EBITDA margin fell from 16.36% to 12.50%. CFO fell from +₹11.77 crore to -₹18.63 crore, gross borrowings increased from ₹56.65 crore to ₹103.08 crore, and receivables rose from ₹147.25 crore to ₹175.78 crore. Gross capex was ₹14.59 crore in FY26, yielding CFO less the selected capex line of -₹33.22 crore. [Printed 92-94 / PDF47-48]

Use the FY25 comparator **as restated inside FY26**: FY26 is the first Ind AS reporting year; importing FY25 historical GAAP figures from a different source creates a false comparison. Reported ROCE is 42.62%/19.81%, described as profit before interest and taxes over total net worth and borrowings, but it is not comparable to Marine/Vivid's reported definitions without reconciliation. [Printed 96,132-133 / PDF49,67]

Accounts are approved 29 May 2026; the report includes the September 2026 AGM notice. An exact public-filing/upload date was not verified from an accessible primary cover letter. A BSE original attachment attempt returned 403. The company-hosted original is downloaded and financial periods/dates are verified; **do not cite 26 August as verified primary-source publication date**.

#### How to use this set for SPCL

1. Start with Vivid's comparable panel product economics and Marine Industry's segment-result margins. Use Saakshi as an industrial-OEM manufacturing cross-check, RMC as a lower-weight warning about project execution and cash absorption.
2. Compare SPCL on the same operating-income exclusion, standalone scope, fiscal year and cash-capex definition. Retain any disclosed exceptional/one-off reconciliation separately.
3. Require a cash bridge: growth in receivables, inventory, supplier credit, contract assets/advances and margin deposits. A higher EBIT margin with weaker cash conversion does not by itself establish a moat.
4. Do not average reported ROCE or P/E multiples across this set. Product scope, public-market scale, leverage, accounting standards, cash restrictions and capital expansion are too different for an unqualified league table.

No substantive claim above relies on an aggregator. Aggregator search results were used only to discover original filings; all numerical evidence is from downloaded company/exchange originals. The RMC source-date limitation is explicit.


## 6. Revenue Growth and Scale

| FY / basis | Core revenue | Annual addition / YoY | Value added proxy | Operating EBITDA / margin | Operating EBIT |
|---|---|---|---|---|---|
| 2021 / audited_restated | 52.22 | ND / NS | 8.59 | 5.02 / 9.61% | 3.75 |
| 2022 / audited_restated | 57.33 | 5.11 / 9.78% | 8.50 | 5.04 / 8.79% | 3.97 |
| 2023 / audited_restated | 82.16 | 24.82 / 43.30% | 17.90 | 12.72 / 15.48% | 11.48 |
| 2024 / audited_annual | 102.18 | 20.03 / 24.38% | 26.36 | 19.46 / 19.04% | 17.70 |
| 2025 / audited_annual | 132.36 | 30.17 / 29.53% | 32.49 | 18.82 / 14.22% | 17.02 |
| 2026 / audited_annual | 143.66 | 11.30 / 8.54% | 33.52 | 15.78 / 10.98% | 14.03 |

| Window | Revenue endpoints | Revenue CAGR | Value-added CAGR | Operating EBITDA CAGR |
|---|---|---|---|---|
| 2023–2026 | 82.16 → 143.66 | 20.47% | 23.26% | 7.44% |
| 2021–2026 | 52.22 → 143.66 | 22.43% | 31.30% | 25.74% |

| Comparable core period | Revenue current / prior | Revenue growth | PAT current / prior | PAT growth |
|---|---|---|---|---|
| H1FY26, limited-reviewed | 54.22 / 53.51 | 1.32% | 5.16 / 6.46 | -20.13% |
| H2FY26, calculated FY less H1 | 89.44 / 78.85 | 13.44% | 5.17 / 5.96 | -13.29% |

FY26 full-year statements already contain both halves; no overlapping TTM is added. No H1FY27 results were available by the fixed cutoff.

The predetermined five-year measurement window is FY21–26 standalone: ₹52.2244 crore to ₹143.6593 crore, 22.43% CAGR. The three-year cross-check is 20.47%, but FY26 slowed to 8.54%; its two comparable halves grew only 1.32% and 13.44%. REV starts at 8 and receives one explicit -1 current-trajectory adjustment, not a discretionary small-size penalty. The original/restated FY21–23 revenue endpoints agree, while several profit and cash-flow vintages differ and are retained separately. The 2019 CARE historical operating-income observation is context only, not a ten-year CAGR. No ten-year CAGR is available. FY26 group revenue ₹155.3958 crore is not a comparable organic growth series: it includes acquired subsidiaries from their relevant acquisition dates. The parent-to-group difference is not a clean acquired-revenue bridge without eliminations. Current physical volumes, realization/mix and capacity utilization are not sufficiently disclosed to allocate all nominal growth to volume. Model panel-equivalent units are explicitly assumptions, not reported output. [RHP2024; AR2025; AR2026; H12026](https://shivalic.com/wp-content/uploads/2024/06/RHP-1.pdf)

## 7. Growth Quality and Reinvestment Runway

The accessible opportunity is industrial and commercial power distribution, engineered panels, EPC/substations and selected solar projects through acquired entities. This is more concrete than a generic electrification TAM, but neither an OEM tie-up nor a prospective 50 MW park proves funded execution or excess returns. The old 10,000-vertical annual capacity and FY23 production of 3,900 are dated operating observations; current physical output and the economics of expansion are ND. The model links hypothetical panel-equivalent volume, price, capacity blocks, commissioning delays, inventory and receivable collection to cash. It keeps subsidiary equity and project advances separate rather than assigning them the core panel margin. A broader product scope can raise revenue while reducing cash returns if larger EPC contracts require longer credit. Measured core incremental-return proxies and repeated negative CFO are why CAP and CASH, not projected TAM, cap growth quality. [RHP2024; AR2026; MODEL](https://shivalic.com/wp-content/uploads/2024/06/RHP-1.pdf)

## 8. Management Governance and Execution

### IPO capital: original plan, revision and actual use

The June 2024 IPO was a fresh issue of 6,432,000 shares at ₹100, gross ₹64.32 crore. The original stated allocations, subsequently reproduced in the EGM notice, were: working capital ₹30.0275 crore; machinery ₹5.8155 crore; new assembly/roof ₹1.8230 crore; unidentified acquisition ₹5.7500 crore; GCP ₹14.2553 crore; issue costs ₹6.6487 crore. Net proceeds ₹57.6713 crore. [S6 PDF16-17; S2 prospectus](https://shivalic.com/wp-content/uploads/2026/01/Shivalic-EGM-Notice.pdf)

The FY25 cash-flow statement separately reports ₹59.2649 crore proceeds of equity share capital and securities premium, matching ₹6.4320 crore capital increase plus ₹52.8329 crore premium movement. That is ₹1.5936 crore above the prospectus/uses-based ₹57.6713 crore net proceeds. FY24 share-issue expense cash of ₹0.7290 crore only partly explains the difference; prefunded costs or timing may matter, but an explicit bridge was not found. Do not equate gross IPO proceeds, this financing cash-flow line, or net stated allocations with freely available treasury. This is a reconciliation question, not evidence of misappropriation. [S3 PDF140,143-144; S6 PDF16-17; analyst arithmetic](https://shivalic.com/wp-content/uploads/2025/09/SHIVALIC_2025_REPORT-1_compressed.pdf)

The original schedule assigned machinery, assembly and acquisition spending by September 2024, and the last working-capital amount by March 2025. At December 31, 2025, machinery use was only ₹0.8272 crore, assembly ₹1.4083 crore, acquisition nil, and GCP ₹6.3542 crore; working capital fully used. This is documented delay/reallocation relative to the original schedule, not completion of the original capex plan. [S6 PDF17-19; PDF17 visually checked](https://shivalic.com/wp-content/uploads/2026/01/Shivalic-EGM-Notice.pdf)

The January 2026 EGM notice requests ratification because machines/vendors bought in November 2024 differed from detailed objects. It says cheaper alternatives saved machinery spend and the assembly scope/floor area and solar installation were enlarged. Proposed revisions, approved at February 18 EGM, were machinery ₹1.9072 crore; assembly ₹6.5193 crore; Somaya acquisition ₹6.5396 crore; GCP ₹12.6777 crore; working capital unchanged. Revised use was planned January-September 2026. [S6 PDF18-25; S4 NSE PDF146; S7 PDF21-26](https://shivalic.com/wp-content/uploads/2026/01/Shivalic-EGM-Notice.pdf)

At March 31, 2026, the signed May 29 utilisation statement reports: working capital ₹30.0275 crore, machinery ₹0.8272 crore, assembly ₹1.8847 crore, acquisition ₹6.5393 crore, GCP ₹8.5990 crore, and issue expense ₹6.6487 crore used. Relative to revised allocation, the arithmetic remaining total is ₹9.7936 crore: machinery ₹1.0800, assembly ₹4.6346, acquisition ₹0.0003, GCP ₹4.0787. This is an earmarked-use reconciliation, not proof all remaining money is freely withdrawable cash. The finance notes separately identify restricted/collateral cash. No pre-cutoff September-2026 utilisation certificate was found; the October 24 filing is out of scope. [S7 PDF23-26; calculation](https://nsearchives.nseindia.com/corporate/SHIVALIC_29052026220417_Outcome_of_BM_29052026_final_sd.pdf)

The May filing's cover says no deviation relative to revised objects, while the form marks 'Yes' and explains shareholder-ratified changes. It also misprints IPO dates as 2026. The correct chronology is the June 2024 IPO followed by February 2026 ratification. Preserve this reconciliation instead of accusing the issuer of an unapproved diversion or pretending there was no change. [S7 PDF21-22](https://nsearchives.nseindia.com/corporate/SHIVALIC_29052026220417_Outcome_of_BM_29052026_final_sd.pdf)

### Acquisitions, loans and contingent commitments

Name convention: this report uses **Somaya Solar Solutions Limited**, exactly as in the February acquisition announcement and AGM annex. Audited consolidation/RPT notes instead spell **SOAMYA SOLAR SOLUTIONS LIMITED**, and the directors' report sometimes says Private Limited. The identical 51.64% stake, 2,422,066 shares and ₹6,53,95,782 transaction identify the same acquired investment. The spelling/status discrepancy is preserved rather than asserting independently registry-verified legal wording. [S8 PDF1-3; S4 NSE PDF90,132,195,259](https://nsearchives.nseindia.com/corporate/SHIVALIC_21022026190931_OUTCOME_BM21022026.pdf)

Somaya Solar Solutions: the February 21, 2026 board filing approved 51.64% (2,422,066 shares) for ₹6,53,95,782 cash at ₹27 each. It explicitly says the transaction was not related-party and SPCL promoters had no prior interest. Target FY23/FY24/FY25 turnover was ₹11.4671/14.4487/23.8369 crore. Later audited consolidation notes give completion/allotment February 27, 2026, comprising 2,230,000 new shares and 192,066 secondary shares, and consolidation from that date. The phrase 'promoter group' for 150,000 secondary shares in those notes is not enough to identify the sellers as SPCL promoters; it can describe target promoters and must not override the explicit acquisition disclosure without evidence. [S8 PDF1-3; S4 NSE PDF259](https://nsearchives.nseindia.com/corporate/SHIVALIC_21022026190931_OUTCOME_BM21022026.pdf)

The FY26 report's AOC-1 uses February 21 rather than February 27 and contains unusable-looking unit/asset entries. Prefer the specific audited consolidation basis for inclusion date, and keep the AOC-1 presentation discrepancies as reconciliation requests. Somaya's FY26 annual metrics appear in AGM explanatory information as turnover ₹25.18 crore, PAT ₹2.93 crore and net worth ₹12.79 crore, but those are not SPCL's one-month acquired contribution and are not an independently reconstructed full-year cash flow. [S4 NSE PDF92,141,259](https://archives.nseindia.com/annual_reports/SME_AR_31631_SPCL_2025_2026_A_10534668_05092026224234.pdf)

Prima Solar HR: the audited consolidation note says 10,500 newly allotted ₹10 shares for ₹1,05,000 on December 17, 2025, resulting in 51.22%. Earlier board/annual narrative refers to 51% and 10,410 shares. Use the specific completed-allotment note for ownership economics while preserving the discrepancy. Management describes a 50MW Haryana solar park but no independently verified complete project budget, commissioning/offtake contract or financed construction schedule was obtained. Do not book an assumed 50MW operating asset or an arbitrary subsidiary equity value. [S4 NSE PDF14,146,259](https://archives.nseindia.com/annual_reports/SME_AR_31631_SPCL_2025_2026_A_10534668_05092026224234.pdf)

The September AGM notice's operative loan resolution and transaction-history table identify ₹1.50 crore already advanced to Prima in FY27 to the notice date, with authorisation up to ₹20 crore outstanding. The explanatory paragraph inconsistently says ₹20 crore already advanced before listing 'up to ₹20 crore'; it states 9% interest and board-approved repayment. The broader RPT annex describes future unsecured on-demand subsidiary loans at 8%-12%. Actual ₹1.50 crore is corroborated in two tables; treat ₹20 crore as ceiling, not a paid cash outflow. Contractual collection timing, later drawdowns and recoverability are ND. [S4 NSE PDF84,101,105,114-115](https://archives.nseindia.com/annual_reports/SME_AR_31631_SPCL_2025_2026_A_10534668_05092026224234.pdf)

Seedlab Ventures: September 19 revised filing confirms completion of 51% for ₹1.43 lakh, correcting ₹1.37 lakh. It expressly classifies it as RPT because a selling shareholder/director belongs to SPCL promoter group; it asserts arm's length. FY26 target turnover was ₹2.49 crore (FY25 ₹0.12 crore; FY24 ₹0.02 crore). The small share purchase price is not the whole capital at risk. [S9 PDF1-4](https://nsearchives.nseindia.com/corporate/SHIVALIC_19092026150222_Revised_Disclosure_for_Completion_sd.pdf)

A separate September 19 filing approves HDFC non-fund credit and bank guarantees of ₹8.632 crore (₹5 crore + ₹3.632 crore), in favour of UPPTCL, to support Seedlab solar grid connectivity in Uttar Pradesh. The issuer calls it a contingent liability without immediate impact. Do not treat approval as an actual cash loss or silently add it to funded debt. In a stress case a call would create cash exposure, with recovery/indemnity details ND. [S10 PDF1-2](https://nsearchives.nseindia.com/corporate/SHIVALIC_19092026160041_Disclosure_For_Gurantee_Final_sd.pdf)

The September 30 AGM approved broad RPT ceilings of ₹100 crore each for Somaya and Prima through the next AGM in 2027, encompassing sales, purchases, loans, royalties and guarantees. These ceilings are not signed orders, revenue or cash deployment. Proposed guarantees are expressly within the respective overall RPT ceiling, so do not add another ₹100 crore to each. Both targets are described as unrated in the guarantee annex. [S4 NSE PDF80,93-97,102-107; S11](https://archives.nseindia.com/annual_reports/SME_AR_31631_SPCL_2025_2026_A_10534668_05092026224234.pdf)

### Governance: documented issues and counterevidence

Ownership remains promoter-controlled. September 22 disclosure reports 13,800 shares bought by three promoter-group persons on September 18 for ₹9.141 lakh. The AGM vote holding table has 17,218,209 promoter/group shares of total 24,115,754, or approximately 71.4%. This signals control/alignment but does not by itself prove capital-allocation quality. [S12; S11 PDF8](https://nsearchives.nseindia.com/corporate/SHIVALIC_22092026175722_Intimation_Letter_SD.pdf)

The board/management are led by founder engineer Amit Kanwar Jindal and his spouse, whole-time director Sapna Jindal. Independent audit committee chair Dheeraj Mangla and independent Surojit Bose provide formal oversight, but the business is still key-person and family controlled. The RHP acknowledges historical ROC/GST/EPFO filing delays with penalties/interest. These are disclosed control lapses, not inferred fraud. [S1 pp 32-33,139-151; S4 NSE PDF132-135](https://shivalic.com/wp-content/uploads/2024/06/RHP-1.pdf)

The FY26 statutory auditor gives an unmodified opinion, no reportable key-audit matters, effective IFC, audit-trail operation without observed tampering, inventory verification without a 10% class discrepancy, bank quarterly returns consistent with books, no default/wilful-defaulter statement, and no material fraud noted. These are genuine counterevidence and must appear alongside cash-quality concerns. Auditor assurance is reasonable, not a guarantee of recoverability or future liquidity. The financial statement notes and auditor wording contain AS/IndAS terminology inconsistency; use the stated Indian GAAP/AS accounting basis with caution rather than silently converting the issuer to IndAS. [S4 NSE PDF161-169,213-221,260](https://archives.nseindia.com/annual_reports/SME_AR_31631_SPCL_2025_2026_A_10534668_05092026224234.pdf)

Shiv & Associates resigned June 22, 2026 citing preoccupation/unwillingness for FY27, after auditing FY26. The annual report says T A S H & Associates consented/was appointed July 21 to fill the vacancy; September 5 filing proposes five years from the 22nd AGM to the 27th AGM in 2031 and the AGM vote passed the appointment. No allegation or auditor dispute was established; do not turn a stated-preoccupation change into misconduct. Full resignation letter and reasons for discrepancies remain a useful diligence request. [S4 NSE PDF135-136; S13; S11](https://archives.nseindia.com/annual_reports/SME_AR_31631_SPCL_2025_2026_A_10534668_05092026224234.pdf)

The related-party vote front tables include promoter totals even as footnotes say the five promoter voters were ineligible. Importantly, the attached signed scrutinizer report (October 3, filed October 5), visually inspected PDF18, separately counts only 31 eligible members and 35,995 votes for each Somaya/Prima RPT resolution, with all in favour. This resolves the substantive promoter-exclusion question in favour of exclusion, while leaving a presentation inconsistency in the front tables. It does not justify alleging invalid approval. [S11 PDF8-9,16,18-19](https://nsearchives.nseindia.com/corporate/SHIVALIC_05102026202811_Final_Disclosure_sd.pdf)

Remuneration needs an explicit bridge rather than a misconduct inference. FY26 managerial-remuneration/RPT amounts are Amit ₹45.90 lakh and Sapna ₹39.10 lakh, versus the FY26 top-employee table at ₹46.656 lakh/₹39.744 lakh. The same remuneration page shows FY25 ₹38.88/₹33.12 lakh, while the audited RPT comparative is ₹35.64/₹30.36 lakh. The page labels increases 20%, but ₹45.90/₹38.88 and ₹39.10/₹33.12 imply about 18.1%, and the audited comparative implies about 28.8%. Perquisites, accrual versus payroll basis or drafting errors may explain some gaps; no reconciliation was supplied, and it is not appropriate to call the larger number excess or unauthorised pay. [S4 NSE PDF157,196](https://archives.nseindia.com/annual_reports/SME_AR_31631_SPCL_2025_2026_A_10534668_05092026224234.pdf)

A precise CARO/RPT reconciliation is also required. The actual clause 9(e) wording states no borrowings from subsidiary, joint venture or other related party in the year, while the standalone RPT note identifies ₹32.99 lakh unsecured borrowing and closing payable to Religreen Energy India, a step-down subsidiary through Prima. This is the filing's wording, not an inference from a generic CARO clause about subsidiary obligations. The borrowing should not be silently added again to total debt without locating its balance-sheet classification. [S4 NSE PDF166,197](https://archives.nseindia.com/annual_reports/SME_AR_31631_SPCL_2025_2026_A_10534668_05092026224234.pdf)

Other reconciliation items include AOC-1 units/date/asset data, the CS role labelled CFO, Prima loan wording and the standalone/group guarantee differences being checked by the finance researcher. These are evidence-quality flags to resolve, not proven diversion. Avoid presenting trivial typographical errors as independent governance offenses.

The approved ESOP 2026 pool is 300,000 options total across company and eligible group employees, exercise price ₹10, about 1.24% of existing shares. It is not 300,000 plus another 300,000 for subsidiaries. Promoters/promoter group and independent directors are excluded; normal time vesting is 25% annually over years 1-4, maximum exercise period five years after vesting; maximum per employee 200,000 subject to applicable approvals. Approval is not evidence of grant/exercise by cutoff. Fully diluted terminal sensitivity should show the pool, and expense/vesting should not be fabricated. [S4 NSE PDF81-83,108-111; S11 PDF19](https://archives.nseindia.com/annual_reports/SME_AR_31631_SPCL_2025_2026_A_10534668_05092026224234.pdf)

### Ratings and diligence boundary

The only issuer-matched credit-rating rationale located was CARE July 17, 2019. It withdrew prior CARE BB/Stable and A4 bank ratings at issuer request with lender NOC; surrendered facilities had no outstanding amount and proposed facilities were not availed. It is not a current rating or a current default signal. No current issuer-matched rating rationale was verified. Shivalik Engineering Industries and other similarly named issuers must be excluded. [S14](https://www.careratings.com/upload/CompanyFiles/PR/Shivalic%20Power%20Control%20Private%20Limited-07-17-2019.pdf)

Highest-value missing evidence: current signed executable backlog and ageing; named customer/supplier concentration FY25/FY26; completed-capex commissioning and certified capacity/output; customer acceptance and inventory ageing/recoverability; loan/guarantee documentation and post-March borrowing availability; independently complete subsidiary cash flows, minority economics and intercompany eliminations; dated reconciliation of published financial inconsistencies; and actual ESOP grants. 'Not disclosed/verified' should remain ND, not scored as wrongdoing and not filled with convenient assumptions.

### Growth and margin narrative: claims versus delivery

The December 2024 roadmap presents 40%-45% CAGR from FY24 for five-six years without clearly specifying the financial metric. It proposes offices in Kolkata/Ahmedabad in 2024 and Mumbai/Hyderabad/Nepal/Bangladesh in 2025, AMC/smart-panel services, SAP/process automation, distributed assembly points and a new plant during 2026-28, followed by global expansion/R&D. These are forward-looking aims, not contractual revenue guidance. [S5 PDF30](https://nsearchives.nseindia.com/corporate/SPCL_04122024131901_Shivalic_-_Updated_investor_presentation.pdf)

Audited standalone operating sales increased from ₹102.1845 crore FY24 to ₹132.3571 crore FY25, then ₹143.6593 crore FY26. That is approximately 29.5% and 8.5% annual growth, or 18.6% two-year CAGR. This is below the roadmap's 40%-45% aspiration under a revenue interpretation, which must be explicitly labelled an interpretation because the slide does not identify the CAGR metric. The new solar group cannot be used to conceal the core slowdown. [S2/S3/S4 financial statements; calculations](https://shivalic.com/wp-content/uploads/2024/06/Prospectus.pdf)

The exact core operating bridge is adverse after FY24. Operating EBITDA excluding all other income was ₹19.4604 crore FY24, ₹18.82484 crore FY25 and ₹15.77892 crore FY26, or 19.044%, 14.223% and 10.984% of operating revenue. Economic EBIT after depreciation was ₹17.6969/17.02484/14.03422 crore. Net material cost rose from approximately 74.20% to 75.45% to 76.67% of sales. In FY25, ₹30.1726 crore additional sales was outweighed by ₹24.0483 crore additional net material costs, ₹3.33717 crore staff costs and ₹3.42257 crore other operating costs; EBITDA fell ₹0.63556 crore. In FY26, ₹11.3022 crore additional sales faced ₹10.27132 crore additional net material, ₹2.29883 crore staff and ₹1.77812 crore other costs; EBITDA fell ₹3.04592 crore. These are arithmetic decompositions of reported operating costs, not estimated product margins. [S3 PDF137-138; S4 NSE PDF171-172,191-194; finance companion calculations](https://shivalic.com/wp-content/uploads/2025/09/SHIVALIC_2025_REPORT-1_compressed.pdf)

FY26 other-cost lines include consultancy ₹1.48121 crore versus ₹0.28228 crore, rates/taxes ₹0.55863 versus ₹0.04858 crore, and erection ₹1.02307 versus ₹0.05425 crore; lower legal, selling and cartage partially offset them. These expenses have not been established as non-recurring. Adding them back automatically would manufacture a recovery. Staff salaries alone rose to ₹9.57563 crore from ₹7.26598 crore. No price/volume/product-mix decomposition permits attributing the whole margin fall to one factor. [S4 NSE PDF192-194](https://archives.nseindia.com/annual_reports/SME_AR_31631_SPCL_2025_2026_A_10534668_05092026224234.pdf)

The historic jump in gross/EBITDA margins has an economic explanation in the RHP: direct OEM discounts and larger projects. It also has a financing cost. FY26 MD&A says profitability was affected by material costs and longer government-linked receivables. The finance companion reconstructs the exact gross-material, staff-cost, other-expense and cash-return bridge; use that rather than copying management EBIT, which in the deck includes other income. The right falsification test for a premium-margin story is whether margins and incremental cash returns improve together while receivable/inventory days stabilise. [S1 p 75; S4 NSE PDF151; S5 PDF37-38](https://shivalic.com/wp-content/uploads/2024/06/RHP-1.pdf)

Sector opportunities exist in data centres, industrial electrification, automation and renewables, but the evidence does not identify signed incremental core panel volumes, customer-funded capex or a robust new order backlog. Acquired solar businesses and proposed parks enlarge the opportunity set and the funding/execution burden simultaneously.

| Promise / source date | Original milestone | Delivery by cutoff / assessment |
|---|---|---|
| IPO prospectus, June 2024 | Machinery, assembly and unidentified acquisition by September 2024; WC by March 2025 | WC ₹30.0275 crore utilized as of December 2025 in the January 2026 notice; original capital-project schedule not delivered as planned. Dates are original targets, not new commitments. |
| Investor presentation,4 December 2024 | 40–45%CAGR over 5–6years; metric not specified | Comparable FY24–26 revenue CAGR≈18.6%; if the aspiration referred to revenue, progress is below its implied trajectory. Not a formal FY26 earnings guidance miss. |
| EGM notice,22 January 2026; approval 18 February 2026 | Revised machinery ₹1.9072 crore and assembly ₹6.5193 crore; larger roof/solar and substitutions | March 2026 use ₹0.8272 crore/₹1.8847 crore respectively;₹5.7146 crore unspent in these categories. Ratification and expenditure do not establish commissioning. |
| Acquisition completion,27 February 2026 | 51.64%Somaya stake;₹6.5396 crore consideration | Completion disclosed; owner-attributable return on paid capital is not established by one-month group consolidation. |
| FY26 annual report,September 2026 | Panel capacity expansion and Prima 50MWsolar-park plan | Expansion described as ongoing. Current physical capacity, funded solar budget, offtake and commissioning evidence are ND. |
| AGM approval,30 September 2026; scrutinizer 3 October, filed 5 October 2026 | Prima loan permission up to ₹20 crore and RPT ceilings | ₹1.50 crore already advanced per operative text; full ceiling is not money paid. Current drawdown and project cash return require verification. |

## 9. Financial Forensics

| FY / scope | Revenue | EBITDA / EBIT | PAT / normalized full 25% tax PAT | CFO / capex / FCF | Gross debt / reported cash | Equity / IC proxy |
|---|---|---|---|---|---|---|
| 2021 parent | 52.22 | 5.02 / 3.75 | 0.67 / 0.71 | -1.27 / 0.74 / -2.00 | 23.94 / 0.35 | 15.60 / 41.05 |
| 2022 parent | 57.33 | 5.04 / 3.97 | 1.75 / 1.37 | 3.73 / 2.37 / 1.35 | 27.23 / 3.08 | 17.34 / 47.57 |
| 2023 parent | 82.16 | 12.72 / 11.48 | 7.16 / 6.79 | 4.12 / 0.27 / 3.85 | 23.54 / 1.05 | 24.51 / 52.53 |
| 2024 parent | 102.18 | 19.46 / 17.70 | 11.21 / 11.05 | -8.27 / 2.11 / -10.38 | 31.95 / 1.28 | 41.20 / 74.53 |
| 2025 parent | 132.36 | 18.82 / 17.02 | 12.42 / 11.58 | -8.55 / 2.06 / -10.62 | 5.25 / 22.28 | 112.89 / 97.41 |
| 2026 parent | 143.66 | 15.78 / 14.03 | 10.33 / 9.48 | -17.95 / 2.15 / -20.11 | 27.53 / 16.89 | 123.22 / 129.14 |

| FY26 consolidated metric | Value / scope |
|---|---|
| Revenue / EBITDA / EBIT | 155.40 / 18.82 / 17.06 |
| Total PAT / owner PAT / NCI PAT | 13.1182 / 11.7687 / 1.3496 |
| CFO / cash capex | -22.81 / 2.20 |
| CFO / total group PAT | -1.74× |
| Owner equity / NCI book equity | 124.66 / 6.13 |
| Gross debt / total reported cash | 37.88 / 20.28 |
| Inventory / receivables / payables | 80.03 / 57.98 / 12.08 |

| Window parent | CFO | PAT | Ratio of sums | Cash capex | FCF before acquisitions |
|---|---|---|---|---|---|
| 2024–2026 | -34.78 | 33.96 | -1.0241× | 6.32 | -41.10 |
| 2022–2026 | -26.93 | 42.87 | -0.6281× | 8.97 | -35.90 |

| FY | Receivables / inventory / payables | Average receivable days | Inventory days material proxy | Payable days material proxy | CCC proxy | Interest coverage |
|---|---|---|---|---|---|---|
| 2021 | 3.91 / 25.71 / 6.60 | ND | ND | ND | ND | 1.34× |
| 2022 | 13.32 / 24.50 / 9.59 | 54.85 | 187.63 | 60.51 | 181.97 | 1.85× |
| 2023 | 13.25 / 24.93 / 3.95 | 59.02 | 140.39 | 38.46 | 160.95 | 4.73× |
| 2024 | 34.63 / 31.68 / 10.42 | 85.52 | 136.26 | 34.59 | 187.18 | 5.98× |
| 2025 | 28.53 / 57.01 / 7.04 | 87.09 | 162.08 | 31.91 | 217.26 | 10.70× |
| 2026 | 47.69 / 73.33 / 11.11 | 96.83 | 215.97 | 30.07 | 282.73 | 10.03× |

Material-cost proxy includes the inventory-change expense; it is not full audited COGS or credit purchases. Simple ONWC is AR plus inventory less AP. Average-balance days are not ending-balance aggregator ratios.

| Window | Delta NOPAT | Delta IC simple / broad | Incremental return simple / broad | ONWC / net asset change | Cash capex less DA / residual |
|---|---|---|---|---|---|
| 2023–2026 | 1.92 | 76.61 / 78.76 | 2.50% / 2.44% | 75.68 / 0.93 | 1.02 / -0.0867 |
| 2021–2026 | 7.72 | 88.08 / 88.25 | 8.76% / 8.74% | 86.89 / 1.19 | 1.35 / -0.1574 |

| FY | NOPAT25% assumed | Simple average-IC ROIC | Broad average-IC ROIC | Simple pre-tax ROCE |
|---|---|---|---|---|
| 2021 | 2.81 | NS | NS | NS |
| 2022 | 2.98 | 6.72% | 7.37% | 8.96% |
| 2023 | 8.61 | 17.20% | 19.06% | 22.93% |
| 2024 | 13.27 | 20.89% | 21.86% | 27.86% |
| 2025 | 12.77 | 14.85% | 15.14% | 19.80% |
| 2026 | 10.53 | 9.29% | 9.40% | 12.39% |

The detailed source-derived IC variants yield approximately 2.45–2.57% for FY23–26 and 8.64–9.01% for FY21–26. They exclude treasury cash/FD and parent investments in subsidiaries, so uncertain FD availability does not drive this low-return result. Three-year net-book disposals of ₹0.08672 crore explain almost all of the ₹0.08668 crore net-asset residual, leaving rounding. The proxy is not a causal project IRR; newer investment may not be mature. The largely unchanged plant and ₹75.6781 crore extra simple ONWC indicate that credit/inventory, rather than just uncommissioned machinery, dominate the capital addition. Full paid acquisition capital remains a separate return assessment, not erased by the core proxy.

Operating EBIT is PBT plus finance cost minus all other income; operating EBITDA adds depreciation. Value added is revenue less material consumption and inventory-change expense, a disclosed proxy rather than a claimed audited gross-profit line. Normalized PAT sensitivity removes other income at an assumed 25% tax rate; actual current and deferred taxes remain in the original statements. Do not assume every inventory movement is fraud or every accounting estimate is recurring cash. FY26 group PAT must be split between owners and NCI: owner PAT ₹11.7687 crore yields approximately ₹4.88 per current share, whereas total group PAT ₹13.1182 crore yields ₹5.44 and is not the owners' EPS. The old and new weighted-share bases are not interchangeable; the IPO is real dilution, while a bonus itself is not economic dilution. CFO comparisons use the full PAT matching each cash-flow perimeter, never group CFO divided by only parent PAT. [AR2025; AR2026](https://shivalic.com/wp-content/uploads/2025/09/SHIVALIC_2025_REPORT-1_compressed.pdf)

The alternate fully standardized calculation is (PBT minus other income)×75%, not merely PAT minus 75%of other income. FY26 parent normalized PBT is ₹12.63478 crore and normalized PAT ₹9.47608 crore. Group normalization is not forced across the partial acquisition period or unknown subsidiary tax allocation.

#### Working capital and incremental capital returns

At 31 March 2026 the core had inventory of INR 73.33 crore and receivables of INR 47.69 crore. Inventory comprised INR 31.53 crore of raw material, INR 18.33 crore of WIP and INR 23.46 crore of finished goods. Trade creditors were INR 11.11 crore and customer advances INR 3.80 crore. The core balance-sheet current ratio of 3.45 is therefore not the same as abundant spendable cash. The group has a larger perimeter: inventory INR 80.03 crore and receivables INR 57.98 crore.

The receivables ageing identifies INR 0.54361 crore as disputed and doubtful within the headline receivable balance. It is not appropriate to assert a matching allowance exists merely because the net balance is labelled unsecured and good. The remainder of the ageing is mostly less than six months; that is useful counterevidence against labelling the entire balance impaired. See company PDF pages 187–188 and 239.

For transparent return calculations, NOPAT is defined as (PBT + finance cost − all other income) × 75%, using a standardized 25% tax assumption. The simple core invested-capital proxy is receivables + inventory − trade payables + net PPE + intangibles. It excludes treasury cash and deposits, deferred tax, property advances and subsidiary investment.

From FY23 to FY26, this capital proxy increased from INR 52.53 crore to INR 129.14 crore. NOPAT rose by only INR 1.9181 crore. The endpoint incremental return is 2.50%. Deducting customer advances yields 2.57%. Expanding to operating advances, security deposits, operating accruals and employee-benefit funding produces approximately 2.46%; omitting statutory-payable funding or adding employee imprest leaves the result near 2.45%–2.46%. The FY21–FY26 sensitivity range is approximately 8.64%–9.01%. These are return-on-incremental-capital proxies, not individual project IRRs, and the endpoints do not identify causation.

The three-year PPE roll-forward is unusually useful: INR 6.32478 crore cash capex, less INR 5.30820 crore D&A and approximately INR 0.08672 crore carrying value of assets sold, reconciles to the INR 0.92990 crore increase in net PPE plus intangibles, to rounding. Simple ONWC increased INR 75.6781 crore over the same period. Thus nearly all incremental operating capital is working capital, not a large new plant. Restriction uncertainty over IPO deposits and the changed overdraft presentation does not drive this low incremental-return conclusion because both are excluded from these operating-capital definitions. FY26 subsidiary investment of INR 6.55008 crore is also excluded from the parent manufacturing calculation.



#### Cash availability and cash-flow reconciliation

Standalone note 2.16, company PDF page 188, reports INR 16.8894 crore of cash and bank balances. Of this, INR 16.2297 crore is deposits with original maturity longer than three months; INR 0.39224 crore is cash in hand and INR 0.26749 crore employee imprest. The latter is operating float, not surplus liquidity. The note provides no bankwise lien/margin split or release dates, while debt security explicitly includes BG margin. Unrestricted deposit availability therefore remains unknown, not zero and not the entire FD balance.

Group note 2.16, company PDF page 240, shows bank current accounts INR 3.2209 crore, cash in hand INR 0.55934 crore, imprest INR 0.26749 crore and deposits INR 16.2297 crore, totalling INR 20.2774 crore. The group cash-flow note on page 227 instead allocates the same total to INR 19.6012 crore deposits and INR 0.6762 crore cash. Both pages were visually checked in the original PDF. The matching total does not resolve the nature or accessibility of its components. Subsidiary balances should not be treated as automatically upstreamable to parent shareholders.

FY25 cash-flow cash is net of INR 0.67694 crore overdraft. FY26 cash-flow opening cash retains this net basis, while year-end cash does not subtract INR 24.2773 crore core CC debt. The reported cash-flow change of negative INR 4.71122 crore differs from gross balance-sheet cash movement of negative INR 5.3880 crore by approximately the opening overdraft. This is an unresolved presentation bridge, not a reason to replace reported CFO with a fabricated cash number.

Group cash-flow opening cash of INR 22.7687 crore differs from FY25 closing INR 21.6005 crore. Acquired cash may contribute to the INR 1.1682 crore difference, but the statement does not supply the bridge. Group CFI also has no separately displayed acquisition payment despite parent investment outflow of INR 6.55008 crore. Do not use group CFI as clean evidence that acquisitions were free or that group CFO is purely organic.



#### Debt, facilities and capex

Core gross debt was INR 27.5313 crore: INR 3.2540 crore long term plus INR 24.2773 crore HDFC cash credit repayable on demand. Group gross debt was INR 37.8766 crore, including Indian Bank overdraft of INR 8.2191 crore, current term maturities of INR 1.1744 crore, and additional subsidiary loans. Source: company PDF pages 179–182 and 231–234.

The core term-loan schedule lists HDFC vehicle loans maturing March 2027, August 2027 and July 2028; HDFC working-capital/MSME loans maturing June 2029 and July 2027; an ICICI HFCL property loan maturing June 2034; and a Bank of Baroda vehicle loan maturing February 2029. The JSON retains the reported balances, rates and available EMIs. Yet standalone current maturities are printed as nil despite continuing EMIs and several repeated prior-year balances. A reliable monthly principal-amortization ladder cannot be inferred from this presentation. Do not model zero amortization.

HDFC security includes stocks, debtors, plant/machinery, BG margin, personal guarantees and an equitable mortgage of the Faridabad industrial property. The ICICI loan is supported by a promoter-owned property. These property mortgages do not establish promoter share pledges. Current sanction letters, renewal dates, lender covenants, borrowing-base availability and unrestricted undrawn headroom were not located. The RHP's INR 30 crore WCDL sanction and 90-day tenor describe December 2023, not guaranteed 2026 funding availability.

The historical [CARE withdrawal](https://www.careratings.com/upload/CompanyFiles/PR/Shivalic%20Power%20Control%20Private%20Limited-07-17-2019.pdf), dated 17 July 2019, followed a company request and lender NOC/surrender of facilities. It is neither a current rating nor evidence of default or non-cooperation. Current rating evidence was not established.

FY26 cash capex was INR 2.1545 crore, including INR 1.0224 crore cars, INR 0.6044 crore building work and only INR 0.0806 crore plant/machinery. The PPE schedule's header says lakhs, but its row amounts are rupees, as verified against the balance-sheet net block; these were converted correctly. No CWIP or capitalized borrowing cost is reported. Capital-creditor lines are nil and capital-contract commitments are dashes at year end. This does not erase subsequent approved solar projects, subsidiary loans or guarantee commitments, which are recorded separately by the business research.



#### Disclosure discrepancies and audit counterevidence

1. Customer guarantees are INR 20.9115 crore in standalone note 2.28, but only INR 2.1386 crore in the group note with the same caption. Company PDF pages 197 and 248, or NSE pages 198 and 249, were visually verified. A gross-versus-net or perimeter explanation is possible, but not disclosed in these notes. Neither amount should be automatically assumed to represent complete group exposure.
2. The standalone RPT note records INR 0.3299 crore received and payable to step-down entity Religreen. The standalone debt table does not separately show it, and CARO says no borrowing from a subsidiary or related party. Group short debt does list approximately INR 0.33 crore. The borrower/perimeter and elimination treatment need reconciliation; do not mechanically add the amount twice.
3. Cash classifications conflict as described above. The AOC-1 subsidiary summary also contains unit/date/arithmetic inconsistencies and is not sufficient by itself for a reliable subsidiary valuation.
4. The audit wording refers to Ind AS, while the accounting policies identify Indian GAAP Accounting Standards. This is a document-consistency concern, not proof that any particular recognition treatment is wrong.

Positive evidence must accompany these concerns: the auditor gives an unmodified opinion, reports no KAM, says quarterly bank statements agree with books, reports no default or wilful-defaulter status, and reports no material fraud identified during audit. The correct conclusion is a need for documentary reconciliation and a restricted evidence base for liquidity valuation, not an allegation of fraud.



#### Original-versus-restated historical reconciliation

The RHP expressly states on pages 176/183 that gratuity was absent from original FY21–FY23 statements and has been recorded retrospectively for AS15. Expenses of INR 30.52/3.24/4.38 lakh on page 192 account for nearly all reductions from original PAT of INR 97.81/178.02/720.68 lakh to restated INR 67.28/174.79/716.26 lakh. This is a disclosed accounting change.

Cash-flow vintages also differ: original FY22 CFO INR 590.75 lakh versus RHP INR 372.53 lakh; original FY23 CFO INR 360.09 lakh versus RHP INR 412.47 lakh and FY24 comparative INR 429.33 lakh. Those do not have a complete line-by-line bridge in the reviewed documents. The FY24 CFO of negative INR 827.13 lakh does agree between its original annual report and FY25 comparative; financing cash flow changes as overdrafts move into cash management. The principal three-negative-year FY24–FY26 cash-conversion finding therefore does not depend on choosing the most adverse pre-IPO vintage.



#### Evidence required to clear remaining uncertainty

Obtain bankwise FD/margin/lien confirmations and release schedules; current fund-based and non-fund-based facility letters with expiry, conditions and undrawn capacity; an instrumentwise guarantee register reconciling parent and group disclosures; a term-principal maturity ladder; an acquisition-date opening-balance and cash-flow bridge; and a reconciliation of Religreen intercompany borrowing. An IPO gross-to-net issue-cost timing bridge is also needed: gross issue INR 64.32 crore less disclosed total issue expense INR 6.6487 crore implies INR 57.6713 crore net, whereas FY25 cash-flow equity proceeds are INR 59.2649 crore. Prior-funded expense timing may explain the difference, but the reviewed sources do not explicitly establish that bridge.


## 10. Valuation and Market Expectations

At the primary 19 October 2026 close, market capitalization is ₹152.29 crore. The master verifies shares and lot size, not a guarantee of executable liquidity. [MARKET](https://nsearchives.nseindia.com/content/cm/BhavCopy_NSE_CM_0_0_0_20261019_F_0000.csv.zip)

| Measure | As-of-price calculation | Qualification |
|---|---|---|
| Owner P/E | 12.94× | FY26 owner PAT, not total group PAT |
| Incorrect all-group-PAT comparison | 11.61× | Shown to expose the NCI denominator error, not adopted |
| Owner P/B | 1.22× | Book equity is not guaranteed recovery value |
| Group EV/EBITDA cash sensitivity | 9.35× to 10.43× | Uses NCI book equity only as a placeholder claim proxy and cash credit from 0toallreportedcash. Neither endpoint is verified fair EV. No restricted cash is silently netted. |
| Parent normalized earnings | ₹9.48 crore | Assumed 25%tax, no whole-company valuation from parent profits alone |

#### Shivalic Power Control: monthly model methodology

#### Interpretation comes before the numbers

This is a standalone-core scenario and funding model, not a consolidated price target. Every ordinary common-equity IRR and total-company price is NS. A funded path can report the panel business's equity contribution per current or conditionally diluted share; it cannot tell us the value of Somaya Solar, Prima Solar, Religreen, Seedlab, their financing, or the recoverability of the parent's loans. Missing subsidiary value is not assigned zero. A core-only illustrative IRR is explicitly a sufficiency diagnostic: what the modeled core contribution alone would return against the entire quoted entry price. It is not a prediction of the shareholder's total return.

The valuation price is the verified NSE Emerge close of ₹63.15 on 19 October 2026. The model uses 24,115,754 issued shares, not the previous year's weighted-average EPS denominator. All monetary amounts in the model are ₹ crore, except per-share prices and explicitly identified rupee amounts. Decimal arithmetic uses 40-digit precision; JSON stores unrounded decimal strings.

#### Date and entity boundaries

The source operating balance sheet is standalone 31 March 2026. Forecast months are labelled November 2026 onward: 60 months for the five-year model and 120 months for the ten-year model, each followed by 12 explicit terminal-transition months. There is no verified April–October operating, working-capital, cash or debt bridge. These are therefore conditional paths seeded with an old balance sheet, not reconstructed actual monthly accounts or verified October liquidity.

The ₹1.50 crore Prima loan disclosed after March and ₹0.0143 crore Seedlab consideration are separately charged in the first model month as a transparent pro forma funding stress. The first-month date is not asserted to be their actual payment date. The balance sheet and those later commitments are not silently mixed and presented as a current audited opening. A first-month shortfall is a model funding gap, not evidence of a default. The annual audit's reported absence of default is not overridden by the model.

Consolidated revenue, cash, inventory and debt are not inserted into standalone cash generation. The first FY2026 consolidated period includes acquisition-date results; it is not a full-year organic operating history for the subsidiaries. Group PAT of ₹13.1182 crore includes approximately ₹1.3496 crore of NCI profit. Owner PAT and EPS, rather than total group PAT divided by parent shares, are the applicable equity-earnings cross-check.

#### Complete opening state

The source binding identifies the exact financial JSON and a hash-preserved input vintage. Lakh values are divided by 100 without editing the financial worker's original fields.

| Opening item | ₹ crore | Treatment |
|---|---:|---|
| Standalone annual revenue | 143.65930 | Operating anchor, not FY2027 forecast |
| Annual D&A | 1.74470 | Existing-asset depreciation anchor |
| Cash in hand | 0.39224 | Historical deployability floor only |
| Term deposits | 16.22970 | Separate asset; restriction and release dates unknown |
| Trade receivables | 47.69240 | Explicit collection queue |
| Inventory | 73.32660 | Explicit purchases and material consumption |
| Trade payables | 11.10990 | Explicit supplier-payment queue |
| Customer advances | 3.79842 | Separate receipts and application balance |
| Other operating current assets and imprest | 4.64150 | Includes ₹0.26749 crore employee imprest, not cash available for valuation |
| Other current cash claims | 2.03435 | Other current liabilities excluding customer advances, plus auditor payable |
| Current income-tax provision | 0 | Source-disclosed zero, not a missing-value substitution |
| PPE and intangible carrying amount | 19.22940 | Separate commissioned and paid-but-uncommissioned assets |
| Cash-credit debt | 24.27730 | On demand; current renewal terms not verified |
| Term debt | 3.25398 | Seven named facilities, individual interest and maturity treatment |
| Post-March Prima loan in opening | 0 | It is added as a later disclosed advance, not assumed already in March balances |
| Acquired investment historical cost | 6.5500782 | Memorandum record, never automatically added as fair value |

Short- and long-term employee-benefit claims of ₹1.15533 crore are separately retained for the core equity bridge. Uncertain deposit restrictions, unused lending limits, subsidiary fair values, NCI market value, parent-loan recoverability and separately capitalized lease claims remain null/ND/NS as applicable, not forced numeric zeros. A numeric zero draw under a closed financing gate means no assumed usable financing, not proof that the real facility has zero capacity.

The opening inventory notes distinguish raw materials ₹31.5304 crore, WIP ₹18.3316 crore and finished goods ₹23.4645 crore. Forecast inventory is an aggregate manufacturing working-capital proxy. Material expense of ₹110.14052 crore is raw-material consumption adjusted for the disclosed finished-goods/WIP change. Labor and other costs are separately modeled; the inventory-day denominator is not represented as a fully observed economic COGS schedule.

#### Physical panel bridge and capex

The RHP disclosed 10,000 verticals of annual installed capacity on three shifts, with FY2023 production of 3,900. That is historical capacity, not a current output certificate. FY2023 revenue of ₹82.1568 crore divided by 3,900 gives a historical revenue-per-vertical proxy. Three years of explicitly assumed 3% price/mix escalation produce ₹0.02301921887 crore per panel-equivalent and approximately 6,240.84 panel-equivalents for the FY2026 standalone revenue anchor.

These are analytical equivalents, not reported FY2026 physical units. Standalone EPC and product mix may make the proxy inaccurate. The model exposes that limitation rather than silently applying a revenue CAGR unrelated to physical production. Revenue equals delivered panel-equivalents times assumed price. Delivery is capped by commissioned capacity. Unfulfilled demand and terminal lost units are retained.

Conditional expansion costs ₹0.0035 crore per unit of annual vertical capacity, has a six-month commissioning lag and seeks 20% capacity headroom. This is an analyst capital-intensity assumption, with a 50% cost-inflation case and a 12-month lag case. Source-bounded paths cannot assume additional installed capacity.

The March 2026 remaining IPO core-capex earmark is ₹5.7146 crore: ₹1.08 crore machinery and ₹4.6346 crore assembly work. It is spent over six scenario months and commissioned after the same lag. This remaining amount might have been spent before the research cutoff; completion is not verified. No quantified capacity uplift is invented for this IPO spending. Conditional incremental capacity is modeled and paid for separately. That is intentionally conservative but may overstate future required expenditure if the IPO work already created usable capacity; the uncertainty is not hidden.

Maintenance capex is 2% of sales in the reference path. Terminal maintenance must also cover the modeled replacement allowance, and terminal replacement capex cannot be less than D&A. Payments enter the cash flow when made, assets enter PPE only on commissioning, and D&A follows commissioned assets. Paid pipeline balances are not counted as freely available cash.

#### Monthly operating cash mechanics

Opening receivables are collected over an explicit number of months, with recovery haircuts only in identified stresses. New credit sales enter a dated collection queue. Customer advances are both received and applied separately; the same sale cannot be collected twice. Opening supplier balances have their own payment queue. Material purchases equal material use plus the required inventory build, subject to no negative purchases. Supplier payments follow the selected payment lag.

The reference operating assumptions are 7% annual panel-equivalent volume growth, 2% price growth, 11% operating EBITDA margin, 210 inventory days, four-month new-receivable collection lag and one-month new-purchase supplier lag. Source-bounded base inventory is 240 days, close to the historical year-end proxy of 243 days. The improvement to 210 days is a conditional normalization, not established cash conversion. There is also a 245-day case and a six-month collections case.

The material ratio comes from FY2026 standalone disclosures. Other operating costs are split between 55% fixed and 45% sales-sensitive components. Thus customer loss affects utilization, operating leverage and cash generation, not merely the terminal multiple. Cash tax is 26% of positive post-interest profit; no loss tax asset is monetized. Operating FCFF removes financing and uses tax on positive operating EBIT. Other income, deposit interest and uncollected related-loan interest are not treated as recurring operating cash generation.

#### Deposits, facilities and maturity gates

Deposit availability is unresolved. Source-bounded cases release no deposit and invent no new borrowing headroom. The conditional reference releases all ₹16.2297 crore, renews the existing cash-credit balance and permits up to ₹25 crore of hypothetical new debt, with a ₹50 crore cumulative new-money limit. The reference may not actually draw that capacity; realized draws are shown. The no-new-debt case tests whether the permission is necessary. Conditional facility existence or renewal is not an actual sanction or an authorisation.

Cash-credit interest is assumed at 10.5%; a demand-call stress repays its entire outstanding balance in month 12. That month is a stress convention, not a discovered expiry date. The old prospectus's ₹30 crore WCDL limit and 90-day tenor are historical context only and do not establish current available headroom.

Seven term facilities use their printed opening balances, rates, EMIs and stated maturity dates. Each month's principal is the lesser of balance and EMI less monthly interest. Any residual is paid at the stated maturity. The HDFC MSME EMI is ND, so the model retains interest and pays a bullet at its July 2027 maturity as a stress convention, not a verified contractual amortization schedule. The March-to-November missing bridge also affects these stale opening loans. A ₹0.001 lakh difference between summed facility balances and reported term debt is explicitly reconciled in the final facility, not silently discarded. A separate immediate-call stress is retained.

New debt bears 13.5% interest and 1.5% draw fees. Current-month interest is charged on the actual draw as well as opening debt. The draw calculation solves for the cash requirement including that interest and the available tax shield; it does not fund a deficit and then omit the financing cost that caused a new deficit. New-money limits, three-year maturities, renewals and fees are explicit. No new draw or equity rescue is allowed in the terminal transition. Any allowed pre-terminal refinancing is distinctly conditional.

The minimum operating reserve is the greater of ₹0.50 crore and 15% of a month's material and cash operating cost. A path stops at its first unmet reserve or liquidity obligation. Its failure row, negative or positive remaining cash and exact shortfall remain in the canonical archive. No ordinary investor return is emitted for failed paths.

#### Acquisitions, loans, guarantees and options

Somaya's 51.64% ownership and Prima's 51.22% reported actual allotment are distinct from 100% group assets and profits. Prima's 51% approval wording conflicts with the 10,500-of-20,500 actual allotment and AOC percentage; the discrepancy remains visible. Seedlab is a separately disclosed 51% acquisition. The ₹6.5500782 crore historical acquisition cost is neither added to core value as if a verified market price nor treated as the subsidiaries' future cash flow.

The Prima loan is a separate parent financial claim. ₹1.50 crore is disclosed as already advanced after March; the ₹20 crore maximum is not assumed paid. The full-limit stress substitutes ₹20 crore total for the ₹1.50 crore case, so it does not add the first advance twice. The specific approval states 9% interest, but collection and principal-repayment timing are not established. The model assumes no receipt without a separate condition and leaves recoverable loan value NS. That is a cash-flow permission boundary, not a conclusion that the loan is worthless.

The ₹100 crore related-party transaction authorizations for Somaya and Prima are limits, not revenues, completed payments or separate lending facilities. They are not included as operating assets or funding.

Disclosed guarantees are contingent, not ordinary funded debt. The ₹8.632 crore HDFC grid-connection BG and ₹20.9115 crore older standalone guarantee disclosure each have their own called-guarantee stress. Their overlap is not resolved, so they are not summed as distinct debt or paid capex. A call reduces cash only in its selected scenario and is not also subtracted as outstanding debt in the terminal bridge.

The approved ESOP pool is 300,000 options, not 600,000 and not already issued capital. Approval alone supplies no cash. The full-pool exercise sensitivity adds 300,000 shares and ₹0.30 crore cash at the ₹10 strike in month 48. Vesting and grants are not assumed to have occurred in the source-bounded scenarios. This is an explicit dilution stress, not a forecast issuance schedule.

#### Earned terminal value and no cash/debt double count

The engine runs another full year after each investment horizon. Terminal growth is normally 4%; WACC is 16%. A 13–17% range is the reference cost-of-capital discussion, while the 19% grid point is an adverse-rate stress. The WACC/g grid tests 13%, 15%, 17%, 19% against 2%, 4%, 6%. Equity-hurdle tests are separate at 12%, 15% and 18%.

Terminal operating NOPAT is earned from this extra year, not mechanically extrapolated from reported PAT. Replacement capex is at least D&A. Growth reinvestment is the larger of physical growth capex plus positive operating-working-capital growth and NOPAT × terminal growth / terminal ROIC. Terminal ROIC is a conditional 14% recovery assumption, not achieved historical performance; 8% and 10% cases test weaker reinvestment economics. Terminal FCFF equals NOPAT plus D&A less replacement and growth reinvestment. Terminal EV is FCFF divided by WACC less growth, floored at zero only for the limited-liability core claim calculation.

The model computes the largest cash requirement over every transition month, including any additional replacement and reinvestment not already paid in the monthly cash schedule. A terminal value is suppressed if that requirement is not funded or if the extra year cannot meet demand with physical capacity. No exit distribution can leave the transition below the reserve.

Funding reserves and valuation operating reserves are different. Cash earmarked for debt principal, interest net of tax shield, or other separately deducted senior claims is added back when calculating the operating reserve. The equity bridge then adds cash above that operating reserve and subtracts debt and remaining senior claims exactly once. It does not deduct debt-service cash from assets and the same debt again from equity. Restricted or uncertain deposits are not automatically added. No modeled dividends are distributed during the horizon, so retained cash is not counted twice as both dividends and terminal cash.

An EBITDA multiple cross-check uses 8× in the reference, with 6× normalization. These are analytical multiples, not verified peer trading medians. The explicit operating FCFF DCF and terminal share of that DCF are separately retained; terminal dependence can exceed 100% when the explicit investment period consumes cash.

#### Scenario families, reverse expectations and targets

Bear, base and bull preserve source-bounded financing gates and differ in customer loss, volume, pricing, margins, collections, inventory and capex timing. They are not assigned probabilities or averaged into an expected return.

Conditional cases separately test FD release, new-debt permission, CC renewal, new-debt renewal, inventory normalization, collections, commissioning delays, capex inflation, Prima funding, called guarantees, option exercise, IPO-only deposit release, later subsidiary outflows, maturity acceleration, lower exit multiples and terminal reinvestment returns. Both five- and ten-year horizons are run.

The growth/margin grid uses volume growth of 0%, 5%, 10%, 15% and 20% and EBITDA margins of 8%, 11% and 14%. Reverse expectations use a saved 0–40% volume-growth grid in two-percentage-point steps. A wider target envelope tests 10%, 20%, 30%, 40%, 60% growth and 11%, 14%, 17% margins, with larger but entirely hypothetical capacity and financing limits. The full tested grid, including failed funding paths, is retained. A selected crossing is only the least tested grid point; it is not an exact continuous threshold or an achievable forecast.

Targets include 12%, 15%, 18% annual hurdles and 3×, 5×, 10× net wealth over five and ten years. They ask whether the core contribution alone would be sufficient. They do not silently declare the subsidiaries worthless or value their upside. For funded reference paths, the model also calculates the additional owner-attributable non-core exit equity required to meet each hurdle. A negative residual means the modeled core contribution alone is sufficient under those conditions, not that a negative subsidiary valuation is predicted.

#### Reproduction and validation

Run `python run_model.py`, then `python independent_replay.py`, `python summarize_model.py` and `python model_mutation_tests.py`, from this folder. The first script builds source-bound inputs, predeclared scenarios, the full canonical archive, readable annual paths and summary, and producer recurrence checks. The second script imports neither the engine nor its audit and independently rebuilds monthly physical delivery, collections, supplier payments, inventory, debt, individual facilities, fees, current-draw interest, cash, shares, terminal reinvestment, reserves and core claims from saved inputs and rules.

The canonical gzip contains every scenario specification, every monthly scalar and facility record, all failures, terminal attempts, valuation bridges, and target selectors. Its gzip timestamp is fixed for deterministic reproduction. Input files are hash-bound and preserved before updates. Complete previous generated paths and contemporaneous code are retained in model vintages; the first complete trial summary is never overwritten. Computational PASS does not certify the unsupported funding assumptions or turn a core contribution into a consolidated price target.

Prior distinct vintages can be reproduced with `python rebuild_model_vintage.py <vintage folder>`. The cold-rebuild proofs compare the entire deterministic gzip byte hash, not just selected rounded outputs. A compact package may map byte-identical current-vintage copies to root originals and omit prior large generated gzip copies only when frozen inputs, contemporaneous code and exact checksum proofs are retained. The on-disk original vintages are not deleted.


| Source-bounded stress | Unit growth / margin | Failure month / gap | Ordinary full-company IRR |
|---|---|---|---|
| bear_5y | -3.00% / 8.00% | 1 / ₹5.22 | NS |
| base_5y | 7.00% / 11.00% | 1 / ₹2.42 | NS |
| bull_5y | 14.00% / 14.00% | 1 / ₹0.09 | NS |
| bear_10y | -3.00% / 8.00% | 1 / ₹5.22 | NS |
| base_10y | 7.00% / 11.00% | 1 / ₹2.42 | NS |
| bull_10y | 14.00% / 14.00% | 1 / ₹0.09 | NS |

These stress cases are not a verified current cash forecast. A source-bounded inability to assume FD release/renewal is not evidence that the issuer cannot actually obtain it.

| Conditional core path | Terminal core sales | Horizon capex / gross new debt | Core-only per-share contribution | Illustrative core-only IRR / whole-company IRR |
|---|---|---|---|---|
| conditional_reference_5y | 222.46 | 26.30 / 0.00 | 34.16 | -11.91% / NS |
| conditional_reference_10y | 344.49 | 70.24 / 0.00 | 78.37 | 1.98% / NS |

Core contributions are components of a possible sum of parts, not targets for the complete share. The residual subsidiary equity, parent loans, intercompany claims and minority economics are NS, not assigned zero.

| Conditional reference | Next NOPAT / DA | Replacement / growth reinvestment | FCFF | Exit cash / operating reserve / funding reserve | Debt / senior claims | Terminal share of operating DCF |
|---|---|---|---|---|---|---|
| conditional_reference_5y | 20.81 / 3.27 | 4.63 / 7.85 | 11.61 | 17.00 / 5.67 / 6.01 | 24.49 / 1.16 | 81.82% |
| conditional_reference_10y | 35.78 / 5.61 | 7.17 / 11.95 | 22.28 | 36.55 / 7.81 / 8.14 | 24.28 / 1.16 | 70.37% |

| Conditional path / hurdle | Core-only entry contribution | Required total exit equity | Required noncore residual equity |
|---|---|---|---|
| conditional_reference_5y / 12.00% | 19.00 | 273.81 | 191.42 |
| conditional_reference_5y / 15.00% | 16.65 | 312.50 | 230.11 |
| conditional_reference_5y / 18.00% | 14.64 | 355.44 | 273.05 |
| conditional_reference_10y / 12.00% | 24.73 | 482.55 | 293.56 |
| conditional_reference_10y / 15.00% | 18.99 | 628.55 | 439.56 |
| conditional_reference_10y / 18.00% | 14.68 | 813.17 | 624.18 |

Residual is the incremental noncore equity value needed at exit after the modeled core contribution; it is not a forecast of subsidiary value. A negative residual, if any, would mean core sufficiency only under that conditional path. It would not resolve current source eligibility.

| Retained path | Unit growth / EBITDA margin | Conditional core contribution | Core-only IRR or failure | Whole-company price |
|---|---|---|---|---|
| conditional_no_new_debt_5y | 7.00% / 11.00% | 34.16 | -11.91% | NS |
| conditional_no_fd_release_5y | 7.00% / 11.00% | 23.82 | -18.04% | NS |
| conditional_no_cc_renewal_5y | 7.00% / 11.00% | 33.68 | -12.17% | NS |
| conditional_no_new_renewal_5y | 7.00% / 11.00% | 34.16 | -11.91% | NS |
| conditional_no_inventory_normalization_5y | 7.00% / 11.00% | 22.02 | -19.32% | NS |
| conditional_slow_collections_5y | 7.00% / 11.00% | ND | Failed month 26 | NS |
| conditional_delayed_capex_5y | 7.00% / 11.00% | 34.09 | -11.95% | NS |
| conditional_capex_inflation_5y | 7.00% / 11.00% | 31.06 | -13.58% | NS |
| conditional_prima_full_limit_5y | 7.00% / 11.00% | 22.26 | -19.14% | NS |
| conditional_guarantee_hdfc_call_5y | 7.00% / 11.00% | 29.71 | -14.34% | NS |
| conditional_guarantee_old_pool_call_5y | 7.00% / 11.00% | 21.96 | -19.37% | NS |
| conditional_esop_full_exercise_5y | 7.00% / 11.00% | 33.87 | -12.07% | NS |
| conditional_deposit_ipo_only_5y | 7.00% / 11.00% | 27.28 | -15.79% | NS |
| conditional_no_future_sub_outflow_5y | 7.00% / 11.00% | 34.79 | -11.59% | NS |
| conditional_term_immediate_call_5y | 7.00% / 11.00% | 33.89 | -12.06% | NS |
| conditional_multiple_normalization_5y | 7.00% / 11.00% | 34.16 | -11.91% | NS |
| conditional_terminal_roic_8_5y | 7.00% / 11.00% | 25.16 | -17.14% | NS |
| conditional_terminal_roic_10_5y | 7.00% / 11.00% | 32.50 | -12.79% | NS |
| wacc_growth_5y_w.13_g.02 | 7.00% / 11.00% | 52.01 | -4.19% | NS |
| wacc_growth_5y_w.13_g.04 | 7.00% / 11.00% | 47.53 | -5.90% | NS |
| wacc_growth_5y_w.13_g.06 | 7.00% / 11.00% | 41.24 | -8.54% | NS |
| wacc_growth_5y_w.15_g.02 | 7.00% / 11.00% | 43.30 | -7.64% | NS |
| wacc_growth_5y_w.15_g.04 | 7.00% / 11.00% | 37.81 | -10.11% | NS |
| wacc_growth_5y_w.15_g.06 | 7.00% / 11.00% | 30.47 | -13.91% | NS |
| wacc_growth_5y_w.17_g.02 | 7.00% / 11.00% | 36.91 | -10.54% | NS |
| wacc_growth_5y_w.17_g.04 | 7.00% / 11.00% | 31.08 | -13.57% | NS |
| wacc_growth_5y_w.17_g.06 | 7.00% / 11.00% | 23.61 | -18.19% | NS |
| wacc_growth_5y_w.19_g.02 | 7.00% / 11.00% | 32.02 | -13.05% | NS |
| wacc_growth_5y_w.19_g.04 | 7.00% / 11.00% | 26.14 | -16.50% | NS |
| wacc_growth_5y_w.19_g.06 | 7.00% / 11.00% | 18.86 | -21.78% | NS |
| growth_margin_5y_v0_m.08 | 0.00% / 8.00% | 12.98 | -27.41% | NS |
| growth_margin_5y_v0_m.11 | 0.00% / 11.00% | 31.79 | -13.17% | NS |
| growth_margin_5y_v0_m.14 | 0.00% / 14.00% | 50.61 | -4.71% | NS |
| growth_margin_5y_v.05_m.08 | 5.00% / 8.00% | 16.82 | -23.55% | NS |
| growth_margin_5y_v.05_m.11 | 5.00% / 11.00% | 37.75 | -10.14% | NS |
| growth_margin_5y_v.05_m.14 | 5.00% / 14.00% | 56.82 | -2.48% | NS |
| growth_margin_5y_v.10_m.08 | 10.00% / 8.00% | ND | Failed month 38 | NS |
| growth_margin_5y_v.10_m.11 | 10.00% / 11.00% | 33.81 | -12.10% | NS |
| growth_margin_5y_v.10_m.14 | 10.00% / 14.00% | 58.94 | -1.76% | NS |
| growth_margin_5y_v.15_m.08 | 15.00% / 8.00% | ND | Failed month 26 | NS |
| growth_margin_5y_v.15_m.11 | 15.00% / 11.00% | ND | Failed month 26 | NS |
| growth_margin_5y_v.15_m.14 | 15.00% / 14.00% | ND | Failed month 38 | NS |
| growth_margin_5y_v.20_m.08 | 20.00% / 8.00% | ND | Failed month 14 | NS |
| growth_margin_5y_v.20_m.11 | 20.00% / 11.00% | ND | Failed month 15 | NS |
| growth_margin_5y_v.20_m.14 | 20.00% / 14.00% | ND | Failed month 26 | NS |
| reverse_5y_v0 | 0.00% / 11.00% | 31.79 | -13.17% | NS |
| reverse_5y_v0.02 | 2.00% / 11.00% | 34.08 | -11.96% | NS |
| reverse_5y_v0.04 | 4.00% / 11.00% | 36.50 | -10.74% | NS |
| reverse_5y_v0.06 | 6.00% / 11.00% | 33.65 | -12.18% | NS |
| reverse_5y_v0.08 | 8.00% / 11.00% | 34.49 | -11.75% | NS |
| reverse_5y_v0.1 | 10.00% / 11.00% | 33.81 | -12.10% | NS |
| reverse_5y_v0.12 | 12.00% / 11.00% | ND | Failed month 51 | NS |
| reverse_5y_v0.14 | 14.00% / 11.00% | ND | Failed month 38 | NS |
| reverse_5y_v0.16 | 16.00% / 11.00% | ND | Failed month 38 | NS |
| reverse_5y_v0.18 | 18.00% / 11.00% | ND | Failed month 26 | NS |
| reverse_5y_v0.2 | 20.00% / 11.00% | ND | Failed month 26 | NS |
| reverse_5y_v0.22 | 22.00% / 11.00% | ND | Failed month 26 | NS |
| reverse_5y_v0.24 | 24.00% / 11.00% | ND | Failed month 16 | NS |
| reverse_5y_v0.26 | 26.00% / 11.00% | ND | Failed month 14 | NS |
| reverse_5y_v0.28 | 28.00% / 11.00% | ND | Failed month 14 | NS |
| reverse_5y_v0.3 | 30.00% / 11.00% | ND | Failed month 14 | NS |
| reverse_5y_v0.32 | 32.00% / 11.00% | ND | Failed month 14 | NS |
| reverse_5y_v0.34 | 34.00% / 11.00% | ND | Failed month 14 | NS |
| reverse_5y_v0.36 | 36.00% / 11.00% | ND | Failed month 14 | NS |
| reverse_5y_v0.38 | 38.00% / 11.00% | ND | Failed month 14 | NS |
| reverse_5y_v0.4 | 40.00% / 11.00% | ND | Failed month 14 | NS |
| conditional_no_new_debt_10y | 7.00% / 11.00% | 78.37 | 1.98% | NS |
| conditional_no_fd_release_10y | 7.00% / 11.00% | 62.84 | -0.25% | NS |
| conditional_no_cc_renewal_10y | 7.00% / 11.00% | 77.06 | 1.81% | NS |
| conditional_no_new_renewal_10y | 7.00% / 11.00% | 78.37 | 1.98% | NS |
| conditional_no_inventory_normalization_10y | 7.00% / 11.00% | ND | Failed month 75 | NS |
| conditional_slow_collections_10y | 7.00% / 11.00% | ND | Failed month 26 | NS |
| conditional_delayed_capex_10y | 7.00% / 11.00% | 78.26 | 1.96% | NS |
| conditional_capex_inflation_10y | 7.00% / 11.00% | 71.75 | 1.08% | NS |
| conditional_prima_full_limit_10y | 7.00% / 11.00% | ND | Failed month 62 | NS |
| conditional_guarantee_hdfc_call_10y | 7.00% / 11.00% | 72.29 | 1.16% | NS |
| conditional_guarantee_old_pool_call_10y | 7.00% / 11.00% | ND | Failed month 62 | NS |
| conditional_esop_full_exercise_10y | 7.00% / 11.00% | 77.53 | 1.87% | NS |
| conditional_deposit_ipo_only_10y | 7.00% / 11.00% | 68.40 | 0.60% | NS |
| conditional_no_future_sub_outflow_10y | 7.00% / 11.00% | 79.00 | 2.06% | NS |
| conditional_term_immediate_call_10y | 7.00% / 11.00% | 77.65 | 1.88% | NS |
| conditional_multiple_normalization_10y | 7.00% / 11.00% | 78.37 | 1.98% | NS |
| conditional_terminal_roic_8_10y | 7.00% / 11.00% | 57.41 | -1.15% | NS |
| conditional_terminal_roic_10_10y | 7.00% / 11.00% | 70.02 | 0.84% | NS |
| wacc_growth_10y_w.13_g.02 | 7.00% / 11.00% | 106.65 | 5.17% | NS |
| wacc_growth_10y_w.13_g.04 | 7.00% / 11.00% | 104.03 | 4.91% | NS |
| wacc_growth_10y_w.13_g.06 | 7.00% / 11.00% | 100.64 | 4.56% | NS |
| wacc_growth_10y_w.15_g.02 | 7.00% / 11.00% | 90.72 | 3.48% | NS |
| wacc_growth_10y_w.15_g.04 | 7.00% / 11.00% | 85.37 | 2.85% | NS |
| wacc_growth_10y_w.15_g.06 | 7.00% / 11.00% | 78.14 | 1.95% | NS |
| wacc_growth_10y_w.17_g.02 | 7.00% / 11.00% | 79.03 | 2.06% | NS |
| wacc_growth_10y_w.17_g.04 | 7.00% / 11.00% | 72.44 | 1.18% | NS |
| wacc_growth_10y_w.17_g.06 | 7.00% / 11.00% | 63.82 | -0.09% | NS |
| wacc_growth_10y_w.19_g.02 | 7.00% / 11.00% | 70.10 | 0.85% | NS |
| wacc_growth_10y_w.19_g.04 | 7.00% / 11.00% | 62.97 | -0.23% | NS |
| wacc_growth_10y_w.19_g.06 | 7.00% / 11.00% | 53.91 | -1.77% | NS |
| growth_margin_10y_v0_m.08 | 0.00% / 8.00% | 26.89 | -8.37% | NS |
| growth_margin_10y_v0_m.11 | 0.00% / 11.00% | 53.43 | -1.85% | NS |
| growth_margin_10y_v0_m.14 | 0.00% / 14.00% | 79.42 | 2.11% | NS |
| growth_margin_10y_v.05_m.08 | 5.00% / 8.00% | 37.14 | -5.36% | NS |
| growth_margin_10y_v.05_m.11 | 5.00% / 11.00% | 69.96 | 0.83% | NS |
| growth_margin_10y_v.05_m.14 | 5.00% / 14.00% | 102.75 | 4.78% | NS |
| growth_margin_10y_v.10_m.08 | 10.00% / 8.00% | ND | Failed month 38 | NS |
| growth_margin_10y_v.10_m.11 | 10.00% / 11.00% | ND | Failed month 62 | NS |
| growth_margin_10y_v.10_m.14 | 10.00% / 14.00% | 132.81 | 7.50% | NS |
| growth_margin_10y_v.15_m.08 | 15.00% / 8.00% | ND | Failed month 26 | NS |
| growth_margin_10y_v.15_m.11 | 15.00% / 11.00% | ND | Failed month 26 | NS |
| growth_margin_10y_v.15_m.14 | 15.00% / 14.00% | ND | Failed month 38 | NS |
| growth_margin_10y_v.20_m.08 | 20.00% / 8.00% | ND | Failed month 14 | NS |
| growth_margin_10y_v.20_m.11 | 20.00% / 11.00% | ND | Failed month 15 | NS |
| growth_margin_10y_v.20_m.14 | 20.00% / 14.00% | ND | Failed month 26 | NS |
| reverse_10y_v0 | 0.00% / 11.00% | 53.43 | -1.85% | NS |
| reverse_10y_v0.02 | 2.00% / 11.00% | 62.73 | -0.27% | NS |
| reverse_10y_v0.04 | 4.00% / 11.00% | 66.06 | 0.25% | NS |
| reverse_10y_v0.06 | 6.00% / 11.00% | 74.06 | 1.40% | NS |
| reverse_10y_v0.08 | 8.00% / 11.00% | 81.06 | 2.32% | NS |
| reverse_10y_v0.1 | 10.00% / 11.00% | ND | Failed month 86 | NS |
| reverse_10y_v0.12 | 12.00% / 11.00% | ND | Failed month 51 | NS |
| reverse_10y_v0.14 | 14.00% / 11.00% | ND | Failed month 38 | NS |
| reverse_10y_v0.16 | 16.00% / 11.00% | ND | Failed month 38 | NS |
| reverse_10y_v0.18 | 18.00% / 11.00% | ND | Failed month 26 | NS |
| reverse_10y_v0.2 | 20.00% / 11.00% | ND | Failed month 26 | NS |
| reverse_10y_v0.22 | 22.00% / 11.00% | ND | Failed month 26 | NS |
| reverse_10y_v0.24 | 24.00% / 11.00% | ND | Failed month 16 | NS |
| reverse_10y_v0.26 | 26.00% / 11.00% | ND | Failed month 14 | NS |
| reverse_10y_v0.28 | 28.00% / 11.00% | ND | Failed month 14 | NS |
| reverse_10y_v0.3 | 30.00% / 11.00% | ND | Failed month 14 | NS |
| reverse_10y_v0.32 | 32.00% / 11.00% | ND | Failed month 14 | NS |
| reverse_10y_v0.34 | 34.00% / 11.00% | ND | Failed month 14 | NS |
| reverse_10y_v0.36 | 36.00% / 11.00% | ND | Failed month 14 | NS |
| reverse_10y_v0.38 | 38.00% / 11.00% | ND | Failed month 14 | NS |
| reverse_10y_v0.4 | 40.00% / 11.00% | ND | Failed month 14 | NS |

| Window | Observed / zero / missing | Mean / median daily turnover ₹ | Exit days 2% /5% /10% |
|---|---|---|---|
| 20 | 20 / 0 / 0 | 1,571,082.00 / 1,220,670.00 | 20.48 / 8.19 / 4.10 |
| 60 | 60 / 0 / 0 | 1,267,504.00 / 1,130,460.00 | 22.11 / 8.85 / 4.42 |

All 60 issuer rows are present and positive, so no missing date is imputed as zero. Formula uses 5%of the lower 60-day mean/median turnover; actual whole-lot orders, spreads, limits and market impact can be worse. Reference 13lots cost ₹492,570; an illustrative fractional daily participation figure does not guarantee that every day permits a lot-sized exit.

## 11. Bear Case and Permanent Loss Path

The strongest adverse path is not just a lower P/E. Larger panel/EPC contracts and solar expansion consume inventory and credit; delayed collections then require bank finance or restricted-deposit release; a guarantee call or additional subsidiary loan competes with those needs; resulting dilution or a forced asset sale reduces value per owner share. The old factory and positive operating earnings provide recovery support, and no observed default is established in the reviewed audit. Nonetheless, reported net worth cannot substitute for available cash. Model reserve breaches are conditional stress findings from dated balances, not claims that an actual payment was missed. The single thesis-break variable is the ability to turn growing receivables/inventory into cash without repeated low-return funding. A supported return thesis would be falsified by sustained weak collection economics even if reported sales continue rising. Impairment risk is qualitatively High, but precise current whole-company downside/recovery is NS pending the claim and liquidity bridge. [AR2026; MODEL](https://archives.nseindia.com/annual_reports/SME_AR_31631_SPCL_2025_2026_A_10534668_05092026224234.pdf)

## 12. Five Times and Ten Times Feasibility

| Horizon / test | Funded / failed grid paths | Core sufficiency crossings | Least tested growth crossing | Best core-only net multiple |
|---|---|---|---|---|
| 5y / annual_hurdle .12 | 9 / 27 | 0 | None | 1.25× |
| 5y / annual_hurdle .15 | 9 / 27 | 0 | None | 1.25× |
| 5y / annual_hurdle .18 | 9 / 27 | 0 | None | 1.25× |
| 5y / wealth_multiple 3 | 9 / 27 | 0 | None | 1.25× |
| 5y / wealth_multiple 5 | 9 / 27 | 0 | None | 1.25× |
| 5y / wealth_multiple 10 | 9 / 27 | 0 | None | 1.25× |
| 10y / annual_hurdle .12 | 8 / 28 | 0 | None | 2.63× |
| 10y / annual_hurdle .15 | 8 / 28 | 0 | None | 2.63× |
| 10y / annual_hurdle .18 | 8 / 28 | 0 | None | 2.63× |
| 10y / wealth_multiple 3 | 8 / 28 | 0 | None | 2.63× |
| 10y / wealth_multiple 5 | 8 / 28 | 0 | None | 2.63× |
| 10y / wealth_multiple 10 | 8 / 28 | 0 | None | 2.63× |

Speculative / unsupported as a whole-company 5× or 10× thesis. Tenfold price growth alone requires 58.49% annually over five years or 25.89% over ten, before costs and any dilution. Every tested crossing is only a conditional core-contribution sufficiency test; all source-eligible crossing counts arezero. Failure of a finite tested grid is not proof no possible future outcome could reach the target. Detailed growth, margin, capital, debt, share and residual-equity outcomes accompany every retained path.

## 13. Monitoring Plan

| KPI baseline | Evidence/milestone | Warning / thesis-break distinction |
|---|---|---|
| FY26 core sales ₹143.66 crore,8.54%growth | Comparable orders, physical output and realization | Continued growth with deteriorating value added warrants review; declining repeat customer economics challenges runway |
| FY24–26 CFO−₹34.78 crore | Collections, customer acceptance, inventory ageing and deposits | One season is not failure; persistent loss of cash per incremental sale breaks compounder thesis |
| Core 3-year incremental return≈2.5% | Committed-capital bridge and mature-cohort returns | No improvement as capital matures versus 13–17%cost range undermines reinvestment thesis |
| Cash/guarantee source conflicts | Bank-confirmed unrestricted balances, instrumentwise guarantees and corrected disclosures | A verified material hidden liability or unexplained asset shortfall changes reliability; typo alone is not fraud |
| Revised IPO machinery/assembly schedule | Actual commissioning, dispatch and use certificate | Ratification is not completion; material unauthorized reallocation would change governance |
| Prima ₹1.50 crore known advance/₹20 crore permission | Actual drawdowns, lender terms, repayment and funded project budget | Ceiling is not payment; loss-making additional funding reduces parent value |
| Seedlab 51%stake/₹8.632croreBGpermission | Issued/called guarantees, indemnity and project progress | Approval is not loss; actual calls need cash and recovery reassessment |
| 300,000ESOPpool | Grants, vesting, expense and exercise | Approval not dilution yet; actual diluted per-share returns must be updated |
| 600-share lot and 8.85theoreticaldays | Current restrictions, depth and spread for actual position | Thin/one-sided market changes execution; not a generic automatic exit |

## 14. Final Classification and Conditional Action

Hold — unresolved; research priority is cash, claims and subsidiary capital allocation, not a buy/exit instruction. G2 and G3 remain holds, G1 and G4 are conditional, with no established governance-avoid override or observed funding-default claim. BQS and IAS are NS; GQS has a disclosed raw value and 5.0 cap but is not an eligible ranking observation while material reliability gaps remain. The compounder designation fails both the required factor thresholds and the unresolved-gate condition. For an existing holder, this is a review candidate because cash economics and funding evidence need resolution; without holdings, taxes or actual exit depth, an unconditional sell instruction is not supported. A lower share price alone cannot resolve cash restrictions, missing claims or unsupported project returns. Conversely, clean reconciliations plus recurring cash realization and improved incremental returns could justify reassessment even without an immediate price change.

## 15. Sources Assumptions and Open Questions

| ID / source | Date | Primary link / scope and limits |
|---|---|---|
| S1 | 2024-06-14 | [Shivalic Power Control RHP](https://shivalic.com/wp-content/uploads/2024/06/RHP-1.pdf)  Printed page equals PDF page; historical/stub data only. |
| S2 | 2024-06-26 | [Shivalic Power Control final prospectus](https://shivalic.com/wp-content/uploads/2024/06/Prospectus.pdf)  Final issue terms; prospectus dates crosschecked EGM. |
| S3 | 2025-09-03 | [FY2024-25 Annual Report](https://shivalic.com/wp-content/uploads/2025/09/SHIVALIC_2025_REPORT-1_compressed.pdf)  Company-hosted original; page refs PDF1based. |
| S4 | 2026-09-05 | [FY2025-26 Annual Report filed NSE](https://archives.nseindia.com/annual_reports/SME_AR_31631_SPCL_2025_2026_A_10534668_05092026224234.pdf)  Canonical cutoff-stable exchange filing. Company AR2026.pdf has one fewer cover page; its page+1=this PDF page. Normalized full report comparison confirms substantive finance/governance match. |
| S5 | 2024-12-04 | [Updated investor presentation](https://nsearchives.nseindia.com/corporate/SPCL_04122024131901_Shivalic_-_Updated_investor_presentation.pdf)  Use updated Dec 4 deck not prior Dec 3 deck with Nov 2025 title typo. PDFpage=printedslide+1. |
| S6 | 2026-01-22 | [Notice EGM18 Feb 2026 and explanatory statements](https://shivalic.com/wp-content/uploads/2026/01/Shivalic-EGM-Notice.pdf)  Meeting 18 Feb 2026. Approval separately corroborated May 29 filing and AR26 secretarial report. PDF17 scanned table visually verified. |
| S7 | 2026-05-29 | [FY26 audited results and IPO deviation statement](https://nsearchives.nseindia.com/corporate/SHIVALIC_29052026220417_Outcome_of_BM_29052026_final_sd.pdf)  IPO date typo 2026 not carried forward; historical actual June 2024. Revised allocation basis explicit. |
| S8 | 2026-02-21 | [Board approval Somaya acquisition](https://nsearchives.nseindia.com/corporate/SHIVALIC_21022026190931_OUTCOME_BM21022026.pdf)  Approval date not completion; AR consolidated notes give 27 Feb completion. |
| S9 | 2026-09-19 | [Revised completed acquisition Seedlab](https://nsearchives.nseindia.com/corporate/SHIVALIC_19092026150222_Revised_Disclosure_for_Completion_sd.pdf)  Corrected price 1.43 lakh supersedes 1.37 lakh; completion confirmed not projected completion date. |
| S10 | 2026-09-19 | [Seedlab UPPTCL bank guarantees approval](https://nsearchives.nseindia.com/corporate/SHIVALIC_19092026160041_Disclosure_For_Gurantee_Final_sd.pdf)  Approved contingent guarantees; do not assume funded payment. |
| S11 | 2026-10-05 | [AGM30 Sep 2026 voting results and scrutinizer](https://nsearchives.nseindia.com/corporate/SHIVALIC_05102026202811_Final_Disclosure_sd.pdf)  Signed scrutinizer 3 Oct 2026. PDF18/19 image verified; promoter excluded RPTs despite misleading front totals. |
| S12 | 2026-09-22 | [Promoter group share acquisition intimation](https://nsearchives.nseindia.com/corporate/SHIVALIC_22092026175722_Intimation_Letter_SD.pdf)  Purchases 18 Sep 2026 not new company capital issue. |
| S13 | 2026-09-05 | [Statutory auditor five-year appointment](https://nsearchives.nseindia.com/corporate/SHIVALIC_05092026211917_Change_in_Auditor_Disclosure_BM2_sd__1_.pdf)  Subject AGM subsequently approved; separate interim 21 Jul appointment in AR. |
| S14 | 2019-07-17 | [CARE withdrawal bank ratings](https://www.careratings.com/upload/CompanyFiles/PR/Shivalic%20Power%20Control%20Private%20Limited-07-17-2019.pdf)  Historical withdrawn BB/Stable A4 only, NOT a live 2026rating. |
| S15 | 2024-09-05 | [FY2023-24 Annual Report](https://shivalic.com/wp-content/uploads/2024/09/Final-Shivalic-Annual-Report-2024.pdf)  Financial/capacity background; native large PDF retained. |
| RHP2024 | 2024-06-14 | [Audited restated standalone; examination report 22 January 2024](https://shivalic.com/wp-content/uploads/2024/06/RHP-1.pdf) 166-171 main statements; 172-201 notes; 214-218 indebtedness Page locators refer to the linked original PDF, without any general cover-page adjustment. |
| AR2026 | 2026-09-05 | [Standalone core and first consolidated FY26; all page numbers 1-based PDF](https://archives.nseindia.com/annual_reports/SME_AR_31631_SPCL_2025_2026_A_10534668_05092026224234.pdf) PDF169-175 standalone BS/P&L/CF,179-208 notes;221-227 group statements,231-258 notes Existing page numbers refer company PDF. Add 1 for dated NSE filing, whose first page is exchange cover. Business worker normalized-text comparison found financial content identical. |
| AR2025 | 2025-09-03 | [Standalone FY25 and FY24 comparatives](https://shivalic.com/wp-content/uploads/2025/09/SHIVALIC_2025_REPORT-1_compressed.pdf) 135-141 statements,147-174 notes Page locators refer to the linked original PDF, without any general cover-page adjustment. |
| AR2024 | 2024-09 | [Original standalone annual accounts; scan](https://shivalic.com/wp-content/uploads/2024/09/Final-Shivalic-Annual-Report-2024.pdf) PDF108-112 main statements,113-124 notes Page locators refer to the linked original PDF, without any general cover-page adjustment. |
| FR2023 | 2023-09-02 | [Original audited standalone, original units INR thousand, converted to lakh /100](https://shivalic.com/wp-content/uploads/2024/04/FR-2022-2023-1.pdf) 1 BS,2 P&L,3 cash flow,4-18 notes Page locators refer to the linked original PDF, without any general cover-page adjustment. |
| FR2022 | 2022-09-05 | [Original audited standalone FY22/FY21 comparatives, original units INR thousand, converted to lakh /100](https://shivalic.com/wp-content/uploads/2024/04/FR-2021-2022-1.pdf) 1 BS,2 P&L,3 cash flow,4-13 notes Page locators refer to the linked original PDF, without any general cover-page adjustment. |
| H12026 | 2025-11-14 | [Unaudited, limited review, half-year ended 30 September 2025; not H1 FY27](https://shivalic.com/wp-content/uploads/2025/11/Outcome.pdf) 4 financial results,5 BS,6 P&L,7 CF Page locators refer to the linked original PDF, without any general cover-page adjustment. |
| FY2026_RESULTS | 2026-05-29 | [NSE annual-results release; financial schedules scanned, issued before cutoff](https://nsearchives.nseindia.com/corporate/SHIVALIC_29052026220417_Outcome_of_BM_29052026_final_sd.pdf)  Page locators refer to the linked original PDF, without any general cover-page adjustment. |
| CARE2019 | 2019-07-17 | [Historical rating withdrawn at borrower request with lender NOC; NOT a current rating or current facility limit](https://www.careratings.com/upload/CompanyFiles/PR/Shivalic%20Power%20Control%20Private%20Limited-07-17-2019.pdf)  Page locators refer to the linked original PDF, without any general cover-page adjustment. |
| Prospectus 2024 | 2024-06-26 | [Shivalic Power Control final prospectus](https://shivalic.com/wp-content/uploads/2024/06/Prospectus.pdf)  Final issue terms; prospectus dates crosschecked EGM. |
| AR2026_NSE20260905 | 2026-09-05 | [FY2025-26 Annual Report filed NSE](https://archives.nseindia.com/annual_reports/SME_AR_31631_SPCL_2025_2026_A_10534668_05092026224234.pdf)  Canonical cutoff-stable exchange filing. Company AR2026.pdf has one fewer cover page; its page+1=this PDF page. Normalized full report comparison confirms substantive finance/governance match. |
| InvestorPresentation 20241204 | 2024-12-04 | [Updated investor presentation](https://nsearchives.nseindia.com/corporate/SPCL_04122024131901_Shivalic_-_Updated_investor_presentation.pdf)  Use updated Dec 4 deck not prior Dec 3 deck with Nov 2025 title typo. PDFpage=printedslide+1. |
| EGM20260218 | 2026-01-22 | [Notice EGM18 Feb 2026 and explanatory statements](https://shivalic.com/wp-content/uploads/2026/01/Shivalic-EGM-Notice.pdf)  Meeting 18 Feb 2026. Approval separately corroborated May 29 filing and AR26 secretarial report. PDF17 scanned table visually verified. |
| FY26Results 20260529 | 2026-05-29 | [FY26 audited results and IPO deviation statement](https://nsearchives.nseindia.com/corporate/SHIVALIC_29052026220417_Outcome_of_BM_29052026_final_sd.pdf)  IPO date typo 2026 not carried forward; historical actual June 2024. Revised allocation basis explicit. |
| Somaya 20260221 | 2026-02-21 | [Board approval Somaya acquisition](https://nsearchives.nseindia.com/corporate/SHIVALIC_21022026190931_OUTCOME_BM21022026.pdf)  Approval date not completion; AR consolidated notes give 27 Feb completion. |
| Acquisition 20260919 | 2026-09-19 | [Revised completed acquisition Seedlab](https://nsearchives.nseindia.com/corporate/SHIVALIC_19092026150222_Revised_Disclosure_for_Completion_sd.pdf)  Corrected price 1.43 lakh supersedes 1.37 lakh; completion confirmed not projected completion date. |
| Guarantee 20260919 | 2026-09-19 | [Seedlab UPPTCL bank guarantees approval](https://nsearchives.nseindia.com/corporate/SHIVALIC_19092026160041_Disclosure_For_Gurantee_Final_sd.pdf)  Approved contingent guarantees; do not assume funded payment. |
| AGMVotes 20261005 | 2026-10-05 | [AGM30 Sep 2026 voting results and scrutinizer](https://nsearchives.nseindia.com/corporate/SHIVALIC_05102026202811_Final_Disclosure_sd.pdf)  Signed scrutinizer 3 Oct 2026. PDF18/19 image verified; promoter excluded RPTs despite misleading front totals. |
| Promoter 20260922 | 2026-09-22 | [Promoter group share acquisition intimation](https://nsearchives.nseindia.com/corporate/SHIVALIC_22092026175722_Intimation_Letter_SD.pdf)  Purchases 18 Sep 2026 not new company capital issue. |
| Auditor 20260905 | 2026-09-05 | [Statutory auditor five-year appointment](https://nsearchives.nseindia.com/corporate/SHIVALIC_05092026211917_Change_in_Auditor_Disclosure_BM2_sd__1_.pdf)  Subject AGM subsequently approved; separate interim 21 Jul appointment in AR. |
| RatingCARE20190717 | 2019-07-17 | [CARE withdrawal bank ratings](https://www.careratings.com/upload/CompanyFiles/PR/Shivalic%20Power%20Control%20Private%20Limited-07-17-2019.pdf)  Historical withdrawn BB/Stable A4 only, NOT a live 2026rating. |
| Results 20260529 | 2026-05-29 | [FY26 audited results and IPO deviation statement](https://nsearchives.nseindia.com/corporate/SHIVALIC_29052026220417_Outcome_of_BM_29052026_final_sd.pdf)  IPO date typo 2026 not carried forward; historical actual June 2024. Revised allocation basis explicit. |
| MARKET | 2026-10-19 | [NSE19 October 2026bhavcopy and prior 59dated archives](https://nsearchives.nseindia.com/content/cm/BhavCopy_NSE_CM_0_0_0_20261019_F_0000.csv.zip)  Full source URLs and byte/CSV hashes retained for all 60sessions and dated master; no order-book depth guarantee. |

Detailed claim ledger and original/restated reconciliation accompany the report. Only FY26 annual-report page references use the company PDF with a one-page addition for the NSE exchange cover, unless explicitly labeled NSE. Other sources retain their own linked PDF pagination. Evidence types: V verified disclosure; C calculation; M management statement; A analyst assumption.

The material open questions are the exact unrestricted bank/FD balance and post-March deployment; parent-versus-group guarantee reconciliation; sanctioned and available facilities, maturity/renewal terms and collateral; acquisition-date cash/NCI and intercompany eliminations; how much of the Prima authorization is actually funded at cutoff; current solar project obligations and commissioning economics; granted versus approved ESOPs; current unit production, price/mix and backlog quality; and complete reconciliation of older cash-flow vintages. A dated resolved item should be removed from a hold, not retained as a permanent allegation. The 2019 CARE withdrawal was voluntary with NOC/surrender evidence and is not a current adverse rating. October 24, 2026 results are outside the fixed cutoff and deliberately excluded. All model growth, recovery, facility-access, maturity fallback, cost-of-capital and terminal assumptions are analyst inputs unless specifically identified as verified disclosures. No probability or 10× success likelihood is claimed.

### Required quality checks

| Check | Evidence / treatment |
|---|---|
| 1. Identity and scope | ISIN INE0T7B01010, NSE SPCL, 60 issuer sessions and dated security master verified. Consolidated investable perimeter is separated from comparable parent-core history. |
| 2. Primary records and assumptions | RHP, original and later annual accounts, audited notes, offer use, acquisition, AGM scrutiny and exchange filings read. Issuer forecasts and model assumptions are labeled. |
| 3. Audit RPT financing dilution | Clean opinion/CARO/IFC and promoter-exclusion counterevidence retained beside material cash/guarantee discrepancies. ESOP approval is not grant or exercise; subsidiary NCI remains separate. |
| 4. Periods units TTM | Original input lakh converted to crore. Restated and original vintages shown. H2 subtraction is labeled, not invented quarterly CFO. October 24 results excluded. |
| 5. Revenue growth decomposition | Five-year core revenue window fixed before scoring, three-year cross-check and two comparable halves; acquired group uplift not called organic. Unit/mix gap retained. |
| 6. CFO ratio of sums | Three-year and five-year sum CFO/sum PAT calculated separately. Capex appears in investing/FCF bridge, not explanation of CFO. |
| 7. Incremental returns | 3/5-year NOPAT and operating-capital denominators, net-asset/capex/DA bridge, alternative definitions and investment timing limits visible. |
| 8. Normalization claims dilution | Other-income/tax assumption explicit; parent-owner PAT/NCI and share counts not mixed. Subsidiary claim values remain NS rather than zero. |
| 9. Linked cash financing scenarios | Monthly collections, purchasing, capex, debt maturity/fees and terminal reserves tested; no ordinary return from failed or source-ineligible paths. Restricted cash and approved claims remain distinct. |
| 10. Canonical factors and weights | 13 factors each stored once, exact original weights sum to 1, BQS reused only once in IAS. |
| 11. Missingness coverage bounds | BAL and unsupported IAS dimensions NS, no renormalization. Mathematical bounds and dependency-aware IAS bounds are not confidence intervals. |
| 12. Raw final and overrides | GQS persistent CAP/CASH cap disclosed; no hidden governance/default cap. Decimal half-up display and unrounded classification. |
| 13. Classification | Hold unresolved precedes score matrix; no compounder designation or eligible quality ranking with G2 hold. |
| 14. Liquidity | ₹5 lakh at 2/5/10% turnover, 20/60 days, missing/zero distinction and 600-share lot; depth/spread unverified. |
| 15. Bear and falsification | Collection/funding loop, guarantee/project commitment and owner dilution path explicit. Model shortfall is not actual default. |
| 16. Batch and ranking integrity | Research 367 remains unpublished and pending independent final acceptance. No universe-wide winner or portfolio exit count claimed. |

### Research and implementation boundary

This is research, not an instruction to transact. No position size or tax context was supplied. Conditional model outcomes are not predictions, target prices or guarantees. Reproducibility establishes arithmetic and document consistency; it does not remove source gaps, uncertain financing or the need to reassess a different price or information date. No post-cutoff results are used in this historical assessment.
