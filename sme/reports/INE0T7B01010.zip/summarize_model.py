"""Readable, deterministic model tables derived solely from the canonical archive."""
from pathlib import Path
import json,gzip,hashlib
P=Path(__file__).resolve().parent

def main():
    file=P/'canonical_paths.json.gz';data=json.loads(gzip.decompress(file.read_bytes()));rows=[]
    for path in data['paths']:
        r=dict(path['summary']);r.update(wacc=path['spec']['wacc'],terminal_growth=path['spec']['terminal_growth'],terminal_roic=path['spec']['terminal_roic'],exit_ebitda_multiple=path['spec']['exit_ebitda_multiple'])
        t=path['terminal']
        if t:
            for key in ['core_enterprise_value','core_equity_contribution','core_operating_dcf','explicit_fcff_present_value','terminal_enterprise_present_value','terminal_value_share_of_operating_dcf','next_nopat','fcff','replacement_capex','growth_reinvestment','funding_reserve','operating_reserve','cash_bridge','cash_at_exit','debt','senior_claims','shares','multiple_core_per_share_contribution','loan_claim_excluded']:
                r[key]=t[key]
            r['hurdles']=t['hurdles']
        rows.append(r)
    table=dict(canonical_sha256=hashlib.sha256(file.read_bytes()).hexdigest(),interpretation='All numerical contribution values are conditional standalone-core values. Whole-company valuation and ordinary shareholder IRR are NS.',rows=rows,reference_annual_paths={p['path_id']:p['annual'] for p in data['paths'] if p['spec']['kind']=='conditional_reference'})
    (P/'model_tables.json').write_text(json.dumps(table,indent=2,ensure_ascii=False)+'\n');print('Wrote model_tables.json:',len(rows),'path summaries')
if __name__=='__main__':main()
