"""Independent saved-path replay. No imports from producer model or audit modules.
Reconstructs physical/cash queues, financing decisions and earned terminal valuation.
This is computational validation, not independent primary-source verification.
"""
import json,gzip,hashlib
from pathlib import Path
from collections import defaultdict
from decimal import Decimal as D,localcontext
P=Path(__file__).resolve().parent
ZERO=D(0); ONE=D(1)
def num(v):return D(str(v))
def norm(o):
    if isinstance(o,D):return format(o,'f')
    if isinstance(o,dict):return {k:norm(v) for k,v in o.items()}
    if isinstance(o,list):return [norm(v) for v in o]
    return o

def replay(path,inputs):
    s=path['spec'];o={k:num(v) for k,v in inputs['opening'].items() if v is not None}; checks=0; maxerr=ZERO
    def equal(a,b,name):
        nonlocal checks,maxerr
        a=num(a);b=num(b);error=abs(a-b);maxerr=max(maxerr,error)
        if error>D('1e-22')*max(ONE,abs(a),abs(b)):raise AssertionError((path['path_id'],name,str(a),str(b)))
        checks+=1
    cash=o['deployable_cash_floor'];deposit=o['deposits_uncertain_restriction'];ar=o['receivables'];inv=o['inventory'];ap=o['trade_payables'];adv=o['customer_advances'];oa=o['other_operating_assets'];oc=o['other_current_claims'];taxclaim=o['tax_claim'];ppe=o['ppe'];cwip=ZERO;wc=o['cash_credit'];term=o['term_debt'];debt=ZERO;cumdraw=ZERO;shares=inputs['issued_shares'];loan=o['related_party_loan'];cap=num(inputs['panel_bridge']['historical_capacity']);baseprice=num(inputs['panel_bridge']['annualized_price_per_equivalent']);baseunits=o['sales']/baseprice;n=path['years']*12
    facilities=[dict(a,balance=num(a['model_opening'])) for a in inputs['facilities']]
    rec=defaultdict(lambda:ZERO);pay=defaultdict(lambda:ZERO);projects=[];loans=[];replayed=[];exit_units=None;exit_price=None
    for month in range(1,int(s['opening_ar_months'])+1):rec[month]+=o['receivables']*num(s['opening_ar_recovery'])/num(s['opening_ar_months'])
    for month in range(1,int(s['opening_ap_months'])+1):pay[month]+=o['trade_payables']/num(s['opening_ap_months'])
    for raw in path['monthly']:
        r={k:num(v) if isinstance(v,str) and k not in ['date','phase'] else v for k,v in raw.items()};m=r['month'];year=(m-1)//12
        for key,value in [('cash',cash),('deposits',deposit),('ar',ar),('inventory',inv),('ap',ap),('advances',adv),('other_assets',oa),('other_claim',oc),('tax_claim',taxclaim),('ppe',ppe),('pipeline',cwip),('wc',wc),('term',term),('new_debt',debt),('shares',shares),('loan_claim',loan)]:equal(r[key+'_open'],value,'opening '+key)
        commissioned=sum((p[1] for p in projects if p[0]==m),ZERO);capadded=sum((p[2] for p in projects if p[0]==m),ZERO);projects=[p for p in projects if p[0]!=m];ppe+=commissioned;cwip-=commissioned;cap+=capadded
        if m<=n:quantity=baseunits*(ONE+num(s['unit_growth']))**(year+1)*(ONE-num(s['customer_loss']));price=baseprice*(ONE+num(s['price_growth']))**(year+1)
        else:quantity=exit_units*(ONE+num(s['terminal_growth']));price=exit_price
        units=min(quantity/12,cap/12);sales=units*price;lost=max(ZERO,quantity/12-units);forecastsales=quantity*price
        ipocapex=num(s['remaining_ipo_capex_assumption'])/num(s['ipo_spend_months']) if m<=int(s['ipo_spend_months']) else ZERO
        if ipocapex:cwip+=ipocapex;projects.append((m+int(s['capex_lead_months']),ipocapex,ZERO))
        expansion=ZERO;ordercap=ZERO;futurecap=cap+sum((p[2] for p in projects),ZERO)
        if s['expansion_gate'] and quantity*num(s['capacity_buffer'])>futurecap:
            ordercap=max(ZERO,min(quantity*num(s['capacity_buffer'])-futurecap,num(s['max_capacity'])-futurecap));expansion=ordercap*num(s['capex_per_vertical_capacity']);cwip+=expansion
            if expansion:projects.append((m+int(s['capex_lead_months']),expansion,ordercap))
        material=sales*num(s['material_ratio']);damage=inv*num(s['inventory_impairment']) if m==int(s['inventory_impairment_month']) else ZERO;inv-=damage;desired=forecastsales*num(s['material_ratio'])*num(s['inventory_days'])/365;purchases=max(ZERO,material+desired-inv);inv+=purchases-material;pay[m+int(s['supplier_delay'])]+=purchases;supplier=pay.pop(m,ZERO);ap+=purchases-supplier
        advrec=sales*num(s['customer_advance_share']);advapp=min(adv,sales*num(s['customer_advance_application']));adv+=advrec-advapp;credit=sales-advapp;rec[m+int(s['collection_delay'])]+=credit;collections=rec.pop(m,ZERO);writeoff=o['receivables']*(ONE-num(s['opening_ar_recovery'])) if m==int(s['opening_ar_months']) else ZERO;ar+=credit-collections-writeoff
        expenseratio=ONE-num(s['material_ratio'])-num(s['ebitda_margin']);opex=expenseratio*(num(s['fixed_opex_fraction'])*o['sales']/12+(ONE-num(s['fixed_opex_fraction']))*sales);maintenance=max(sales*num(s['maintenance_ratio']),ppe*num(s['replacement_rate'])/12 if m>n else ZERO);ppe+=maintenance;da=min(ppe,o['da']/12+max(ZERO,ppe-o['ppe'])*num(s['incremental_da_rate'])/12);ppe-=da;ebitda=sales-material-opex;ebit=ebitda-da-damage-writeoff
        facilityinterest=ZERO;termrep=ZERO
        for idx,facility in enumerate(facilities):
            balance=facility['balance'];cost=balance*num(facility['annual_rate'])/12;emi=None if facility['monthly_emi'] is None else num(facility['monthly_emi']);principal=min(balance,max(ZERO,emi-cost)) if emi is not None else ZERO
            if m>=int(facility['maturity_month']) or (s['maturity_policy']=='immediate_call' and m==1):principal=balance
            facility['balance']-=principal;facilityinterest+=cost;termrep+=principal
            for key,value in [('opening',balance),('interest',cost),('principal',principal),('closing',facility['balance'])]:equal(raw['facility_schedule'][idx][key],value,'facility '+str(idx)+' '+key)
        term=sum((a['balance'] for a in facilities),ZERO)
        interest=(wc*num(s['cash_credit_rate'])+debt*num(s['new_debt_rate']))/12+facilityinterest;wcrep=wc if m==int(s['cash_credit_call_month']) and not s['cash_credit_renewal_gate'] else ZERO;wc-=wcrep
        newrep=ZERO;renewalfee=ZERO;renewedprincipal=ZERO;keeploans=[]
        for due,amount in loans:
            if due==m:
                if m<=n and s['new_debt_renewal_gate']:renewedprincipal+=amount;renewalfee+=amount*num(s['renewal_fee']);keeploans.append((m+int(s['new_debt_tenor']),amount))
                else:newrep+=amount
            else:keeploans.append((due,amount))
        loans=keeploans;debt-=newrep;tax=max(ZERO,ebit-interest)*num(s['tax_rate']);taxsettle=taxclaim if m==int(s['tax_settlement_month']) else ZERO;taxclaim-=taxsettle;othersettle=min(oc,o['other_current_claims']/num(s['other_claim_months'])) if m<=int(s['other_claim_months']) else ZERO;oc-=othersettle;new_oa=o['other_operating_assets']+max(ZERO,forecastsales-o['sales'])*num(s['other_assets_growth_ratio']);oamove=new_oa-oa;oa=new_oa
        release=min(deposit,num(s['deposit_release_amount'])) if m==int(s['deposit_release_month']) and s['deposit_release_gate'] else ZERO;deposit-=release;iporelease=min(deposit,ipocapex) if s['ipo_restricted_release_gate'] else ZERO;deposit-=iporelease
        subadvance=num(s['additional_subsidiary_advance']) if m==int(s['subsidiary_advance_month']) else ZERO;loan+=subadvance;subpurchase=num(s['seedlab_purchase']) if m==int(s['seedlab_purchase_month']) else ZERO;loanrep=loan*num(s['loan_repayment_fraction']) if m==int(s['loan_repayment_month']) else ZERO;loan-=loanrep;guarantee=num(s['guarantee_call']) if m==int(s['guarantee_call_month']) else ZERO;fees=num(s['annual_facility_fees'])/12+renewalfee;capex=maintenance+expansion+ipocapex;reserve=max(num(s['minimum_cash']),num(s['reserve_cost_months'])*(material+opex))
        before=cash+collections+advrec+release+iporelease+loanrep-supplier-opex-interest-tax-taxsettle-othersettle-oamove-capex-termrep-wcrep-newrep-fees-subadvance-subpurchase-guarantee
        draw=ZERO;need=max(ZERO,reserve-before);rate=num(s['new_debt_rate'])/12;feerate=num(s['draw_fee']);taxrate=num(s['tax_rate'])
        if m<=n and s['new_debt_gate']:
            taxable=max(ZERO,ebit-interest);required=need/(ONE-feerate-rate*(ONE-taxrate))
            if required*rate>taxable:required=(need-taxable*taxrate)/(ONE-feerate-rate)
            draw=min(max(ZERO,required),max(ZERO,num(s['new_debt_limit'])-debt),max(ZERO,num(s['cumulative_debt_limit'])-cumdraw));debt+=draw;cumdraw+=draw
            if draw:loans.append((m+int(s['new_debt_tenor']),draw))
        drawinterest=draw*rate;drawfee=draw*feerate;oldtax=tax;interest+=drawinterest;tax=max(ZERO,ebit-interest)*taxrate
        options=int(s['esop_exercise_shares']) if m==int(s['esop_exercise_month']) else 0;optioncash=D(options)*num(inputs['claims']['esop_strike'])/10000000;shares+=options;cash=before+draw-drawfee-drawinterest+oldtax-tax+optioncash
        expected=dict(commissioned=commissioned,capacity_commissioned=capadded,capacity=cap,units=units,price=price,lost_units=lost,sales=sales,ordered_capacity=ordercap,material=material,purchases=purchases,supplier_cash=supplier,collections=collections,advance_receipts=advrec,advance_application=advapp,credit_sales=credit,receivable_writeoff=writeoff,inventory_impairment=damage,opex=opex,da=da,ebitda=ebitda,ebit=ebit,interest=interest,facility_interest=facilityinterest,current_draw_interest=drawinterest,tax=tax,tax_settlement=taxsettle,other_settlement=othersettle,other_assets_change=oamove,fees=fees,renewed_principal=renewedprincipal,renewal_fee=renewalfee,maintenance_capex=maintenance,growth_capex=expansion,ipo_capex=ipocapex,capex=capex,principal_term=termrep,principal_wc=wcrep,principal_new=newrep,new_draw=draw,draw_fee=drawfee,deposit_release=release,restricted_ipo_use=iporelease,subsidiary_advance=subadvance,subsidiary_purchase=subpurchase,loan_repayment=loanrep,guarantee_call=guarantee,esop_issued=options,esop_cash=optioncash,reserve=reserve,shortfall=max(ZERO,reserve-cash),cash_close=cash,deposits_close=deposit,ar_close=ar,inventory_close=inv,ap_close=ap,advances_close=adv,other_assets_close=oa,other_claim_close=oc,tax_claim_close=taxclaim,ppe_close=ppe,pipeline_close=cwip,wc_close=wc,term_close=term,new_debt_close=debt,debt_close=wc+term+debt,shares_close=shares,loan_claim_close=loan,operating_fcff=collections+advrec-supplier-opex-max(ZERO,ebit)*taxrate-capex-oamove)
        for key,value in expected.items():equal(r[key],value,f'month {m}: {key}')
        if m>n:assert draw==0 and options==0 and renewedprincipal==0;checks+=1
        replayed.append(expected)
        if m==n:exit_units=sum((x['units'] for x in replayed[-12:]),ZERO);exit_price=price
    terminal=path['terminal']
    assert path['summary']['common_equity_irr'] is None and path['summary']['total_company_price'] is None and path['source_eligible'] is False;checks+=3
    if terminal is not None:
        t={k:num(v) if isinstance(v,str) and not k.endswith('status') else v for k,v in terminal.items()};tr=replayed[n:];ex=replayed[n-1];taxrate=num(s['tax_rate']);g=num(s['terminal_growth']);w=num(s['wacc']);nopat=sum((max(ZERO,r['ebit'])*(ONE-taxrate) for r in tr),ZERO);dep=sum((r['da'] for r in tr),ZERO);maintenance=sum((r['maintenance_capex'] for r in tr),ZERO);replacement=max(maintenance,dep);physical=sum((r['growth_capex']+r['ipo_capex'] for r in tr),ZERO)
        def onwc(x):return x['ar_close']+x['inventory_close']+x['other_assets_close']-x['ap_close']-x['advances_close']
        wcneed=max(ZERO,onwc(tr[-1])-onwc(ex));economic=nopat*g/num(s['terminal_roic']);growth=max(physical+wcneed,economic);extra=replacement-maintenance+growth-physical-wcneed;fcff=nopat+dep-replacement-growth;fundingreserve=max(ZERO,max([ex['reserve']]+[r['reserve']-(r['cash_close']-ex['cash_close'])+extra*D(k+1)/12 for k,r in enumerate(tr)]));addback=ZERO;opreserve=[ex['reserve']]
        for k,r in enumerate(tr):
            shield=max(ZERO,r['ebit'])*taxrate-r['tax'];addback+=r['principal_term']+r['principal_wc']+r['principal_new']+r['interest']-shield+r['fees']+r['tax_settlement']+r['other_settlement']+r['subsidiary_advance']+r['subsidiary_purchase']+r['guarantee_call']-r['loan_repayment'];opreserve.append(r['reserve']-(r['cash_close']+addback-ex['cash_close'])+extra*D(k+1)/12)
        opreserve=max(ZERO,max(opreserve));cashbridge=max(ZERO,ex['cash_close']-opreserve);claim=ex['tax_claim_close']+ex['other_claim_close']+num(inputs['claims']['employee_benefits']);ev=max(ZERO,fcff/(w-g));core=max(ZERO,ev+cashbridge-ex['debt_close']-claim);per=core*10000000/D(ex['shares_close']);irr=(per*(ONE-num(s['exit_cost']))/(num(inputs['entry_price'])*(ONE+num(s['entry_cost']))))**(ONE/path['years'])-ONE if per>0 else D(-1)
        expected=dict(next_nopat=nopat,next_da=dep,replacement_capex=replacement,physical_growth_capex=physical,working_capital_reinvestment=wcneed,economic_reinvestment_floor=economic,growth_reinvestment=growth,extra_terminal_cash_need=extra,fcff=fcff,funding_reserve=fundingreserve,operating_reserve=opreserve,cash_bridge=cashbridge,core_enterprise_value=ev,core_equity_contribution=core,core_per_share_contribution=per,core_only_illustrative_irr=irr)
        for k,v in expected.items():equal(t[k],v,'terminal '+k)
        assert ex['cash_close']+D('1e-20')>=fundingreserve and sum((r['lost_units'] for r in tr),ZERO)<=D('1e-20');checks+=1
    else:assert path['failure'] is not None and path['summary']['core_only_illustrative_irr'] is None;checks+=1
    return dict(path_id=path['path_id'],status='PASS',scalar_checks=checks,max_absolute_decimal_error=maxerr)

def main():
    archive=P/'canonical_paths.json.gz';raw=archive.read_bytes();data=json.loads(gzip.decompress(raw));results=[]
    with localcontext() as c:
        c.prec=40
        for path in data['paths']:results.append(replay(path,data['inputs']))
    binding=data['inputs']['source_binding'];vintage=P/binding['vintage'];assert hashlib.sha256(vintage.read_bytes()).hexdigest()==binding['sha256']
    result=dict(status='PASS',scope='Independent calculation replay, not source verification or approval of forecast assumptions.',canonical_sha256=hashlib.sha256(raw).hexdigest(),paths=len(results),scalar_checks=sum(x['scalar_checks'] for x in results),source_eligible_paths=0,ordinary_equity_irr_status='NS in every path',snapshot_hash_valid=True,current_finance_same_as_snapshot=hashlib.sha256((P/binding['file']).read_bytes()).hexdigest()==binding['sha256'],results=results)
    (P/'independent_replay_results.json').write_text(json.dumps(norm(result),indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k!='results'},indent=2))
if __name__=='__main__':main()
