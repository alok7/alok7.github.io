"""Source-safe model runtime inventory, duplicate map and vintage reconstruction manifest."""
from pathlib import Path
import json,hashlib
P=Path(__file__).resolve().parent

def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
    authored=['build_model_inputs.py','model.py','scenarios.py','run_model.py','model_audit.py','independent_replay.py','summarize_model.py','model_mutation_tests.py','rebuild_model_vintage.py','build_model_registry.py']
    inputs=['financial_research/financial_inputs.json','market_inputs.json']
    generated=['model_inputs.json','scenario_inputs.json','canonical_paths.json.gz','model_summary.json','model_audit.json','trial_index.csv','annual_paths.csv','independent_replay_results.json','model_tables.json','model_mutation_results.json']
    documentation=['model_methodology.md','model_provenance_revision.json'];historical_inputs=[str(x.relative_to(P)) for x in sorted((P/'model_input_vintages').glob('*.json'))];historical_summaries=['first_trial_summary.json'];duplicates=[];omittable=[];full_vintages=[]
    canonical=digest(P/'canonical_paths.json.gz');coldfiles=['model_inputs.json','scenario_inputs.json','model.py','scenarios.py','run_model.py','model_audit.py','build_model_inputs.py']
    for folder in sorted((P/'model_vintages').iterdir()):
        if not folder.is_dir():continue
        files=[p for p in sorted(folder.iterdir()) if p.is_file()];full_vintages.extend(str(p.relative_to(P)) for p in files)
        for file in files:
            root=P/file.name
            if root.exists() and digest(root)==digest(file):duplicates.append(dict(duplicate=str(file.relative_to(P)),canonical=file.name,sha256=digest(root),bytes=file.stat().st_size))
        old=folder/'canonical_paths.json.gz';proof=folder/'cold_rebuild_proof.json';content=json.loads(proof.read_text()) if proof.exists() and proof.stat().st_size else None;old_digest=digest(old) if old.exists() else (content['expected_sha256'] if content else None)
        if old_digest is None or old_digest==canonical:continue
        for filename in coldfiles:historical_inputs.append(str((folder/filename).relative_to(P)))
        for filename in ['model_summary.json','model_audit.json','cold_rebuild_proof.json']:
            if(folder/filename).exists():historical_summaries.append(str((folder/filename).relative_to(P)))
        verified=content is not None and content['exact_match'] is True and content['expected_sha256']==old_digest
        omittable.append(dict(path=str(old.relative_to(P)),sha256=old_digest,bytes=old.stat().st_size if old.exists() else content['compressed_bytes'],can_omit_from_compact_only=verified,proof=str(proof.relative_to(P)),rebuild_command=f"python rebuild_model_vintage.py model_vintages/{folder.name} --write model_vintages/{folder.name}/canonical_paths.json.gz"))
    source_safe=list(dict.fromkeys(authored+inputs+generated+documentation+historical_inputs+historical_summaries+['model_runtime_files.json']))
    metadata=[dict(path=name,bytes=(P/name).stat().st_size,sha256=digest(P/name)) for name in source_safe if name!='model_runtime_files.json' and (P/name).exists()]
    result=dict(status='FINAL' if all(x['can_omit_from_compact_only'] for x in omittable) else 'READY_CURRENT_RUNTIME_VINTAGE_PROOFS_PENDING',canonical_sha256=canonical,authored_runtime=authored,source_data_inputs=inputs,generated_outputs=generated,documentation=documentation,historical_vintage_inputs=historical_inputs,historical_summaries_and_proofs=historical_summaries,source_safe_runtime_files=source_safe,runtime_files=source_safe,reproduction_commands=['python run_model.py','python independent_replay.py','python summarize_model.py','python model_mutation_tests.py','python build_model_registry.py'],byte_identical_duplicate_map=duplicates,cold_rebuild_optional_omissions=omittable,full_vintage_files_preserved_on_disk=full_vintages,source_safe_file_metadata=metadata,source_safe_total_bytes_excluding_registry=sum(x['bytes'] for x in metadata),on_disk_current_canonical_bytes=(P/'canonical_paths.json.gz').stat().st_size,on_disk_vintages_total_bytes=sum((P/f).stat().st_size for f in full_vintages),rules=['No original PDFs, original-source extracts, download helpers, browser scratch files, or acquisition helpers are required for model runtime.','Ordinary shareholder IRR and whole-company price remain NS. Source-eligible path count is zero.','Do not delete original on-disk vintages. Compact packaging may omit byte-identical duplicates and verified cold-rebuild gzip copies only.','Frozen prior input JSON and code plus exact checksum proofs are mandatory if an old canonical gzip is omitted.'])
    (P/'model_runtime_files.json').write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n');print(result['status'],len(source_safe),'files,',result['source_safe_total_bytes_excluding_registry'],'bytes before outer compression')
if __name__=='__main__':main()
