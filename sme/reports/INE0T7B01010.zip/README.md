# Shivalic Power Control research 367

This research applies Master Prompt v3.0 to Shivalic Power Control Limited, ISIN INE0T7B01010, NSE Emerge SPCL. Information cutoff is 20 October 2026; the valuation reference is the NSE close on 19 October 2026. Later disclosures and prices are excluded from the historical assessment.

The report, source ledger, financial calculations, complete monthly scenarios and failed paths are authored research. Original third-party annual reports and exchange files are not included in the source-safe package. The source links and exact dates preserve auditability. Numerical reproducibility is not evidence that an uncertain forecast is investable.

No order or trade has been placed. A ₹5 lakh reference position is an analytical liquidity test, not a recommended allocation. A research hold does not prove fraud or default.

Run python build.py in an extracted copy to regenerate the authored output files. Run python guarded_rebuild.py to copy only declared inputs into a new temporary directory and verify exact output hashes. These offline commands do not fetch new data, publish files, or delete source files. Current security-master extraction is a separately retained acquisition aid and is not needed for the offline build.

Current research includes 170 retained paths and 10,991 monthly rows. All ordinary whole-company prices and shareholder IRRs are NS; funded core contributions are explicitly conditional and are not complete equity valuations.

For compact provenance, the package retains distinct prior model code, frozen inputs, first-trial summaries and exact cold-rebuild checksum proofs. Byte-identical copies and regenerable older canonical gzip files are omitted from the archive, not deleted from research storage. Recreate a prior gzip offline with python rebuild_model_vintage.py model_vintages/<vintage_id> --write <output.gz>. model_runtime_files.json records every retained file and omitted duplicate. The current full canonical gzip is included. The compact and full archives contain the same complete authored research and runtime file set with different compression levels; neither includes third-party originals.
