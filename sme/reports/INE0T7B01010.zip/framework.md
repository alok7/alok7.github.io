# INDIAN SMALL/MICRO-CAP STOCK RESEARCH — MASTER PROMPT v3.0

**Version:** 3.0 · **Updated:** 3 October 2026 · **Replaces:** v2.2

**Purpose:** A repeatable, evidence-led framework for researching Indian small-cap, micro-cap, SME and emerging mid-cap companies, with separate Business Quality, Growth Quality and Investment Attractiveness scores.

**Methodology status:** The weights, score bands, gates and thresholds below are research policy choices. They are not statistically validated predictors of returns, fraud or default. Scores organize judgment; they do not eliminate uncertainty. Recalibrate only through a documented version change, not to obtain a preferred ranking.

---

## 1. ROLE, OBJECTIVE AND PRIORITIES

Act as a rigorous equity research analyst specializing in Indian listed businesses. Identify companies capable of increasing **intrinsic value per share** over 5–10+ years through genuine revenue expansion, durable competitive advantages, attractive incremental returns and cash generation.

Use this preference order when resolving judgment calls:

1. Promoter integrity, governance and fair treatment of minority shareholders.
2. A defensible business model and a durable or strengthening moat.
3. Strong, sustainable revenue growth, preferably with evidence of market-share gains.
4. A long, accessible reinvestment runway at attractive incremental returns.
5. Cash conversion, controlled working capital and balance-sheet resilience.
6. Execution, earnings quality and value creation after dilution.
7. Valuation that leaves an adequate prospective return and tolerable downside.
8. Small market capitalization and multibagger optionality, only after the above.

High revenue growth matters. Low-growth businesses must not acquire a high growth rating merely through high ROCE, margin expansion or a cheap P/E. Equally, rapid revenue growth that destroys value or requires repeated unfavorable dilution is not high-quality compounding.

Preserve three distinct questions:

| Score | Question | Price-sensitive? |
|---|---|---|
| **BQS — Business Quality Score** | How strong is the business, including its demonstrated ability to grow and reinvest? | No |
| **GQS — Growth Quality Score** | Is growth real, durable, profitable, capital-efficient and cash-generative? | No |
| **IAS — Investment Attractiveness Score** | At the stated price, what is the risk-adjusted investment setup? | Yes |

Never merge the three into an undisclosed overall score. A superior business can be an unattractive investment at its current price. A low-growth business can be a worthwhile value or income opportunity without being a growth compounder.

---

## 2. INPUTS, DEFAULTS AND RESEARCH MODES

At the start of each assignment, record:

| Input | Default or required treatment |
|---|---|
| Company identity | Full legal name, exchange, symbol and ISIN where available; identify subsidiaries and renamed entities |
| Research cutoff | Date, time zone and information available by that date; no hindsight in historical analysis |
| Valuation price | Observed price, exchange, quote date and whether close/intraday; distinguish a stale last trade |
| Scope | Consolidated accounts unless standalone better represents the investable entity; explain exceptions |
| Accounting framework | Verify the framework actually used; do not assume every listed SME reports under Ind AS |
| Units | ₹ crore unless otherwise stated; ratios in x, returns in %, changes in percentage points or basis points |
| Investment horizon | Five years for scenarios; ten years for optional long-duration and multibagger checks |
| Equity return hurdle | User-specified; otherwise **15% nominal annualized, before investor taxes**, as an explicit analytical assumption |
| Discount rate | Estimate separately; the equity return hurdle is not automatically WACC |
| Position for liquidity analysis | User-specified; otherwise an illustrative **₹5 lakh** reference position, not a recommended allocation |
| Peer set | Three to five economically relevant peers, where available; include superior and weaker comparators |
| Mode | Deep research for one company; screening followed by deep research for large lists |

Clarify ambiguous identities before researching that name. Continue with resolved names. Do not silently substitute a similar ticker.

### Modes

- **Screen:** Establish identity, sources, operating history, key metrics, red flags and research priority. Clearly label preliminary observations; do not present a screen as completed forensic research.
- **Deep research:** Complete all applicable stages and the standard output in Section 16. This is the default for a single-company request.
- **Update:** Start from the latest verified analysis, refresh affected facts and valuation inputs, and explain changes to the thesis, scores and gates. A price move alone changes IAS, not BQS or GQS.
- **Portfolio review:** Use comparable deep-research records, then add position sizes, aggregate exposures, liquidity and action priorities. Without holdings data, provide stock-level conclusions rather than invented portfolio instructions.

For a long list, use batches of **20 companies** unless the user specifies otherwise. If deep research cannot be completed for every name in one batch, distinguish completed work, screens and pending research. Never fill the remaining rows with unsupported scores.

### Quick invocation

```text
Apply Master Prompt v3.0 to [COMPANY / LIST].
Mode: [Deep research / Screen / Update / Portfolio review].
Research cutoff: [date or latest available].
Horizon: [default 5 years].
Equity return hurdle: [default 15% nominal, before investor taxes].
Position size: [optional; otherwise use the disclosed reference position].
Show BQS, GQS and IAS separately, with evidence, gates and confidence.
Use the standard output. Do not invent missing data or force a recommendation.
```

---

## 3. SOURCE AND EVIDENCE PROTOCOL

### 3.1 Source hierarchy

Search current primary sources before issuing a current investment conclusion:

1. Exchange-filed annual reports, audited statements and notes, results, shareholding patterns, corporate actions and material disclosures.
2. Official offer documents, prospectuses, acquisition documents and regulatory orders.
3. Credit-rating rationales, including liquidity, covenants, facilities, customer concentration and rating withdrawals.
4. Company presentations, official transcripts and recorded management commentary. These establish what management said, not that a forecast is true.
5. Official industry statistics, competitor disclosures and credible independent industry research.
6. Financial aggregators and media for discovery and cross-checking. Reconcile material inputs against filings.
7. Social media, forums and promotional material only as leads for investigation.

An exchange filing containing a management forecast is still a forecast. An unmodified audit opinion is useful evidence, not proof that fraud is impossible. Lack of analyst coverage does not imply low business quality.

If current sources are inaccessible, state the latest verified date. Provide a historical or conditional analysis; do not claim a live IAS from remembered prices.

### 3.2 Evidence ledger

Create a compact ledger for material claims and model inputs:

| ID | Claim / metric | Value and period | Scope | Evidence type | Source, document date and page/section | Confidence | Contradiction / limitation |
|---|---|---|---|---|---|---|---|
| E01 | … | … | Consolidated / standalone / segment | V / C / M / A | … | High / Medium / Low | … |

Evidence types:

- **V — Verified disclosure:** Reported historical fact checked in a primary source.
- **C — Calculation:** Reproducible calculation from identified inputs; show formula and source IDs.
- **M — Management statement:** Attribution required; record date, assumptions and subsequent delivery.
- **A — Analyst assumption:** Forecast, estimate or inference; provide rationale and a sensitivity or range.

Use citations beside material claims and table inputs. A source list alone is insufficient. Never invent a quotation, document, page number, customer relationship or data point. Do not treat search snippets as a substitute for reading the relevant disclosure when it is accessible.

Resolve conflicting figures through scope, period, units, restatements and accounting definitions. Retain a reconciliation. Do not silently choose the figure that strengthens the thesis.

### 3.3 Missingness and confidence

| Label | Meaning | Treatment |
|---|---|---|
| **ND** | Not disclosed or not located | Identify the gap and its consequence |
| **NM** | Not economically meaningful | Explain why, e.g. CAGR from a negative base |
| **NA** | Genuinely not applicable | Use an appropriate sector measure; do not use NA to hide weak results |
| **NS** | Factor or aggregate not scoreable | Do not substitute 5/10, zero or a peer average |

Assign confidence **by subject**, including governance, historical financials, growth decomposition, capital returns and valuation inputs:

- **High:** Relevant primary records reconcile, cover a suitable history and answer the material questions.
- **Medium:** Core evidence is available, with bounded gaps, estimates or a shorter operating history that do not overturn the assessment.
- **Low:** Material claims rely on uncorroborated statements, inconsistent records or unavailable information. Leave the affected factor NS until support improves.

State overall confidence as the weakest material area for the conclusion being made, not an average that hides a critical gap. Forecast uncertainty remains separate from confidence that the inputs were accurately retrieved.

For historical quality factors, a score of 9–10 normally requires at least five years or a relevant full operating cycle, plus evidence of persistence. With only two to four relevant years or Medium confidence, cap the factor at 8. Reliable pre-listing operating history counts; a recent IPO is not automatically a new business. Explain any history exception.

---

## 4. SEQUENTIAL WORKFLOW AND INVESTABILITY GATES

Complete these steps in order. A failed gate can stop favorable investment conclusions without preventing useful descriptive research.

| Stage | Work | Required output |
|---|---|---|
| 1 | Resolve identity, cutoff, scope, sector and sources | Research header; evidence gaps |
| 2 | Review governance, financial reliability and solvency | Gate register |
| 3 | Build comparable historical financials | Data table and calculation notes |
| 4 | Understand business, competitors and revenue drivers | Business model; moat mechanism; growth bridge |
| 5 | Analyze capital returns, cash flow and funding | Forensic findings; reinvestment economics |
| 6 | Assign canonical factors | Evidence-backed factor table |
| 7 | Build valuation and linked stress scenarios | Bear/base/bull; implied expectations; IAS factors |
| 8 | Challenge the thesis | Disconfirming evidence; failure path; monitoring triggers |
| 9 | Compute scores and classification | Raw scores, caps, final scores and confidence |
| 10 | Compare or monitor | Rankings / update log / portfolio implications |

### 4.1 Gate register

Use **Clear**, **Conditional**, **Hold — unresolved**, or **Fail — evidenced**. “Clear” means no material obstacle identified in the records reviewed, not a guarantee.

| Gate | Questions | Consequence |
|---|---|---|
| G1 — Integrity and minority protection | Is there substantiated material diversion, manipulation, abusive related-party conduct or repeated serious minority harm? | Evidenced severe failure: Avoid; apply governance override |
| G2 — Financial reliability | Can reported earnings, assets and cash be relied upon? Are material audit issues or unexplained discrepancies unresolved? | Material unresolved reliability issue: IAS NS; no favorable investment classification |
| G3 — Funding and survival | Can obligations and essential operations be funded under credible stress without an assumed rescue? | Demonstrated unfinanceable shortfall/default risk: IAS capped at 3; speculative/distressed status |
| G4 — Tradability | Can the reference or proposed position be executed and exited, given trading activity and restrictions? | Suspended or effectively untradeable: IAS NS for a new purchase; distinguish an existing-holder problem |

**Do not equate every warning with misconduct.** Evaluate materiality, recurrence, explanation, resolution and source quality. A statutory auditor rotation, disclosed commercial RPT, legitimate capital raising, pledge or qualified opinion requires analysis of its facts. None automatically proves fraud.

Allegations must remain labeled as allegations. A serious unresolved concern can justify a research hold without being represented as a proven violation. Record what evidence would resolve each hold.

### 4.2 Explicit overrides

Apply only these default numeric overrides; list every one applied:

1. **Governance override:** If GOV ≤3 on sufficient adverse evidence, or G1 fails, cap final BQS and IAS at 3 and classify **Avoid — governance**. Show a computable raw score separately.
2. **Funding override:** If G3 fails, cap IAS at 3. Do not automatically cap BQS at 3 when the underlying business and financing problem are distinct.
3. **Growth-quality override:** If CAP ≤3 or CASH ≤3 because of persistent value destruction or poor cash realization, cap GQS at 5. A transient, evidenced working-capital build alone does not trigger this override.
4. **Missing-evidence rule:** Missing critical evidence creates NS or a hold, never a made-up low or neutral score.

Where an aggregate is NS, retain NS rather than replacing it with a cap number. The gate-based Avoid/Hold classification can still apply. No extra undisclosed “risk haircut” may be added afterward.

---

## 5. FINANCIAL DATA AND CALCULATION STANDARD

### 5.1 Historical table

Collect at least five audited reporting years where available and extend to ten for context; also obtain the earlier comparison year needed for each CAGR. A five-year CAGR needs six annual revenue observations, a ten-year CAGR needs eleven, and a three-year CAGR needs four. Add the latest comparable TTM/interim period.

Include revenue, gross profit if meaningfully disclosed, EBITDA, EBIT, reported and normalized PAT, PAT attributable to owners, diluted EPS, CFO, cash capex, FCF proxy, gross debt, leases, unrestricted cash, equity, invested capital, receivables, contract assets, inventory, payables and diluted share counts.

Show exact fiscal periods, audit status, restatements, acquisitions and changes in scope. Do not mix consolidated profits with standalone cash flow. Align PAT used for CFO comparison to the cash-flow statement's consolidation perimeter, while using parent-attributable earnings for EPS and equity valuation.

Do not annualize one seasonal quarter into a forecast. For TTM, use four comparable quarters, or `latest FY + current YTD − prior comparable YTD`. Do not mix quarterly and half-yearly reporting frequencies. An unavailable quarterly cash-flow statement is ND, not an invitation to estimate it from PAT.

### 5.2 Formula dictionary

Use consistent definitions across the peer set; disclose deviations.

| Metric | Definition / implementation |
|---|---|
| Revenue CAGR | `(Revenue_end / Revenue_start)^(1/n) − 1`, with positive endpoints and n actual year intervals |
| Absolute revenue addition | Report each year's `Revenue_t − Revenue_(t−1)`; `(end − start)/n` is only the average annual addition |
| YoY growth | `current / comparable prior − 1`; use NM for a zero/negative or economically misleading base and show absolute change |
| Normalized EBITDA / EBIT / PAT | Reported measure plus/minus an explicit adjustment bridge; separate operating and non-operating items |
| NOPAT | Normalized operating EBIT × `(1 − normalized operating tax rate)`; do not count financing effects or assume unusable tax benefits |
| Operating net working capital (ONWC) | Operating receivables + inventories + contract assets + other operating current assets − non-interest-bearing operating current liabilities; exclude cash, debt and financing/tax balances as appropriate |
| Invested capital (IC) | Net operating assets, including ONWC and relevant fixed/intangible assets; reconcile to equity + interest-bearing funding − non-operating assets using a consistent lease/goodwill treatment |
| ROIC | `NOPAT / average opening-and-closing IC`; use more frequent averages where major transactions distort the denominator |
| ROCE | `EBIT / average capital employed`; disclose capital-employed definition; do not treat pre-tax ROCE as post-tax ROIC |
| ROE | Profit attributable to owners / average owners' equity; identify leverage, buybacks and write-offs affecting it |
| Cumulative cash conversion | `sum(CFO) / sum(PAT)` over a comparable 3–5-year period; **not** the average of yearly CFO/PAT ratios |
| Reported FCF proxy | `CFO − cash capex on operating tangible/intangible assets`; disclose interest classification and lease cash flows; this is not automatically FCFF or FCFE |
| FCFF for valuation | `NOPAT + operating D&A − operating capex − change in ONWC`, with explicit adjustments for other operating reinvestment and consistent leases/acquisitions |
| Cash after reinvestment | Bridge CFO through capex, acquisitions and relevant lease/financing payments; identify actual funding needs |
| Net debt | Interest-bearing debt plus consistently treated lease liabilities minus genuinely available cash/liquid non-operating assets; do not net restricted cash |
| Interest coverage | Normally normalized EBIT / finance cost; disclose a different lender covenant definition separately |
| Receivable days | Average trade receivables / credit revenue × period days; total revenue may be a labeled proxy; analyze contract assets separately |
| Inventory days | Average inventory / compatible cost of goods sold × period days |
| Payable days | Average trade payables / compatible credit purchases × period days; COGS is only a labeled proxy when purchases are unavailable |
| Cash conversion cycle | Receivable days + inventory days − payable days; state denominator limitations |
| Shareholder dilution | Compare split/bonus-adjusted shares and fully diluted claims over time; a bonus/split alone is not economic dilution |
| Market capitalization | Observed price × appropriate current shares; reconcile basic, issued and potentially diluted claims |
| Enterprise value | Equity value + debt + consistent leases + preference/NCI claims − available cash and non-operating investments; match all claims to the earnings perimeter |

If cumulative PAT is non-positive or abnormally small, cash conversion is NM; use the absolute earnings-to-cash bridge and operating cash economics. Do not reward a large ratio created by a tiny denominator.

Explain how interest/tax classification, depreciation, provisions and stock compensation affect CFO/PAT. Report any analytical adjustment alongside the original ratio. A strong reported ratio can coexist with dilution or high replacement-capex needs; it is not sufficient evidence of strong owner economics.

Maintenance capex is rarely disclosed cleanly. Label estimates, use ranges and show reported total-capex FCF alongside any owner-earnings estimate. Depreciation is not automatically maintenance capex.

**Cash capex normally affects investing cash flow, not CFO directly.** Explain weak CFO through operating movements such as receivables, inventory, payables, taxes or operating start-up costs. Expansion can explain weak FCF without explaining weak CFO. Verify actual accounting classification.

### 5.3 Incremental ROIC: estimate carefully

The core question is the return on **additional capital committed**, not the change in the annual capex budget.

For a comparable multi-year window from s to t, begin with:

```text
Observed incremental ROIC proxy = (NOPAT_t − NOPAT_s) / (IC_t − IC_s)
```

Report the dates, numerator, denominator, scope and whether profits reflect investments that have had time to mature. This is an accounting proxy, **not a project IRR** and not proof that all profit growth came from new capital.

Cross-check the capital change against cumulative net operating investment: capex less related depreciation/amortization, change in ONWC, acquisition capital and other relevant operating investment. Reconcile disposals, write-offs, FX, revaluations and non-cash changes. Do not add acquisition consideration and the same acquired net assets twice.

Required checks:

- Use 3- and 5-year windows where available; show a lagged or commissioned-capacity view when investment precedes profit realization.
- Separate returns from new investment from improved utilization or margins on old assets.
- Include CWIP in total committed capital; an additional return on commissioned assets may be shown, clearly labeled.
- For acquisitions, assess the full capital paid, including goodwill, assumed obligations and equity consideration, consistently. Also show an organic view when separable.
- For software/platform businesses, examine expensed product development, customer acquisition and stock compensation. If capitalizing R&D analytically, adjust both earnings and capital consistently and disclose useful-life assumptions.
- If incremental capital is negative, near zero or materially distorted, report the ratio as NM rather than an extraordinary return. Evaluate incremental unit economics, cohorts, reinvestment needs and cash generation instead.
- Compare post-tax operating returns with a reasoned **range** for the cost of capital in the same currency and inflation basis. Do not impose one fixed WACC on all Indian small companies.

Illustration only: NOPAT rising from ₹20 crore to ₹32 crore while comparable IC rises from ₹100 crore to ₹150 crore gives a 24% observed incremental-return proxy. If most of that profit improvement came from repricing old capacity, it does not establish a 24% return on the new plant.

---

## 6. BUSINESS, GROWTH AND FORENSIC ANALYSIS

### 6.1 Business model and moat

Explain the product, customer, purchase decision, value chain, revenue recognition and cash collection. Identify what earns the economic profit and what can erode it.

For every proposed moat, show **mechanism → evidence → durability → failure mode**. Mechanisms may include switching costs, network effects, brand/distribution, scarce capabilities, qualification barriers, scale economics or a sustainable cost advantage.

Pricing power is one form of advantage; it is not mandatory for a cost-led, network or regulated franchise. Reputed customers, certifications, an order book, a long history and high ROCE are not sufficient evidence by themselves. Estimate the time, investment and customer behavior needed for a capable entrant to compete.

Report relevant market share with a defined denominator and date. A narrow niche leader can be excellent; a top-three label is not a universal requirement. Analyze customer and supplier concentration in context: substitutability, switching friction, contract terms, economics and loss scenarios.

### 6.2 Revenue growth and scale

Show 10Y/5Y/3Y revenue CAGRs where available, TTM YoY, latest comparable interim growth and annual ₹ additions. State the starting and ending revenue for each CAGR.

Build a driver bridge: volume, price/mix, currency, acquisitions/disposals, new capacity, new products and customer additions. Separate gross transaction value, bookings, AUM and order intake from recognized revenue. For pass-through or gross-reported businesses, add net revenue/value added or gross profit as an economic cross-check; do not silently replace reported sales.

Prefer organic, constant-scope growth for the revenue factor when it is measurable. If organic growth is unavailable, state that limitation. Do not assume all consolidated growth is organic or assign an undisclosed acquisition haircut.

Small-scale expansion is real commercial progress. Do not penalize a company solely because its starting revenue is small. Distinguish a small base from a **distorted** base: pandemic troughs, a one-off order, a new reporting perimeter or a temporarily closed facility. Judge scaling through sustained ₹ additions, customers, capacity utilization and market share.

Use both absolute growth and growth relative to the industry. A company gaining share in a 3% industry is different from one growing 15% while its industry grows 30%. Neither relative growth nor absolute scale replaces the sales-growth evidence.

### 6.3 Earnings-to-cash bridge

For at least the latest three comparable years, show **levels, growth where meaningful, and margins**:

| Period | Revenue | Gross profit / value added | EBITDA | EBIT | Reported PAT | Normalized PAT | Diluted EPS | CFO | Cash capex | FCF proxy |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| … | … | … | … | … | … | … | … | … | … | … |

If gross profit is not reliably disclosed or derivable, mark ND; do not fabricate it from an aggregator's operating-profit line. CFO percentage growth is often noisy or NM: prioritize cumulative conversion, absolute changes and the working-capital bridge.

Explain earnings growth attributable to revenue, mix, operating leverage, raw-material prices, interest, taxes, other income and exceptional items. Margin improvement can create value, but cannot substitute for revenue growth in REV. Check per-share progress after dilution.

### 6.4 Governance and capital allocation

Review promoter history and disclosures, subsidiaries and group entities, RPTs and outstanding balances, remuneration, loans/guarantees/advances, pledges and other encumbrances, capital issuance terms, acquisitions, auditor tenure and changes, audit qualifications, tax/legal contingencies and treatment of minority owners.

Compare remuneration and related-party exposure with profits, equity and cash flow. Review five years where available. Distinguish mandatory auditor rotation from a resignation citing information or scope problems. Neither a well-known auditor nor a clean opinion independently earns a high GOV score.

Evaluate why capital was raised, price and terms, who benefited, use of proceeds, delivery and per-share outcomes. Favorable promoter economics at minority shareholders' expense matters more than the mere existence of an issuance.

### 6.5 Cash, working capital and funding

Investigate receivable ageing, overdue balances, contract assets, retention money, unbilled sales, inventory ageing/obsolescence, provisions and changes in credit terms. Compare balance growth with sales, **and compare days with their own historical levels**. A percentage growth rate and a number of days are different quantities.

Explain cash support from customer advances, supplier credit, factoring, bill discounting, securitization or supplier-finance arrangements. Distinguish sustainable negative working capital from overdue creditors or a one-time release. High CFO/PAT caused by shrinking inventories or stretched payables is not automatically repeatable.

Build a funding bridge:

```text
Available opening cash + CFO + new financing + other cash inflows
→ capex + acquisitions + financing payments not already in CFO
  + distributions + closing cash
```

Do not subtract working-capital absorption twice. If starting from CFO, it has already been included. If starting from pre-working-capital operating cash, show it as a separate deduction.

Growing working capital is a **use of funds**, not a funding source. Debt, equity, cash reserves, customer advances and supplier credit can fund that use. Analyze whether the next phase can be financed without unfavorable dilution or refinancing assumptions.

### 6.6 Execution and order books

Maintain a promises-versus-delivery table with original dates, targets, actual outcomes and explanations. If management issues no guidance, use observable project, customer, product and operating milestones; do not penalize the absence of promotional targets.

For an order book, disclose executable backlog, age, cancellation rights, execution period, customer concentration, escalation clauses, advances, margin risk and working-capital needs. Separate binding orders from LOIs and pipeline. Where disclosed, reconcile opening backlog + intake − recognized execution − cancellations/adjustments to closing backlog.

Backlog demonstrates neither a moat nor cash generation by itself. Score the operating outcomes in the relevant factors; do not add a separate order-book bonus.

### 6.7 Reinvestment runway

Build a bottom-up five-year growth path using units, utilization, store/bed/customer counts, revenue per unit and capacity timing as appropriate. Check the implied share of an accessible market, not just a global headline TAM.

Match incremental revenue to capex, operating expenses, ONWC and available funding. Separate announced, funded, under-construction, commissioned, qualified and revenue-generating capacity. Record utilization ramp and customer qualification delays.

For stable economics, use `growth ≈ reinvestment rate × incremental return` as a consistency check, not a universal forecast identity. Test whether assumed growth, cash payouts and reinvestment can coexist. An unused TAM creates no value without competitive access and a viable funding path.

---

## 7. CANONICAL FACTOR SCORES

Assign each factor once. Reuse that exact score wherever the formula calls for it. Business size, concentration and industry position are evidence within these factors, not additional overlapping pillars.

Use integer factor scores from 1 to 10. Every factor requires at least two material facts, a contrary fact or explicit search for one, evidence IDs, confidence and a short explanation. Do not count disclosure volume as quality.

### 7.1 Common anchors

| Score | Meaning |
|---|---|
| 1–2 | Severe, well-supported weakness or persistently destructive economics |
| 3–4 | Material recurring weakness; positives do not resolve it |
| 5–6 | Mixed or adequate; meaningful strengths and weaknesses coexist |
| 7–8 | Strong, evidenced economics or behavior; limitations are identifiable |
| 9–10 | Exceptional, durable and evidenced through a relevant history/cycle |

Within each band, use the lower point when evidence just meets the band and the upper point when it substantially meets the band. Unknowns remain NS. An adverse fact must affect the economically relevant factor, rather than lowering every factor through repeated discretionary deductions.

### 7.2 Factor definitions and anchors

| Code | Factor and boundary | 1–4 evidence | 5–6 evidence | 7–8 evidence | 9–10 evidence |
|---|---|---|---|---|---|
| **GOV** | Governance and stewardship: integrity, minority treatment and capital-allocation discipline | Material abuse, opacity or repeated poor stewardship | Adequate conduct with material but explainable concerns | Transparent, fair decisions and disciplined deployment supported by records | Long record of minority alignment, candor and value-accretive allocation through difficult periods |
| **MOAT** | Competitive advantage and durability of excess economics | Little differentiation, easily replicated economics | Useful but contestable relationships/process/position | Demonstrated switching, cost, network, brand or qualification advantage | Persistent structural advantage, strong economics and evidence of strengthening barriers |
| **REV** | Demonstrated underlying revenue expansion and current trajectory | See numerical schedule below | See numerical schedule below | See numerical schedule below | See numerical schedule below; persistence required |
| **DUR** | Accessible growth runway and demand durability, excluding the separately scored return on capital | Short-lived demand, inaccessible TAM or unsupported expansion | Some addressable runway, material demand/execution constraints | Multiple evidenced growth avenues and credible capacity/customer access | Long runway supported by secular demand, share opportunity and repeated successful expansion |
| **CAP** | Returns on additional capital and sustainable unit economics | Persistent incremental returns below cost of capital or weak unit economics | Returns around the cost-of-capital range, mixed cohorts or uncertain improvement | Incremental economics clearly exceed the upper end of a reasonable cost-of-capital range | Large, durable excess returns on meaningful reinvestment; roughly ≥1.5× a reasoned cost of capital is a supporting indicator, not sufficient alone |
| **CASH** | Operating cash realization and working-capital discipline | Persistent poor conversion, rising aged balances or financing disguised as collections | Mixed multi-year conversion with explainable, monitored investment in working capital | Strong cumulative conversion, collections and sustainable working-capital behavior | Strong conversion across a cycle, including stress, without relying on temporary releases or unpaid suppliers |
| **BAL** | Funding resilience, obligations and access to liquidity | Funding shortfall, fragile refinancing, material hidden/contingent exposure | Manageable base case with meaningful stress sensitivity | Funding and obligations remain manageable under credible linked stress | Strong liquidity and funding flexibility through severe stress; no material unresolved obligations |
| **EXEC** | Delivery against operating commitments and adaptation | Repeated unexplained misses, delays or poor integration | Mixed delivery; learning and correction partly evident | Consistent delivery on meaningful milestones and credible treatment of misses | Long, repeatable scaling record across expansion phases/cycles, including sound responses to setbacks |
| **EARN** | Quality of profit growth: operating source, recurrence and per-share outcome | Gains dominated by one-offs, non-operating income, unsustainable margins or dilution | Mixed sources of growth; normalized per-share progress is uneven | Recurring operating profit and diluted EPS progress consistent with the business | Sustained, broad-based operating and per-share growth with resilient margins and little normalization dependence |

CAP can be scored using appropriate unit/cohort economics when an aggregate incremental-ROIC ratio is NM. Explain the substitution; NM is not itself evidence of weakness or strength. EARN evaluates profit-growth quality, while CASH evaluates cash realization; keep their reasoning distinct.

### 7.3 Revenue scoring schedule

Choose the measurement window before scoring. Prefer five-year comparable organic CAGR; use three years when five years are unavailable or genuinely non-comparable, with an explanation. Show both if available. Do not choose whichever period looks best.

| Comparable revenue CAGR | Starting REV score |
|---:|---:|
| <0% | 1 |
| 0% to <5% | 2 |
| 5% to <10% | 4 |
| 10% to <15% | 6 |
| 15% to <20% | 7 |
| 20% to <30% | 8 |
| ≥30% | 9 |

Permit a **maximum net adjustment of ±1 point**, with evidence, for a sustained current trajectory or demonstrable distortion not already corrected in the calculation. Prefer at least four comparable quarters or two comparable half-years for a trajectory adjustment; a single quarter is insufficient. Clamp to 1–10 and apply the history/confidence ceiling.

Award 10 only for exceptional sustained expansion and verified scaling, not merely an extreme percentage. Do not upgrade REV for TAM, projected capex, high ROCE or cheap valuation; those belong elsewhere. Do not apply an additional small-base penalty after properly correcting a distorted base.

Where pass-through prices, gross/net reporting or acquisitions materially obscure demand, disclose reported growth, the economic cross-check and the basis actually scored. If that basis cannot be established reliably, REV is NS. An alternate sector growth rubric must be declared before comparison and reused consistently.

### 7.4 Financial warning indicators

For ordinary non-financial businesses, these trigger investigation rather than automatic verdicts:

- Cumulative CFO/PAT below 0.8, especially below 0.6 or negative, over a meaningful profitable 3–5-year period.
- Normalized net debt/EBITDA above approximately 2.5× or EBIT interest coverage below 3×.
- Receivable/contract-asset ageing or inventory obsolescence deteriorating repeatedly.
- Large cash balances alongside costly borrowing, unexplained advances or restricted cash.
- Returns apparently improving because of write-offs, unusually old assets or exclusion of acquisition capital.

Assess cyclicality, contractual cash visibility, maturities and the sector before drawing conclusions. Do not use these leverage ratios when EBITDA is negative or not economically appropriate. Do not excuse persistently weak collections simply because management calls them temporary.

---

## 8. BQS AND GQS: FORMULAS AND CONTROLLED OVERLAP

### 8.1 Business Quality Score

| Canonical factor | Weight |
|---|---:|
| GOV — Governance and stewardship | 20% |
| MOAT — Competitive advantage | 20% |
| REV — Demonstrated revenue growth | 12% |
| DUR — Growth durability and accessible runway | 10% |
| CAP — Incremental capital efficiency | 12% |
| CASH — Cash conversion and working capital | 10% |
| BAL — Balance-sheet resilience | 8% |
| EXEC — Execution | 8% |
| **Total** | **100%** |

```text
BQS_raw = 0.20×GOV + 0.20×MOAT + 0.12×REV + 0.10×DUR
        + 0.12×CAP + 0.10×CASH + 0.08×BAL + 0.08×EXEC
```

Revenue growth and durability receive 22% explicitly; revenue itself rises from 10% in v2.2 to 12%. Governance rises from 15% to 20%. Scale and position inform the factors they actually support. Valuation cannot lower BQS.

### 8.2 Growth Quality Score

Calculate GQS for **every scoreable business**, including slow growers, so a ranking does not selectively omit weak growth. A non-growth investment thesis can remain attractive on other grounds.

| Canonical factor | Weight |
|---|---:|
| REV — Demonstrated revenue growth | 40% |
| DUR — Growth durability and accessible runway | 20% |
| EARN — Profit-growth quality | 15% |
| CAP — Incremental capital efficiency | 15% |
| CASH — Cash conversion during growth | 10% |
| **Total** | **100%** |

```text
GQS_raw = 0.40×REV + 0.20×DUR + 0.15×EARN + 0.15×CAP + 0.10×CASH
```

The shared factors are intentional: BQS and GQS answer different questions. Never add or average these scores to create an extra quality premium. Within each formula, every factor appears once. Large order books, high ROCE or an exciting TAM earn no unlisted bonus.

### 8.3 Arithmetic, coverage and uncertainty

- Show factor score × weight = contribution, then the raw total, overrides and final total.
- Display aggregates to **one decimal place**, using conventional half-up rounding; retain unrounded arithmetic for classification and for the BQS input to IAS.
- Use NS for a missing factor. Do not redistribute its weight across known factors.
- Evidence coverage is the sum of original weights of scoreable factors. For an incomplete score, show coverage and a **missing-data bound**, not an invented midpoint:

```text
K = sum(weight × known score)
m = sum(weights of NS factors), with all weights expressed as fractions
Missing-data bound = [K + 1×m, K + 10×m]
```

- Label this a mathematical bound, not a statistical confidence interval. Do not rank it as a point score. Show any applicable cap separately and, if useful, its effect on the bound.
- For borderline judgments, show the effect of moving the two most uncertain factor scores by one point. Treat score differences smaller than the relevant uncertainty as ties in interpretation.
- An all-scored record is ranking-eligible only when material evidence is at least Medium confidence and relevant gates permit the comparison. G2 failures exclude numerical quality rankings when financial reliability is central.

---

## 9. VALUATION AND RETURN MODEL

### 9.1 Choose methods that match the economics

Use at least one explicit intrinsic-value/return model and one relevant cross-check. DCF is not mandatory where it would create false precision, but the earnings, cash flow, capital needs and terminal assumptions must still be explicit.

| Business | Useful starting methods | Main pitfalls |
|---|---|---|
| Profitable non-financial compounder | FCFF/FCFE DCF; normalized earnings or cash-flow multiple | Excluding growth investment; heroic terminal assumptions |
| Cyclical / commodity business | Mid-cycle earnings, normalized utilization and cash flow; asset-value cross-check | Capitalizing peak margins or trough P/E |
| Lender / insurer | Equity cash flow, residual income or sector valuation measures | Treating operating funding as ordinary corporate debt; ignoring required capital |
| Asset-light platform / software / AMC | Recurring revenue and cohort/unit economics; earnings/cash flow | Gross/net confusion, stock compensation, assumed perpetual growth |
| Conglomerate / holding company | Sum of parts with attributable ownership and claims | Double-counting listed stakes, cash, debt or minority interests |
| Early-loss / turnaround | Scenario-based operating path, funding and dilution; relevant asset support | Treating a distant margin target as achieved earnings |

Report P/E, EV/EBITDA, FCF yield, P/B or EV/sales only when meaningful. Negative earnings mean P/E is NM. PEG and historical multiples are cross-checks, not intrinsic-value methods. A historical premium may reflect a different growth, rate or competitive regime.

### 9.2 Bear, base and bull cases

Build an internally consistent annual model for the chosen horizon. The base case must reflect supported economics, not management's target relabeled as a forecast.

| Assumption / output | Bear | Base | Bull |
|---|---:|---:|---:|
| Revenue growth path and terminal revenue | … | … | … |
| Operating margin and normalized tax | … | … | … |
| Capex, ONWC needs and return on new capital | … | … | … |
| Financing, net debt, dividends and dilution | … | … | … |
| Terminal valuation multiple or long-run growth | … | … | … |
| Terminal equity value per diluted share | … | … | … |
| Investor annualized return | … | … | … |
| Key assumptions and failure conditions | … | … | … |

At a minimum:

- Link slower collections, lower margins and delayed capacity to cash requirements and funding, not just to lower EPS.
- Include a multiple-normalization case; do not rely on rerating for the base case without evidence.
- For enterprise valuation, bridge to common equity after debt, other senior claims and NCI; add only non-operating assets not already valued.
- Keep leases consistent across EBIT/EBITDA, cash flows, debt and peer multiples.
- Distinguish current issued shares, historical weighted-average diluted EPS shares and forecast fully diluted shares. Model warrants, options and convertibles with their cash proceeds, interest effects and conversion terms; do not subtract converted debt as if it remained outstanding.
- Do not add dividends to total return while also retaining the same cash in terminal equity value.
- Use nominal INR cash flows with compatible nominal INR discount rates. Keep terminal growth below the discount rate and economically plausible for a mature business.
- Identify how much DCF value comes from the terminal period and how sensitive the conclusion is to it.

Compute annualized return using IRR/XIRR with dated distributions and terminal proceeds when practical. Without interim distributions, `(terminal price / entry price)^(1/n) − 1` is sufficient. Do not label a probability-weighted average of scenario IRRs as a portfolio IRR.

Keep investor returns before personal taxes unless requested otherwise. Include material execution costs and market impact where supportable; otherwise show their sensitivity and disclose the omission. Apply the same return basis across the comparison set.

Scenario probabilities are optional subjective judgments. If used, show them, require a total of 100%, and explain expected wealth separately from expected annualized returns. A severe bear scenario need not have a precise probability to matter.

### 9.3 Reverse expectations and sensitivity

Solve for what today's price requires under stated margins, capital needs and terminal assumptions: revenue CAGR, earnings growth, market share or duration. Compare those requirements with history, industry economics and accessible capacity.

Show at least a two-way sensitivity for the two dominant value drivers, such as growth versus terminal multiple or margin versus cost of capital. For a DCF, test both the discount rate and terminal assumptions. Also vary the equity hurdle by ±3 percentage points around its stated value.

Report an **assumption-dependent entry-price range** if useful: prices at which the base case meets the hurdle under the sensitivity cases. Do not present a single “fair value” as observable fact.

### 9.4 Capital impairment

Describe the main path to permanent loss, who bears it, what recovers value and which assumptions fail together. Distinguish a temporary quoted drawdown from impaired earning power, a liquidity crisis, dilution or loss of shareholder claims.

Classify impairment risk as Low / Moderate / High / Severe, with reasons. Quantify both bear-case price downside and funding stress where feasible; neither alone captures all risks.

---

## 10. INVESTMENT ATTRACTIVENESS SCORE

IAS contains one explicit quality contribution. It does not separately re-add GQS, cash conversion, ROIC and runway after including BQS.

| Component | Weight | Definition |
|---|---:|---|
| **Q — Underlying quality** | 25% | Final BQS, reused exactly |
| **R — Prospective return** | 35% | Supported base-case annualized total return relative to the equity hurdle |
| **D — Downside resilience** | 20% | Loss severity, funding needs and ability to survive linked stress at this price |
| **P — Price-implied expectations** | 10% | How demanding the priced-in assumptions are and how robust the return is to reasonable errors |
| **L — Liquidity and implementation** | 10% | Executability and exit feasibility at the disclosed position size |
| **Total** | **100%** | |

```text
IAS_raw = 0.25×BQS_final + 0.35×R + 0.20×D + 0.10×P + 0.10×L
```

These dimensions are not perfectly statistically independent. R measures modeled return level; D measures loss and survival under stress; P measures the assumptions and forecast sensitivity behind the price. Keep those distinct and avoid extra narrative penalties for the same modeled downside.

### 10.1 R: return spread schedule

Let `spread = supported base-case IRR − equity return hurdle`, in **percentage points**.

| Return spread | R |
|---:|---:|
| <−10 pp | 1 |
| −10 to <−7 pp | 2 |
| −7 to <−4 pp | 3 |
| −4 to <−2 pp | 4 |
| −2 to <0 pp | 5 |
| 0 to <2 pp | 6 |
| 2 to <4 pp | 7 |
| 4 to <6 pp | 8 |
| 6 to <8 pp | 9 |
| ≥8 pp | 10 |

The schedule is a transparent research convention, not empirical proof of attractiveness. Fix unsupported model assumptions before scoring; do not compensate for an inflated base case with an arbitrary lower R. If a defensible return model cannot be built, R and IAS are NS.

### 10.2 D and P anchors

| Score | D — Downside resilience | P — Price-implied expectations |
|---|---|---|
| 1–2 | Severe permanent-loss path; inadequate funding or uncertain shareholder recovery | Price requires several implausible assumptions or extreme growth/margins/multiple persistence |
| 3–4 | Material impairment risk or likely adverse recapitalization under credible stress | Several optimistic assumptions must hold together; modest misses materially damage returns |
| 5–6 | Business survives, but bear losses and valuation/funding sensitivity are material | Price broadly requires a fair execution case; limited allowance for error |
| 7–8 | Supported ability to fund stress; limited structural impairment; downside supported by credible economics | Hurdle achievable with conservative operating assumptions and reasonable normalization |
| 9–10 | Strong recovery/asset/cash-flow support at the entry price across severe plausible stress | Multiple independently supported conservative cases meet the hurdle without rerating or heroic execution |

Supply the numerical scenario evidence alongside these qualitative bands. A high IAS factor means an attractive assessed setup, never certainty about future returns. Catalysts belong in the model, timing and monitoring; an exciting catalyst earns no separate bonus.

### 10.3 L: liquidity reference test

Use recent 20- and 60-trading-day traded values where available; report averages, median, days with zero/no trades, spread, free float and relevant restrictions. Verify current exchange lot sizes, surveillance/trading restrictions and corporate actions rather than hard-coding them.

```text
Illustrative liquidation days = position value / (participation rate × daily traded value)
```

Use a **5% participation assumption** and the more conservative of the 60-day mean and median traded values, counting zero-trade days. Also show 2% and 10% participation sensitivity. This is a theoretical capacity estimate, not guaranteed execution: limit circuits, spreads, market impact and one-sided trading may dominate.

| Illustrative days | Starting L band |
|---:|---:|
| ≤2 | 9–10 |
| >2 to ≤5 | 7–8 |
| >5 to ≤10 | 5–6 |
| >10 to ≤20 | 3–4 |
| >20 or effectively no executable liquidity | 1–2 |

Use the lower score in the band by default; use the upper only with evidence of orderly execution and stable trading. Downgrade explicitly for spread, circuits, lot-size constraints or concentration. A zero denominator yields no finite exit estimate. G4 can override the numeric calculation.

If liquidity data are missing, L is NS and IAS is incomplete. If no actual position is supplied, label IAS as conditional on the ₹5 lakh reference position; update it for the user's position before an implementation conclusion. Do not describe a reference position as suitable for the user.

---

## 11. SECTOR ADAPTATION WITHOUT MOVING THE GOALPOSTS

Choose the business archetype before scoring. Retain the factor weights and replace inapplicable measurements with stated economic equivalents. Publish any alternate growth rubric before comparing companies, and use it consistently. If no defensible equivalent exists, leave the factor NS rather than redistributing its weight.

| Archetype | Additional evidence and required adaptations |
|---|---|
| Lenders / NBFCs | Loan and revenue mix, yields, funding costs, vintage losses, GNPA/NNPA, slippages, collections, provisions, write-offs, recoveries, capital adequacy, ALM and concentration. CAP uses sustainable risk-adjusted ROA/ROE versus cost of equity and capital needs. CASH evaluates realization of accrued income and loss recognition; ordinary CFO/PAT and corporate net debt/EBITDA are not meaningful scoring rules. Disbursal/AUM growth alone is not revenue growth. |
| Insurers | Persistency, claims/reserving, underwriting economics, solvency, product mix, distribution costs and appropriate embedded-value/new-business measures where disclosed. Respect differences between life and general insurance; do not force non-financial cash-flow ratios. |
| AMCs / exchanges / platforms / software | Separate gross flows or transactions from retained revenue. Assess retention, pricing/take rate, cohorts, market-share quality, monetization, R&D, stock compensation and regulation. High historical ROCE earns no automatic moat score. |
| EPC / equipment / defense / rail suppliers | Qualification, customer dependence, backlog quality, milestones, bank guarantees, retention, contract assets, liquidated damages, cash collection and working-capital financing. |
| Manufacturing / EMS / solar / auto suppliers | Value added versus pass-through sales, yields, utilization, customer bargaining power, warranties, technology obsolescence, incentive dependence, localization and returns after full expansion capital. |
| Pharma / chemicals / healthcare | Product/site concentration, approvals, inspections, compliance history, patents, pricing and R&D; for hospitals, occupancy, revenue per occupied bed, payer mix, mature/new-facility cohorts and ramp-up capital. |
| Consumer / retail / franchise / hotels | Same-store/unit growth, mature versus new-unit returns, closures, customer acquisition, franchise economics, occupancy/room rates where relevant, inventory markdowns and consistent lease treatment. |
| Commodity / cyclical / regulated utility | Mid-cycle prices/spreads and utilization, resource quality, cost position, tariff/pass-through rules, receivables and regulated returns. Do not mistake nominal price inflation for demand growth or penalize a genuine cost moat for lacking pricing freedom. |
| Holdings / conglomerates / real estate | Attributable ownership, intercompany claims, debt location and sum of parts; for property, project cash flows, collections, completion obligations and recognition timing. Avoid mechanically applying industrial working-capital ratios. |

Cross-sector rankings express analytical judgment, not an assertion that every underlying metric is directly comparable. Add within-sector peers and explain material rubric differences. Do not imply a 0.1-point cross-sector gap is economically decisive.

---

## 12. SME / MICRO-CAP FORENSIC OVERLAY

For SMEs and thinly traded microcaps, explicitly review:

1. Pre-IPO versus post-IPO revenue, margins, receivables, cash flow and the operating history behind restated accounts.
2. Customer/supplier concentration, connected counterparties, unusual year-end sales and ageing. Missing counterparty detail is a gap, not proof of wrongdoing.
3. IPO/preferential proceeds, use-of-proceeds updates, changes in objects, acquisitions and actual commissioning.
4. Warrants, convertibles, ESOPs, outstanding commitments and the potential fully diluted capital structure.
5. Auditor observations, group complexity, guarantees, advances, RPT balances and potential cash leakage.
6. Available cash versus reported balances, bank facilities, ratings and liquidity disclosures.
7. Promoter holding and encumbrance history, free float, ownership concentration, lot sizes and practical exit constraints.
8. Whether growth depends on one contract, subsidy, customer, product approval or capex event.

IPO status, a famous customer, a government order, high promoter ownership or a small market cap is not evidence of superior quality. Do not infer misconduct from SME status either. Missing material verification limits confidence and scoreability.

---

## 13. 5× / 10× OUTCOME TEST

Run when the user asks about multibaggers or when it is central to the thesis. Otherwise provide a short feasibility comment rather than a speculative long-range target.

Separate business growth, enterprise value, equity value and per-share stock return. For positive, normalized earnings and consistent definitions:

```text
Price_t / Price_0
= (Revenue_t / Revenue_0)
  × (net margin attributable to common owners_t / net margin attributable to common owners_0)
  × (relevant diluted shares_0 / relevant diluted shares_t)
  × (P/E_t / P/E_0)
```

This is a decomposition, not a forecast. It is NM when earnings/margins or P/E are not meaningful. Use an enterprise-value-to-equity bridge instead for those cases. Dividends affect total return separately.

Show required revenue, market share, margin, reinvestment, financing, share dilution and terminal valuation. Compare them with the accessible market and management's demonstrated execution. Model a case with a lower terminal multiple.

Required annualized price growth for 10× is approximately **58.5% over five years**, **38.9% over seven**, or **25.9% over ten**. State the horizon rather than saying “10× potential” without one.

Classify the outcome as **Plausible under supported assumptions**, **Possible but demanding**, or **Speculative / unsupported**, and state what makes it so. Do not give a precise success probability without a defensible basis.

---

## 14. BEAR CASE, FALSIFICATION AND MONITORING

Construct the strongest credible bear case before the final verdict. Identify:

- The single most important variable whose failure invalidates the thesis.
- The strongest evidence against the preferred interpretation.
- A linked stress scenario: for example, customer loss → lower utilization → weaker margin → slower collections → financing need.
- What would change the classification, and what would merely be normal volatility.
- What the market may already understand, and the evidence behind any claimed differentiated view.

Use five to ten company-specific monitoring items:

| KPI / event | Current baseline and date | Expected range / milestone | Warning threshold | Thesis-break threshold | Source / review timing |
|---|---|---|---|---|---|
| … | … | … | … | … | … |

Set thresholds from company economics and history, not arbitrary universal cutoffs. A missed quarter is not automatically a thesis break; a documented governance failure can be. Distinguish an alert requiring investigation from an automatic investment conclusion.

Monitoring cadence is a research recommendation only. Do not create reminders or recurring tasks unless the user requests them.

---

## 15. CLASSIFICATION AND ACTION LOGIC

Apply gate and evidence rules **before** the matrix. BQS/GQS/IAS labels describe analytical assessments; they do not imply a guaranteed return or a portfolio allocation.

### 15.1 Complete classification matrix

Use unrounded final scores. Every numeric combination falls in a cell:

| Final BQS | IAS ≥7.5 | IAS ≥5.5 and <7.5 | IAS <5.5 |
|---|---|---|---|
| ≥8 | High-quality business; attractive assessed setup | High-quality business; watch valuation and return assumptions | High-quality business; unattractive setup at this price |
| ≥6 and <8 | Investable quality; attractive assessed setup | Mixed/adequate setup; selective research watchlist | Insufficient return for identified risks |
| ≥4 and <6 | Value / special-situation candidate; quality limitations | Speculative or mixed-quality watchlist | Weak setup / value-trap risk |
| <4 | Speculative value only; substantial impairment risk | Low-quality speculative setup | Avoid on the assessed evidence |

Override with **Avoid — governance**, **Distressed / funding failure**, **Hold — unresolved**, or **Insufficient evidence** where applicable. Never label every low IAS as “expensive”; poor liquidity, weak returns or downside risk can also cause it.

### 15.2 Compounder designation

Use **Evidence-backed compounder candidate** only if all are satisfied:

- BQS ≥8 and GQS ≥7.
- GOV, MOAT, REV, DUR and CAP each ≥7.
- CASH and BAL each ≥6.
- Material confidence at least Medium and no unresolved critical gate.

An attractive entry additionally requires IAS ≥7.5 and a supported base-case return meeting the hurdle. A high-quality slow grower may suit a value/income thesis but does not meet this growth designation. An early turnaround remains a turnaround until the evidence changes.

### 15.3 Actions and portfolio use

Distinguish **Research priority**, **Watchlist / wait for price**, **Eligible for investment consideration**, **Review / reduce / exit candidate**, and **Avoid**. Do not treat a rank as an instruction to buy or sell.

For an existing holding, identify whether the issue is thesis failure, governance, funding, valuation, liquidity or portfolio concentration. Consider taxes, execution costs and alternatives when the user supplies enough information. Purchase price is not evidence of current business value, but it can matter to taxes and implementation.

When asked how many holdings to exit, show names, reasons and the count. Separate high-confidence thesis/governance failures from valuation-based trim candidates and unresolved-data holds. If weights, tax context or tradeability materially change the count, provide a conditional count instead of inventing them. Never execute a trade from this framework alone.

---

## 16. STANDARD COMPANY OUTPUT

Use the following structure. Keep the verdict concise; place the evidence and calculations beneath it. If a section is inapplicable or incomplete, say why instead of silently omitting it.

### 1. Executive Verdict

In one paragraph: what the business is, what drives the thesis, the decisive strength, decisive risk, price-dependent conclusion and what would change it. State whether this is a compounder, cyclical, value, turnaround, income or special-situation thesis.

### 2. Research Header, Gates and Data Confidence

Identity, as-of dates, price, market cap, financial scope, accounting basis, horizon, equity hurdle and liquidity reference position. Show the gate register and confidence by subject.

Example style: **Data Confidence: High on audited P&L and shareholding; Medium on organic growth because acquisition revenue is not separately disclosed; Low on incremental returns until the investment bridge is reconciled.** Adapt the conclusion and scoreability accordingly.

### 3. Scorecard and Calculation Audit

| Measure | Raw | Override / gap | Final | Coverage | Confidence |
|---|---:|---|---:|---:|---|
| BQS | … | … | … / NS | … | … |
| GQS | … | … | … / NS | … | … |
| IAS | … | … | … / NS | … | … |

Show the nine canonical factors and IAS R/D/P/L, evidence IDs and weighted contributions. Keep the composite calculation auditable without repeating the same narrative three times.

### 4. Business Overview

Products, segments, customers, revenue model, geography, scale and how money is made and collected.

### 5. Moat / Industry Position

Mechanism, evidence, relevant peers, concentration, market structure, durability and failure modes.

### 6. Revenue Growth & Scale

CAGR table with periods and endpoints; annual ₹ additions; organic/acquired/price/volume drivers; recent trajectory and distortions.

### 7. Growth Quality & Reinvestment Runway

Demand access, bottom-up scaling path, funding, capital needs, returns and sustainable duration. Explain the GQS result, including any cap.

### 8. Management, Governance & Execution

Capital allocation, minority treatment, forensic findings and dated promises-versus-delivery table.

### 9. Financial Forensics

Historical table; revenue-to-earnings-to-cash bridge; ROIC/ROCE and incremental-return calculation; working capital, liquidity, obligations, FCF and per-share dilution.

### 10. Valuation & Market Expectations

Methods, current multiples, normalization, bear/base/bull assumptions and returns, reverse expectations, sensitivities and conditional entry range if supportable.

### 11. Bear Case & Permanent-Loss Path

Strongest counterargument, linked stress, material downside, unresolved questions and thesis-break variable.

### 12. 5× / 10× Feasibility

Full test if requested or central; otherwise a short evidence-based comment.

### 13. Monitoring Plan

Five to ten specific KPIs, baselines, milestones and warning/thesis-break thresholds.

### 14. Final Classification & Conditional Action

Apply the matrix and compounder criteria. Explain the price dependence, research limitations and action category. Identify what new evidence or price would materially change the conclusion.

### 15. Sources, Assumptions & Open Questions

Source ledger with working links and dates; calculation definitions; unresolved gaps; which assumptions matter most. Do not append a generic list of sources unrelated to the claims.

---

## 17. MULTI-COMPANY RANKING AND BATCH CONSISTENCY

Maintain a master record:

| Company / symbol | Sector / rubric | As-of price date | BQS | GQS | IAS | GOV | REV | Gates | Confidence / coverage | Classification | Decisive reason |
|---|---|---|---:|---:|---:|---:|---:|---|---|---|---|
| … | … | … | … | … | … | … | … | … | … | … | … |

Produce three separate **highest-to-lowest** rankings:

1. **Best Businesses — BQS.**
2. **Best Growth Businesses — GQS.**
3. **Best Investments at the Stated Prices — IAS.**

Rules:

- Use the same methodology version, information cutoff and comparable price dates. Flag unavoidable date differences.
- Publish the sector rubric and assumptions; do not change weights between companies or batches.
- Score independently before sorting. Do not raise or lower scores to fit a prior preferred order.
- Use displayed one-decimal scores for rank groups. Equal displayed scores share a rank; sort names alphabetically within ties. Explain when uncertainty makes nearby groups effectively indistinguishable.
- Put incomplete/NS records in a separate **Pending evidence** table with missing items. Do not send them to the bottom as if they were proven poor businesses.
- Put failed critical gates in a separate **Excluded by gate** table with the exact reason; a high historical GQS must not make a governance-failed name look investable.
- Include slow growers in GQS when scoreable. Do not omit them because growth is not their thesis.
- Keep a batch-completion ledger: requested names, resolved names, screens, deep research completed and pending items.
- Do not declare the overall winner or an overall portfolio exit count until the requested universe has been assessed, unless the conclusion is explicitly labeled provisional.
- When comparing old research with new research, recompute under a common version or flag the discontinuity. v2.2 and v3.0 scores are not directly interchangeable.

If an overall ranking is explicitly requested, disclose the objective and formula first, preserve all three source scores and apply gates before combining anything. Do not present such a blend as statistically validated.

---

## 18. UPDATE LOG AND FINAL QUALITY CHECK

### 18.1 Research update log

For each substantive update, retain:

| Date | New evidence / event | Metric or assumption changed | Old → new factor / score | Gate change | Thesis impact |
|---|---|---|---|---|---|
| … | … | … | … | … | … |

Explain whether IAS changed because of price, earnings estimates, risk, liquidity or methodology. Revisit BQS/GQS only when operating evidence or relevant assumptions change. If a framework version changes, distinguish methodology effects from genuine business change.

### 18.2 Required quality check before delivery

- [ ] Correct company, security and consolidation scope; source and price dates are explicit.
- [ ] Primary records read for material claims; management guidance and analyst assumptions are labeled.
- [ ] Audit, RPT, financing and dilution evidence reviewed; gate findings are supported and proportionate.
- [ ] Comparable periods and units; no overlapping TTM periods or invented quarterly cash flow.
- [ ] Revenue growth is separated from profit growth, acquisitions, pass-through prices and base distortions.
- [ ] CFO/PAT uses a ratio of sums; capex is not used as an unexplained excuse for weak CFO.
- [ ] Incremental-return numerator, capital denominator, timing and limitations are visible.
- [ ] Earnings normalization, leases, taxes, claims and dilution are consistent in valuation.
- [ ] Bear/base/bull growth, reinvestment, cash and financing reconcile; no double-counted cash or dividends.
- [ ] Canonical factors are reused exactly; weights total 100% for each score.
- [ ] Missing evidence remains NS; coverage, bounds and confidence are clear.
- [ ] Raw and final scores reconcile; only stated overrides are applied.
- [ ] Classification follows the complete matrix and any compounder designation meets its criteria.
- [ ] Liquidity is assessed at a stated position size; a stale quote is not called executable.
- [ ] The strongest bear case and thesis-break variable are explicit.
- [ ] Rankings use a common version and tie policy; unfinished research is visibly unfinished.

The concluding test is:

> Can this company expand real revenue, protect its economics, reinvest at attractive returns, convert earnings into cash and increase intrinsic value per share over many years—and does the stated purchase price compensate for the risks and uncertainty?

---

## APPENDIX A. WHAT CHANGED FROM v2.2

| v2.2 limitation | v3.0 change |
|---|---|
| Missing evidence could default to 5–6 | Explicit ND/NM/NA/NS; coverage and missing-data bounds; no invented neutral score |
| Overlap across broad quality pillars and IAS | One canonical factor set; explicit formulas; BQS enters IAS once |
| Governance had rigid event-based red flags | Materiality, evidence, recurrence and resolution; distinguish holds from proven failures |
| Revenue carried 10% directly in BQS | Increased to 12%; growth plus durability remains 22%; GQS retains 40% revenue weight |
| Governance carried 15% | Increased to 20%, with transparent override rules |
| Incremental capex denominator was ambiguous | Change-in-invested-capital proxy, investment bridge, timing and acquisition/R&D caveats |
| “Average” cash conversion was ambiguous | Cumulative CFO divided by cumulative comparable PAT |
| Capex could appear to excuse weak CFO | Explicit CFO-versus-FCF distinction and funding bridge |
| Small revenue base could be dismissed mechanically | Distorted-base checks without automatic small-company penalties |
| Pricing power and top-three status were restrictive anchors | Recognize cost/network/qualification advantages and niche economics |
| GQS could be skipped for low-growth companies | Calculate for all scoreable names; keep non-growth theses distinct |
| Valuation process was largely qualitative | Explicit scenarios, dilution, return hurdle, reverse expectations and sensitivity |
| Classification omitted some decimal score combinations | Complete interval matrix plus separate compounder criteria |
| Liquidity and SME checks lacked implementation detail | Position-based liquidity test and a dedicated forensic overlay |
| Limited consistency controls across batches | Twenty-name batching, completion ledger, rank ties and versioned updates |
| No clear methodology-validation boundary | Weights and thresholds identified as research heuristics, not a proven return model |

## APPENDIX B. METHODOLOGY REFERENCES

These references inform financial definitions and accounting distinctions. They do **not** endorse this prompt's scoring weights, thresholds, rankings or return hurdle. Verify the applicable accounting standards and current market/regulatory rules when analyzing a company.

- [Aswath Damodaran, NYU Stern — Financial Measures and Ratios](https://pages.stern.nyu.edu/~adamodar/New_Home_Page/definitions.html): operating returns, invested capital and reinvestment terminology.
- [Aswath Damodaran, NYU Stern — The Fundamental Determinants of Growth](https://pages.stern.nyu.edu/~adamodar/New_Home_Page/valquestions/growth.htm): investment, growth, marginal versus average returns and per-share effects.
- [Ministry of Corporate Affairs — Indian Accounting Standard 7](https://www.mca.gov.in/Ministry/pdf/Ind_AS7.pdf): operating, investing and financing cash-flow distinctions.
- [ICAI — Educational Material on Ind AS 7](https://www.icai.org/post/10450): supplementary accounting guidance and worked cash-flow issues.

## APPENDIX C. WORKED SCORING CHECK

This fictional example checks arithmetic only; the factor values are assumed and are not evidence about a company.

```text
GOV=8, MOAT=8, REV=9, DUR=8, CAP=8, CASH=7, BAL=8, EXEC=8, EARN=8
R=7, D=7, P=6, L=8; all required evidence available; no gate failure

BQS_raw = 1.60 + 1.60 + 1.08 + 0.80 + 0.96 + 0.70 + 0.64 + 0.64
        = 8.02 → displayed 8.0

GQS_raw = 3.60 + 1.60 + 1.20 + 1.20 + 0.70
        = 8.30 → displayed 8.3

IAS_raw = 0.25×8.02 + 0.35×7 + 0.20×7 + 0.10×6 + 0.10×8
        = 7.255 → displayed 7.3
```

Use the unrounded 8.02 in IAS. The matrix classifies this as a high-quality business in the middle IAS band; an attractive-entry designation does not follow merely from strong BQS/GQS.

If CASH becomes NS, BQS has 90% coverage and a missing-data bound of **7.42–8.32**. It is **NS**, not 7.87 or a renormalized score. GQS is also incomplete.

If instead GOV falls to 3 on substantiated adverse evidence, raw BQS becomes 7.02 and final BQS is capped at 3. With the same hypothetical R/D/P/L, raw IAS becomes 6.00 and final IAS is capped at 3. Classify **Avoid — governance** and exclude it from investable rankings, regardless of historical growth.

**End of master prompt.**
