### Disclosure discrepancies and audit counterevidence

1. Customer guarantees are INR 20.9115 crore in standalone note 2.28, but only INR 2.1386 crore in the group note with the same caption. Company PDF pages 197 and 248, or NSE pages 198 and 249, were visually verified. A gross-versus-net or perimeter explanation is possible, but not disclosed in these notes. Neither amount should be automatically assumed to represent complete group exposure.
2. The standalone RPT note records INR 0.3299 crore received and payable to step-down entity Religreen. The standalone debt table does not separately show it, and CARO says no borrowing from a subsidiary or related party. Group short debt does list approximately INR 0.33 crore. The borrower/perimeter and elimination treatment need reconciliation; do not mechanically add the amount twice.
3. Cash classifications conflict as described above. The AOC-1 subsidiary summary also contains unit/date/arithmetic inconsistencies and is not sufficient by itself for a reliable subsidiary valuation.
4. The audit wording refers to Ind AS, while the accounting policies identify Indian GAAP Accounting Standards. This is a document-consistency concern, not proof that any particular recognition treatment is wrong.

Positive evidence must accompany these concerns: the auditor gives an unmodified opinion, reports no KAM, says quarterly bank statements agree with books, reports no default or wilful-defaulter status, and reports no material fraud identified during audit. The correct conclusion is a need for documentary reconciliation and a restricted evidence base for liquidity valuation, not an allegation of fraud.



### Original-versus-restated historical reconciliation

The RHP expressly states on pages 176/183 that gratuity was absent from original FY21–FY23 statements and has been recorded retrospectively for AS15. Expenses of INR 30.52/3.24/4.38 lakh on page 192 account for nearly all reductions from original PAT of INR 97.81/178.02/720.68 lakh to restated INR 67.28/174.79/716.26 lakh. This is a disclosed accounting change.

Cash-flow vintages also differ: original FY22 CFO INR 590.75 lakh versus RHP INR 372.53 lakh; original FY23 CFO INR 360.09 lakh versus RHP INR 412.47 lakh and FY24 comparative INR 429.33 lakh. Those do not have a complete line-by-line bridge in the reviewed documents. The FY24 CFO of negative INR 827.13 lakh does agree between its original annual report and FY25 comparative; financing cash flow changes as overdrafts move into cash management. The principal three-negative-year FY24–FY26 cash-conversion finding therefore does not depend on choosing the most adverse pre-IPO vintage.



### Evidence required to clear remaining uncertainty

Obtain bankwise FD/margin/lien confirmations and release schedules; current fund-based and non-fund-based facility letters with expiry, conditions and undrawn capacity; an instrumentwise guarantee register reconciling parent and group disclosures; a term-principal maturity ladder; an acquisition-date opening-balance and cash-flow bridge; and a reconciliation of Religreen intercompany borrowing. An IPO gross-to-net issue-cost timing bridge is also needed: gross issue INR 64.32 crore less disclosed total issue expense INR 6.6487 crore implies INR 57.6713 crore net, whereas FY25 cash-flow equity proceeds are INR 59.2649 crore. Prior-funded expense timing may explain the difference, but the reviewed sources do not explicitly establish that bridge.
