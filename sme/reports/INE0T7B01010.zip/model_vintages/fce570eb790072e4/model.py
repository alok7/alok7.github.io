"""Shivalic panel-manufacturing monthly scenario engine; INR crore unless stated.
All financial input values remain in financial_inputs.json. Scenarios are hypotheses,
not representations of current lending access or acquired-subsidiary fair value.
"""
from decimal import Decimal as D, localcontext
from copy import deepcopy
from collections import defaultdict
Z=D('0'); O=D('1'); CR=D('10000000')
def d(x):
    if isinstance(x,float): raise TypeError('Decimal strings, not binary floats')
    return x if isinstance(x,D) else D(str(x))
def month_date(m):
    n=2026*12+10+m-1
    return f'{n//12:04d}-{n%12+1:02d}'
def distribute(queue, amount, start, months):
    for k in range(months): queue[start+k]+=amount/d(months)
def run(inputs, scenario, years, path_id):
    with localcontext() as ctx:
        ctx.prec=40
        return _run(inputs,deepcopy(scenario),years,path_id)
def _run(i,s,years,path_id):
    o={k:d(v) for k,v in i['opening'].items() if v is not None}; n=years*12
    cash=o['deployable_cash_floor']; deposits=o['deposits_uncertain_restriction']; ar=o['receivables']; inventory=o['inventory']; ap=o['trade_payables']; advances=o['customer_advances']; other_assets=o['other_operating_assets']; other_claim=o['other_current_claims']; tax_claim=o['tax_claim']; ppe=o['ppe']; pipeline_asset=Z
    wc=o['cash_credit']; term=o['term_debt']; new_debt=Z; shares=int(i['issued_shares']); baseprice=d(i['panel_bridge']['annualized_price_per_equivalent']); baseunits=o['sales']/baseprice; capacity=d(i['panel_bridge']['historical_capacity']); pipeline=[]; receipts=defaultdict(lambda:Z); suppliers=defaultdict(lambda:Z)
    distribute(receipts,ar*d(s['opening_ar_recovery']),1,int(s['opening_ar_months'])); distribute(suppliers,ap,1,int(s['opening_ap_months']))
    facilities=[dict(a,balance=d(a['model_opening'])) for a in i['facilities']]
    rows=[]; failure=None; exitrow=None; cumdraw=Z; debts=[]; loan_claim=o['related_party_loan']; original_loan=loan_claim; acquired_cost=o['subsidiary_investment_cost']; cumulative_sub_funding=Z; rejected_draw=Z
    for m in range(1,n+13):
        y=(m-1)//12
        opening=dict(cash=cash,deposits=deposits,ar=ar,inventory=inventory,ap=ap,advances=advances,other_assets=other_assets,other_claim=other_claim,tax_claim=tax_claim,ppe=ppe,pipeline_asset=pipeline_asset,wc=wc,term=term,new_debt=new_debt,shares=shares,loan_claim=loan_claim)
        commissioned=sum((x['cost'] for x in pipeline if x['due']==m),Z); capacity_commissioned=sum((x['capacity'] for x in pipeline if x['due']==m),Z); pipeline=[x for x in pipeline if x['due']!=m]; ppe+=commissioned; pipeline_asset-=commissioned; capacity+=capacity_commissioned
        if m<=n:
            volume_demand=baseunits*(O+d(s['unit_growth']))**(y+1)*(O-d(s['customer_loss'])); price=baseprice*(O+d(s['price_growth']))**(y+1)
        else:
            volume_demand=terminal_basis['units']*(O+d(s['terminal_growth'])); price=terminal_basis['price']
        delivered=min(volume_demand/12,capacity/12); lost_units=max(Z,volume_demand/12-delivered); sales=delivered*price
        annual_sales_demand=volume_demand*price
        # The original IPO roof/machine budget does not itself establish quantified capacity.
        ipo_capex=d(s['remaining_ipo_capex_assumption'])/int(s['ipo_spend_months']) if m<=int(s['ipo_spend_months']) else Z
        if ipo_capex:
            pipeline_asset+=ipo_capex; pipeline.append({'cost':ipo_capex,'capacity':Z,'due':m+int(s['capex_lead_months'])})
        expansion=Z; ordered_capacity=Z
        projected_capacity=capacity+sum((x['capacity'] for x in pipeline),Z)
        if s['expansion_gate'] and volume_demand*d(s['capacity_buffer'])>projected_capacity:
            ordered_capacity=min(volume_demand*d(s['capacity_buffer'])-projected_capacity,d(s['max_capacity'])-projected_capacity)
            ordered_capacity=max(Z,ordered_capacity); expansion=ordered_capacity*d(s['capex_per_vertical_capacity']); pipeline_asset+=expansion
            if expansion: pipeline.append({'cost':expansion,'capacity':ordered_capacity,'due':m+int(s['capex_lead_months'])})
        material=sales*d(s['material_ratio'])
        impairment=inventory*d(s['inventory_impairment']) if m==int(s['inventory_impairment_month']) else Z; inventory-=impairment
        desired_inventory=annual_sales_demand*d(s['material_ratio'])*d(s['inventory_days'])/365
        purchases=max(Z,material+desired_inventory-inventory); inventory+=purchases-material
        suppliers[m+int(s['supplier_delay'])]+=purchases; supplier_cash=suppliers.pop(m,Z); ap+=purchases-supplier_cash
        advance_receipts=sales*d(s['customer_advance_share']); advance_application=min(advances,sales*d(s['customer_advance_application'])); advances+=advance_receipts-advance_application
        credit_sales=sales-advance_application
        receipts[m+int(s['collection_delay'])]+=credit_sales; collections=receipts.pop(m,Z); ar+=credit_sales-collections
        writeoff=o['receivables']*(O-d(s['opening_ar_recovery'])) if m==int(s['opening_ar_months']) else Z; ar-=writeoff
        opex_ratio=O-d(s['material_ratio'])-d(s['ebitda_margin']); assert opex_ratio>=0
        opex=opex_ratio*(d(s['fixed_opex_fraction'])*o['sales']/12+(O-d(s['fixed_opex_fraction']))*sales)
        maintenance=max(sales*d(s['maintenance_ratio']),ppe*d(s['replacement_rate'])/12 if m>n else Z); ppe+=maintenance
        da=min(ppe,o['da']/12+max(Z,ppe-o['ppe'])*d(s['incremental_da_rate'])/12); ppe-=da
        ebitda=sales-material-opex; ebit=ebitda-da-impairment-writeoff
        facility_interest=Z;principal_term=Z;facility_schedule=[]
        for facility in facilities:
            balance=facility['balance'];expense=balance*d(facility['annual_rate'])/12;emi=None if facility['monthly_emi'] is None else d(facility['monthly_emi']);principal=min(balance,max(Z,emi-expense)) if emi is not None else Z
            if m>=int(facility['maturity_month']) or (s['maturity_policy']=='immediate_call' and m==1):principal=balance
            facility['balance']-=principal;facility_interest+=expense;principal_term+=principal
            facility_schedule.append(dict(id=facility['id'],opening=balance,interest=expense,scheduled_emi=emi,principal=principal,closing=facility['balance'],stated_maturity=facility['stated_maturity'],maturity_month=facility['maturity_month']))
        term=sum((a['balance'] for a in facilities),Z)
        interest=(wc*d(s['cash_credit_rate'])+new_debt*d(s['new_debt_rate']))/12+facility_interest
        principal_wc=wc if m==int(s['cash_credit_call_month']) and not s['cash_credit_renewal_gate'] else Z; wc-=principal_wc
        principal_new=Z; renewal_fee=Z; kept=[]
        for debt in debts:
            if debt['due']==m:
                if s['new_debt_renewal_gate']:
                    renewal_fee+=debt['amount']*d(s['renewal_fee']); kept.append({'amount':debt['amount'],'due':m+int(s['new_debt_tenor'])})
                else: principal_new+=debt['amount']
            else: kept.append(debt)
        debts=kept; new_debt-=principal_new
        taxes=max(Z,ebit-interest)*d(s['tax_rate'])
        tax_settlement=tax_claim if m==int(s['tax_settlement_month']) else Z; tax_claim-=tax_settlement
        other_settlement=min(other_claim,o['other_current_claims']/int(s['other_claim_months'])) if m<=int(s['other_claim_months']) else Z; other_claim-=other_settlement
        other_assets_target=o['other_operating_assets']+max(Z,annual_sales_demand-o['sales'])*d(s['other_assets_growth_ratio']); other_assets_change=other_assets_target-other_assets; other_assets=other_assets_target
        # Restriction unknown is not ordinary cash. Only a labelled condition releases it.
        deposit_release=min(deposits,d(s['deposit_release_amount'])) if m==int(s['deposit_release_month']) and s['deposit_release_gate'] else Z
        deposits-=deposit_release
        restricted_ipo_use=min(deposits,ipo_capex) if s['ipo_restricted_release_gate'] else Z; deposits-=restricted_ipo_use
        subsidiary_advance=d(s['additional_subsidiary_advance']) if m==int(s['subsidiary_advance_month']) else Z; loan_claim+=subsidiary_advance; cumulative_sub_funding+=subsidiary_advance
        subsidiary_purchase=d(s['seedlab_purchase']) if m==int(s['seedlab_purchase_month']) else Z; acquired_cost+=subsidiary_purchase
        loan_repayment=loan_claim*d(s['loan_repayment_fraction']) if m==int(s['loan_repayment_month']) else Z; loan_claim-=loan_repayment
        guarantee_call=d(s['guarantee_call']) if m==int(s['guarantee_call_month']) else Z
        fees=d(s['annual_facility_fees'])/12+renewal_fee
        capex=maintenance+expansion+ipo_capex
        reserve=max(d(s['minimum_cash']),d(s['reserve_cost_months'])*(material+opex))
        pre=cash+collections+advance_receipts+deposit_release+restricted_ipo_use+loan_repayment-supplier_cash-opex-interest-taxes-tax_settlement-other_settlement-other_assets_change-capex-principal_term-principal_wc-principal_new-fees-subsidiary_advance-subsidiary_purchase-guarantee_call
        need=max(Z,reserve-pre); draw=Z; drawfee=Z
        if m<=n and s['new_debt_gate']:
            rate_month=d(s['new_debt_rate'])/12; taxable=max(Z,ebit-interest); fee_rate=d(s['draw_fee']); taxrate=d(s['tax_rate'])
            candidate=need/(O-fee_rate-rate_month*(O-taxrate))
            if candidate*rate_month>taxable: candidate=(need-taxable*taxrate)/(O-fee_rate-rate_month)
            draw=min(max(Z,candidate),max(Z,d(s['new_debt_limit'])-new_debt),max(Z,d(s['cumulative_debt_limit'])-cumdraw)); drawfee=draw*fee_rate; new_debt+=draw; cumdraw+=draw
            if draw: debts.append({'amount':draw,'due':m+int(s['new_debt_tenor'])})
        current_draw_interest=draw*d(s['new_debt_rate'])/12; oldtax=taxes; interest+=current_draw_interest; taxes=max(Z,ebit-interest)*d(s['tax_rate'])
        pre+=draw-drawfee-current_draw_interest+oldtax-taxes; rejected_draw+=max(Z,reserve-pre)
        esop_issued=int(s['esop_exercise_shares']) if m==int(s['esop_exercise_month']) else 0
        esop_cash=d(esop_issued)*d(i['claims']['esop_strike'])/CR; shares+=esop_issued
        # No rescue equity. ESOP approved pool is not an issued share or cash receipt.
        cash=pre+esop_cash; shortfall=max(Z,reserve-cash)
        operating_fcff=collections+advance_receipts-supplier_cash-opex-max(Z,ebit)*d(s['tax_rate'])-capex-other_assets_change
        row=dict(operating_fcff=operating_fcff,month=m,date=month_date(m),year=y+1,phase='horizon' if m<=n else 'terminal_transition',cash_open=opening['cash'],cash_close=cash,reserve=reserve,shortfall=shortfall,deposits_open=opening['deposits'],deposits_close=deposits,deposit_release=deposit_release,restricted_ipo_use=restricted_ipo_use,ar_open=opening['ar'],ar_close=ar,inventory_open=opening['inventory'],inventory_close=inventory,ap_open=opening['ap'],ap_close=ap,advances_open=opening['advances'],advances_close=advances,other_assets_open=opening['other_assets'],other_assets_close=other_assets,other_assets_change=other_assets_change,other_claim_open=opening['other_claim'],other_claim_close=other_claim,tax_claim_open=opening['tax_claim'],tax_claim_close=tax_claim,ppe_open=opening['ppe'],ppe_close=ppe,pipeline_open=opening['pipeline_asset'],pipeline_close=pipeline_asset,commissioned=commissioned,capacity_commissioned=capacity_commissioned,capacity=capacity,ordered_capacity=ordered_capacity,units=delivered,price=price,lost_units=lost_units,sales=sales,material=material,purchases=purchases,supplier_cash=supplier_cash,collections=collections,advance_receipts=advance_receipts,advance_application=advance_application,credit_sales=credit_sales,receivable_writeoff=writeoff,inventory_impairment=impairment,opex=opex,ebitda=ebitda,da=da,ebit=ebit,interest=interest,facility_interest=facility_interest,facility_schedule=facility_schedule,tax=taxes,tax_settlement=tax_settlement,other_settlement=other_settlement,fees=fees,maintenance_capex=maintenance,growth_capex=expansion,ipo_capex=ipo_capex,capex=capex,wc_open=opening['wc'],wc_close=wc,term_open=opening['term'],term_close=term,new_debt_open=opening['new_debt'],new_debt_close=new_debt,debt_open=opening['wc']+opening['term']+opening['new_debt'],debt_close=wc+term+new_debt,principal_term=principal_term,principal_wc=principal_wc,principal_new=principal_new,new_draw=draw,draw_fee=drawfee,current_draw_interest=current_draw_interest,shares_open=opening['shares'],shares_close=shares,esop_issued=esop_issued,esop_cash=esop_cash,loan_claim_open=opening['loan_claim'],loan_claim_close=loan_claim,subsidiary_advance=subsidiary_advance,subsidiary_purchase=subsidiary_purchase,loan_repayment=loan_repayment,guarantee_call=guarantee_call,failed=shortfall>D('1e-24'))
        rows.append(row)
        if m==n:
            exitrow=deepcopy(row); terminal_basis=dict(units=sum(x['units'] for x in rows[-12:]),sales=sum(x['sales'] for x in rows[-12:]),ebitda=sum(x['ebitda'] for x in rows[-12:]),price=price)
        if row['failed']:
            failure=dict(month=m,date=row['date'],shortfall=shortfall,negative_cash=cash<0,reason='Scenario liquidity/reserve shortfall. Not an observed default; opening snapshot and facility bridge are incomplete.'); break
    terminal=None; attempt=None
    if failure is None:
        transition=rows[n:]; end=exitrow; g=d(s['terminal_growth']); wacc=d(s['wacc']); assert wacc>g
        nopat=sum((max(Z,x['ebit'])*(O-d(s['tax_rate'])) for x in transition),Z); da=sum((x['da'] for x in transition),Z); actual_maintenance=sum((x['maintenance_capex'] for x in transition),Z); replacement=max(actual_maintenance,da)
        physical_growth=sum((x['growth_capex']+x['ipo_capex'] for x in transition),Z)
        def onwc(x): return x['ar_close']+x['inventory_close']+x['other_assets_close']-x['ap_close']-x['advances_close']
        working_capital=max(Z,onwc(transition[-1])-onwc(end)); economic_floor=nopat*g/d(s['terminal_roic']); growth_reinvestment=max(physical_growth+working_capital,economic_floor); extra=replacement-actual_maintenance+growth_reinvestment-physical_growth-working_capital
        fcff=nopat+da-replacement-growth_reinvestment
        reserve_required=max([end['reserve']]+[x['reserve']-(x['cash_close']-end['cash_close'])+extra*d(k+1)/12 for k,x in enumerate(transition)]); reserve_required=max(Z,reserve_required)
        financing_addback=Z; operating_requirements=[end['reserve']]; unlevered=[]
        for k,x in enumerate(transition):
            taxshield=max(Z,x['ebit'])*d(s['tax_rate'])-x['tax']; principal=x['principal_term']+x['principal_wc']+x['principal_new']; claims=x['tax_settlement']+x['other_settlement']; financial_outflows=x['subsidiary_advance']+x['subsidiary_purchase']+x['guarantee_call']-x['loan_repayment']
            financing_addback+=principal+x['interest']-taxshield+x['fees']+claims+financial_outflows
            unlevered_cash=x['cash_close']+financing_addback; operating_requirements.append(x['reserve']-(unlevered_cash-end['cash_close'])+extra*d(k+1)/12); unlevered.append(dict(month=k+1,cumulative_financing_addback=financing_addback,unlevered_cash=unlevered_cash,taxshield=taxshield))
        operating_reserve=max(Z,max(operating_requirements)); cash_bridge=max(Z,end['cash_close']-operating_reserve); distributable=max(Z,end['cash_close']-reserve_required); terminal_lost=sum((x['lost_units'] for x in transition),Z); funded=end['cash_close']+D('1e-20')>=reserve_required and terminal_lost<=D('1e-20')
        claims=end['tax_claim_close']+end['other_claim_close']+d(i['claims']['employee_benefits'])
        attempt=dict(next_sales=sum((x['sales'] for x in transition),Z),next_nopat=nopat,next_da=da,replacement_capex=replacement,physical_growth_capex=physical_growth,working_capital_reinvestment=working_capital,economic_reinvestment_floor=economic_floor,growth_reinvestment=growth_reinvestment,extra_terminal_cash_need=extra,fcff=fcff,funding_reserve=reserve_required,operating_reserve=operating_reserve,cash_bridge=cash_bridge,distributable_cash=distributable,debt_service_earmarked_cash=max(Z,cash_bridge-distributable),cash_at_exit=end['cash_close'],deposit_uncertain_excluded=end['deposits_close'],debt=end['debt_close'],senior_claims=claims,shares=end['shares_close'],terminal_lost_units=terminal_lost,funded=funded,unlevered_transition=unlevered,transition=[dict(month=k+1,cash_after_distribution_and_extra=x['cash_close']-distributable-extra*d(k+1)/12,reserve=x['reserve'],new_finance=x['new_draw']+x['esop_cash']) for k,x in enumerate(transition)])
        if funded:
            ev=max(Z,fcff/(wacc-g)); core_equity=max(Z,ev+cash_bridge-end['debt_close']-claims); contribution=core_equity*CR/end['shares_close']; entry=d(i['entry_price'])*(O+d(s['entry_cost'])); net=contribution*(O-d(s['exit_cost'])); core_only_irr=(net/entry)**(O/years)-O if net>0 else D(-1)
            # This is a contribution, not a total-company price: acquired stakes and loan recovery are NS.
            multiple_ev=terminal_basis['ebitda']*d(s['exit_ebitda_multiple']); multiple_core=max(Z,multiple_ev+cash_bridge-end['debt_close']-claims)
            hurdles={str(h):dict(core_only_entry=net/((O+h)**years*(O+d(s['entry_cost']))),required_total_exit_equity=entry*(O+h)**years/(O-d(s['exit_cost']))*d(end['shares_close'])/CR,required_noncore_exit_equity=entry*(O+h)**years/(O-d(s['exit_cost']))*d(end['shares_close'])/CR-core_equity) for h in [D('.12'),D('.15'),D('.18')]}
            operating_pv=sum((r['operating_fcff']/(O+wacc)**(d(r['month'])/12) for r in rows[:n]),Z); discounted_terminal=ev/(O+wacc)**years; operating_dcf=operating_pv+discounted_terminal
            terminal=dict(attempt,explicit_fcff_present_value=operating_pv,terminal_enterprise_present_value=discounted_terminal,core_operating_dcf=operating_dcf,core_enterprise_value=ev,core_equity_contribution=core_equity,core_per_share_contribution=contribution,core_only_illustrative_irr=core_only_irr,common_equity_irr=None,total_company_price=None,noncore_equity_value=None,noncore_valuation_status='NS: subsidiary operating forecasts, current net debt and cash ownership, and parent-loan recovery are not established.',multiple_core_equity_contribution=multiple_core,multiple_core_per_share_contribution=multiple_core*CR/end['shares_close'],hurdles=hurdles,core_contribution_present_value=core_equity/(O+wacc)**years,terminal_value_share_of_operating_dcf=discounted_terminal/operating_dcf if operating_dcf>0 else None,loan_claim_excluded=end['loan_claim_close'],acquired_investment_cost_not_added=acquired_cost)
        else:
            failure=dict(month=n+12,date=month_date(n+12),shortfall=max(Z,reserve_required-end['cash_close']),negative_cash=False,reason='Terminal replacement, growth reinvestment, reserve or physical-capacity gate failure. No rescue assumed.')
    annual=[]
    for y in range(1,years+1):
        a=[x for x in rows if x['year']==y and x['phase']=='horizon']
        if not a: continue
        sums=['sales','units','ebitda','ebit','da','tax','interest','capex','growth_capex','maintenance_capex','ipo_capex','collections','supplier_cash','new_draw','subsidiary_advance','guarantee_call','esop_cash']; rec={k:sum((x[k] for x in a),Z) for k in sums}; rec.update(year=y,months=len(a),cash_close=a[-1]['cash_close'],debt_close=a[-1]['debt_close'],shares_close=a[-1]['shares_close'],capacity=a[-1]['capacity'],ar_close=a[-1]['ar_close'],inventory_close=a[-1]['inventory_close'],ap_close=a[-1]['ap_close']); annual.append(rec)
    summary=dict(path_id=path_id,years=years,kind=s['kind'],source_eligible=False,common_equity_irr=None,total_company_price=None,core_only_illustrative_irr=None if terminal is None else terminal['core_only_illustrative_irr'],core_per_share_contribution=None if terminal is None else terminal['core_per_share_contribution'],failure_month=None if failure is None else failure['month'],failure_reason=None if failure is None else failure['reason'],failure_shortfall=None if failure is None else failure['shortfall'],funded_terminal=terminal is not None,terminal_sales=None if exitrow is None else terminal_basis['sales'],total_horizon_capex=sum((x['capex'] for x in rows if x['phase']=='horizon'),Z),new_debt_gross=cumdraw,final_shares=rows[-1]['shares_close'],deposits_released=sum((x['deposit_release']+x['restricted_ipo_use'] for x in rows),Z),conditional_facility_limit=s['new_debt_limit'],unit_growth=s['unit_growth'],ebitda_margin=s['ebitda_margin'],label=s['label'])
    return dict(path_id=path_id,years=years,spec=s,source_eligible=False,source_limit=i['source_eligibility_limit'],monthly=rows,annual=annual,failure=failure,terminal_attempt=attempt,terminal=terminal,summary=summary)
