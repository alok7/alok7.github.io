"""Predeclared scenario grid. Conditional finance never becomes source-eligible."""
from copy import deepcopy
from decimal import Decimal as D

def base(i):
    return dict(label='Source-bounded core operating base; current liquidity/renewals and group fair value not established',kind='source_bounded',unit_growth='.07',price_growth='.02',customer_loss='0',ebitda_margin='.11',material_ratio=i['derived']['material_ratio'],fixed_opex_fraction='.55',collection_delay=4,opening_ar_months=5,opening_ar_recovery='1',supplier_delay=1,opening_ap_months=2,inventory_days='240',inventory_impairment='0',inventory_impairment_month=3,customer_advance_share='.025',customer_advance_application='.025',other_assets_growth_ratio='.015',maintenance_ratio='.02',replacement_rate='.08',incremental_da_rate='.10',tax_rate='.26',tax_settlement_month=3,other_claim_months=6,capex_lead_months=6,remaining_ipo_capex_assumption=i['claims']['remaining_ipo_core_capex'],ipo_spend_months=6,capacity_buffer='1.20',expansion_gate=False,max_capacity='10000',capex_per_vertical_capacity='.0035',deposit_release_gate=False,deposit_release_amount='0',deposit_release_month=1,ipo_restricted_release_gate=False,cash_credit_rate='.105',term_rate='.105',maturity_policy='source_emi_maturity',term_monthly_principal=i['derived']['monthly_term_principal_assumption'],cash_credit_renewal_gate=False,cash_credit_call_month=12,annual_facility_fees='.10',minimum_cash='.50',reserve_cost_months='.15',new_debt_gate=False,new_debt_limit='0',cumulative_debt_limit='0',new_debt_rate='.135',draw_fee='.015',new_debt_tenor=36,new_debt_renewal_gate=False,renewal_fee='.01',additional_subsidiary_advance='1.50',subsidiary_advance_month=1,seedlab_purchase='.0143',seedlab_purchase_month=1,loan_repayment_fraction='0',loan_repayment_month=48,guarantee_call='0',guarantee_call_month=12,esop_exercise_shares=0,esop_exercise_month=48,wacc='.16',terminal_growth='.04',terminal_roic='.14',exit_ebitda_multiple='8',entry_cost='.01',exit_cost='.01')

def specifications(i):
    out=[]
    def add(name,years,kind,**changes):
        s=base(i);s.update(changes);s['kind']=kind;out.append(dict(path_id=name,years=years,kind=kind,spec=s))
    conditional=dict(label='Conditional core recovery: all FDs deployable, CC renewed, new financing and capacity assumed; not a company target',deposit_release_gate=True,deposit_release_amount=i['opening']['deposits_uncertain_restriction'],cash_credit_renewal_gate=True,new_debt_gate=True,new_debt_limit='25',cumulative_debt_limit='50',new_debt_renewal_gate=True,expansion_gate=True,max_capacity='20000',inventory_days='210',collection_delay=4)
    for years in [5,10]:
        add(f'bear_{years}y',years,'source_bounded',label='Customer loss, collections, inventory damage, margin and repayment stress',unit_growth='-.03',price_growth='0',customer_loss='.15',ebitda_margin='.08',collection_delay=6,opening_ar_months=7,opening_ar_recovery='.90',inventory_days='290',inventory_impairment='.10',capex_lead_months=12)
        add(f'base_{years}y',years,'source_bounded')
        add(f'bull_{years}y',years,'source_bounded',label='Operating improvement without invented funding permission',unit_growth='.14',price_growth='.03',ebitda_margin='.14',inventory_days='180',collection_delay=3,opening_ar_months=4)
        add(f'conditional_reference_{years}y',years,'conditional_reference',**conditional)
        variations=[('no_new_debt',dict(new_debt_gate=False)),('no_fd_release',dict(deposit_release_gate=False)),('no_cc_renewal',dict(cash_credit_renewal_gate=False)),('no_new_renewal',dict(new_debt_renewal_gate=False)),('no_inventory_normalization',dict(inventory_days='245')),('slow_collections',dict(collection_delay=6,opening_ar_months=7)),('delayed_capex',dict(capex_lead_months=12)),('capex_inflation',dict(capex_per_vertical_capacity='.00525')),('prima_full_limit',dict(additional_subsidiary_advance='20.00')),('guarantee_hdfc_call',dict(guarantee_call='8.632')),('guarantee_old_pool_call',dict(guarantee_call='20.9115')),('esop_full_exercise',dict(esop_exercise_shares=300000)),('deposit_ipo_only',dict(deposit_release_gate=False,ipo_restricted_release_gate=True)),('no_future_sub_outflow',dict(additional_subsidiary_advance='0',seedlab_purchase='0')),('term_immediate_call',dict(maturity_policy='immediate_call')),('multiple_normalization',dict(exit_ebitda_multiple='6')),('terminal_roic_8',dict(terminal_roic='.08')),('terminal_roic_10',dict(terminal_roic='.10'))]
        for label,v in variations:add(f'conditional_{label}_{years}y',years,'linked_sensitivity',**dict(conditional,**v))
        for w in ['.13','.15','.17','.19']:
            for g in ['.02','.04','.06']:add(f'wacc_growth_{years}y_w{w}_g{g}',years,'wacc_growth',**dict(conditional,wacc=w,terminal_growth=g))
        for growth in ['0','.05','.10','.15','.20']:
            for margin in ['.08','.11','.14']:add(f'growth_margin_{years}y_v{growth}_m{margin}',years,'growth_margin',**dict(conditional,unit_growth=growth,ebitda_margin=margin))
        for pct in range(0,41,2):
            growth=str(D(pct)/100);add(f'reverse_{years}y_v{growth}',years,'reverse',**dict(conditional,unit_growth=growth,max_capacity='30000',new_debt_limit='40',cumulative_debt_limit='80'))
        for growth in ['.10','.20','.30','.40','.60']:
            for margin in ['.11','.14','.17']:
                add(f'target_{years}y_v{growth}_m{margin}',years,'target',**dict(conditional,label='Expanded conditional target feasibility envelope; not evidence of financing or achievable volume',unit_growth=growth,ebitda_margin=margin,max_capacity='60000',new_debt_limit='80',cumulative_debt_limit='160'))
    return out

def target_tests(paths,i):
    result=[]; entry=D(i['entry_price']); entrycost=D('1.01'); exitcost=D('.99')
    for years in [5,10]:
        candidates=[x for x in paths if x['years']==years and x['spec']['kind'] in ['reverse','target']]
        for kind,value in [('annual_hurdle','.12'),('annual_hurdle','.15'),('annual_hurdle','.18'),('wealth_multiple','3'),('wealth_multiple','5'),('wealth_multiple','10')]:
            required=(1+D(value))**years if kind=='annual_hurdle' else D(value)
            viable=[x for x in candidates if x['terminal'] is not None]; crossing=[x for x in viable if x['terminal']['core_per_share_contribution']*exitcost/(entry*entrycost)>=required]
            best=max(viable,key=lambda x:x['terminal']['core_per_share_contribution']) if viable else None
            least=min(crossing,key=lambda x:(D(x['spec']['unit_growth']),D(x['spec']['ebitda_margin']))) if crossing else None
            result.append(dict(years=years,target_type=kind,target=value,required_net_multiple=required,all_tested_paths=len(candidates),funded_paths=len(viable),failed_paths=len(candidates)-len(viable),crossing_paths=len(crossing),least_tested_growth_crossing=None if least is None else least['path_id'],least_tested_growth=None if least is None else least['spec']['unit_growth'],least_tested_growth_margin=None if least is None else least['spec']['ebitda_margin'],best_funded_path=None if best is None else best['path_id'],best_core_only_net_multiple=None if best is None else best['terminal']['core_per_share_contribution']*exitcost/(entry*entrycost),source_eligible_crossings=0,status='Only a core-contribution sufficiency test. Subsidiary value remains NS; failed financing trials retained. Grid resolution is not a continuous threshold.'))
    return result
