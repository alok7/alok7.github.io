"""Producer recurrence audit. Separate independent_replay.py does not import this module."""
from decimal import Decimal as D,localcontext
Z=D(0)
def audit(path,i):
    checks=0
    def same(a,b,label):
        nonlocal checks
        a=D(a);b=D(b)
        if abs(a-b)>D('1e-24')*max(D(1),abs(a),abs(b)): raise AssertionError((path['path_id'],label,a,b))
        checks+=1
    with localcontext() as ctx:
        ctx.prec=40
        last=None;s=path['spec']
        for r in path['monthly']:
            cash=r['cash_open']+r['collections']+r['advance_receipts']+r['deposit_release']+r['restricted_ipo_use']+r['loan_repayment']-r['supplier_cash']-r['opex']-r['interest']-r['tax']-r['tax_settlement']-r['other_settlement']-r['other_assets_change']-r['capex']-r['principal_term']-r['principal_wc']-r['principal_new']-r['fees']-r['subsidiary_advance']-r['subsidiary_purchase']-r['guarantee_call']+r['new_draw']-r['draw_fee']+r['esop_cash']
            same(r['cash_close'],cash,'cash');same(r['deposits_close'],r['deposits_open']-r['deposit_release']-r['restricted_ipo_use'],'deposits');same(r['ar_close'],r['ar_open']+r['credit_sales']-r['collections']-r['receivable_writeoff'],'AR');same(r['inventory_close'],r['inventory_open']-r['inventory_impairment']+r['purchases']-r['material'],'inventory');same(r['ap_close'],r['ap_open']+r['purchases']-r['supplier_cash'],'AP');same(r['advances_close'],r['advances_open']+r['advance_receipts']-r['advance_application'],'customer advances');same(r['other_assets_close'],r['other_assets_open']+r['other_assets_change'],'operating assets');same(r['other_claim_close'],r['other_claim_open']-r['other_settlement'],'other claims');same(r['tax_claim_close'],r['tax_claim_open']-r['tax_settlement'],'tax claims');same(r['ppe_close'],r['ppe_open']+r['commissioned']+r['maintenance_capex']-r['da'],'PPE');same(r['pipeline_close'],r['pipeline_open']+r['growth_capex']+r['ipo_capex']-r['commissioned'],'pipeline');same(r['debt_close'],r['debt_open']+r['new_draw']-r['principal_term']-r['principal_wc']-r['principal_new'],'debt');same(r['shares_close'],r['shares_open']+r['esop_issued'],'shares');same(r['esop_cash'],D(r['esop_issued'])*D(i['claims']['esop_strike'])/D(10000000),'ESOP cash');same(r['loan_claim_close'],r['loan_claim_open']+r['subsidiary_advance']-r['loan_repayment'],'related loans');same(r['interest'],(r['wc_open']*D(s['cash_credit_rate'])+r['new_debt_open']*D(s['new_debt_rate']))/12+r['facility_interest']+r['new_draw']*D(s['new_debt_rate'])/12,'current draw interest');same(r['sales'],r['units']*r['price'],'panel equivalent revenue');same(r['ebitda'],r['sales']-r['material']-r['opex'],'EBITDA');same(r['ebit'],r['ebitda']-r['da']-r['inventory_impairment']-r['receivable_writeoff'],'EBIT');same(r['tax'],max(Z,r['ebit']-r['interest'])*D(s['tax_rate']),'tax');same(r['shortfall'],max(Z,r['reserve']-r['cash_close']),'funding gap');same(r['operating_fcff'],r['collections']+r['advance_receipts']-r['supplier_cash']-r['opex']-max(Z,r['ebit'])*D(s['tax_rate'])-r['capex']-r['other_assets_change'],'operating FCFF')
            assert r['units']<=r['capacity']/12+D('1e-24');assert r['deposits_close']>=-D('1e-24');assert r['shares_close']<=i['issued_shares']+i['claims']['esop_pool_approved'];checks+=3
            if r['phase']=='terminal_transition':assert r['new_draw']==0 and r['esop_issued']==0;checks+=1
            if last:
                for k in ['cash','deposits','ar','inventory','ap','advances','other_assets','other_claim','tax_claim','ppe','pipeline','wc','term','new_debt','shares','loan_claim']:
                    same(r[k+'_open'],last[k+'_close'],'continuity '+k)
            last=r
        assert path['source_eligible'] is False and path['summary']['common_equity_irr'] is None and path['summary']['total_company_price'] is None;checks+=1
        if path['failure']:
            assert path['terminal'] is None and path['summary']['core_only_illustrative_irr'] is None;checks+=1
        else:
            t=path['terminal'];same(t['fcff'],t['next_nopat']+t['next_da']-t['replacement_capex']-t['growth_reinvestment'],'earned FCFF');same(t['core_enterprise_value'],max(Z,t['fcff']/(D(s['wacc'])-D(s['terminal_growth']))),'terminal EV');same(t['core_equity_contribution'],max(Z,t['core_enterprise_value']+t['cash_bridge']-t['debt']-t['senior_claims']),'core claim bridge');same(t['core_per_share_contribution'],t['core_equity_contribution']*10000000/t['shares'],'per share');assert t['replacement_capex']>=t['next_da'];assert t['growth_reinvestment']>=t['economic_reinvestment_floor'];checks+=2
            for r in t['transition']:assert r['cash_after_distribution_and_extra']+D('1e-20')>=r['reserve'] and r['new_finance']==0;checks+=1
    return dict(path_id=path['path_id'],checks=checks,status='PASS')
