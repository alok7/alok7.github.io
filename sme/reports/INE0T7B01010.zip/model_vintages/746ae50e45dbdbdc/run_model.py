"""One-command deterministic monthly model, canonical archive and audit build."""
from pathlib import Path
import json,gzip,hashlib,csv,shutil
from decimal import Decimal as D
from build_model_inputs import build,exact
from model import run
from scenarios import specifications,target_tests
from model_audit import audit
P=Path(__file__).resolve().parent

def dump(path,object):path.write_text(json.dumps(exact(object),indent=2,ensure_ascii=False)+'\n')
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def main():
    # Keep original complete canonical trials before any regeneration.
    archive=P/'model_vintages';archive.mkdir(exist_ok=True)
    old=P/'canonical_paths.json.gz'
    if old.exists():
        oldhash=sha(old);dest=archive/oldhash[:16];dest.mkdir(exist_ok=True)
        for file in ['canonical_paths.json.gz','model_inputs.json','scenario_inputs.json','model_summary.json','model_audit.json']:
            src=P/file
            if src.exists() and not(dest/file).exists():shutil.copy2(src,dest/file)
    inputs=build();specs=specifications(inputs);paths=[];audits=[]
    for spec in specs:
        result=run(inputs,spec['spec'],spec['years'],spec['path_id']);audits.append(audit(result,inputs));paths.append(result)
    payload=dict(format='Canonical unrounded Decimal strings. Every scenario, failed trial, monthly scalar, terminal reserve and selector is retained.',inputs=inputs,paths=paths,target_tests=target_tests(paths,inputs),code_sha256={file:sha(P/file) for file in ['model.py','scenarios.py','run_model.py','model_audit.py','build_model_inputs.py']})
    raw=json.dumps(exact(payload),sort_keys=True,separators=(',',':'),ensure_ascii=False).encode();old.write_bytes(gzip.compress(raw,compresslevel=9,mtime=0))
    summary=dict(company=inputs['company'],whole_company_valuation_status='NS',supported_base_irr=None,total_paths=len(paths),monthly_rows=sum(len(p['monthly']) for p in paths),funded_core_contribution_paths=sum(p['terminal'] is not None for p in paths),failed_paths=sum(p['failure'] is not None for p in paths),source_eligible_paths=0,source_limit=inputs['source_eligibility_limit'],canonical_sha256=sha(old),canonical_uncompressed_sha256=hashlib.sha256(raw).hexdigest(),main_scenarios=[p['summary'] for p in paths if p['spec']['kind'] in ['source_bounded','conditional_reference']],target_tests=payload['target_tests'],core_contribution_hurdles=[dict(path_id=p['path_id'],hurdles=p['terminal']['hurdles']) for p in paths if p['spec']['kind']=='conditional_reference' and p['terminal'] is not None])
    dump(P/'model_summary.json',summary);dump(P/'scenario_inputs.json',specs);dump(P/'model_audit.json',dict(status='PASS',total_paths=len(paths),total_checks=sum(a['checks'] for a in audits),results=audits,canonical_sha256=sha(old)))
    with (P/'trial_index.csv').open('w',newline='') as f:
        records=[exact(x['summary']) for x in paths];writer=csv.DictWriter(f,fieldnames=list(records[0]));writer.writeheader();writer.writerows(records)
    with (P/'annual_paths.csv').open('w',newline='') as f:
        records=[dict(path_id=p['path_id'],**exact(a)) for p in paths for a in p['annual']];writer=csv.DictWriter(f,fieldnames=list(records[0]));writer.writeheader();writer.writerows(records)
    # A frozen first generated complete trial, never overwritten by tuning or repairs.
    first=P/'first_trial_summary.json'
    if not first.exists():dump(first,summary)
    current_vintage=archive/sha(old)[:16];current_vintage.mkdir(exist_ok=True)
    for file in ['canonical_paths.json.gz','model_inputs.json','scenario_inputs.json','model_summary.json','model_audit.json','model.py','scenarios.py','run_model.py','model_audit.py','build_model_inputs.py','independent_replay.py']:
        if not(current_vintage/file).exists():shutil.copy2(P/file,current_vintage/file)
    print(json.dumps(exact({k:v for k,v in summary.items() if k not in ['source_limit','main_scenarios','target_tests','core_contribution_hurdles']}),indent=2))
if __name__=='__main__':main()
