"""Package only explicit authored inputs/outputs and local reproducibility evidence."""
from pathlib import Path
import json,hashlib,zipfile
P=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def main():
 r=json.loads((P/'company_record.json').read_text());names=sorted(set(r['authored_input_sha256'])|set(r['output_sha256'])|{'company_record.json','build_manifest.json','rebuild_attestation.json','verification.json','README.md','package.py'})
 assert all((P/n).is_file()for n in names)
 assert all(not n.endswith(('.pdf','.png','.pyc'))for n in names)
 for n in names:
  assert not n.startswith('/')and '..'not in Path(n).parts
 manifest={'files':{n:{'sha256':sha(P/n),'bytes':(P/n).stat().st_size}for n in names},'source_safe':True,'original_documents_included':False,'inputs':list(r['authored_input_sha256']),'outputs':list(r['output_sha256']),'research_position':367,'isin':'INE0T7B01010','publication_status':'Not published','scope':'Full authored report and all current/retained model values; numerical reproducibility is not current source eligibility.'}
 (P/'archive_manifest.json').write_text(json.dumps(manifest,sort_keys=True,indent=2)+'\n');names+=['archive_manifest.json']
 identities=[]
 for kind,level in [('compact',9),('full',1)]:
  path=P/f'SME_367_Shivalic_Power_Control_20261020_source_safe_{kind}.zip'
  with zipfile.ZipFile(path,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=level)as z:
   for n in names:
    q=zipfile.ZipInfo('Shivalic_Power_Control_367/'+n,date_time=(2026,10,20,0,0,0));q.compress_type=zipfile.ZIP_DEFLATED;q.external_attr=0o644<<16;z.writestr(q,(P/n).read_bytes(),compresslevel=level)
  with zipfile.ZipFile(path)as z:
   assert z.testzip()is None
   for n in names:assert hashlib.sha256(z.read('Shivalic_Power_Control_367/'+n)).hexdigest()==sha(P/n)
  identities.append({'kind':kind,'filename':path.name,'sha256':sha(path),'bytes':path.stat().st_size,'members':len(names)})
 (P/'archive_identities.json').write_text(json.dumps(identities,sort_keys=True,indent=2)+'\n');print(json.dumps(identities))
if __name__=='__main__':main()
