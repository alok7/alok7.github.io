# Shivalic Power Control: economic peer evidence

Research cutoff: 20 October 2026. Prepared 24 October 2026. Currency: INR crore unless stated. FY25/FY26 mean years ended 31 March 2025/2026. All core financial comparisons below are **standalone with standalone**, using FY25 comparatives within the same FY26 source. This is a business-economics comparison, not a valuation ranking.

## Executive judgment

**Vivid Electromech is the closest product/economic comparator of the four researched. Marine Electricals' Industry segment is the most useful scaled operating comparator, but its company-level cash flow also contains marine/defence activities. Saakshi is a legitimate control-panel manufacturing comparator with a materially different product mix. RMC belongs in the adjacent, lower-weight reference set, not a panel-maker valuation median.**

The common lesson is not that a high margin proves superior economics. Cash conversion and working-capital funding matter: FY26 operating EBITDA was positive at all four, but CFO after tax was negative at Marine and RMC, weak relative to EBITDA at Vivid, and much stronger at Saakshi. Every company in this set spent more on the selected gross capex cash-flow lines than it generated in CFO in FY26. This is a one-year observation, not proof of permanent poor economics or insolvency.

## Comparable method and numerical snapshot

Operating EBIT = profit before exceptional items and tax + finance cost - other income. Operating EBITDA = that EBIT + depreciation/amortisation. Divide both by **revenue from operations**, not total income. These are analyst calculations, not management-adjusted EBITDA. They retain all items recorded within operating expenses, including litigation costs. This removes the most obvious inconsistent treatment of interest/other income but does not homogenise product mix, leasing, accounting standards or expenses.

| Company / scope | FY25 revenue | FY26 revenue | FY25 op. EBITDA margin | FY26 op. EBITDA margin | FY25 CFO | FY26 CFO | FY25 capex cash | FY26 capex cash |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| Marine, standalone | 700.58 | 746.94 | 8.91% | 10.85% | 45.56 | -28.87 | 16.76 | 15.54 |
| Vivid, standalone | 155.32 | 200.14 | 18.09% | 22.59% | 6.74 | 9.31 | 1.64 | 35.55 |
| Saakshi, standalone | 92.43 | 115.51 | 11.16% | 19.24% | 3.02 | 17.58 | 15.20 | 25.67 |
| RMC, standalone | 315.88 | 303.47 | 16.36% | 12.50% | 11.77 | -18.63 | 9.89 | 14.59 |

Full EBIT, borrowings, cash, receivables, inventory, payables, simple working capital and calculations are in `peer_metrics.csv`. Each raw input is traced in `peer_source_ledger.csv`; primary documents and dated provenance are in `peer_source_register.csv`.

### Cash and capital definitions

- CFO is the reported net operating cash flow **after tax**, before financing interest where separately classified. CFO/EBITDA is a directional conversion measure, not a fully comparable cash-tax/interest-adjusted return.
- Capex is gross cash spent on PPE/intangibles/CWIP and explicit capital-advance lines, not the entire investing cash flow. Marine's line includes investment property and movements in capital creditors/advances; Vivid includes PPE, intangibles and CWIP but not its separately described loans/advances; Saakshi includes fixed-asset purchases/CWIP plus capital advances; RMC uses its PPE/CWIP purchase line. These differences are material and disclosed, not silently netted.
- Gross borrowings sums current and non-current borrowings. Separately reported lease liabilities are excluded. Reported cash equivalents and other bank balances are separate: bank deposits cannot all be treated as freely available net-debt offsets.
- Simple operating working capital = receivables + inventory - trade payables. It intentionally excludes contract assets, advances, other operating assets/liabilities and taxes. Closing receivable days = year-end receivables/revenue × 365, a snapshot proxy, **not collection DSO based on average balances**.
- Do not rank reported ROCE: definitions differ and some omit an explicit averaging convention.

## 1. Vivid Electromech: closest product comparison, weak cash conversion

Vivid's FY26 mix is 79.84% LV panels and 15.07% MV panels of product/trading/service sales, with LV ArTu K-design panels alone 64.52%. Its data-centre/technology customers are 49.95% of that sales base, versus 35.80% in FY25. This makes it a strong panel-engineering comparator but one with a concentrated end-market and product/OEM-architecture mix. The mix denominator is ₹200.07 crore, slightly below ₹200.14 crore operating revenue, because other operating revenue is excluded. [Vivid presentation, cover letter 5 June 2026; PDF pp29-30, printed slides24-25](https://nsearchives.nseindia.com/corporate/VIVID_09062026115012_Intimation_and_Presentation.pdf)

Audited revenue increased from ₹155.32 crore to ₹200.14 crore. Normalised operating EBITDA increased from ₹28.10 crore to ₹45.21 crore; operating EBIT margin rose from 16.88% to 21.89%. CFO of ₹9.31 crore was only 20.6% of operating EBITDA, versus 24.0% in FY25. Receivables rose from ₹60.55 crore to ₹116.50 crore, taking the closing receivable-days proxy from 142 to 212 days. Gross borrowings rose from ₹4.23 crore to ₹33.30 crore. These are real capital-absorption signals, not merely a margin story. [Audited results, approved/signed 14 May 2026; PDF pp4-7](https://vividgroup.in/wp-content/uploads/2026/06/Audited-Financial-Results_H2_2025-26.pdf)

**Avoid three traps.** (1) The presentation's ₹201.09 crore headline is total income; its ₹46.15 crore EBITDA includes other income and its 22.95% margin divides by total income. (2) Audited cash capex is ₹22.1693 crore PPE + ₹0.0163 crore intangibles + ₹13.3646 crore CWIP = ₹35.5502 crore, not just the presentation's approximately ₹22 crore investment headline. (3) FY26 reported cash equivalents of ₹0.5574 crore include ₹0.2564 crore deposits held as margin/security. Total cash-and-bank balances are ₹2.2677 crore; do not equate either subtotal with unrestricted cash. The presentation itself also contains inconsistent growth percentages, unit labels and a listing-date sentence that places an April 2026 event 'during' FY26. Prefer audited base numbers. [Results PDF pp5-7; presentation PDF pp4,37-39]

The presentation reports ROCE of 84.75%/48.32% for FY25/FY26 and notes exclusion of revaluation reserves, but does not provide enough denominator detail on that slide for a matched ROCE ranking. [Presentation PDF p35, slide28]

## 2. Marine Electricals: use Industry segment for operations, not group cash attribution

The Industry segment supplies power-distribution solutions to data centres, industrial facilities and large buildings. Its revenue was ₹371.04 crore in FY25 and ₹412.77 crore in FY26; segment result was ₹24.95 crore and ₹39.98 crore. Result/revenue therefore improved from **6.72% to 9.68%**. This is a segment-result margin, not EBITDA: finance costs, exceptional items and unallocable income/expenses sit below the segment-result total. The company explicitly says the CODM does not separately review segment assets/liabilities, so segment ROCE and cash conversion cannot be produced from this disclosure. [FY26 annual report, note49, printed214-215 / company-PDF219-220](https://www.marineelectricals.com/images/report/Marine-Electricals-Annual-Report-2026.pdf)

At the standalone-company level, op. EBITDA margin rose to 10.85%, but CFO moved from +₹45.56 crore to -₹28.87 crore. FY26 operating cash flow includes a ₹94.70 crore outflow from receivables and ₹20.83 crore from other assets. Closing receivables rose to ₹375.40 crore, and gross borrowings to ₹57.54 crore from ₹28.83 crore. Those company-wide cash flows must **not** be represented as Industry-segment cash flows. [Printed167-171 / PDF172-176]

The table retains ₹16.41 crore arbitration-claim expense in FY26 and ₹10.78 crore provision against legal contingency in FY25, both within other expenses. A separately labelled ₹1.21 crore FY26 exceptional loss is excluded by the pre-exception method. Reported standalone ROCE is 16.78%/17.65%, with capital employed defined as tangible net worth + total debt + deferred-tax liability. It is not the same denominator as an operating invested-capital calculation. [Printed169,204,224 / PDF174,209,229]

Annual report transmission is verified by the company letter dated **5 September 2026**, whose NSE filename records 6 September. [NSE cover PDF p1](https://nsearchives.nseindia.com/corporate/MARINE_06092026000501_Signed_Regulation_30_Annual_Report_2026.pdf)

## 3. Saakshi: genuine control-panel OEM supplier, diversified and capital intensive

Integrated Control Systems & EV Solutions contributed 54.68% of FY26 sales, versus 56.40% in FY25. Engineered Mechanical Assemblies were 40.44%, wire harness 2.18%, precision medtech 0.63%, and others 2.07%. The company makes control panels/cabinets for industrial OEM applications, but a substantial and growing mechanical-assembly business prevents treating total-company margins as pure panel margins. Segment-profit allocation is unavailable: audited results use one 'Manufacturing' reporting segment. [Annual report printed/PDF14,24; notice 8 September 2026](https://smtpl.co/files/SMPL_Detailed%20Annual%20Report%202025-26.pdf); [audited results 26 May 2026, PDF8](https://smtpl.co/files/Saakshi_2526.pdf)

Revenue from operations rose from ₹92.4311 crore to ₹115.5064 crore. Op. EBITDA rose from ₹10.3115 crore to ₹22.2191 crore; margin improved from 11.16% to 19.24%. CFO rose from ₹3.0226 crore to ₹17.5836 crore, substantially stronger conversion than the other three in FY26, but gross capex including capital advances was ₹25.6711 crore. Gross borrowings increased from ₹17.8235 crore to ₹25.4535 crore; cash equivalents fell from ₹3.2646 crore to ₹1.7961 crore. This is a cleaner FY26 collection/cash-conversion outcome, not evidence that growth is capital-free. [Audited results PDF5-7]

**Source discrepancy to preserve:** the annual-report corporate summary compares FY26 operating revenue ₹115.5064 crore with FY25 total income ₹93.0033 crore, and reports FY25 EBITDA ₹10.1168 crore/10.95%. The audited P&L instead gives PBT ₹6.5885 crore + finance ₹0.4052 crore + D&A ₹3.89 crore - other income ₹0.5722 crore = **₹10.3115 crore operating EBITDA**. FY26 reconciles exactly to the corporate summary's ₹22.2191 crore using the same operating definition. Use the audited, consistently defined series; do not silently propagate the summary's FY25 number. Financial scans have OCR errors, so the clean company-hosted results PDF5-7 is the numerical source. [Annual report PDF22-23; audited results PDF6]

## 4. RMC Switchgears: adjacent grid/EPC reference, not a pure panel peer

RMC's FY26 standalone revenue comprised ₹234.06 crore works-contract services and ₹67.55 crore product sales, plus scrap/other operating items. Works-contract services therefore represented roughly 77% of total operating revenue, versus roughly 56% in FY25. EPC revenue is recognised over time using a cost-to-cost input method. This customer-contract model has different execution, receivable, subcontractor and working-capital economics from a predominantly industrial panel supplier. [FY26 annual report, printed96-97,114 / PDF49,58](https://rmcindia.in/wp-content/uploads/2026/09/RMC-AR-2025-26.pdf)

Standalone revenue fell from ₹315.88 crore to ₹303.47 crore; op. EBITDA margin fell from 16.36% to 12.50%. CFO fell from +₹11.77 crore to -₹18.63 crore, gross borrowings increased from ₹56.65 crore to ₹103.08 crore, and receivables rose from ₹147.25 crore to ₹175.78 crore. Gross capex was ₹14.59 crore in FY26, yielding CFO less the selected capex line of -₹33.22 crore. [Printed92-94 / PDF47-48]

Use the FY25 comparator **as restated inside FY26**: FY26 is the first Ind AS reporting year; importing FY25 historical GAAP figures from a different source creates a false comparison. Reported ROCE is 42.62%/19.81%, described as profit before interest and taxes over total net worth and borrowings, but it is not comparable to Marine/Vivid's reported definitions without reconciliation. [Printed96,132-133 / PDF49,67]

Accounts are approved 29 May 2026; the report includes the September 2026 AGM notice. An exact public-filing/upload date was not verified from an accessible primary cover letter. A BSE original attachment attempt returned403. The company-hosted original is downloaded and financial periods/dates are verified; **do not cite 26 August as verified primary-source publication date**.

## How to use this set for SPCL

1. Start with Vivid's comparable panel product economics and Marine Industry's segment-result margins. Use Saakshi as an industrial-OEM manufacturing cross-check, RMC as a lower-weight warning about project execution and cash absorption.
2. Compare SPCL on the same operating-income exclusion, standalone scope, fiscal year and cash-capex definition. Retain any disclosed exceptional/one-off reconciliation separately.
3. Require a cash bridge: growth in receivables, inventory, supplier credit, contract assets/advances and margin deposits. A higher EBIT margin with weaker cash conversion does not by itself establish a moat.
4. Do not average reported ROCE or P/E multiples across this set. Product scope, public-market scale, leverage, accounting standards, cash restrictions and capital expansion are too different for an unqualified league table.

No substantive claim above relies on an aggregator. Aggregator search results were used only to discover original filings; all numerical evidence is from downloaded company/exchange originals. The RMC source-date limitation is explicit.
