### Working capital and incremental capital returns

At 31 March 2026 the core had inventory of INR 73.33 crore and receivables of INR 47.69 crore. Inventory comprised INR 31.53 crore of raw material, INR 18.33 crore of WIP and INR 23.46 crore of finished goods. Trade creditors were INR 11.11 crore and customer advances INR 3.80 crore. The core balance-sheet current ratio of 3.45 is therefore not the same as abundant spendable cash. The group has a larger perimeter: inventory INR 80.03 crore and receivables INR 57.98 crore.

The receivables ageing identifies INR 0.54361 crore as disputed and doubtful within the headline receivable balance. It is not appropriate to assert a matching allowance exists merely because the net balance is labelled unsecured and good. The remainder of the ageing is mostly less than six months; that is useful counterevidence against labelling the entire balance impaired. See company PDF pages 187–188 and 239.

For transparent return calculations, NOPAT is defined as (PBT + finance cost − all other income) × 75%, using a standardized 25% tax assumption. The simple core invested-capital proxy is receivables + inventory − trade payables + net PPE + intangibles. It excludes treasury cash and deposits, deferred tax, property advances and subsidiary investment.

From FY23 to FY26, this capital proxy increased from INR 52.53 crore to INR 129.14 crore. NOPAT rose by only INR 1.9181 crore. The endpoint incremental return is 2.50%. Deducting customer advances yields 2.57%. Expanding to operating advances, security deposits, operating accruals and employee-benefit funding produces approximately 2.46%; omitting statutory-payable funding or adding employee imprest leaves the result near 2.45%–2.46%. The FY21–FY26 sensitivity range is approximately 8.64%–9.01%. These are return-on-incremental-capital proxies, not individual project IRRs, and the endpoints do not identify causation.

The three-year PPE roll-forward is unusually useful: INR 6.32478 crore cash capex, less INR 5.30820 crore D&A and approximately INR 0.08672 crore carrying value of assets sold, reconciles to the INR 0.92990 crore increase in net PPE plus intangibles, to rounding. Simple ONWC increased INR 75.6781 crore over the same period. Thus nearly all incremental operating capital is working capital, not a large new plant. Restriction uncertainty over IPO deposits and the changed overdraft presentation does not drive this low incremental-return conclusion because both are excluded from these operating-capital definitions. FY26 subsidiary investment of INR 6.55008 crore is also excluded from the parent manufacturing calculation.



### Cash availability and cash-flow reconciliation

Standalone note 2.16, company PDF page 188, reports INR 16.8894 crore of cash and bank balances. Of this, INR 16.2297 crore is deposits with original maturity longer than three months; INR 0.39224 crore is cash in hand and INR 0.26749 crore employee imprest. The latter is operating float, not surplus liquidity. The note provides no bankwise lien/margin split or release dates, while debt security explicitly includes BG margin. Unrestricted deposit availability therefore remains unknown, not zero and not the entire FD balance.

Group note 2.16, company PDF page 240, shows bank current accounts INR 3.2209 crore, cash in hand INR 0.55934 crore, imprest INR 0.26749 crore and deposits INR 16.2297 crore, totalling INR 20.2774 crore. The group cash-flow note on page 227 instead allocates the same total to INR 19.6012 crore deposits and INR 0.6762 crore cash. Both pages were visually checked in the original PDF. The matching total does not resolve the nature or accessibility of its components. Subsidiary balances should not be treated as automatically upstreamable to parent shareholders.

FY25 cash-flow cash is net of INR 0.67694 crore overdraft. FY26 cash-flow opening cash retains this net basis, while year-end cash does not subtract INR 24.2773 crore core CC debt. The reported cash-flow change of negative INR 4.71122 crore differs from gross balance-sheet cash movement of negative INR 5.3880 crore by approximately the opening overdraft. This is an unresolved presentation bridge, not a reason to replace reported CFO with a fabricated cash number.

Group cash-flow opening cash of INR 22.7687 crore differs from FY25 closing INR 21.6005 crore. Acquired cash may contribute to the INR 1.1682 crore difference, but the statement does not supply the bridge. Group CFI also has no separately displayed acquisition payment despite parent investment outflow of INR 6.55008 crore. Do not use group CFI as clean evidence that acquisitions were free or that group CFO is purely organic.



### Debt, facilities and capex

Core gross debt was INR 27.5313 crore: INR 3.2540 crore long term plus INR 24.2773 crore HDFC cash credit repayable on demand. Group gross debt was INR 37.8766 crore, including Indian Bank overdraft of INR 8.2191 crore, current term maturities of INR 1.1744 crore, and additional subsidiary loans. Source: company PDF pages 179–182 and 231–234.

The core term-loan schedule lists HDFC vehicle loans maturing March 2027, August 2027 and July 2028; HDFC working-capital/MSME loans maturing June 2029 and July 2027; an ICICI HFCL property loan maturing June 2034; and a Bank of Baroda vehicle loan maturing February 2029. The JSON retains the reported balances, rates and available EMIs. Yet standalone current maturities are printed as nil despite continuing EMIs and several repeated prior-year balances. A reliable monthly principal-amortization ladder cannot be inferred from this presentation. Do not model zero amortization.

HDFC security includes stocks, debtors, plant/machinery, BG margin, personal guarantees and an equitable mortgage of the Faridabad industrial property. The ICICI loan is supported by a promoter-owned property. These property mortgages do not establish promoter share pledges. Current sanction letters, renewal dates, lender covenants, borrowing-base availability and unrestricted undrawn headroom were not located. The RHP's INR 30 crore WCDL sanction and 90-day tenor describe December 2023, not guaranteed 2026 funding availability.

The historical [CARE withdrawal](https://www.careratings.com/upload/CompanyFiles/PR/Shivalic%20Power%20Control%20Private%20Limited-07-17-2019.pdf), dated 17 July 2019, followed a company request and lender NOC/surrender of facilities. It is neither a current rating nor evidence of default or non-cooperation. Current rating evidence was not established.

FY26 cash capex was INR 2.1545 crore, including INR 1.0224 crore cars, INR 0.6044 crore building work and only INR 0.0806 crore plant/machinery. The PPE schedule's header says lakhs, but its row amounts are rupees, as verified against the balance-sheet net block; these were converted correctly. No CWIP or capitalized borrowing cost is reported. Capital-creditor lines are nil and capital-contract commitments are dashes at year end. This does not erase subsequent approved solar projects, subsidiary loans or guarantee commitments, which are recorded separately by the business research.

