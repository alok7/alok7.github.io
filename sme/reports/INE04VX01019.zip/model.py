"""Monthly conditional commodity cash/physical-capacity model. Standard library only, exact Decimal."""
from decimal import Decimal as D, ROUND_CEILING, localcontext
from collections import defaultdict
from copy import deepcopy
ZERO=D(0);ONE=D(1);CR=D(10000000)
def d(x):
 if isinstance(x,float):raise TypeError('Decimal strings required')
 return x if isinstance(x,D)else D(str(x))
def default():
 return {'volume_growth':'.10','price_growth':'.02','core_ebitda_margin':'.06','material_ratio':'.86','fixed_opex_fraction':'.25','export_fraction':'.2831676285142734808601150534','export_price_shock':'0','customer_loss':'0','domestic_delay':3,'export_delay':4,'opening_ar_months':6,'old_ar_start':7,'old_ar_months':18,'old_ar_recovery':'.85','opening_ap_months':3,'supplier_delay':2,'inventory_days':'100','procurement_seasonality':True,'inventory_impairment':'0','inventory_impairment_month':3,'operating_asset_growth_ratio':'.03','advance_recovery':'0','advance_recovery_month':12,'deposit_release':'0','deposit_release_month':1,'retained_warrant_cash':'14.91','initial_capacity_tonnes':'18000','initial_realisation_crore_per_tonne':'.0145','capacity_ceiling_tonnes':'60000','capex_per_annual_tonne':'.0025','capacity_lead_months':6,'annual_capacity_addition_limit':'6000','maintenance_capex_ratio':'.012','da_opening_annual':'3.108','da_new_assets_rate':'.15','tax_rate':'.25168','opening_tax_settlement_month':12,'minimum_cash':'.5','reserve_cost_months':'.25','wc_renewal':True,'wc_call_month':12,'wc_rate':'.11','bank_term_rate':'.0935','unsecured_rate':'.12','bank_term_principal_monthly':'.0576923','unsecured_repayment_month':36,'incremental_debt_gate':False,'new_debt_limit':'0','new_debt_cumulative_limit':'0','new_debt_rate':'.14','new_debt_tenor':36,'debt_draw_fee':'.01','debt_renewal_gate':False,'debt_renewal_fee':'.005','annual_bank_fees':'.2718','equity_gate':False,'equity_authorization_gate':False,'equity_price_discount':'.30','equity_fee':'.02','equity_last_month':36,'expanded_authorized_shares':20000000,'forced_equity_month':1,'forced_equity_shares':0,'wacc':'.16','terminal_growth':'.04','terminal_roic':'.12','exit_ebitda_multiple':'8','entry_cost':'.01','exit_cost':'.01','source_eligible':False,'label':'Conditional normalization, not forecast; current cash and lender continuity unverified'}
def month(m):
 n=2026*12+10+m-1;return f'{n//12:04d}-{n%12+1:02d}'
def _season(m):
 # Monthly sales weights do not claim observed product seasonality. Weights sum exactly12.
 return [D(x)for x in['.85','.85','.95','.95','1','1','1','1','1.05','1.10','1.10','1.15']][(m-1)%12]
def run(i,s,years,path_id):
 s=deepcopy(s);o={k:d(v)for k,v in i['opening'].items()};n=12*years;cash=o['cash']+d(s['retained_warrant_cash']);shares=int(i['issued_shares']);auth=int(s['expanded_authorized_shares'])if s['equity_authorization_gate']else int(i['authorized_shares']);startcash=cash
 wc=o['working_capital_debt'];tl=o['bank_term_debt'];ul=o['unsecured_debt']+o.get('unallocated_debt_rounding',ZERO);newdebt=ZERO;debtcoh=[];capacity=d(s['initial_capacity_tonnes']);pipeline=[];ppe=o['ppe'];legacy_ppe=ppe;new_ppe=ZERO;cwip=o['cwip'];inventory=o['inventory'];ar=o['ar_current']+o['ar_old'];ap=o['payables'];opa=o['other_operating_assets_proxy'];longadv=o['long_advances'];restricted=o['restricted_deposits'];taxclaim=o['tax_provision'];base=o['annual_sales'];baseunits=base/d(s['initial_realisation_crore_per_tonne']);receipts=defaultdict(lambda:ZERO);payments=defaultdict(lambda:ZERO)
 for k in range(1,int(s['opening_ar_months'])+1):receipts[k]+=o['ar_current']/int(s['opening_ar_months'])
 recovery=d(s['old_ar_recovery']);oldrecover=o['ar_old']*recovery
 for k in range(int(s['old_ar_start']),int(s['old_ar_start'])+int(s['old_ar_months'])):receipts[k]+=oldrecover/int(s['old_ar_months'])
 for k in range(1,int(s['opening_ap_months'])+1):payments[k]+=ap/int(s['opening_ap_months'])
 rows=[];failure=None;cumdraw=ZERO;eqgross=ZERO;capexsum=ZERO;equity_authorization_rejections=0;prev_annual_sales=base;added_by_year=defaultdict(lambda:ZERO);exitstate=None;terminal_basis=None
 for m in range(1,n+13):
  y=(m-1)//12;open_cash=cash;open_ar=ar;open_ap=ap;open_inv=inventory;open_debt=wc+tl+ul+newdebt;open_shares=shares;open_ppe=ppe;open_cwip=cwip;open_opa=opa
  commission=sum((x['tonnes']for x in pipeline if x['ready']==m),ZERO);commission_cost=sum((x['cost']for x in pipeline if x['ready']==m),ZERO);capacity+=commission;cwip-=commission_cost;new_ppe+=commission_cost;pipeline=[x for x in pipeline if x['ready']!=m]
  if m<=n:
   annual_units=baseunits*(ONE+d(s['volume_growth']))**(y+1);target_units=annual_units*_season(m)/12*(ONE-d(s['customer_loss']));unitprice=d(s['initial_realisation_crore_per_tonne'])*(ONE+d(s['price_growth']))**(y+1);unitprice*=ONE+d(s['export_fraction'])*d(s['export_price_shock'])
  else:
   annual_units=terminal_basis['units']*(ONE+d(s['terminal_growth']));target_units=annual_units*_season(m)/12;unitprice=terminal_basis['sales']/terminal_basis['units']
  sold=min(target_units,capacity/12);lost=target_units-sold;sales=sold*unitprice
  # Commit expansion in advance, with physical annual/total limits and paid capex now.
  pipelinecap=sum((x['tonnes']for x in pipeline),ZERO);needed=max(ZERO,annual_units*D('1.15')-capacity-pipelinecap);room=max(ZERO,d(s['capacity_ceiling_tonnes'])-capacity-pipelinecap);annual_room=max(ZERO,d(s['annual_capacity_addition_limit'])-added_by_year[y]);add=min(needed,room,annual_room)
  growthcapex=add*d(s['capex_per_annual_tonne']);cwip+=growthcapex;added_by_year[y]+=add
  if add:pipeline.append({'tonnes':add,'ready':m+int(s['capacity_lead_months']),'cost':growthcapex})
  maintenance=sales*d(s['maintenance_capex_ratio'])
  if m>n:
   rate=d(s['da_new_assets_rate'])/12;replacement_floor=(min(legacy_ppe,d(s['da_opening_annual'])/12)+new_ppe*rate)/(ONE-rate);maintenance=max(maintenance,replacement_floor)
  capex=growthcapex+maintenance;capexsum+=capex
  cogs=sales*d(s['material_ratio']);loss=inventory*d(s['inventory_impairment'])if m==int(s['inventory_impairment_month'])else ZERO;inventory-=loss
  seasonal_buffer=D('1.25')if s['procurement_seasonality']and int(month(m)[5:])in[10,11,12,1]else ONE
  desired_inventory=annual_units*unitprice*d(s['material_ratio'])*d(s['inventory_days'])/365*seasonal_buffer
  purchases=max(ZERO,cogs+desired_inventory-inventory);inventory+=purchases-cogs
  # Supplier credit is explicit and never counted again as fresh debt.
  delay=int(s['supplier_delay']);payments[m+delay]+=purchases;paid=payments.pop(m,ZERO);ap+=purchases-paid
  exp=sales*d(s['export_fraction']);dom=sales-exp;receipts[m+int(s['domestic_delay'])]+=dom;receipts[m+int(s['export_delay'])]+=exp;collected=receipts.pop(m,ZERO);ar+=sales-collected
  bad_debt=o['ar_old']*(ONE-recovery)if m==int(s['old_ar_start'])+int(s['old_ar_months'])-1 else ZERO;ar-=bad_debt
  opexrate=ONE-d(s['material_ratio'])-d(s['core_ebitda_margin']);assert opexrate>=0
  opex=opexrate*(d(s['fixed_opex_fraction'])*base/12+(ONE-d(s['fixed_opex_fraction']))*sales)
  ebitda=sales-cogs-opex;new_ppe+=maintenance;legacy_da=min(legacy_ppe,d(s['da_opening_annual'])/12);new_da=min(new_ppe,new_ppe*d(s['da_new_assets_rate'])/12);da=legacy_da+new_da;legacy_ppe-=legacy_da;new_ppe-=new_da;ppe=legacy_ppe+new_ppe;ebit=ebitda-da-loss-bad_debt
  interest=(wc*d(s['wc_rate'])+tl*d(s['bank_term_rate'])+ul*d(s['unsecured_rate'])+newdebt*d(s['new_debt_rate']))/12
  principal_tl=min(tl,d(s['bank_term_principal_monthly']));tl-=principal_tl;principal_ul=ul if m==int(s['unsecured_repayment_month'])else ZERO;ul-=principal_ul
  principal_wc=wc if not s['wc_renewal']and m==int(s['wc_call_month'])else ZERO;wc-=principal_wc
  principal_new=ZERO;renew_fee=ZERO;nextcoh=[]
  for c in debtcoh:
   if c['due']==m:
    if s['debt_renewal_gate']:
     renew_fee+=c['amount']*d(s['debt_renewal_fee']);c={'amount':c['amount'],'due':m+int(s['new_debt_tenor'])};nextcoh.append(c)
    else:principal_new+=c['amount']
   else:nextcoh.append(c)
  debtcoh=nextcoh;newdebt-=principal_new
  tax=max(ZERO,ebit-interest)*d(s['tax_rate']);oldtax=taxclaim if m==int(s['opening_tax_settlement_month'])else ZERO;taxclaim-=oldtax
  opa_target=o['other_operating_assets_proxy']+max(ZERO,annual_units*unitprice-base)*d(s['operating_asset_growth_ratio']);opa_movement=opa_target-opa;opa=opa_target
  advance_release=min(longadv,d(s['advance_recovery']))if m==int(s['advance_recovery_month'])else ZERO;longadv-=advance_release
  dep_release=min(restricted,d(s['deposit_release']))if m==int(s['deposit_release_month'])else ZERO;restricted-=dep_release
  fees=d(s['annual_bank_fees'])/12+renew_fee;cash_before_finance=cash+collected+advance_release+dep_release-paid-opex-tax-oldtax-interest-fees-capex-principal_tl-principal_ul-principal_wc-principal_new-opa_movement
  reserve=max(d(s['minimum_cash']),(cogs+opex)*d(s['reserve_cost_months']));needed_cash=max(ZERO,reserve-cash_before_finance);draw=ZERO;drawfee=ZERO
  if m<=n and s['incremental_debt_gate']and needed_cash>0:
   grossneed=needed_cash/(ONE-d(s['debt_draw_fee']));draw=min(grossneed,max(ZERO,d(s['new_debt_limit'])-newdebt),max(ZERO,d(s['new_debt_cumulative_limit'])-cumdraw));drawfee=draw*d(s['debt_draw_fee']);newdebt+=draw;cumdraw+=draw
   if draw:debtcoh.append({'amount':draw,'due':m+int(s['new_debt_tenor'])})
  cash_after_debt=cash_before_finance+draw-drawfee;needed_cash=max(ZERO,reserve-cash_after_debt);newshares=0;gross=ZERO;eqfee=ZERO;issueprice=d(i['entry_price'])*(ONE-d(s['equity_price_discount']))
  force=int(s['forced_equity_shares'])if m==int(s['forced_equity_month'])else 0
  if m<=n and s['equity_gate']and m<=int(s['equity_last_month'])and(needed_cash>0 or force>0):
   wanted=max(force,int((needed_cash*CR/(issueprice*(ONE-d(s['equity_fee'])))).to_integral_value(rounding=ROUND_CEILING)))
   newshares=min(wanted,max(0,auth-shares));equity_authorization_rejections+=int(wanted>newshares);shares+=newshares;gross=d(newshares)*issueprice/CR;eqfee=gross*d(s['equity_fee']);eqgross+=gross
  cash=cash_after_debt+gross-eqfee;shortfall=max(ZERO,reserve-cash);financial_failure=shortfall>D('1e-24')
  row={'month':m,'date':month(m),'year':y+1,'phase':'operating_horizon'if m<=n else'terminal_transition','cash_open':open_cash,'cash_close':cash,'cash_reserve':reserve,'cash_shortfall':shortfall,'ar_open':open_ar,'ar_close':ar,'inventory_open':open_inv,'inventory_close':inventory,'ap_open':open_ap,'ap_close':ap,'other_operating_assets_open':open_opa,'other_operating_assets_close':opa,'long_advances_close':longadv,'restricted_deposits_close':restricted,'tax_claim_close':taxclaim,'sales':sales,'units_sold':sold,'units_lost':lost,'unitprice':unitprice,'capacity_tonnes':capacity,'capacity_added':commission,'capacity_committed':add,'growth_capex':growthcapex,'maintenance_capex':maintenance,'capex':capex,'ppe_open':open_ppe,'ppe_close':ppe,'cwip_open':open_cwip,'cwip_close':cwip,'commissioned_cost':commission_cost,'legacy_ppe':legacy_ppe,'new_ppe':new_ppe,'material_cogs':cogs,'purchases':purchases,'supplier_payments':paid,'customer_collections':collected,'inventory_impairment':loss,'bad_debt':bad_debt,'opex':opex,'ebitda':ebitda,'da':da,'ebit':ebit,'tax_cash':tax,'opening_tax_settlement':oldtax,'interest':interest,'bank_fees':fees,'advance_release':advance_release,'deposit_release':dep_release,'opa_movement':opa_movement,'debt_open':open_debt,'wc_debt_close':wc,'term_debt_close':tl,'unsecured_debt_close':ul,'new_debt_close':newdebt,'debt_close':wc+tl+ul+newdebt,'principal_term':principal_tl,'principal_unsecured':principal_ul,'principal_wc':principal_wc,'principal_new':principal_new,'debt_draw':draw,'debt_draw_fee':drawfee,'shares_open':open_shares,'shares_close':shares,'new_shares':newshares,'equity_issue_price':issueprice,'equity_gross':gross,'equity_fee':eqfee,'cash_before_new_finance':cash_before_finance,'failure':financial_failure}
  rows.append(row)
  if m==n:
   exitstate=deepcopy(row);terminal_basis={'sales':sum(x['sales']for x in rows[-12:]),'units':sum(x['units_sold']for x in rows[-12:]),'ebitda':sum(x['ebitda']for x in rows[-12:]),'ebit':sum(x['ebit']for x in rows[-12:]),'pending_tonnes':sum((x['tonnes']for x in pipeline),ZERO),'pipeline':deepcopy(pipeline)}
  if financial_failure:failure={'month':m,'date':month(m),'shortfall_to_reserve':shortfall,'negative_cash':cash<0,'reason':'Conditional policy reserve/cash funding failure, not observed default'};break
 terminal=None;terminal_attempt=None
 if failure is None:
  horizon=rows[:n];transition=rows[n:];end=horizon[-1];g=d(s['terminal_growth']);wacc=d(s['wacc']);assert g<wacc
  annualsales=terminal_basis['sales'];annualebitda=terminal_basis['ebitda'];annualebit=terminal_basis['ebit'];nextsales=sum(x['sales']for x in transition);nextnopat=sum(max(ZERO,x['ebit'])*(ONE-d(s['tax_rate']))for x in transition);nextda=sum(x['da']for x in transition);replacement=sum(x['maintenance_capex']for x in transition);physical=sum(x['growth_capex']for x in transition)
  onwc_start=end['ar_close']+end['inventory_close']-end['ap_close']+end['other_operating_assets_close'];last=transition[-1];onwc_end=last['ar_close']+last['inventory_close']-last['ap_close']+last['other_operating_assets_close'];wc_need=max(ZERO,onwc_end-onwc_start);economic=nextnopat*g/d(s['terminal_roic']);growth_reinvestment=max(physical+wc_need,economic);extra_reinvestment=growth_reinvestment-physical-wc_need;fcff=nextnopat+nextda-replacement-growth_reinvestment
  # Retain enough cash for ALL twelve transition troughs, not merely the exit-month reserve.
  # The marginal-return reinvestment floor is an additional cash use, spread monthly; no borrowing/equity rescue is allowed here.
  cash_at_exit=end['cash_close'];required=max([end['cash_reserve']]+[x['cash_reserve']-(x['cash_close']-cash_at_exit)+extra_reinvestment*(k+1)/12 for k,x in enumerate(transition)])
  required=max(ZERO,required);excess=max(ZERO,cash_at_exit-required);lost=sum(x['units_lost']for x in transition);funded=cash_at_exit+ D('1e-18')>=required and lost<=D('1e-18')
  transition_diagnostics=[]
  for k,x in enumerate(transition):transition_diagnostics.append({'month_after_exit':k+1,'source_month':x['month'],'retained_cash_after_excess_distribution':x['cash_close']-excess-extra_reinvestment*(k+1)/12,'reserve':x['cash_reserve'],'extra_reinvestment':extra_reinvestment/12,'capacity':x['capacity_tonnes'],'lost_units':x['units_lost'],'incremental_debt':x['debt_draw'],'new_shares':x['new_shares']})
  terminal_attempt={'annual_sales':annualsales,'annual_ebitda':annualebitda,'annual_ebit':annualebit,'next_sales':nextsales,'next_nopat':nextnopat,'next_da':nextda,'replacement_capex':replacement,'capacity_expansion_cost':physical,'working_capital_reinvestment':wc_need,'actual_onwc_change':onwc_end-onwc_start,'economic_reinvestment_floor':economic,'extra_reinvestment':extra_reinvestment,'reinvestment':growth_reinvestment,'fcff':fcff,'reserve':required,'cash_at_exit':cash_at_exit,'excess_cash':excess,'debt':end['debt_close'],'unpaid_tax_claim':end['tax_claim_close'],'shares':end['shares_close'],'already_paid_pipeline_tonnes':terminal_basis['pending_tonnes'],'uncommissioned_cwip':end['cwip_close'],'terminal_reinvestment_funded':funded,'transition':transition_diagnostics,'transition_engine_months':len(transition),'terminal_lost_units':lost}
  if funded:
   ev=max(ZERO,fcff/(wacc-g));equity=max(ZERO,ev+excess-end['debt_close']-end['tax_claim_close']);price=equity*CR/end['shares_close'];exitprice=price*(ONE-d(s['exit_cost']));entry=d(i['entry_price'])*(ONE+d(s['entry_cost']));irr=(exitprice/entry)**(ONE/years)-1 if exitprice>0 else D(-1);cross_ev=annualebitda*d(s['exit_ebitda_multiple']);cross_price=max(ZERO,cross_ev+excess-end['debt_close']-end['tax_claim_close'])*CR/end['shares_close']
   terminal=deepcopy(terminal_attempt);terminal.update({'enterprise_value':ev,'equity_value':equity,'price':price,'irr':irr,'multiple_crosscheck_price':cross_price,'terminal_value_at_entry':ev/(ONE+wacc)**years,'hurdle_entries':{str(h):exitprice/((ONE+h)**years*(ONE+d(s['entry_cost'])))for h in[D('.12'),D('.15'),D('.18')]}})
  else:failure={'month':n+1,'date':'terminal transition','shortfall_to_reserve':max(ZERO,required-cash_at_exit),'negative_cash':False,'reason':'Terminal actual monthly trough, reinvestment floor or commissioned capacity fails'}
 annual=[]
 for y in range(1,years+2):
  a=[r for r in rows if r['year']==y]
  if not a:continue
  z={'year':y,'months':len(a),'sales':sum(x['sales']for x in a),'ebitda':sum(x['ebitda']for x in a),'ebit':sum(x['ebit']for x in a),'interest':sum(x['interest']for x in a),'tax':sum(x['tax_cash']for x in a),'capex':sum(x['capex']for x in a),'equity_gross':sum(x['equity_gross']for x in a),'new_debt':sum(x['debt_draw']for x in a),'cash_close':a[-1]['cash_close'],'ar_close':a[-1]['ar_close'],'inventory_close':a[-1]['inventory_close'],'ap_close':a[-1]['ap_close'],'debt_close':a[-1]['debt_close'],'shares_close':a[-1]['shares_close'],'capacity_close':a[-1]['capacity_tonnes'],'cwip_close':a[-1]['cwip_close'],'ppe_close':a[-1]['ppe_close']};annual.append(z)
 return {'path_id':path_id,'years':years,'spec':s,'source_eligible':False,'opening_cash':startcash,'monthly':rows,'annual':annual,'failure':failure,'terminal':terminal,'terminal_attempt':terminal_attempt,'summary':{'path_id':path_id,'years':years,'status':'failed_conditional'if failure else'funded_conditional','failure_month':failure['month']if failure else None,'volume_growth':s['volume_growth'],'core_ebitda_margin':s['core_ebitda_margin'],'retained_warrant_cash':s['retained_warrant_cash'],'total_capex':sum(x['capex']for x in rows if x['month']<=n),'transition_capex':sum(x['capex']for x in rows if x['month']>n),'equity_gross':eqgross,'new_debt_gross':cumdraw,'final_shares':shares,'authorization_rejections':equity_authorization_rejections,'terminal_sales':terminal['annual_sales']if terminal else None,'terminal_price':terminal['price']if terminal else None,'irr':terminal['irr']if terminal else None,'hurdle_entries':terminal['hurdle_entries']if terminal else None,'source_eligible':False}}
