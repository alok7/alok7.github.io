# Sheetal Universal Limited: audit, governance and financial-reliability investigation

Dossier #364. NSE SHEETAL; ISIN INE04VX01019. Information cutoff: 20 October 2026. Research is consolidated unless explicitly labelled standalone. Figures are ₹ crore, except tables explicitly marked lakh or thousand. V = verified disclosure; C = calculation; M = management explanation; A = analyst inference. A verified disclosure establishes what the filing says, not that every underlying representation has been independently established.

## Decision-useful conclusions

1. **Do not describe this as an adverse audit opinion or an auditor-conflict resignation.** The original consolidated audit/IFC opinions reviewed are unmodified. The 2 August 2025 resignation letter expressly cites prior work commitments and denies another material reason. This is important counterevidence. It does not eliminate the other, separately documented concerns.
2. **Financial reliability warrants a research hold pending clarification, rather than a fraud accusation.** Four-year FY2022–FY2025 bank-stock discrepancies, recurring asset/balance verification caveats, absent FY2026 audit logs, large unitemised advances and inconsistent current CARO disclosures remain. The latest clean IFC opinion and internal-auditor appointment are counterevidence, not a documented bridge closing every earlier issue.
3. **CRISIL did not restore cooperation in June 2026.** It retained issuer-not-cooperating status and revised long-term BB+ to BB; this is not a default rating. Its financial-indicator table mislabels half-year consolidated figures as full-year figures. Do not feed that table into the model.
4. **Cash-flow presentation is not vintage-consistent.** Original FY2025 consolidated CFO was ₹10.0565 crore, versus ₹9.2517 crore in the FY2026 comparative. About ₹0.8049 crore was shifted into investing, with negligible rounding. This is largely a reproducible classification bridge, not missing cash. Standalone FY2025 CFO also includes short-term borrowing changes and must not be mixed with consolidated cash generation.
5. **Current concerns have explicit, bounded resolution tests.** Obtain bank-return reconciliation and acceptance, receivable collections, partywise advances, edit-log remediation, clarification of contradictory CARO cash-loss/loan statements, and CSR/cash-capex/tax bridges. No evidence reviewed establishes deliberate diversion or a loan default.

Recommended gate interpretation (A): G1 Conditional; G2 Hold — unresolved, with IAS NS until the material reliability questions are reconciled; G3 Hold, unresolved in the complete dossier because current funding evidence is missing; the audit record and issuer-not-cooperating status alone do not establish a failure. Avoid an unsupported numeric governance override. Confidence is High that the cited disclosures exist, Medium on comparable historical financials, and Low on independent remediation evidence.

## 1. Original audit and IFC chronology

| Period | Original evidence and exact locator | Result and qualification of interpretation |
|---|---|---|
| FY2021 | Company consolidated audit package, PDF pp5–8 and 12–14, signed 9 November 2021; annual report repeats these on PDF pp10–19 | Main opinion and IFC opinion unmodified (V). Consolidated CARO reports no noticed fraud or bank/financial-institution repayment default (PDF p10). Some package front matter carries a later year/date, so identify the signed financial statements rather than treating the website upload timestamp as the audit date. |
| FY2022 | Consolidated statutory audit, 30 September 2022, PDF pp2–3, 7–10 | Unmodified opinion; EOM says PPE was not independently inspected and balances were confirmed only on a test basis. Any resulting adjustment could affect profit/assets. Opinion expressly not modified (V). IFC clean. |
| FY2023 | Consolidated statutory audit, 8 July 2023, PDF pp2–3, 7–8, 13–14; also annual report PDF pp16–17, 21–22, 27–28 | Same EOM plus bank-stock reconciliation finding; IFC clean (V). Original annual report and original audit must not be replaced by the prospectus restatement when describing audit findings. |
| April–August 2023 | Website document labelled “Consolidated Statutory Audit Report F.Y. 2023–24”, cover and PDF pp2–3 | It is explicitly a five-month April–August 2023 report, not FY2024 (V). Do not annualise or insert as a full annual observation. |
| FY2024 | Annual report, audit 30 May 2024, PDF pp43–57 standalone and 82–95 consolidated | Unmodified main opinion and clean IFC; PPE/balance EOM continues; bank stock discrepancies and missing internal audit remain. Original text was image-only and targeted page OCR is retained. |
| FY2025 | Complete NSE annual report filed 8 September 2025, audit 30 May 2025; printed pp44–58 and 81–94, corresponding NSE PDF pp45–59 and 82–95 | Unmodified main/IFC opinions, recurring EOM, bank-stock issues, and internal-audit inconsistencies (V). The company-website copy has actually blank pages in some financial sections; the complete NSE copy restores those pages. |
| FY2026 | Annual report, audit 30 May 2026; PDF pp66–80 standalone and 105–113 consolidated | Main opinions remain unmodified in wording and IFC clean. CSR noncompliance is separately stated; edit-log absence and dividend-account delay appear under Rule 11. The consolidated CARO summary says no adverse remarks, although standalone CSR and cash-loss statements require reconciliation (V). |

The fact that the latest auditor no longer repeats the older EOM is counterevidence, but the report does not provide a specific retrospective confirmation/collection or bank-reconciliation closure. Do not silently mark all prior issues resolved.

## 2. Bank stock statements: scale, explanation and unresolved closure

### FY2022: original standalone report extends the adverse history

Original standalone audit dated 30 September 2022, PDF p9, reports book stock of ₹39,090 / ₹38,808 / ₹117,002 thousand versus bank stock of ₹41,354 / ₹43,492 / ₹135,398 thousand in Q1–Q3. Differences are ₹2,264 / ₹4,684 / ₹18,396 thousand. Management says domestic receivables were erroneously counted as stock (M). For Q4, book stock is ₹37,298 thousand and the report explicitly says the stock statement was not submitted (V). The page image was visually verified after OCR.

The consolidated audit of the same year, PDF p7, nonetheless says no adverse CARO remarks were reported. This summary conflict is unresolved and demonstrates why reading only the consolidated CARO summary or prospectus is insufficient. The main audit and IFC opinions are clean; that is not equivalent to a clean CARO history.

### FY2023: original CARO, not just prospectus text

Source: original consolidated audit PDF p8 and annual report FY2023 PDF p22, signed 8 July 2023. Units below are ₹ thousand.

| Quarter | Book stock | Stock reported to bank | Reported difference | Calculated bank minus book |
|---|---:|---:|---:|---:|
| Q1 | 59,936.70 | 129,801.00 | 69,684.30 | 69,864.30 |
| Q2 | 26,313.43 | 83,455.00 | 57,141.57 | 57,141.57 |
| Q3 | 83,475.47 | 192,009.00 | 108,533.53 | 108,533.53 |
| Q4 | 64,822.95 | 163,243.00 | 98,420.05 | 98,420.05 |

The auditor says bank statements do not agree with books (V). Management says export receivables were erroneously included as stock in drawing-power calculations (M). The original standalone report dated 21 May 2023, PDF p9, labels the same explanation domestic receivables, whereas the consolidated report dated 8 July says export receivables. The standalone Q1 difference is the arithmetically correct ₹69,864.30 thousand. The consolidated version has a further ₹180 thousand / ₹1.80 lakh arithmetic difference; preserve the printed number and the arithmetic separately. This is not evidence that all ₹9.842005 crore of the Q4 difference was fictitious stock or misappropriated cash. It is evidence that drawing-power reporting needs reconciliation.

### FY2024: large transit/Bill-of-Lading bridge

Source: annual report FY2024 PDF p50 standalone and p88 consolidated, audit 30 May 2024. Units ₹ lakh.

| Quarter | Book stock | Bank stock | Transit/Bill-of-Lading bridge | Table residual |
|---|---:|---:|---:|---:|
| Q1 | 956.96 | 2,342.49 | 1,385.53 | 0 |
| Q2 | 475.68 | 1,622.84 | 1,147.16 | 0 |
| Q3 | 488.98 | 3,396.05 | 2,907.07 | 0 |
| Q4 | 604.38 | 2,582.38 | 1,978.00 | 0 |

Narrative: statements are not in agreement (V). Management explanation: goods in transit or goods for which original bills of lading were held were erroneously counted for drawing power (M). The disclosed transit bridge gives a zero residual, which is important counterevidence against calling the entire difference unexplained. It does not establish that the bank accepted the eligibility/classification or that no double counting occurred.

### FY2025 and FY2026 follow-through

FY2025 bank/book stock reconciles after ₹31.51 lakh transit in Q2 and ₹160.91 lakh in Q4. Q4 book stock is ₹1,717.80 lakh, bank ₹1,556.89 lakh. The narrative nevertheless says not in agreement, with management referring to debit notes and year-end entries after bank submission. Source: complete NSE AR FY2025 printed pp51,87 / PDF pp52,88, audit 30 May 2025.

FY2026 standalone CARO clause(ii)(b), annual-report PDF p73, merely acknowledges bank working-capital limits above ₹5 crore at Bank of Baroda and Bank of India. It does **not** expressly state that quarterly returns agree. Closure is therefore ND, not verified adverse repetition and not verified remediation. The required next evidence is a quarter-by-quarter books/stock/transit/receivable/drawing-power bridge with bank acceptance and the latest audit conclusion.

## 3. Auditor transition and internal audit

The original NSE resignation filing dated 2 August 2025, PDF pp3–4, is retained. V.V. Patel & Co stated it could not devote the necessary time to FY2026 because of prior work commitments; the annexure cites preoccupation with other assignments, treats information-not-provided concerns as not applicable, and confirms no other material reason. Last audit report was submitted 30 May 2025. Treat this as an auditor-stated reason (V as disclosure), not an inference of conflict.

The outgoing auditor's appointment had been for FY2024–FY2028, approved at the 8th AGM. Sunit M Chhatbar & Co was appointed to the casual vacancy on 6 August 2025, then approved at the AGM on 30 September 2025. Annual-report wording describes a five-year appointment but also says 10th through 16th AGM. Do not invent the true end date; record this drafting inconsistency. Sources: resignation p4; NSE AR2025 printed pp16,22; AR2026 PDF p39.

Internal-auditor sequence:
- FY2024 director report PDF p15 says none appointed, despite a nearby generic statement that internal audit reports were reviewed.
- FY2025 standalone CARO printed p54 says no internal auditor and no report considered. Consolidated CARO printed p90 instead says internal audit is not applicable, again with no report considered. Secretarial disclosures say a filing of the internal-auditor appointment was corrected in May 2025. These statements are not a clean chronology.
- FY2026 PDF p39 identifies appointment of JNCY & Associates on 30 May 2025. CARO PDF p75 says the system is commensurate and the auditor considered its reports. This is tangible current-year remediation counterevidence.

## 4. FY2026 unresolved reporting and compliance contradictions

### Edit logs and cash-loss language

The consolidated auditor's Rule 11 disclosure says the group used software without an audit-trail/edit-log feature throughout FY2026 (AR PDF p110). The clean IFC opinion on PDF pp112–113 must be shown alongside, not substituted for, that disclosure.

Standalone CARO clause(xvii), PDF p76, reports cash losses of ₹30.91 lakh for FY2026 and ₹13.01 lakh for FY2025. The accounts show large positive PAT and depreciation, and the report supplies no calculation. These figures are not the CFO numbers either. Call this an unresolved audit-report inconsistency, **not established economic cash losses**. Consolidated CARO PDF p111 says no qualifications/adverse remarks in group CARO reports, which also needs reconciliation with the standalone CSR finding.

### CSR: partial claimed correction, amount unreconciled

The auditor, as of 30 May 2026, says required CSR had neither been spent nor transferred to the specified fund/account (PDF pp76 and105). The director report (PDF p40, printed39) says management transferred ₹9.325 lakh to PM CARES on 5 September 2026 against a stated obligation of ₹9.3208667 lakh and claims no continuing default (M).

However, the FY2026 balance-sheet note and expense note both recognise ₹12.59 lakh CSR (PDF pp121,126). Difference between provision and claimed payment: ₹3.265 lakh (C). A simple 2% of the FY2023–FY2025 average reported PBT is about ₹12.5877 lakh, close to the provision, but this is only an analytical cross-check, not a legal CSR calculation. The correct obligation, eligible-profit adjustments, payment evidence and closing unpaid balance need a bridge. Do not claim complete compliance or an established ongoing statutory default merely from the unreconciled numbers.

### Dividend timing

Dividend declared 30 September 2025 was paid 18 October 2025, within the prescribed distribution period. The separate bank account was funded 7 October, two days late according to the audit. Source: PDF p110. The ₹57.28 lakh financing outflow in FY2026 relates to this FY2025 dividend and is not contradicted by no new FY2026 dividend recommendation.

### Loans granted versus CARO

Standalone CARO PDF p73 says no loans/advances in the nature of loans were granted in FY2026. RPT note PDF p98 reports a ₹2 lakh loan to Saumesvar International and loan balance ₹24.18 lakh versus ₹22.18 lakh. The same RPT schedule appears in the consolidated notes at p131. Eliminating intercompany balances in consolidation cannot explain the contradiction inside the standalone reporting. The amounts are small; the significance is reporting reliability, not automatic diversion.

## 5. Assets, RPTs, contingencies and ownership

As at 31 March 2026, consolidated notes disclose:
- ₹4.9706 crore long-term unsecured considered-good loans/advances and ₹8.5613 crore short-term unsecured considered-good loans/advances (PDF pp122–123). Combined ₹13.5319 crore is about 24.71% of ₹54.7717 crore equity. Partywise recipients, purpose, interest and recoverability bridge are ND in these notes. Do not call the entire amount related-party lending; the specifically disclosed subsidiary loan is only ₹0.2418 crore.
- ₹41.8577 crore receivables, all treated as good. ₹5.3626 crore is 1–2 years old, ₹2.0888 crore 2–3 years, and ₹0.5444 crore over3years. Thus ₹7.9958 crore / 19.10% is older than1year, without doubtful classification (PDF p128). This is collection-risk evidence, not proof of bad debt. The older-than1year balance was ₹4.8766 crore in FY2025.
- RPT FY2026 includes managing-director funding received ₹68.91 lakh and repaid ₹59.34 lakh; spouse director funding received ₹1.85 lakh and repaid ₹0.75 lakh; director/family balances and ₹1.20 lakh family rent are disclosed (PDF pp98,131). Management's arm's-length claim is M. No abusive pricing conclusion is established.
- Nil contingency/commitment lines in note20, PDF p124, and CARO no-guarantee/security statement at p73. The guarantee line in note20 explicitly excludes financial guarantees, so do not derive a comprehensive guarantee assurance from that line alone.
- FY2025 CARO describes a ₹300 lakh factory-property transaction with title deeds in named individuals' names, while explaining construction on leased land; FY2026 says freehold deeds held in the company's name (AR2025 printedp50/NSEPDF51;AR2026PDF72). The later statement does not expressly reconcile the specific prior property/lease parcel. Request title/lease mapping, rather than alleging invalid ownership.

Important counterevidence: FY2026 CARO PDF p74 reports no repayment/interest default, no willful-defaulter designation and no noticed/reported fraud; PDF p76 does not identify a material12-month solvency uncertainty. These audit statements are not guarantees of future liquidity, but must accompany any adverse interpretation.

## 6. Original-versus-restated financial bridges

### Prospectus restatement

Final prospectus dated28November2023, independent restatement report22November2023. PDF p201 / financial pageF14 explicitly reconciles PAT and net worth. Units₹lakh.

| Period | Original audited PAT | Tax adjustment | Deferred-tax adjustment | Restated PAT |
|---|---:|---:|---:|---:|
| FY2021 |25.40|+0.01|0|25.41|
| FY2022 |28.31|0|0|28.31|
| FY2023 |206.04|−7.19|0|198.85|
| April–August2023 |186.14|−1.54|+3.07|187.67|

FY2023 net worth₹656.41lakh→₹649.22lakh. August2023₹1,052.55lakh→₹1,046.89lakh. These are disclosed tax/reclassification adjustments, not an unexplained earnings discontinuity. Original FY2023 annual report PDF pp36–37 independently supports original PAT/net worth.

### Cash-flow vintage table

| Period / vintage | CFO₹cr | CFI₹cr | CFF₹cr | Source |
|---|---:|---:|---:|---|
| FY2022 original |2.3434|−0.5029|3.1509|AR2023PDF38 comparative|
| FY2022 prospectus-restated |2.3125|−0.4721|3.1511|ProspectusPDF195/F8|
| FY2023 original |−2.6612|−3.1338|2.7907|AR2023PDF38|
| FY2023 prospectus-restated |−2.6802|−3.1140|2.7906|ProspectusPDF195/F8|
| FY2024 filed |−27.0249|−0.8693|26.0658|March2024resultsPDF17;alsoAR2025printed110|
| FY2025 original |10.0565|−15.1829|4.9971|NSEAR2025PDF111/printed110|
| FY2025 latest comparative |9.2517|−14.3780|4.9970|AR2026PDF116|
| FY2026 reported |−13.0349|−0.1156|12.8766|AR2026PDF116|

FY2022–23 cash ending balances substantially agree across original/restated records, allowing rounding. Reclassification/interest-income differences affect CFO/CFI. The detailed restated financial information is the preferred historical comparable series, with original-vintage differences retained rather than hidden.

FY2025 bridge: original operating section includes +₹276.27lakh loans/advances and −₹195.78lakh other noncurrent assets. Net+₹80.49lakh is no longer in operating flows in the FY2026 comparative and appears as+₹80.48lakh in investing. CFO falls₹80.48lakh; CFI improves₹80.49lakh; CFF differs₹0.01lakh. Closing cash remains₹42.27lakh. This nearly exact bridge is substantial counterevidence against alleging cash disappeared.

FY2024 filed CFO is independently present in the29August2024 results PDF17; do not rely solely on the FY2025 comparative. Its investing line comprises₹232.69lakh fixed-asset purchases less₹145.77lakh disposal proceeds. The original FY2024 annual-report package has not been verified to contain a cash-flow page; the actual result filing supplies the needed original-year evidence.

### FY2026 cash-flow interpretation cautions

- Tax paid/adjustment line₹402.70lakh should not be presented as independently verified actual tax cash. The adjustment for current liabilities/provisions includes the₹400.38lakh increase in income-tax provision. Starting with PBT, adding tax-payable change and subtracting current tax expense can algebraically derive net cash taxes. A second deduction of₹400.38lakh would double count. Request the tax ledger/challan bridge, rather than declaring CFO inflated from this presentation alone.
- The two operating labels for short-term advances and other current assets appear swapped relative to balance-sheet changes: ₹308.71lakh and₹507.03lakh. Their combined effect is the same. This is labelling weakness, not an additional cash-flow shortfall.
- Other income includes₹6.12lakh interest but CFO has no interest-income deduction and CFI no receipt. This is a classification gap pending receipt/accrual detail.
- The “purchase of fixed assets” line₹40.48lakh equals gross additions₹83.14lakh less disposals₹42.66lakh (PDFpp116,129). The sale-proceeds line is blank. Treat₹40.48lakh as a net-reported capital-movement proxy, not verified gross cash capex. Gross additions are also not automatically cash expenditure.
- Do not use original standalone FY2025 CFO₹15.7524crore as group cash generation: it includes₹5.6867crore short-term borrowing changes under operating activities (NSEAR2025PDF74/printed73).

## 7. Rating history and an external period-label error

CRISIL30June2026 revises long-term BB+/Stable to BB/Stable, retains A4+, and continues issuer-not-cooperating status on₹25crore facilities. Instrument annexure:₹3.5crore cash credit,₹17crore export packing credit,₹4.5crore term loan. This is a negative information-adequacy and financing-quality signal, not an established payment default. The full web-tool response is retained with a hash; direct source HTML download was not available.

Its “FY2026/FY2025” indicators show revenue₹125.68/₹46.65crore and PAT₹9.98/₹7.97crore. These match the March2026 results' **H2 consolidated** revenue₹12,568.33/₹4,665.13lakh and PAT₹998.39/₹796.91lakh, not annual results. The earlier hypothesis that these were standalone figures is incorrect. Use the company's actual annual consolidated statements for the model, while retaining CRISIL for the rating action.

## 8. What would change the conclusion

1. Independent bank-return and drawing-power reconciliation for FY2022–FY2026, including export receivables, transit and bills of lading, plus bank acceptance.
2. Auditor clarification of FY2026 cash-loss numbers, loan-grant contradiction and group CARO summary.
3. Demonstrated audit-log implementation and control testing.
4. Subsequent collections for older receivables and a partywise₹13.5319crore loans/advances schedule with terms and confirmations.
5. CSR eligible-profit computation, payment receipt and balance reconciliation.
6. Cash-capex/disposal and tax-paid ledger reconciliations; a consistent audited CFO history.
7. Current cooperating credit review and sufficient lender/liquidity information for a non-rescue stress case.

## Source register and preserved evidence

The machine-readable audit_inputs.json contains 28 evidence entries, original/restated cash-flow inputs, bank-stock tables, decision limitations and source URLs/hashes. Source_register.json preserves exact original-document identities; the CRISIL web-response capture is distinguished from an unavailable original HTML hash. Original PDFs and inspection extracts are retained separately and are not included in the source-safe archive. Page references above are PDF page numbers unless explicitly stated printed pages. For the NSE FY2025 annual report, printed page+1=PDF page because of the exchange covering letter.

No publication, Library mutation, Git write or third-party communication was performed for this research.

## Standalone cross-check completion

Original standalone main and IFC opinions were checked: FY2021, signed 29 October 2021 (PDF pp3–4,9); FY2022, signed 30 September 2022 (PDF pp2,7,15); FY2023, signed 21 May 2023 (PDF pp2,7,15). All are unmodified. FY2022 and FY2023 standalone reports nevertheless contain the bank-return findings above. Original page images and verified OCR were inspected and retained separately, not included in this source-safe deliverable.

## Exact primary-source links and SHA-256

- [Annual Report Year 2026](https://sheetaluniversal.com/wp-content/uploads/2026/09/Annual-Report_Final-2025-26-upload.pdf)
  - SHA-256: 78545f7b3d5ce3ed6eb6c57f966f15ebf1bd670d7779388821e38a9561aa7bb2
- [Annual Report Year 2024](https://sheetaluniversal.com/wp-content/uploads/2024/09/ANNUAL-REPORT-2023-24.pdf)
  - SHA-256: 9a3d5562771860f34214e228a5b38c55025954ae66a87371bd12de414d3c9482
- [Consolidated Audit Report- 2020-2021– Financial Statement](https://sheetaluniversal.com/wp-content/uploads/2023/09/CONSOLIDATED-AUDIT-REPORT-2020-2021-FINANCIAL-STATEMENT.pdf)
  - SHA-256: e7f904b7d6e1bc9e8b900beb335b4b441506cef62a6f43dcfd9c654291adf5af
- [Consolidated Statutory Audit Report F.Y. 2023-24](https://sheetaluniversal.com/wp-content/uploads/2023/11/Consolidated-Audit-Report-Sheetal-Universal-Limited_compressed.pdf)
  - SHA-256: 0bd9b510d9e41b0c88182423c09f01e12ca6324810efb4502deaedae46656bc0
- [Standalone Statutory Audit Report F.Y. 2021-22](https://sheetaluniversal.com/wp-content/uploads/2023/09/STANDALONE-STATUTORY-AUDIT-REPORT-F.Y.-2021-22.pdf)
  - SHA-256: ae13e4486642fbc73a618278f88dc2520bbe6d71be73b73cfa135d6c74cd82a2
- [Sul Standalone Statutory Audit Report F.Y. 2020-21](https://sheetaluniversal.com/wp-content/uploads/2023/09/SUL-STANDALONE-STATUTORY-AUDIT-REPORT-F.Y.-2020-21.pdf)
  - SHA-256: a0712aed0db111624b6469636dcdef1633280d68b69aca9a69721cb94ff4b760
- [Annual Report Year 2023](https://sheetaluniversal.com/wp-content/uploads/2023/11/Annual-Report-2023_compressed.pdf)
  - SHA-256: 28e43af9ce415dbdb61c576097c44174ed0abe3df8439b52337e8fce3a862236
- [Annual Report Year 2021](https://sheetaluniversal.com/wp-content/uploads/2023/11/Annual-Report-2021_compressed.pdf)
  - SHA-256: 0cf8d797164732a9d12e8245b14776f5c85afc5c412c5b2a9a323ed195e060f6
- [Consolidated Statutory Audit Report F.Y. 2022-23](https://sheetaluniversal.com/wp-content/uploads/2023/09/CONSOLIDATED-STATUTORY-AUDIT-REPORT-F.Y.-2022-23-min.pdf)
  - SHA-256: 7d4e6f96d74a50f01fef6342a97c7b3e4b2a308ad30c4d1ec1f1fdc476691ddc
- [Consolidated Statutory Audit Report F.Y. 2021-22](https://sheetaluniversal.com/wp-content/uploads/2023/09/CONSOLIDATED-STATUTORY-AUDIT-REPORT-F.Y.-2021-22.pdf)
  - SHA-256: 294466a5e3f1673a50d5c98f438a6b214b2be96efbc74908ddaf421b9369f960
- [Standalone Statutory Audit Report F.Y. 2022-23](https://sheetaluniversal.com/wp-content/uploads/2023/09/SHEETAL-UNIVERSAL-LIMITED-STANDALONE-STATUTORY-AUDIT-REPORT-F.Y.-2022-23_.pdf)
  - SHA-256: 39311b65eceb79875e3a8e8c05a66764248d6328f20b9fd9a71bfc945eadacef
- [March 2026](https://sheetaluniversal.com/wp-content/uploads/2026/09/SHEETAL_30052026144800_Outcome_signed_ocred_signed-mar-26.pdf)
  - SHA-256: ed5c12a0282b4511a3429e253cfe181ec3952e70401c0ee985291cbf05f39994
- [March 2024](https://sheetaluniversal.com/wp-content/uploads/2026/09/SHEETAL_29082024180024_MARCH2024RESULT-mar-24.pdf)
  - SHA-256: 99698c15ead94a62ba813ada4fa1cee121a43b934a25d807f0eb777084b3a3ea
- [PROSPECTUS_FINAL](https://nsearchives.nseindia.com/emerge/corporates/content/SheetalUniversal_PROSP.pdf)
  - SHA-256: cacfb4b71beeae8a637550d28a5a72a6bc4bd824b8c9891f6217117a8fa5d784
- [FY2025 annual report, complete NSE copy](https://nsearchives.nseindia.com/corporate/SHEETAL_08092025163652_Final_report_Sheetal_2025__signed.pdf)
  - SHA-256: 18289968449c13db323643a4ddc89e2fbfb1d265aca4415beb49616d516c0c43
- [FY2024 annual report, NSE copy](https://nsearchives.nseindia.com/annual_reports/SME_AR_26175_SHEETAL_2023_2024_0709202419142.pdf)
  - SHA-256: 64cee68ce45a31cd6ed43bcd0bfd06304ba13c4dd8cf28a830e104285397b889
- [Statutory auditor resignation, original NSE letter](https://nsearchives.nseindia.com/corporate/SHEETAL_02082025160530_Resignation_statutory_auditor_2025_Signed.pdf)
  - SHA-256: e1c4d35fe02c2e874035acbed8e00799b2be8532a9b9db164a9209f896ab7aaa
- [CRISIL June 30 2026 rationale, retained full web-tool response rather than source HTML](https://www.crisil.com/mnt/winshare/Ratings/RatingList/RatingDocs/SheetalUniversalLimited_June%2030_%202026_RR_398716.html)
  - SHA-256: b3fc6640d60b1f48da51712baaf728c066c3085348d183a0da9429806a812431


Restatement PAT basis clarification: FY2022/FY2023 figures of ₹28.31/₹198.85 lakh in the reported restatement bridge are the owner/bridge presentation, while consolidated P&L totals used for CFO/PAT are ₹28.32/₹198.86 lakh. The ₹0.01 lakh differences are retained as attribution/rounding-scale presentation differences, not mixed into cumulative consolidated conversion ratios. The original FY2023 ₹206.04 lakh to ₹198.85 lakh tax-adjusted bridge is not a second consolidated PAT history.
