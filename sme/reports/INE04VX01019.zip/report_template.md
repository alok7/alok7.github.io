# Sheetal Universal Limited
## 1. Executive Verdict

**Hold, unresolved. BQS NS; GQS NS; IAS NS.** Sheetal processes and trades peanuts, sesame, spices and agricultural foods, with new flavoured-nut, protein and oil assets and a nascent domestic brand. The potential thesis is a commodity processor moving toward higher-value products, not yet a demonstrated compounder. Real FY2023 production expansion, installed assets and a specific export order are positives. The decisive obstacle is that reported growth and profits have not produced dependable cumulative operating cash, while four years of bank-stock reporting issues and current disclosure inconsistencies remain incompletely resolved. At ₹375.05, even favourable, explicitly conditional funded cases do not establish a satisfactory return. A lower quote alone cannot resolve the reliability and funding holds. Verified collections, inventory realization, current cash and lender capacity, and mature product economics would change the assessment. This is completed deep research with an incomplete investment-evidence basis, not an allegation of fraud or default.

## 2. Research Header, Gates and Data Confidence

Original requested metadata is retained unchanged: **Sheetal Univer.; SHEETAL; INE04VX01019**. The legal issuer is **Sheetal Universal Limited**, NSE Emerge SME, not Sheetal Cool Products. Dossier 364 is separate from the main-board research and from any pending publication batch. Information cutoff is 20 October 2026; price is the official 19 October 2026 close. Later knowledge is not used to backfill the thesis. [Final prospectus](https://nsearchives.nseindia.com/emerge/corporates/content/SheetalUniversal_PROSP.pdf) and the [dated security master](https://nsearchives.nseindia.com/content/cm/interop/NSE_CM_security_19102026.csv.gz) anchor identity.

{{HEADER}}

Annual financial scope is consolidated Indian GAAP Accounting Standards under section 133, not assumed Ind AS. Original standalone audit/CARO records are examined separately, never treated as consolidated financial data. FY2026 is the latest available audited year; no invented September 2026 cash flow or overlapping TTM is used. Horizons are five and ten years. The equity reference hurdle is 15%, with 12% and 18% sensitivities; liquidity reference is ₹5 lakh, not a proposed allocation. All cash-model forecasts are conditional because the March-to-October balance bridge and actual bank facilities are unverified.

{{LIQUIDITY}}

{{GATES}}

{{CONFIDENCE}}

## 3. Scorecard and Calculation Audit

GQS means **Growth Quality Score**, not governance. The nine business/growth factors and IAS R/D/P/L are scored once and reused. NS means not scoreable; ND means data unavailable; NM means not meaningful. Missing factors are not assigned 5 or renormalized away. Bounds are mechanical possibilities, not confidence intervals or implied investment scores. Full precision is retained in scores.json; numerical displays use Decimal half-up to one decimal and classification uses unrounded values.

{{SCORES}}

{{FACTORS}}

BQS weights are GOV 20%, MOAT 20%, REV 12%, DUR 10%, CAP 12%, CASH 10%, BAL 8%, EXEC 8%. GQS weights are REV 40%, DUR 20%, EARN 15%, CAP 15%, CASH 10%. IAS uses final BQS 25%, R 35%, D 20%, P 10%, L 10%. Persistent CASH 3 imposes a GQS ceiling of 5, but NS remains NS. No GOV≤3 or G1-fail override is imposed, and a conditional simulation failure is not treated as an evidenced G3 default/funding failure. G2 prevents ranking eligibility. IAS dependency-aware bounds use the BQS bound rather than allowing BQS to range independently from 1 to 10. MOAT ±1 changes known BQS by ±0.20 and the IAS dependency contribution by ±0.05; EXEC ±1 changes them by ±0.08 and ±0.02. Unknown factors stay unknown.

## 4. Business Overview

The economic chain is procurement, sorting/processing, storage, shipment, invoicing and collection. Peanuts, sesame, cumin and other agricultural commodities expose the firm to harvest pricing, quality/rejection risk, inventory carry, foreign exchange, freight and customer credit. Revenue recognition is not cash receipt. Supplier credit funds part of the cycle but does not make inventory or receivables free. Exports require market access and certifications, yet neither certification nor an export order proves a durable price premium.

FY2026 exports fell from ₹78.14 crore to ₹49.20 crore, while domestic revenue rose from ₹27.53 crore to ₹124.56 crore. The ₹68.09 crore net revenue increase was therefore domestic-led, not export-led. Exports represented 28.31676285% of sales. Current product volumes, trading versus own-processing mix, unit prices and new-line utilization are unavailable. This prevents attributing the domestic surge to the new brand or protein line. The Russia subsidiary was incorporated on 5 March 2026 with RUB10,000 capital and was not operating at year-end; it is not assumed to have caused consolidated growth. UAE status and quantified contributions need clarification. [FY2026 annual report](https://sheetaluniversal.com/wp-content/uploads/2026/09/Annual-Report_Final-2025-26-upload.pdf), PDF91/124 geography notes and business_research.md.

The original IPO plan described protein powder and cold-pressed oil capability with 25 tonnes/day or 7,500 tonnes/year, ₹5.84 crore machinery and ₹12 crore working capital. There were no disclosed marketing/offtake tie-ups for that plan at the prospectus date. The [21 May 2025 disclosure](https://nsearchives.nseindia.com/corporate/SHEETAL_21052025171754_Disclosure_Signed.pdf) subsequently reported installed machinery, trial runs and commercial readiness: 12 tonnes/day flavoured nuts, 8 protein and 12 oil; machinery ₹11.99 crore plus building ₹3 crore. These are not simply 32 independent tonnes/day because products may share feedstock. Scope changed, so the cost comparison is a reconciliation request, not a proven like-for-like overrun.

## 5. Moat / Industry Position

A Gujarat sourcing base, relationships, export access and processing assets constitute a real operating platform. The moat question is whether they deliver lower delivered cost, repeat demand, superior quality economics or sticky customers after working-capital and capital costs. Current evidence does not demonstrate these sufficiently. Commodity substitutes, customer switching, competing processors and volatile input prices constrain pricing power. Branding may improve economics, but the February 2026 NUTZO launch is an initiative, not verified consumer sell-through. Historical top-ten customer concentration was 79.28%, 56.16%, 66.07% and 72.41% in FY2021, FY2022, FY2023 and the five months to August 2023 respectively. Current concentration is ND; it is not assumed unchanged.

{{PEERS}}

Peers are selected by economics, not size alone. Shreeji is the closest processing/trading SME comparator; NHC supplies another agro-food distribution benchmark; Sakuma shows thin-margin commodity downside; Gujarat Ambuja demonstrates larger-scale integrated processing but is not a direct valuation twin. Their scope, scale and diversification differ. No peer BQS/IAS ranking or imported peer P/E target is fabricated. Primary financial pages, source-scale observations and cautions are in peer_inputs.json and peer_research.md. Their margins show why a processor or brand label does not establish pricing power. Sheetal's higher recent PAT margin must be tested against its own cash cycle and product mix.

## 6. Revenue Growth & Scale

{{CAGR}}

{{GROWTH}}

The FY2021 base is small, but that alone is not a reason to penalize growth. There is real FY2023 operating evidence: peanut production increased from 2,176.40 to 8,898.43 tonnes, while cumin/sesame output increased from 1,528.47 to 3,500.24 tonnes. Combined production grew about 234.66%, near the reported sales increase. Production is not exactly sales volume, but it substantiates expansion beyond mere nominal inflation for that year. By contrast, FY2025 sales contracted and FY2026 recovered through domestic sales; recent price/volume, processing/trading and product-mix decomposition remains absent. The prospectus also conflicts between 12,000 and 18,000 tonnes of peanut capacity while showing the same utilization percentage, so no precise current utilization is manufactured.

REV remains NS. The reported five-year CAGR would mechanically start at 9 and the three-year CAGR at 6 under the schedule, but neither number substitutes for verified underlying expansion. The unresolved issue is current quantity, commodity price and mix, not a blanket rejection of small firms or a claim that new consolidation drove growth. A verified product revenue/volume realization bridge could make REV scoreable without waiting for a different share price.

## 7. Growth Quality & Reinvestment Runway

Food consumption and export markets offer a continuing addressable demand pool. The investable runway is narrower: sellable certified output, actual orders, financed procurement, capacity commissioning and collected customer proceeds. The September 2026 Dubai order covers 1,000 tonnes of peanuts at USD1,220/tonne, USD1.22 million total and company-stated ₹11.529 crore. It is not a protein-powder order or annual recurring contract. Its one-month execution period had not expired by the information cutoff; no absence-of-completion announcement is treated as lateness. The Russia/CIS tie-up lacks quantified offtake and is not booked as forecast demand.

Scaling consumes inventory, receivables, plant and operating reserves. FY2026 inventory was ₹47.59 crore and receivables ₹41.86 crore. Supplier credit of ₹26.47 crore offsets only part. A larger borrowing line or equity issue finances the gap but can reduce returns through interest, fees and dilution. The cash model explicitly separates physical capacity, paid CWIP and commissioned PPE; an order cannot become productive output instantly. It uses one peanut-equivalent throughput proxy because joint-output product data are incomplete. This is not a claim that actual demand or installed capacity equals the model proxy.

DUR is 5: accessible opportunities exist, but sustained utilization and customer repeatability are unproven. EARN is 5: core profit is positive, but the margin rise is not yet reconciled to product economics and per-share claims increased. CAP is NS: accounting incremental-return proxies are observable but cannot certify sustainable returns on new assets. CASH is 3 because cumulative conversion is persistently weak; the GQS cap of 5 follows. A cap is not a point estimate. The weakest link is collected, repeatable, capital-efficient growth rather than theoretical market size.

## 8. Management, Governance & Execution

{{EXECUTION}}

Original FY2022 standalone CARO already records bank-stock differences and no Q4 submission. FY2023 standalone and consolidated versions respectively describe domestic and export receivables counted as stock, with a small arithmetic typo in one difference. FY2024 disclosed stock-in-transit explains its numerical table differences, but the suitability and consistent bank-reporting treatment still needs evidence. FY2025 Q2 ₹31.51 lakh and Q4 ₹160.91 lakh stock-in-transit bridges leave zero arithmetic residual despite the narrative saying statements were not in agreement. Those tables do not prove an unexplained numerical shortfall. FY2026 acknowledges working-capital limits above ₹5 crore without a clear closure of this history.

Other current issues include audit-trail/edit-log operation not throughout the year, inconsistent cash-loss and subsidiary-loan CARO statements, and uncertainty over confirmations and original PPE verification. These are material reliability questions, not automatically fraud. Current main audit and IFC opinions are unmodified; the auditor reports no fraud or default and regular undisputed taxes. An internal auditor was appointed on 30 May 2025 and reports were considered, a genuine remediation step. The 2 August 2025 auditor resignation cites workload/preoccupation, not withheld information or a conflict. There is no basis to rewrite that explanation into an adverse resignation.

The FY2026 CSR audit said neither spending nor transfer had occurred at signing; management later reported ₹9.325 lakh PM CARES payment on 5 September against a stated ₹9.3208667 lakh requirement. That later payment is relevant counterevidence, but the ₹12.59 lakh provision/expense and calculation require reconciliation. The dividend separate-account transfer was two days late while distribution was timely. Neither establishes debt default. The CRISIL June 2026 BB/Stable/A4+ issuer-not-cooperating rating, following the October 2025 cooperation flag, increases information risk. Its ₹25 crore rated-facility table is not current undrawn borrowing capacity. See audit_research.md and its evidence-led original-vintage chronology.

At 10 October 2026, Hiren Vallabhbhai Patel held 6,405,641 shares (49.75%) and spouse Kajal Hiren Patel 1,305,383 (10.14%), jointly about 59.89%, directly disclosed in the conversion filing. Hiren combines chairman/MD roles and Kajal is whole-time director. The six-person board includes three independent directors; the audit committee has two independent directors plus Hiren, relevant structural counterevidence. The annual report classifies six holders totaling 8,055,656 shares (70.32%) as promoters, whereas the prospectus group of five held 7,653,255; the 402,401-share difference is Nishant, shown separately as public in that prospectus. This reconciles arithmetic, not the current exchange promoter-group classification. Full current promoter/group, pledge and encumbrance data are ND. Historical no-pledge disclosure applies only at the prospectus date. Minimum promoter contribution of 2,291,200 shares carried three-year lock-in from IPO allotment; excess promoter and other pre-IPO holdings had one-year terms. Current depository release and preferential-conversion lock-in require verification, so tradable free float is not inferred simply as 100% minus the two directors. Source locators and original figures are in control_inputs.json.

Promoter-related property leasing, subsidiary advances and balances require arm's-length and title scrutiny. The prospectus's “owned” summary is qualified by leased-premises tables and no immovable property ownership; historical lessors included promoter-related parties. Current lease renewal/building rights need a bridge. This is not evidence that all ₹13.53 crore short/long advances are related-party diversion. GOV 4 reflects recurrence and incomplete closure while recognizing positive counterevidence. G2 is a reliability hold; G1 is conditional rather than failed.

## 9. Financial Forensics

{{HISTORY}}

All amounts above are ₹crore; FY2021–FY2023 are restated prospectus periods and later years use the stated original/comparative basis. EBITDA is derived as PBT + finance + D&A − all other income, not copied from a mislabeled summary. FY2026 D&A is ₹3.1080 crore and finance cost ₹2.4935 crore. Core EBITDA is ₹18.7376 crore and core EBIT ₹15.6296 crore. Removing all other income is deliberately conservative: forex and export incentives may recur commercially, whereas capital gains and interest are less central. FY2026 other income of ₹2.2444 crore includes forex ₹1.5339, duty drawback ₹0.0778, RoDTEP ₹0.4788, interest ₹0.0612 and capital gain ₹0.0918 crore. No automatic add-back is made for IPO amortization.

FY2026 disclosed PAT is ₹11.5078 crore. The reserves table adds a ₹0.01 lakh minority loss, suggesting an attributable-owner figure of ₹11.5079 crore; the research uses the explicitly disclosed ₹11.5078 crore as the common-earnings proxy and retains this immaterial attribution ambiguity. It does not silently switch between the two. Normalized tax is 25.168%, an analyst assumption applied to core EBIT, not a statement of statutory future cash tax.

{{CASH}}

Weak CFO is not explained away by capex: capital spending occurs below CFO. FY2025 produced positive operating cash, but not enough to offset FY2024 and FY2026 consumption. The original FY2025 CFO was ₹10.0565 crore, versus ₹9.2517 crore in the FY2026 comparative. Roughly ₹0.8048 crore of loans/advances and non-current asset releases was reclassified to investing; total cash is unchanged to rounding. Using the original CFO improves three-year cumulative CFO to about −₹30.0033 crore, still deeply negative. Original FY2022/FY2023 CFO of ₹2.3434/−₹2.6612 crore differs from restated ₹2.3125/−₹2.6802 crore. Original FY2023 PAT ₹2.0604 crore became ₹1.9885 crore after restatement tax adjustments. The bridges are retained rather than erasing earlier audit vintages.

FY2024 fixed-asset “sale” cash of ₹1.4577 crore matches the CWIP decline, raising a classification question but not proving disposal proceeds. FY2026 fixed-asset purchase cash ₹0.4048 crore equals gross additions ₹0.8314 less sale/scrap ₹0.4266 despite a blank separate sale line. Reported FCF is therefore a labeled proxy, not independently certified gross-capex FCF. FY2021 gross capex is ND, not a fabricated negative investment. FY2026 provisions/current liabilities added ₹4.2085 crore to CFO, while ₹4.0270 crore was labeled taxes paid/adjustment; the current-tax provision increased ₹4.0038 crore. Algebraically the net tax-cash component may be ₹0.0232 crore. Deducting the ₹4.0038 crore again would double count. Tax ledgers and challans are needed before making a stronger claim.

{{RETURNS}}

Funding invested capital is equity + gross debt − cash − investments. Core operating capital is receivables + inventory − payables + PPE + CWIP. These are distinct proxies; advances, deposits, taxes, classifications and other claims explain why neither can simply replace the other. Incremental NOPAT is current less beginning normalized core NOPAT, divided by the change in funding capital over the same three/five-year period. The investment bridge compares reported net capex minus D&A plus core working-capital change with that denominator. Residuals remain material and timing is lumpy, so the 14%–15% accounting returns are not project IRRs or a forced CAP score. New capacity was reported trial-ready after FY2025 year-end, so FY2025 margin expansion cannot all be credited to a full year of its operation.

{{WORKING}}

Average-balance working-capital days use revenue for receivables and a compatible but imperfect cost proxy, revenue minus core EBITDA, for inventory/payables. They are not misrepresented as exact procurement COGS days. FY2026 receivables at least one year old total ₹7.9958 crore, about 19.10%, with no allowance. Finished goods dominate inventory. Unsecured long/short advances total ₹13.5319 crore. Restricted deposits of ₹1.1966 crore are not freely spendable operating cash; deferred issue cost is not liquidity. March gross debt is ₹38.1126 crore against cash ₹0.1489 crore. Displayed debt components differ by ₹0.0001 crore, retained as an unallocated claim rather than ignored.

All 1,420,000 warrants were converted by 10 October 2026, at ₹210 each. Gross cash receipts were ₹7.455 crore upfront, ₹4.11075 crore in July, ₹4.07925 crore in September and ₹14.175 crore in October, totaling ₹29.82 crore. Issued claims are 12,875,999 shares, not the stale 11,716,999 shares in the dated tradable-security master. Authorized capital of 13,000,000 shares leaves only 124,001 further shares without new authorization. There are no remaining warrant proceeds to count again. Current retained cash, expenditure and debt repayment between March and October are ND. [10 October allotment](https://nsearchives.nseindia.com/corporate/SHEETAL_10102026175409_Outcome_10102026.pdf).

## 10. Valuation & Market Expectations

{{MULTIPLES}}

Market capitalization uses the current issued claim count. The displayed EV combines October price with dated March debt/cash and is explicitly a bridge, not a verified current EV. A separate all-proceeds-retained sensitivity subtracts ₹29.82 crore; it is not selected as actual cash. Historical P/E, P/B and EV/EBITDA cannot resolve current financing or prove cheapness. No lease liability is manufactured under Indian GAAP; lease/rent costs remain in operating economics and property obligations require evidence. Unpaid tax is a separate claim in terminal equity, not hidden in debt. No interim dividends are assumed and accumulated cash is not credited twice.

The model starts in November 2026 with March operating balances plus stated 0%, 50% or 100% retention of the known receipts. This intentional stale-opening sensitivity is not an October balance-sheet estimate. Default volume growth is 10%, price growth 2%, core EBITDA input margin 6%, domestic/export collection lags three/four months, 100 inventory days, two months supplier credit and 85% recovery of older receivables. Fixed operating costs prevent margins from being flat by construction. Bear links customer loss, longer collections, inventory loss and tighter suppliers; bull assumes better margins/collection, all cash retained and conditional new finance. Rates, fees, maturities, operating reserve, tax settlement, whole-share issuance and authorization are explicit inputs. Default renewed working-capital debt is an assumption, never a spare sanctioned line.

{{MAIN_CASES}}

Failed paths have no ordinary terminal price, IRR or hurdle-entry range. Their failure months identify the model cash/reserve condition, not an actual corporate default date. All source eligibility flags are false until current funding and product evidence is available. The strict disclosed-balance case is a stress based on dated information, not a finding that the firm has no money today. The favourable funded reference retains all receipts, assumes 10% volume growth, 10% margin, faster collections and 80 inventory days; it is shown to avoid suppressing counterevidence and is not promoted into the unsupported base case.

{{FUNDED}}

Terminal valuation is earned, not merely an exit multiple. At five/ten years the same monthly engine runs for twelve more months at terminal growth, carrying AR/AP cohorts, inventory seasonality, tax, interest, debt maturity, CWIP and commissioning. No fresh debt/equity rescue is allowed in that extension. Replacement capex is at least D&A; incremental reinvestment is the larger of physical growth capex plus nonnegative working-capital needs and NOPAT×g/marginal ROIC. Already-paid CWIP is not repurchased or instantly commissioned. Capacity-lost output or a reserve shortfall suppresses ordinary return. The required retained reserve is the maximum cash needed across actual transition troughs, including the economic reinvestment floor; only cash above it is added to enterprise value. FCFF/(WACC−g) is reduced by horizon debt and unpaid tax, and divided by horizon diluted shares. An 8× earned EBITDA cross-check is separate. Full definitions and assumptions are in model_spec.md.

{{TERMINAL}}

{{SENSITIVITY}}

These finite grids are diagnostics, not optimization proof or probability-weighted forecasts. Every initial trial and every refinement around funding/return-target changes is retained, including failure. Earlier superseded model versions are also retained with their limitations. No target return was manufactured by silently changing capital constraints. Conditional 12%/15%/18% entry values from the funded reference are mathematical sensitivities only; they are not a buy range while G2/G3 remain unresolved.

## 11. Bear Case & Permanent-Loss Path

The strongest bear case is that the move toward branded/value-added products fails to produce sustained collected margins, while commodity inventory and customer credit absorb the equity raised. Domestic growth may prove lower-quality trading or price/mix rather than repeatable volume; old receivables may recover below book, inventory may need discounting, and supplier credit may shorten exactly when banks require better documentation or renewal. Interest and recurring fees then rise, and limited existing share authorization forces either a cash shortfall or a new, discounted, shareholder-approved raise. An apparently growing enterprise can destroy per-share value through cash absorption and dilution even without misconduct.

The linked stress reduces customers and export realization, stretches collections, increases inventory days, impairs inventory, lowers old-AR recovery and cuts supplier terms together. This is more informative than isolated margin changes, but remains hypothetical. Reported no-default/no-fraud audit findings, clean IFC, new equity and actual installations are meaningful counterweights. The thesis-break variable is failure to convert the stock/receivable asset base into usable cash while maintaining lender access, not a one-quarter share-price fall. The investment cannot be assigned a precise permanent-loss probability or D score without a current obligations/funding bridge.

## 12. 5× / 10× Feasibility

Fivefold and tenfold price targets from ₹375.05 are ₹1,875.25 and ₹3,750.50 before costs. At unchanged current shares these require equity values of about ₹2,414.57 crore and ₹4,829.14 crore; additional shares increase the enterprise/equity burden further. Required annualized price gains are 37.97%/58.49% over five years and 17.46%/25.89% over ten years, before entry/exit costs. A narrative about a small market cap or a growing market is insufficient.

{{TARGETS}}

The bounded reverse grid tests 0%–50% annual volume growth with 10% starting margin, ₹15 crore conditional incremental debt and existing share authorization. The expanded envelope uses 12% margin, ₹75 crore outstanding/₹200 crore cumulative new debt, up to 40 million authorized shares and much greater capacity, all expressly unverified assumptions. Refinements are retained at each tested transition. No funded 12%, 15%, 18%, 5× or 10× crossing is established in either envelope. This does not mathematically prove impossibility outside the grid; it shows that a 5×/10× thesis is unsupported by the examined funded cash/capacity paths. Increasing a terminal multiple without reinvestment, funding or dilution would not answer the question.

## 13. Monitoring Plan

{{MONITORING}}

These are evidence milestones, not promises of company delivery or a recurring surveillance service. Reopen the underwriting only when new primary evidence resolves the relevant link. A revised quote should trigger revaluation, not automatic changes to business-quality scores.

## 14. Final Classification & Conditional Action

**Pending evidence / Hold, unresolved.** Neither “high-quality compounder” nor “cheap turnaround” is established under the v3.0 matrix. BQS, GQS and IAS are NS, and this company belongs in a pending-evidence table rather than at the bottom of a numerical ranking as though it had a proven low score. Positive installed assets, real historical volume growth, new equity and clean current main opinions do not override negative cumulative CFO and unresolved financial/cash bridges. Conversely, those gaps do not prove fraud, default or asset nonexistence.

At ₹375.05 there is no source-eligible base return or conditional actionable purchase range. The action category is research hold: obtain reconciled current balances and lender terms, close audit questions, and test collected product economics before considering price. The conditional model suggests substantial valuation discipline is necessary even if favourable assumptions become verified. No trading, allocation, public-page update, Git action or publication authorization is implied by this report.

## 15. Sources, Assumptions & Open Questions

Primary-source priority is original prospectus/audit/results, exchange announcements, official daily market files and dated issuer/credit-rating disclosures. Management assertions, derived calculations and analyst assumptions are distinct. Original files remain retained separately; the archive is source-safe and contains authored extracts, exact links, dates, page locators and original hashes, not PDFs/OCR or private helper material. Missing website copies are not silently replaced with different document vintages. Exact source URLs are preserved without editorial spacing changes. Audit, business and peer supplements provide detailed claim-specific counterevidence and page references.

{{SOURCE_LEDGER}}

Highest-value open questions: a dated April–October cash/debt/working-capital bridge; actual current sanctioned and available facilities with covenants, rates, security and maturities; stock-return reconciliations accepted by lenders; receivable confirmations and subsequent collections; inventory quantity/cost/age and realization; gross capex/disposal/CWIP and title/lease evidence; current tax cash bridge; CSR and CARO corrections; product volume/revenue/capacity economics; current customer concentration; and receipt/collection evidence for the September export order. These are specific closure requirements, not assumed adverse answers.

Model inputs deliberately expose the assumptions that matter most: cash retention, collections and impairment, inventory carry and seasonality, supplier credit, continued bank lines, debt costs/maturities, realisations, commissioned capacity, capex intensity, economic reinvestment return, WACC and terminal growth. Decimal precision is for reproducibility, not a claim of forecasting accuracy. The compact and full archives differ only in compression and contain identical authored material. Running build.py regenerates calculations and readers from declared inputs; guarded fresh recovery and independent reproduction are separately attested.

{{UPDATES}}

{{QUALITY}}
