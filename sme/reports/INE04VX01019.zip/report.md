# Sheetal Universal Limited
## 1. Executive Verdict

**Hold, unresolved. BQS NS; GQS NS; IAS NS.** Sheetal processes and trades peanuts, sesame, spices and agricultural foods, with new flavoured-nut, protein and oil assets and a nascent domestic brand. The potential thesis is a commodity processor moving toward higher-value products, not yet a demonstrated compounder. Real FY2023 production expansion, installed assets and a specific export order are positives. The decisive obstacle is that reported growth and profits have not produced dependable cumulative operating cash, while four years of bank-stock reporting issues and current disclosure inconsistencies remain incompletely resolved. At ₹375.05, even favourable, explicitly conditional funded cases do not establish a satisfactory return. A lower quote alone cannot resolve the reliability and funding holds. Verified collections, inventory realization, current cash and lender capacity, and mature product economics would change the assessment. This is completed deep research with an incomplete investment-evidence basis, not an allegation of fraud or default.

## 2. Research Header, Gates and Data Confidence

Original requested metadata is retained unchanged: **Sheetal Univer.; SHEETAL; INE04VX01019**. The legal issuer is **Sheetal Universal Limited**, NSE Emerge SME, not Sheetal Cool Products. Dossier 364 is separate from the main-board research and from any pending publication batch. Information cutoff is 20 October 2026; price is the official 19 October 2026 close. Later knowledge is not used to backfill the thesis. [Final prospectus](https://nsearchives.nseindia.com/emerge/corporates/content/SheetalUniversal_PROSP.pdf) and the [dated security master](https://nsearchives.nseindia.com/content/cm/interop/NSE_CM_security_19102026.csv.gz) anchor identity.

| Item | Value |
|---|---|
| Security | SHEETAL / INE04VX01019 / NSE Emerge |
| Price / date | ₹375.05 / 19 October 2026 |
| Issued shares / market cap | 12875999 / ₹482.91 crore |
| Framework | v3.0 / SHA256 68d4de4255427df276318d0231530b867a453e740c74150e9768bf1387224137 |
| Financial / model scope | Consolidated annual Indian GAAP / conditional monthly commodity model |

Annual financial scope is consolidated Indian GAAP Accounting Standards under section 133, not assumed Ind AS. Original standalone audit/CARO records are examined separately, never treated as consolidated financial data. FY2026 is the latest available audited year; no invented September 2026 cash flow or overlapping TTM is used. Horizons are five and ten years. The equity reference hurdle is 15%, with 12% and 18% sensitivities; liquidity reference is ₹5 lakh, not a proposed allocation. All cash-model forecasts are conditional because the March-to-October balance bridge and actual bank facilities are unverified.

| Sessions | Observed / missing / zero | Mean / median turnover ₹ | 2% / 5% / 10% exit days for ₹5 lakh |
|---|---|---|---|
| 20 | 20 / 0 / 0 | 1,206,595.00 / 1,141,737.50 | 21.90 / 8.76 / 4.38 |
| 60 | 60 / 0 / 0 | 1,899,244.58 / 1,227,662.50 | 20.36 / 8.15 / 4.07 |

The reference budget can buy only two whole 500-share lots: 1,000 shares costing ₹375,050. A third lot costs ₹562,575 and exceeds ₹5 lakh. One lot costs ₹187,525; only 6 of 60 and none of the last 20 sessions had enough turnover for one such lot at 5% participation. Four sessions had a single reported high/low price, which is not independently proven circuit-lock evidence. Days aggregate turnover theoretically; they do not authorize fractional-lot execution. Live spread/depth and intraday price-band restrictions are ND.

| Gate | Status | Finding / closure |
|---|---|---|
| G1 | Conditional | Disclosure/control and rating-cooperation concerns warrant caution; no established severe diversion or minority-abuse finding. Verify current bank reporting, audit trail and disclosure remediation. |
| G2 | Hold — unresolved | Repeated original audit/control concerns and inconsistencies in audited notes/CARO, net capex and operating balance confirmations limit investment reliability. Corrected reconciled statements and bank/asset/confirmation evidence; distinguish clerical errors from material unexplained differences. |
| G3 | Hold — unresolved | Current post-warrant cash, borrowing headroom, repayment and renewal bridge unavailable. Conditional model shortfalls are not actual default evidence. Dated lender sanctions, current cash/receivable/inventory bridge and due-obligation schedule. |
| G4 | Conditional | Observed market close and 60 trading sessions, but large lot and sparse qualifying turnover constrain implementation. Verify live spread/depth, current restrictions and actual position before dealing. |

| Subject | Confidence |
|---|---|
| identity and price | High: exact ISIN, official dated trades and issuances reconcile; legal issuer not Sheetal Cool Products. |
| historical financials | Medium on retrieved annual levels; Low on unresolved cashflow/control and balance-confirmation questions. |
| growth decomposition | Low on FY24–FY26 price/volume and product mix, though FY23 real production growth is verified. |
| incremental returns | Low: accounting proxies not mature product economics. |
| current funding and valuation | Low: intervening balance bridge and enforceable bank capacity unverified. |
| overall | Low for investment eligibility; not an average of stronger subjects. |

## 3. Scorecard and Calculation Audit

GQS means **Growth Quality Score**, not governance. The nine business/growth factors and IAS R/D/P/L are scored once and reused. NS means not scoreable; ND means data unavailable; NM means not meaningful. Missing factors are not assigned 5 or renormalized away. Bounds are mechanical possibilities, not confidence intervals or implied investment scores. Full precision is retained in scores.json; numerical displays use Decimal half-up to one decimal and classification uses unrounded values.

| Measure | Raw / final | Known weighted contribution | Coverage | Missing-data bound | Cap / dependency |
|---|---|---|---|---|---|
| BQS | NS / NS | 2.8000 | 68.00% | ['3.12', '6.00'] | Cap None; capped ['3.12', '6.00'] |
| GQS | NS / NS | 2.0500 | 45.00% | ['2.60', '7.55'] | Cap 5; capped ['2.60', '5'] |
| IAS | NS / NS | 0.4000 | 10.00% | ['1.30', '9.40'] | Cap None; capped ['1.30', '9.40']; dependency ['1.8300', '8.4000'] |

| Factor | Score / confidence | Evidence and counterevidence | Weighted contributions BQS / GQS / IAS |
|---|---|---|---|
| GOV | 4 / Medium | FY2022–FY2025 bank-stock reporting concerns recur; FY2024/FY2025 stock-in-transit tables numerically reconcile, but controls remediation is not established. FY26 audit-trail absence, inconsistent CARO disclosures and continuing CRISIL non-cooperation limit stewardship confidence. Counter: Original resignation cites workload, not withheld information; current IFC opinion is unmodified and internal audit was appointed. Capital raising is disclosed, not inherently abusive. Rationale: Material recurring disclosure/control weakness; no substantiated diversion or minority-abuse finding, so no governance override. IDs: AR23, AR24, NSE_AR25, AR26, CRISIL26, RESIGNATION25 | 0.80 / NA / NA |
| MOAT | 4 / Medium | Agricultural commodity processing faces raw-material, currency and customer substitution risks; certifications enable access but are not pricing power. Actual FY23 processing volume grew, while new value-added lines and brand provide a possible route beyond commodity trading. Counter: Supply-chain relationships, Gujarat sourcing access, trial-run assets and export orders are genuine operating assets, not evidence of no capability. Rationale: Contestable economics; repeat consumer demand, product unit margins and durable excess returns not yet demonstrated. IDs: PROSPECTUS_FINAL, CAPACITY25, AR26, PEERS | 0.80 / NA / NA |
| REV | NS / Low | Reported FY2021–FY2026 sales CAGR is 35.79%; FY2023–FY2026 only 10.49%, with FY25 contraction and FY26 recovery. FY23 production supports real growth, but FY26 domestic sales surge while exports contract and current product volumes/prices are not disclosed. Counter: A small base alone is not a penalty; FY23 demonstrated production increased materially. Rationale: NS because underlying recent expansion cannot be separated from commodity prices, mix and trading. The reported five-year CAGR starts at 9 and three-year CAGR at 6, but neither is silently substituted for missing evidence. Russia was not operating at March 2026 and is not asserted to be a growth driver. IDs: PROSPECTUS_FINAL, AR26, CAPACITY25 | NS / NS / NA |
| DUR | 5 / Medium | Food demand and processing/export access provide a continuing accessible market. New flavoured nuts, protein and oil capacities plus Dubai order expand possibilities, but no verified repeat uptake or annual operating utilization supports a long runway. Counter: The September2026 order and installed assets are specific opportunities; global food TAM alone is not used as market access. Rationale: Some addressable runway with commodity, execution and customer constraints. IDs: CAPACITY25, PRODUCT26, ORDER26, PROSPECTUS_FINAL | 0.50 / 1.00 / NA |
| CAP | NS / Low | Three/five-year accounting incremental-return proxies use identifiable NOPAT and capital changes, with material reconciliation residuals. The new project investment disclosed in May 2025 was ₹14.99 crore; readiness was announced after FY2025 year-end, so its full-year returns cannot explain the prior margin jump. Counter: Margins and profit rose and invested assets exist; a missing attribution bridge is not proof of value destruction. Rationale: NS: no sustainable product/cohort return evidence or complete operating-capital reconciliation; do not award a neutral/low score merely because information is missing. IDs: AR26, NSE_AR25, PROSPECTUS_FINAL, CAPACITY25 | NS / NS / NA |
| CASH | 3 / Medium | FY24–FY26 cumulative reported CFO −₹30.8081 crore versus PAT ₹22.8815 crore; original FY25 CFO classification still leaves deeply negative cumulative cash. FY26 receivables and finished inventory grew sharply, older receivables total ₹7.9958 crore and long/short advances remain cash tied up. Counter: FY25 generated positive CFO; supplier credit and equity receipts supply financing, and rapid growth can absorb cash without being fraudulent. Rationale: Persistent weak operating realization, not capex masquerading as the explanation for CFO. Triggers disclosed GQS cap 5. IDs: AR26, NSE_AR25, RESULT24, PROSPECTUS_FINAL | 0.30 / 0.30 / NA |
| BAL | NS / Low | March26 gross debt ₹38.1126 crore and cash ₹0.1489 crore are known dated figures; ₹29.82 crore later warrant receipts are verified gross inflows. Current retained cash, actual lender headroom, renewal and complete maturity terms are not established; CRISIL rated facility ₹25 crore is not spare capacity. Counter: New equity can materially strengthen liquidity; conditional model failures do not prove a real default or unfinanceable actual obligation. Rationale: NS until current bridge and facilities establish stress funding. IDs: AR26, CONVERSION_20261010, CRISIL26 | NS / NA / NA |
| EXEC | 5 / Medium | New-line installation and trial run were reported in May 2025, followed by NUTZO domestic launch and specific export orders. IPO machinery plan ₹5.84 crore became ₹11.99 crore machinery plus ₹3 crore building, while actual product volumes and realized order collections are ND. Counter: Completed assets and later commercial activity are evidence of execution; absence of promotional guidance is not a failure. Rationale: Mixed scaling delivery with cost/timing and cash-return gaps. IDs: PROSPECTUS_FINAL, CAPACITY25, PRODUCT26, ORDER26 | 0.40 / NA / NA |
| EARN | 5 / Medium | FY26 core EBITDA ₹18.7376 crore remains positive after excluding all ₹2.2444 crore other income. Net profits rise slower than revenue; current per-share claim count is 12,875,999 after warrants versus 11,455,999 in annual EPS. Counter: Revenue-based core profitability improved relative to pre-IPO period, not all profit is other income; all-other-income exclusion is conservative for export incentives. Rationale: Mixed growth quality because inventory economics, product attribution and dilution temper operating progress. IDs: AR26, NSE_AR25, CONVERSION_20261010 | NA / 0.75 / NA |
| R | NS / Low | No source-eligible supported base-case IRR; failed paths suppress ordinary returns. Conditional monthly cash, physical capacity, financing, whole-share dilution and terminal reinvestment trials are retained. Counter: Favourable conditional cases are also tested, not discarded to make an adverse conclusion. Rationale: No source-eligible supported base-case IRR; failed paths suppress ordinary returns. IDs: MODEL, AR26, MARKET | NA / NA / NS |
| D | NS / Low | Actual current survival cash and claims cannot be established despite conditional stress economics. Conditional monthly cash, physical capacity, financing, whole-share dilution and terminal reinvestment trials are retained. Counter: Favourable conditional cases are also tested, not discarded to make an adverse conclusion. Rationale: Actual current survival cash and claims cannot be established despite conditional stress economics. IDs: MODEL, AR26, MARKET | NA / NA / NS |
| P | NS / Low | Price is verified but reverse cash/capacity expectations remain assumption-dependent; no forced point score from unsupported inputs. Conditional monthly cash, physical capacity, financing, whole-share dilution and terminal reinvestment trials are retained. Counter: Favourable conditional cases are also tested, not discarded to make an adverse conclusion. Rationale: Price is verified but reverse cash/capacity expectations remain assumption-dependent; no forced point score from unsupported inputs. IDs: MODEL, AR26, MARKET | NA / NA / NS |
| L | 4 / Medium | All 60 official sessions contain SM trades; conservative 60-day mean/median implies 8.15 theoretical days for₹5lakh at 5% participation. Lot 500 costs ₹187,525; only 6 of 60 and 0 of the last 20 sessions have turnover sufficient for one such lot at 5% participation. Counter: Trading is observed on every sampled session, so no missing-day-zero inference or suspension claim. Rationale: Starting schedule score 5 reduced one point for severe whole-lot discreteness; spread/current depth unavailable. Conditional on reference size, not a position recommendation. IDs: MARKET, MASTER | NA / NA / 0.40 |

BQS weights are GOV 20%, MOAT 20%, REV 12%, DUR 10%, CAP 12%, CASH 10%, BAL 8%, EXEC 8%. GQS weights are REV 40%, DUR 20%, EARN 15%, CAP 15%, CASH 10%. IAS uses final BQS 25%, R 35%, D 20%, P 10%, L 10%. Persistent CASH 3 imposes a GQS ceiling of 5, but NS remains NS. No GOV≤3 or G1-fail override is imposed, and a conditional simulation failure is not treated as an evidenced G3 default/funding failure. G2 prevents ranking eligibility. IAS dependency-aware bounds use the BQS bound rather than allowing BQS to range independently from 1 to 10. MOAT ±1 changes known BQS by ±0.20 and the IAS dependency contribution by ±0.05; EXEC ±1 changes them by ±0.08 and ±0.02. Unknown factors stay unknown.

## 4. Business Overview

The economic chain is procurement, sorting/processing, storage, shipment, invoicing and collection. Peanuts, sesame, cumin and other agricultural commodities expose the firm to harvest pricing, quality/rejection risk, inventory carry, foreign exchange, freight and customer credit. Revenue recognition is not cash receipt. Supplier credit funds part of the cycle but does not make inventory or receivables free. Exports require market access and certifications, yet neither certification nor an export order proves a durable price premium.

FY2026 exports fell from ₹78.14 crore to ₹49.20 crore, while domestic revenue rose from ₹27.53 crore to ₹124.56 crore. The ₹68.09 crore net revenue increase was therefore domestic-led, not export-led. Exports represented 28.31676285% of sales. Current product volumes, trading versus own-processing mix, unit prices and new-line utilization are unavailable. This prevents attributing the domestic surge to the new brand or protein line. The Russia subsidiary was incorporated on 5 March 2026 with RUB10,000 capital and was not operating at year-end; it is not assumed to have caused consolidated growth. UAE status and quantified contributions need clarification. [FY2026 annual report](https://sheetaluniversal.com/wp-content/uploads/2026/09/Annual-Report_Final-2025-26-upload.pdf), PDF91/124 geography notes and business_research.md.

The original IPO plan described protein powder and cold-pressed oil capability with 25 tonnes/day or 7,500 tonnes/year, ₹5.84 crore machinery and ₹12 crore working capital. There were no disclosed marketing/offtake tie-ups for that plan at the prospectus date. The [21 May 2025 disclosure](https://nsearchives.nseindia.com/corporate/SHEETAL_21052025171754_Disclosure_Signed.pdf) subsequently reported installed machinery, trial runs and commercial readiness: 12 tonnes/day flavoured nuts, 8 protein and 12 oil; machinery ₹11.99 crore plus building ₹3 crore. These are not simply 32 independent tonnes/day because products may share feedstock. Scope changed, so the cost comparison is a reconciliation request, not a proven like-for-like overrun.

## 5. Moat / Industry Position

A Gujarat sourcing base, relationships, export access and processing assets constitute a real operating platform. The moat question is whether they deliver lower delivered cost, repeat demand, superior quality economics or sticky customers after working-capital and capital costs. Current evidence does not demonstrate these sufficiently. Commodity substitutes, customer switching, competing processors and volatile input prices constrain pricing power. Branding may improve economics, but the February 2026 NUTZO launch is an initiative, not verified consumer sell-through. Historical top-ten customer concentration was 79.28%, 56.16%, 66.07% and 72.41% in FY2021, FY2022, FY2023 and the five months to August 2023 respectively. Current concentration is ND; it is not assumed unchanged.

| FY2026 peer / scope | Sales ₹cr | PAT ₹cr / margin | Economic comparison / primary |
|---|---|---|---|
| Shreeji Global FMCG Limited / Standalone | 766.40 | 19.92 / 2.60% | Closest processing/trading and SME comparator. More domestically focused, broader spice/grain portfolio and larger scale; not a peanut powder pure play. [Primary filing](https://nsearchives.nseindia.com/annual_reports/SME_AR_31887_SHETHJI_2025_2026_A_16442392_08092026172713.pdf) |
| NHC Foods Limited / Consolidated | 601.31 | 12.32 / 2.05% | Bulk agri-export/trading comparator; diversification-risk example. Consolidation now includes international trading, a March 2026 Hong Kong acquisition trading metals/steel/agro products, and diversification into beverages and packaged water. [Primary filing](https://nhcgroup.com/legacy-assets/data/investors/34th%20Annual%20General%20Meeting/Annual%20Report%20FY%2025-26.pdf) |
| Sakuma Exports Limited / Consolidated | 1,708.28 | 9.51 / 0.56% | Weaker current profitability / bulk commodity trading downside comparator. Trading-led, broader commodity/geographic mix and much larger turnover; not a new protein/flavoured-nut manufacturer. [Primary filing](https://sakumaexportsltd.com/investors/annualreport/21st-Annual-Report-2025-2026.pdf) |
| Gujarat Ambuja Exports Limited / Consolidated | 5,728.60 | 304.28 / 5.31% | Stronger scale/integration/liquidity benchmark, not direct valuation peer. Maize starch/derivatives, soybean and industrial ingredients at much larger scale, multiple plants and deeper processing, alongside cotton yarn. Not a peanut-processing clone. [Primary filing](https://www.ambujagroup.com/documents/financials/annual-report/annual-report-fy-2025-26.pdf) |

Peers are selected by economics, not size alone. Shreeji is the closest processing/trading SME comparator; NHC supplies another agro-food distribution benchmark; Sakuma shows thin-margin commodity downside; Gujarat Ambuja demonstrates larger-scale integrated processing but is not a direct valuation twin. Their scope, scale and diversification differ. No peer BQS/IAS ranking or imported peer P/E target is fabricated. Primary financial pages, source-scale observations and cautions are in peer_inputs.json and peer_research.md. Their margins show why a processor or brand label does not establish pricing power. Sheetal's higher recent PAT margin must be tested against its own cash cycle and product mix.

## 6. Revenue Growth & Scale

| Period | Start / end revenue ₹cr | Reported CAGR |
|---|---|---|
| 2023–2026 | 128.81 / 173.76 | 10.49% |
| 2021–2026 | 37.64 / 173.76 | 35.79% |

| FY | Revenue ₹cr | Annual addition ₹cr | Growth |
|---|---|---|---|
| 2021 | 37.64 | ND / NS | NS |
| 2022 | 38.69 | 1.05 | 2.79% |
| 2023 | 128.81 | 90.12 | 232.95% |
| 2024 | 131.95 | 3.13 | 2.43% |
| 2025 | 105.67 | -26.27 | -19.91% |
| 2026 | 173.76 | 68.09 | 64.43% |

The FY2021 base is small, but that alone is not a reason to penalize growth. There is real FY2023 operating evidence: peanut production increased from 2,176.40 to 8,898.43 tonnes, while cumin/sesame output increased from 1,528.47 to 3,500.24 tonnes. Combined production grew about 234.66%, near the reported sales increase. Production is not exactly sales volume, but it substantiates expansion beyond mere nominal inflation for that year. By contrast, FY2025 sales contracted and FY2026 recovered through domestic sales; recent price/volume, processing/trading and product-mix decomposition remains absent. The prospectus also conflicts between 12,000 and 18,000 tonnes of peanut capacity while showing the same utilization percentage, so no precise current utilization is manufactured.

REV remains NS. The reported five-year CAGR would mechanically start at 9 and the three-year CAGR at 6 under the schedule, but neither number substitutes for verified underlying expansion. The unresolved issue is current quantity, commodity price and mix, not a blanket rejection of small firms or a claim that new consolidation drove growth. A verified product revenue/volume realization bridge could make REV scoreable without waiting for a different share price.

## 7. Growth Quality & Reinvestment Runway

Food consumption and export markets offer a continuing addressable demand pool. The investable runway is narrower: sellable certified output, actual orders, financed procurement, capacity commissioning and collected customer proceeds. The September 2026 Dubai order covers 1,000 tonnes of peanuts at USD1,220/tonne, USD1.22 million total and company-stated ₹11.529 crore. It is not a protein-powder order or annual recurring contract. Its one-month execution period had not expired by the information cutoff; no absence-of-completion announcement is treated as lateness. The Russia/CIS tie-up lacks quantified offtake and is not booked as forecast demand.

Scaling consumes inventory, receivables, plant and operating reserves. FY2026 inventory was ₹47.59 crore and receivables ₹41.86 crore. Supplier credit of ₹26.47 crore offsets only part. A larger borrowing line or equity issue finances the gap but can reduce returns through interest, fees and dilution. The cash model explicitly separates physical capacity, paid CWIP and commissioned PPE; an order cannot become productive output instantly. It uses one peanut-equivalent throughput proxy because joint-output product data are incomplete. This is not a claim that actual demand or installed capacity equals the model proxy.

DUR is 5: accessible opportunities exist, but sustained utilization and customer repeatability are unproven. EARN is 5: core profit is positive, but the margin rise is not yet reconciled to product economics and per-share claims increased. CAP is NS: accounting incremental-return proxies are observable but cannot certify sustainable returns on new assets. CASH is 3 because cumulative conversion is persistently weak; the GQS cap of 5 follows. A cap is not a point estimate. The weakest link is collected, repeatable, capital-efficient growth rather than theoretical market size.

## 8. Management, Governance & Execution

| Date / commitment | Observed delivery | Unresolved test |
|---|---|---|
| Nov2023 IPO | ₹5.84cr machinery / ₹12cr working capital plan | Offtake, product economics and cost/scope bridge |
| 21May2025 | ₹11.99cr machinery + ₹3cr building, trial ready | Actual commissioning schedule, utilization and collections |
| Feb2026 | NUTZO domestic launch announced | Repeat consumer sell-through, margins and trademark progress |
| May–Oct2026 | All 1.42m warrants converted; ₹29.82cr gross receipts | Current retained funds and deployment bridge |
| 23Sep2026 | 1,000t Dubai peanut order, one-month execution | Shipment and receipt after cutoff; not presumed overdue |

Original FY2022 standalone CARO already records bank-stock differences and no Q4 submission. FY2023 standalone and consolidated versions respectively describe domestic and export receivables counted as stock, with a small arithmetic typo in one difference. FY2024 disclosed stock-in-transit explains its numerical table differences, but the suitability and consistent bank-reporting treatment still needs evidence. FY2025 Q2 ₹31.51 lakh and Q4 ₹160.91 lakh stock-in-transit bridges leave zero arithmetic residual despite the narrative saying statements were not in agreement. Those tables do not prove an unexplained numerical shortfall. FY2026 acknowledges working-capital limits above ₹5 crore without a clear closure of this history.

Other current issues include audit-trail/edit-log operation not throughout the year, inconsistent cash-loss and subsidiary-loan CARO statements, and uncertainty over confirmations and original PPE verification. These are material reliability questions, not automatically fraud. Current main audit and IFC opinions are unmodified; the auditor reports no fraud or default and regular undisputed taxes. An internal auditor was appointed on 30 May 2025 and reports were considered, a genuine remediation step. The 2 August 2025 auditor resignation cites workload/preoccupation, not withheld information or a conflict. There is no basis to rewrite that explanation into an adverse resignation.

The FY2026 CSR audit said neither spending nor transfer had occurred at signing; management later reported ₹9.325 lakh PM CARES payment on 5 September against a stated ₹9.3208667 lakh requirement. That later payment is relevant counterevidence, but the ₹12.59 lakh provision/expense and calculation require reconciliation. The dividend separate-account transfer was two days late while distribution was timely. Neither establishes debt default. The CRISIL June 2026 BB/Stable/A4+ issuer-not-cooperating rating, following the October 2025 cooperation flag, increases information risk. Its ₹25 crore rated-facility table is not current undrawn borrowing capacity. See audit_research.md and its evidence-led original-vintage chronology.

At 10 October 2026, Hiren Vallabhbhai Patel held 6,405,641 shares (49.75%) and spouse Kajal Hiren Patel 1,305,383 (10.14%), jointly about 59.89%, directly disclosed in the conversion filing. Hiren combines chairman/MD roles and Kajal is whole-time director. The six-person board includes three independent directors; the audit committee has two independent directors plus Hiren, relevant structural counterevidence. The annual report classifies six holders totaling 8,055,656 shares (70.32%) as promoters, whereas the prospectus group of five held 7,653,255; the 402,401-share difference is Nishant, shown separately as public in that prospectus. This reconciles arithmetic, not the current exchange promoter-group classification. Full current promoter/group, pledge and encumbrance data are ND. Historical no-pledge disclosure applies only at the prospectus date. Minimum promoter contribution of 2,291,200 shares carried three-year lock-in from IPO allotment; excess promoter and other pre-IPO holdings had one-year terms. Current depository release and preferential-conversion lock-in require verification, so tradable free float is not inferred simply as 100% minus the two directors. Source locators and original figures are in control_inputs.json.

Promoter-related property leasing, subsidiary advances and balances require arm's-length and title scrutiny. The prospectus's “owned” summary is qualified by leased-premises tables and no immovable property ownership; historical lessors included promoter-related parties. Current lease renewal/building rights need a bridge. This is not evidence that all ₹13.53 crore short/long advances are related-party diversion. GOV 4 reflects recurrence and incomplete closure while recognizing positive counterevidence. G2 is a reliability hold; G1 is conditional rather than failed.

## 9. Financial Forensics

| FY | Sales | Core EBITDA | PAT | CFO | Capex proxy | FCF proxy | Debt / cash | Equity |
|---|---|---|---|---|---|---|---|---|
| 2021 | 37.64 | 0.04 | 0.25 | 0.19 | ND gross; net inflow 0.1095 | ND / NS | 6.25 / 0.39 | 4.22 |
| 2022 | 38.69 | 0.16 | 0.28 | 2.31 | 0.43 | 1.89 | 9.85 / 5.38 | 4.50 |
| 2023 | 128.81 | 1.49 | 1.99 | -2.68 | 3.14 | -5.82 | 13.56 / 2.38 | 6.49 |
| 2024 | 131.95 | 2.45 | 2.08 | -27.02 | 2.33 | -29.35 | 15.16 / 0.55 | 34.54 |
| 2025 | 105.67 | 13.84 | 9.30 | 9.25 | 15.18 | -5.93 | 22.17 / 0.42 | 43.84 |
| 2026 | 173.76 | 18.74 | 11.51 | -13.03 | 0.40 | -13.44 | 38.11 / 0.15 | 54.77 |

All amounts above are ₹crore; FY2021–FY2023 are restated prospectus periods and later years use the stated original/comparative basis. EBITDA is derived as PBT + finance + D&A − all other income, not copied from a mislabeled summary. FY2026 D&A is ₹3.1080 crore and finance cost ₹2.4935 crore. Core EBITDA is ₹18.7376 crore and core EBIT ₹15.6296 crore. Removing all other income is deliberately conservative: forex and export incentives may recur commercially, whereas capital gains and interest are less central. FY2026 other income of ₹2.2444 crore includes forex ₹1.5339, duty drawback ₹0.0778, RoDTEP ₹0.4788, interest ₹0.0612 and capital gain ₹0.0918 crore. No automatic add-back is made for IPO amortization.

FY2026 disclosed PAT is ₹11.5078 crore. The reserves table adds a ₹0.01 lakh minority loss, suggesting an attributable-owner figure of ₹11.5079 crore; the research uses the explicitly disclosed ₹11.5078 crore as the common-earnings proxy and retains this immaterial attribution ambiguity. It does not silently switch between the two. Normalized tax is 25.168%, an analyst assumption applied to core EBIT, not a statement of statutory future cash tax.

| Years to FY26 | Cumulative CFO / PAT ₹cr | CFO/PAT | CFO after finance / PAT |
|---|---|---|---|
| 3 | -30.81 / 22.88 | -1.3464× | -1.6059× |
| 5 | -31.18 / 25.15 | -1.2394× | -1.5300× |

Weak CFO is not explained away by capex: capital spending occurs below CFO. FY2025 produced positive operating cash, but not enough to offset FY2024 and FY2026 consumption. The original FY2025 CFO was ₹10.0565 crore, versus ₹9.2517 crore in the FY2026 comparative. Roughly ₹0.8048 crore of loans/advances and non-current asset releases was reclassified to investing; total cash is unchanged to rounding. Using the original CFO improves three-year cumulative CFO to about −₹30.0033 crore, still deeply negative. Original FY2022/FY2023 CFO of ₹2.3434/−₹2.6612 crore differs from restated ₹2.3125/−₹2.6802 crore. Original FY2023 PAT ₹2.0604 crore became ₹1.9885 crore after restatement tax adjustments. The bridges are retained rather than erasing earlier audit vintages.

FY2024 fixed-asset “sale” cash of ₹1.4577 crore matches the CWIP decline, raising a classification question but not proving disposal proceeds. FY2026 fixed-asset purchase cash ₹0.4048 crore equals gross additions ₹0.8314 less sale/scrap ₹0.4266 despite a blank separate sale line. Reported FCF is therefore a labeled proxy, not independently certified gross-capex FCF. FY2021 gross capex is ND, not a fabricated negative investment. FY2026 provisions/current liabilities added ₹4.2085 crore to CFO, while ₹4.0270 crore was labeled taxes paid/adjustment; the current-tax provision increased ₹4.0038 crore. Algebraically the net tax-cash component may be ₹0.0232 crore. Deducting the ₹4.0038 crore again would double count. Tax ledgers and challans are needed before making a stronger claim.

| Period | ΔNOPAT / Δfunding IC ₹cr | Incremental proxy | Capex − D&A + ΔONWC ₹cr | Residual ₹cr |
|---|---|---|---|---|
| 2023–2026 | 11.05 / 75.06 | 14.73% | 17.91 − 5.09 + 52.78 = 65.60 | 9.46 |
| 2021–2026 | 12.02 / 82.61 | 14.55% | 21.48 − 6.17 + 57.36 = 72.67 | 9.94 |

Funding invested capital is equity + gross debt − cash − investments. Core operating capital is receivables + inventory − payables + PPE + CWIP. These are distinct proxies; advances, deposits, taxes, classifications and other claims explain why neither can simply replace the other. Incremental NOPAT is current less beginning normalized core NOPAT, divided by the change in funding capital over the same three/five-year period. The investment bridge compares reported net capex minus D&A plus core working-capital change with that denominator. Residuals remain material and timing is lumpy, so the 14%–15% accounting returns are not project IRRs or a forced CAP score. New capacity was reported trial-ready after FY2025 year-end, so FY2025 margin expansion cannot all be credited to a full year of its operation.

| FY | AR / inventory / AP ₹cr | Avg AR days | Inv / AP cost-proxy days | CCC proxy days | Core ROIC / funding ROCE / ROE |
|---|---|---|---|---|---|
| 2021 | 4.35 / 3.13 / 1.87 | ND / NS | ND / NS / ND / NS | ND / NS | NS / NS / NS |
| 2022 | 2.99 / 3.17 / 1.45 | 34.63 | 29.84 / 15.74 | 48.72 | -2.64% / -3.00% / 6.49% |
| 2023 | 10.86 / 6.48 / 7.15 | 19.63 | 13.83 / 12.33 | 21.13 | 5.53% / 6.48% / 36.17% |
| 2024 | 22.53 / 6.04 / 0.60 | 46.19 | 17.65 / 10.92 | 52.93 | 4.97% / 4.89% / 10.12% |
| 2025 | 21.68 / 17.18 / 1.93 | 76.36 | 46.15 / 5.02 | 117.49 | 21.12% / 22.13% / 23.73% |
| 2026 | 41.86 / 47.59 / 26.47 | 66.74 | 76.24 / 33.44 | 109.54 | 17.18% / 19.76% / 23.34% |

Average-balance working-capital days use revenue for receivables and a compatible but imperfect cost proxy, revenue minus core EBITDA, for inventory/payables. They are not misrepresented as exact procurement COGS days. FY2026 receivables at least one year old total ₹7.9958 crore, about 19.10%, with no allowance. Finished goods dominate inventory. Unsecured long/short advances total ₹13.5319 crore. Restricted deposits of ₹1.1966 crore are not freely spendable operating cash; deferred issue cost is not liquidity. March gross debt is ₹38.1126 crore against cash ₹0.1489 crore. Displayed debt components differ by ₹0.0001 crore, retained as an unallocated claim rather than ignored.

All 1,420,000 warrants were converted by 10 October 2026, at ₹210 each. Gross cash receipts were ₹7.455 crore upfront, ₹4.11075 crore in July, ₹4.07925 crore in September and ₹14.175 crore in October, totaling ₹29.82 crore. Issued claims are 12,875,999 shares, not the stale 11,716,999 shares in the dated tradable-security master. Authorized capital of 13,000,000 shares leaves only 124,001 further shares without new authorization. There are no remaining warrant proceeds to count again. Current retained cash, expenditure and debt repayment between March and October are ND. [10 October allotment](https://nsearchives.nseindia.com/corporate/SHEETAL_10102026175409_Outcome_10102026.pdf).

## 10. Valuation & Market Expectations

| Measure | Value / limitation |
|---|---|
| Market capitalization | ₹482.91cr |
| EV with March debt/cash bridge | ₹520.88cr |
| EV if all later receipts retained, sensitivity | ₹491.06cr |
| Current-share P/E / normalized P/E | 41.96× / 49.13× |
| Core EV/EBITDA / P/B | 27.80× / 8.82× |
| Reported FCF yield | -2.78% |

Market capitalization uses the current issued claim count. The displayed EV combines October price with dated March debt/cash and is explicitly a bridge, not a verified current EV. A separate all-proceeds-retained sensitivity subtracts ₹29.82 crore; it is not selected as actual cash. Historical P/E, P/B and EV/EBITDA cannot resolve current financing or prove cheapness. No lease liability is manufactured under Indian GAAP; lease/rent costs remain in operating economics and property obligations require evidence. Unpaid tax is a separate claim in terminal equity, not hidden in debt. No interim dividends are assumed and accumulated cash is not credited twice.

The model starts in November 2026 with March operating balances plus stated 0%, 50% or 100% retention of the known receipts. This intentional stale-opening sensitivity is not an October balance-sheet estimate. Default volume growth is 10%, price growth 2%, core EBITDA input margin 6%, domestic/export collection lags three/four months, 100 inventory days, two months supplier credit and 85% recovery of older receivables. Fixed operating costs prevent margins from being flat by construction. Bear links customer loss, longer collections, inventory loss and tighter suppliers; bull assumes better margins/collection, all cash retained and conditional new finance. Rates, fees, maturities, operating reserve, tax settlement, whole-share issuance and authorization are explicit inputs. Default renewed working-capital debt is an assumption, never a spare sanctioned line.

| Scenario | Horizon | Volume / margin / retained cash ₹cr | First failure month | Ordinary return |
|---|---|---|---|---|
| bear_5y | 5 | -5.00% / 3.00% / 0.00 | 1 | Suppressed |
| base_5y | 5 | 10.00% / 6.00% / 14.91 | 3 | Suppressed |
| bull_5y | 5 | 20.00% / 10.00% / 29.82 | 39 | Suppressed |
| bear_10y | 10 | -5.00% / 3.00% / 0.00 | 1 | Suppressed |
| base_10y | 10 | 10.00% / 6.00% / 14.91 | 3 | Suppressed |
| bull_10y | 10 | 20.00% / 10.00% / 29.82 | 39 | Suppressed |

Failed paths have no ordinary terminal price, IRR or hurdle-entry range. Their failure months identify the model cash/reserve condition, not an actual corporate default date. All source eligibility flags are false until current funding and product evidence is available. The strict disclosed-balance case is a stress based on dated information, not a finding that the firm has no money today. The favourable funded reference retains all receipts, assumes 10% volume growth, 10% margin, faster collections and 80 inventory days; it is shown to avoid suppressing counterevidence and is not promoted into the unsupported base case.

| Conditional funded reference | Exit sales / capex ₹cr | Diluted shares | Exit price / IRR | 12% / 15% / 18% entry ₹ |
|---|---|---|---|---|
| funded_reference_5y | 308.97 / 25.41 | 12875999 | 98.38 / -23.79% | 54.72 / 47.95 / 42.15 |
| funded_reference_10y | 549.40 / 85.82 | 12875999 | 199.61 / -6.30% | 63.00 / 48.36 / 37.38 |

Terminal valuation is earned, not merely an exit multiple. At five/ten years the same monthly engine runs for twelve more months at terminal growth, carrying AR/AP cohorts, inventory seasonality, tax, interest, debt maturity, CWIP and commissioning. No fresh debt/equity rescue is allowed in that extension. Replacement capex is at least D&A; incremental reinvestment is the larger of physical growth capex plus nonnegative working-capital needs and NOPAT×g/marginal ROIC. Already-paid CWIP is not repurchased or instantly commissioned. Capacity-lost output or a reserve shortfall suppresses ordinary return. The required retained reserve is the maximum cash needed across actual transition troughs, including the economic reinvestment floor; only cash above it is added to enterprise value. FCFF/(WACC−g) is reduced by horizon debt and unpaid tax, and divided by horizon diluted shares. An 8× earned EBITDA cross-check is separate. Full definitions and assumptions are in model_spec.md.

| Reference | Next NOPAT / D&A | Replacement / growth reinvestment | FCFF | Exit cash / retained reserve / excess | Debt / unpaid tax | 8× EBITDA cross-check ₹ |
|---|---|---|---|---|---|---|
| funded_reference_5y | 21.75 / 4.54 | 4.88 / 7.25 | 14.16 | 61.71 / 19.81 / 41.91 | 33.24 / 0.00 | 207.10 |
| funded_reference_10y | 39.51 / 8.31 | 8.31 / 13.17 | 26.34 | 103.57 / 33.28 / 70.29 | 32.79 / 0.00 | 393.81 |

Conditional funded-reference 5-year terminal-price sensitivity (₹; all source-ineligible):

| WACC / growth | 2% | 4% | 6% |
|---|---|---|---|
| 13.00% | 131.27 | 128.93 | 123.98 |
| 16.00% | 104.98 | 98.38 | 88.05 |
| 19.00% | 87.97 | 80.05 | 68.70 |

Default opening/funding 5-year growth/margin grid (first reserve-failure month, not ordinary IRR):

| Volume / margin | 3% | 6% | 9% | 12% |
|---|---|---|---|---|
| 0.00% | 3 | 3 | 3 | 3 |
| 5.00% | 3 | 3 | 3 | 3 |
| 10.00% | 3 | 3 | 3 | 3 |
| 15.00% | 2 | 3 | 3 | 3 |
| 20.00% | 2 | 3 | 3 | 3 |
| 30.00% | 2 | 2 | 3 | 3 |

Conditional funded-reference 10-year terminal-price sensitivity (₹; all source-ineligible):

| WACC / growth | 2% | 4% | 6% |
|---|---|---|---|
| 13.00% | 259.67 | 256.44 | 248.34 |
| 16.00% | 210.87 | 199.61 | 181.25 |
| 19.00% | 179.29 | 165.51 | 145.12 |

Default opening/funding 10-year growth/margin grid (first reserve-failure month, not ordinary IRR):

| Volume / margin | 3% | 6% | 9% | 12% |
|---|---|---|---|---|
| 0.00% | 3 | 3 | 3 | 3 |
| 5.00% | 3 | 3 | 3 | 3 |
| 10.00% | 3 | 3 | 3 | 3 |
| 15.00% | 2 | 3 | 3 | 3 |
| 20.00% | 2 | 3 | 3 | 3 |
| 30.00% | 2 | 2 | 3 | 3 |

These finite grids are diagnostics, not optimization proof or probability-weighted forecasts. Every initial trial and every refinement around funding/return-target changes is retained, including failure. Earlier superseded model versions are also retained with their limitations. No target return was manufactured by silently changing capital constraints. Conditional 12%/15%/18% entry values from the funded reference are mathematical sensitivities only; they are not a buy range while G2/G3 remain unresolved.

## 11. Bear Case & Permanent-Loss Path

The strongest bear case is that the move toward branded/value-added products fails to produce sustained collected margins, while commodity inventory and customer credit absorb the equity raised. Domestic growth may prove lower-quality trading or price/mix rather than repeatable volume; old receivables may recover below book, inventory may need discounting, and supplier credit may shorten exactly when banks require better documentation or renewal. Interest and recurring fees then rise, and limited existing share authorization forces either a cash shortfall or a new, discounted, shareholder-approved raise. An apparently growing enterprise can destroy per-share value through cash absorption and dilution even without misconduct.

The linked stress reduces customers and export realization, stretches collections, increases inventory days, impairs inventory, lowers old-AR recovery and cuts supplier terms together. This is more informative than isolated margin changes, but remains hypothetical. Reported no-default/no-fraud audit findings, clean IFC, new equity and actual installations are meaningful counterweights. The thesis-break variable is failure to convert the stock/receivable asset base into usable cash while maintaining lender access, not a one-quarter share-price fall. The investment cannot be assigned a precise permanent-loss probability or D score without a current obligations/funding bridge.

## 12. 5× / 10× Feasibility

Fivefold and tenfold price targets from ₹375.05 are ₹1,875.25 and ₹3,750.50 before costs. At unchanged current shares these require equity values of about ₹2,414.57 crore and ₹4,829.14 crore; additional shares increase the enterprise/equity burden further. Required annualized price gains are 37.97%/58.49% over five years and 17.46%/25.89% over ten years, before entry/exit costs. A narrative about a small market cap or a growing market is insufficient.

| Envelope | Funded crossings | Best tested funded path | Best IRR | Sales / capex / gross equity ₹cr | Final shares |
|---|---|---|---|---|---|
| 5 years / bounded | hurdle12: none; hurdle15: none; hurdle18: none; 5x: none; 10x: none | refine_bounded_5y_g0.155 | -22.98% | 394.05 / 43.32 / 0.00 | 12875999 |
| 5 years / expanded | hurdle12: none; hurdle15: none; hurdle18: none; 5x: none; 10x: none | reverse_expanded_5y_g0.5 | -11.55% | 1,335.44 / 257.64 / 359.24 | 26559675 |
| 10 years / bounded | hurdle12: none; hurdle15: none; hurdle18: none; 5x: none; 10x: none | refine_bounded_10y_g0.135 | -5.03% | 751.48 / 128.13 / 0.00 | 12875999 |
| 10 years / expanded | hurdle12: none; hurdle15: none; hurdle18: none; 5x: none; 10x: none | refine_expanded_10y_g0.185 | -0.13% | 1,150.80 / 211.10 / 0.00 | 12875999 |

The bounded reverse grid tests 0%–50% annual volume growth with 10% starting margin, ₹15 crore conditional incremental debt and existing share authorization. The expanded envelope uses 12% margin, ₹75 crore outstanding/₹200 crore cumulative new debt, up to 40 million authorized shares and much greater capacity, all expressly unverified assumptions. Refinements are retained at each tested transition. No funded 12%, 15%, 18%, 5× or 10× crossing is established in either envelope. This does not mathematically prove impossibility outside the grid; it shows that a 5×/10× thesis is unsupported by the examined funded cash/capacity paths. Increasing a terminal multiple without reinvestment, funding or dilution would not answer the question.

## 13. Monitoring Plan

| KPI | Dated baseline | Required evidence / warning |
|---|---|---|
| Current liquidity | March cash₹0.1489cr; later gross receipts₹29.82cr | Bank-verified bridge; unexplained draw/use or overdue obligations is a break warning |
| CFO realization | FY24–26 CFO−₹30.8081cr/PAT₹22.8815cr | Rolling comparable cumulative positive conversion without financing classified as CFO |
| Old receivables | ≥1year₹7.9958cr | Customer-level subsequent receipts; worsening age or noncollection |
| Inventory | ₹47.5861cr, mainly finished goods | Quantity/age/margin realization; discounting or slow stock |
| Bank reporting | FY22–25 recurring concerns | Accepted book/drawing-power/stock-in-transit reconciliation and FY26 closure |
| Audit controls | FY26 audit-trail gap; internal auditor appointed | Operational edit logs and reconciled CARO/CSR/tax disclosures |
| New products | May2025 readiness, Feb2026 NUTZO launch | Quarterly volume, realization, utilization, contribution and repeat orders |
| Capital returns | 3Y incremental accounting proxy14.73%, unreconciled residual | Project/cohort returns with investment/working-capital bridge |
| Dilution | 12,875,999 issued; 124,001 authorized headroom | Any approval, price, proceeds use and per-share return effect |
| Market implementation | ₹187,525 lot; median60d₹12.28lakh | Verify live depth/spread and restrictions; no fractional-lot execution assumption |

These are evidence milestones, not promises of company delivery or a recurring surveillance service. Reopen the underwriting only when new primary evidence resolves the relevant link. A revised quote should trigger revaluation, not automatic changes to business-quality scores.

## 14. Final Classification & Conditional Action

**Pending evidence / Hold, unresolved.** Neither “high-quality compounder” nor “cheap turnaround” is established under the v3.0 matrix. BQS, GQS and IAS are NS, and this company belongs in a pending-evidence table rather than at the bottom of a numerical ranking as though it had a proven low score. Positive installed assets, real historical volume growth, new equity and clean current main opinions do not override negative cumulative CFO and unresolved financial/cash bridges. Conversely, those gaps do not prove fraud, default or asset nonexistence.

At ₹375.05 there is no source-eligible base return or conditional actionable purchase range. The action category is research hold: obtain reconciled current balances and lender terms, close audit questions, and test collected product economics before considering price. The conditional model suggests substantial valuation discipline is necessary even if favourable assumptions become verified. No trading, allocation, public-page update, Git action or publication authorization is implied by this report.

## 15. Sources, Assumptions & Open Questions

Primary-source priority is original prospectus/audit/results, exchange announcements, official daily market files and dated issuer/credit-rating disclosures. Management assertions, derived calculations and analyst assumptions are distinct. Original files remain retained separately; the archive is source-safe and contains authored extracts, exact links, dates, page locators and original hashes, not PDFs/OCR or private helper material. Missing website copies are not silently replaced with different document vintages. Exact source URLs are preserved without editorial spacing changes. Audit, business and peer supplements provide detailed claim-specific counterevidence and page references.

| ID / primary record | Date / scope / pages | Original hash status |
|---|---|---|
| BUS01 / [SheetalUniversal_PROSP.pdf](https://nsearchives.nseindia.com/emerge/corporates/content/SheetalUniversal_PROSP.pdf) | 2023-11-28 / Consolidated commercial data unless noted / Printed pp.25–32,77–83,93–95,125–140; PDF p100=printed94, p144=printed138 | cacfb4b71beeae8a637550d28a5a72a6bc4bd824b8c9891f6217117a8fa5d784 |
| BUS02 / [Annual_Report_Year_2026.pdf](https://sheetaluniversal.com/wp-content/uploads/2026/09/Annual-Report_Final-2025-26-upload.pdf) | 2026-09-08 / FY2026 annual report / PDF pp49–51 MDA (printed48–50), p91 standalone noteA, p124 consolidated noteA; PDF p64 employee disclosure | 78545f7b3d5ce3ed6eb6c57f966f15ebf1bd670d7779388821e38a9561aa7bb2 |
| BUS03 / [SHEETAL_21052025171754_Disclosure_Signed.pdf](https://nsearchives.nseindia.com/corporate/SHEETAL_21052025171754_Disclosure_Signed.pdf) | 2025-05-21 / New line installation and proposed launch disclosure / PDF pp1–2 | 709956af52f2a9d59f92a38584eff204bebef846b8b63de511199d329ff464b7 |
| BUS04 / [SHEETAL_23022026191013_Disclosure_-23-02-2026_Signed.pdf](https://nsearchives.nseindia.com/corporate/SHEETAL_23022026191013_Disclosure_-23-02-2026_Signed.pdf) | 2026-02-23 / Domestic NUTZO launch / PDF p1, scanned; visually checked | e0419b3bd0bdb05f58454e178fe3f6a657060703f08554c3b57a15b8d8366b6e |
| BUS05 / [SHEETAL_13052024190933_announcement.pdf](https://nsearchives.nseindia.com/corporate/SHEETAL_13052024190933_announcement.pdf) | 2024-05-13 / YSM & K LLC market-development tie-up / PDF p1 | 667bc57137a78f3919a087db3316fd28a5566e503d4aa5226cf2fb5b34593ea7 |
| BUS06 / [SHEETAL_06032026200957_Regulation_30_signed.pdf](https://nsearchives.nseindia.com/corporate/SHEETAL_06032026200957_Regulation_30_signed.pdf) | 2026-03-06 / Helios Global LLC incorporation / PDF pp1–2 | 7852897ebcfe43b091af1840f5bc1d57e33f5f0ac8b972f5ca2a624eccc2fc4c |
| BUS07 / [SHEETAL_23092026190411_Peanuts_from_a_UAE-based_Company__Signed.pdf](https://nsearchives.nseindia.com/corporate/SHEETAL_23092026190411_Peanuts_from_a_UAE-based_Company__Signed.pdf) | 2026-09-23 / Export order, not executed revenue / PDF pp1–2 | 863e98b6d1eacc3a1992fe84079cee63e7713e63b15e8d38d7403a9221351016 |
| BUS08 / [Annual_Report_Year_2025.pdf](https://sheetaluniversal.com/wp-content/uploads/2025/09/Final-Report_Sheetal_2025.pdf) | 2025-09-08 / FY2025 annual report / PDF pp32–34 MDA, p103 revenue notes | e9f05c96609a626d3ff212aae2cabc4cdde9c5484bf2299d5305e9b26bac063a |
| BUS09 / [CRISIL rating rationale 2024-08-02](https://www.crisil.com/mnt/winshare/Ratings/RatingList/RatingDocs/SheetalUniversalLimited_August%2002_%202024_RR_348996.html) | 2024-08-02 / Credit rating opinion; not audited financial source / HTML: Rating Action, Detailed Rationale, Key Rating Drivers/About Group | missing_original_source_hash_web_only |
| BUS10 / [CRISIL rating rationale 2025-10-23](https://www.crisil.com/mnt/winshare/Ratings/RatingList/RatingDocs/SheetalUniversalLimited_October%2023_%202025_RR_377942.html) | 2025-10-23 / Credit rating opinion; not audited financial source / HTML: Rating Action, Detailed Rationale, Key Rating Drivers/About Group | missing_original_source_hash_web_only |
| BUS11 / [CRISIL rating rationale 2026-06-30](https://www.crisil.com/mnt/winshare/Ratings/RatingList/RatingDocs/SheetalUniversalLimited_June%2030_%202026_RR_398716.html) | 2026-06-30 / Credit rating opinion; not audited financial source / HTML: Rating Action, Detailed Rationale, Key Rating Drivers/About Group | missing_original_source_hash_web_only |
| PEER01 / [Shreeji_FY26.pdf](https://nsearchives.nseindia.com/annual_reports/SME_AR_31887_SHETHJI_2025_2026_A_16442392_08092026172713.pdf) | 2026-09-08 / FY2026 standalone / PDF pp59–66 business / MDA,105 P&L,106 sales geography; PDF pp59–66 business/MDA,105 P&L,106 sales geography | f7f939f1ae53498166a90522edf80ee7d24089b808f0c6fa50842397984a4fc4 |
| PEER02 / [NHC_FY26.pdf](https://nhcgroup.com/legacy-assets/data/investors/34th%20Annual%20General%20Meeting/Annual%20Report%20FY%2025-26.pdf) | 2026-09-01 (AGM notice); audited accounts dated 2026-05-21 / FY2026 consolidated / PDF pp72–73/printed70–71 MDA; PDF137/printed135 consolidated P&L; PDF pp72–73/printed70–71 MDA; PDF137/printed135 consolidatedP&L | dd3c16739ed36f46469560f07db9e49129ad59baaf60ba2a29274fab1fb6974e |
| PEER03 / [Sakuma_FY26.pdf](https://sakumaexportsltd.com/investors/annualreport/21st-Annual-Report-2025-2026.pdf) | 2026-09-03 (exchange cover letter) / FY2026 consolidated / PDF pp25–27 MDA; PDF126/printed123 consolidated P&L; PDF pp25–27 MDA; PDF126/printed123 consolidatedP&L | ab7a2343efc4538d8de92c2cfa6c772cd6eb32f3899fbeb061232342eb6e7245 |
| PEER04 / [annual-report-fy-2025-26.pdf](https://www.ambujagroup.com/documents/financials/annual-report/annual-report-fy-2025-26.pdf) | 2026-08-01 (Board report); AGM 2026-09-05 / FY2026 consolidated / PDF p4 printed4–5 highlights;PDF p11 printed18–19 processing;PDF p122 printed240–241 consolidated accounts; PDFp4 printed4–5 highlights;PDFp11 printed18–19 processing;PDFp122 printed240–241 consolidatedaccounts | db05128cb0cfae597bf3dbb96a1bd5742aeaaa4d290ad1bd68ab84f74d8a60c5 |
| PROSPECTUS_WEBSITE / [Draft Prospectus](https://sheetaluniversal.com/wp-content/uploads/2023/11/Prospectus_Sheetal_SD.pdf) | Date not independently established /  /  | bbe8c36416751ea8d7782893a9423d297a7989d741512704a0e18aee92a95a0f |
| VALUATION26 / [Valuation Report](https://sheetaluniversal.com/wp-content/uploads/2026/02/Valuation_Report.pdf) | Date not independently established /  /  | c92f796353b786f2194d657be1f1fad046b205da8c4a39b54144ef58c39a9735 |
| COMPLIANCE26 / [Compliance Certificate](https://sheetaluniversal.com/wp-content/uploads/2026/02/Compliance_Certificate.pdf) | Date not independently established /  /  | bf1cee575b7e5c823c0d48840a1fa01f4ebdf9cdbe676d44c390b2274c73ec73 |
| AR24 / [Annual Report Year 2024](https://sheetaluniversal.com/wp-content/uploads/2024/09/ANNUAL-REPORT-2023-24.pdf) | 2024-05-30 (Audit date, not inferred upload date) / FY2024 annual consolidated and standalone audit / PDF50 and88 bank-stock audit findings; PDF15 internal-audit disclosure | 9a3d5562771860f34214e228a5b38c55025954ae66a87371bd12de414d3c9482 |
| AR22 / [Annual Report Year 2022](https://sheetaluniversal.com/wp-content/uploads/2023/11/Annual-report-2022-compressed.pdf) | Date not independently established /  /  | cb9ad9f30ee45d4a77c3dd88db8292d5bca44c74e8f0952a5c10480bfc71f125 |
| ORIGINAL_CONS21 / [Consolidated Audit Report- 2020-2021– Financial Statement](https://sheetaluniversal.com/wp-content/uploads/2023/09/CONSOLIDATED-AUDIT-REPORT-2020-2021-FINANCIAL-STATEMENT.pdf) | Date not independently established /  /  | e7f904b7d6e1bc9e8b900beb335b4b441506cef62a6f43dcfd9c654291adf5af |
| CONSOLIDATED_AUDIT_WEBSITE_LABEL24 / [Consolidated Statutory Audit Report F.Y. 2023-24](https://sheetaluniversal.com/wp-content/uploads/2023/11/Consolidated-Audit-Report-Sheetal-Universal-Limited_compressed.pdf) | Date not independently established /  /  | 0bd9b510d9e41b0c88182423c09f01e12ca6324810efb4502deaedae46656bc0 |
| ORIGINAL_SOLO22 / [Standalone Statutory Audit Report F.Y. 2021-22](https://sheetaluniversal.com/wp-content/uploads/2023/09/STANDALONE-STATUTORY-AUDIT-REPORT-F.Y.-2021-22.pdf) | Date not independently established /  /  | ae13e4486642fbc73a618278f88dc2520bbe6d71be73b73cfa135d6c74cd82a2 |
| ORIGINAL_SOLO21 / [Sul Standalone Statutory Audit Report F.Y. 2020-21](https://sheetaluniversal.com/wp-content/uploads/2023/09/SUL-STANDALONE-STATUTORY-AUDIT-REPORT-F.Y.-2020-21.pdf) | Date not independently established /  /  | a0712aed0db111624b6469636dcdef1633280d68b69aca9a69721cb94ff4b760 |
| AR23 / [Annual Report Year 2023](https://sheetaluniversal.com/wp-content/uploads/2023/11/Annual-Report-2023_compressed.pdf) | 2023-07-08 (Signed consolidated audit date) / FY2023 annual consolidated; original audited, not prospectus restatement / PDF16–17 opinion,21–22 CARO,28 IFC,36–38 financial statements | 28e43af9ce415dbdb61c576097c44174ed0abe3df8439b52337e8fce3a862236 |
| AR21 / [Annual Report Year 2021](https://sheetaluniversal.com/wp-content/uploads/2023/11/Annual-Report-2021_compressed.pdf) | Date not independently established /  /  | 0cf8d797164732a9d12e8245b14776f5c85afc5c412c5b2a9a323ed195e060f6 |
| ORIGINAL_CONS23 / [Consolidated Statutory Audit Report F.Y. 2022-23](https://sheetaluniversal.com/wp-content/uploads/2023/09/CONSOLIDATED-STATUTORY-AUDIT-REPORT-F.Y.-2022-23-min.pdf) | Date not independently established /  /  | 7d4e6f96d74a50f01fef6342a97c7b3e4b2a308ad30c4d1ec1f1fdc476691ddc |
| ORIGINAL_CONS22 / [Consolidated Statutory Audit Report F.Y. 2021-22](https://sheetaluniversal.com/wp-content/uploads/2023/09/CONSOLIDATED-STATUTORY-AUDIT-REPORT-F.Y.-2021-22.pdf) | Date not independently established /  /  | 294466a5e3f1673a50d5c98f438a6b214b2be96efbc74908ddaf421b9369f960 |
| ORIGINAL_SOLO23 / [Standalone Statutory Audit Report F.Y. 2022-23](https://sheetaluniversal.com/wp-content/uploads/2023/09/SHEETAL-UNIVERSAL-LIMITED-STANDALONE-STATUTORY-AUDIT-REPORT-F.Y.-2022-23_.pdf) | Date not independently established /  /  | 39311b65eceb79875e3a8e8c05a66764248d6328f20b9fd9a71bfc945eadacef |
| RESULT26 / [March 2026](https://sheetaluniversal.com/wp-content/uploads/2026/09/SHEETAL_30052026144800_Outcome_signed_ocred_signed-mar-26.pdf) | Date not independently established /  /  | ed5c12a0282b4511a3429e253cfe181ec3952e70401c0ee985291cbf05f39994 |
| RESULT25 / [March 2025](https://sheetaluniversal.com/wp-content/uploads/2026/09/SHEETAL_15072025115709_Clarification_financials_mar25_signed.pdf) | Date not independently established /  /  | 7846105e6349f935ef50d52bc8cd0a07d99e3a2be81b9476de06ed7bb32d7084 |
| RESULT24 / [March 2024](https://sheetaluniversal.com/wp-content/uploads/2026/09/SHEETAL_29082024180024_MARCH2024RESULT-mar-24.pdf) | 2024-06-15 (Board outcome and financial-result signed date; exchange filename later) / FY2024 consolidated annual results / PDF15 P&L,16 balance sheet,17 cash flow | 99698c15ead94a62ba813ada4fa1cee121a43b934a25d807f0eb777084b3a3ea |
| SEPT25 / [September 2025](https://sheetaluniversal.com/wp-content/uploads/2026/09/SHEETAL_14112025125004_Outcome_Final_SIGNED-sep-25.pdf) | Date not independently established /  /  | 5168afc1ef5d1430c90d389d2a9ed2381fab47ab1e407baa884e027519b14af1 |
| SEPT24 / [September 2024](https://sheetaluniversal.com/wp-content/uploads/2026/09/Outcome_Final_Signed.pdf) | Date not independently established /  /  | 86393c16f9a8d55ffbd15165add2163f3df1b6f06548185d1df1ba7416d6e896 |
| SEPT23 / [September 2023](https://sheetaluniversal.com/wp-content/uploads/2026/09/SEP2023RESULT.pdf) | Date not independently established /  /  | 1e8eea196ddb95d11a5d8652ed0c8818646fbb41054cc6d281f6286308ff12a4 |
| AR26_NSE / [AR26_NSE](https://archives.nseindia.com/annual_reports/SME_AR_31942_SHEETAL_2025_2026_A_2663300_08092026200238.pdf) | 2026-09-08 (NSE submission date; audits30May2026) / FY2026 annual report, standalone/consolidated / PDF66 standalone audit,73–76 CARO; PDF108–110 consolidated audit; PDF114–116 consolidated BS/P&L/CF | 78545f7b3d5ce3ed6eb6c57f966f15ebf1bd670d7779388821e38a9561aa7bb2 |
| CONVERSION_20261010 / [CONVERSION_20261010](https://nsearchives.nseindia.com/corporate/SHEETAL_10102026175409_Outcome_10102026.pdf) | 2026-10-10 (Exchange allotment announcement) / All remaining warrants converted / PDF1 issued capital and proceeds; PDF2 holder conversions/holdings | 450ce03fae22cb4f28d421a32d8230f667acd79b728c3b4c3d2e458a1cf79364 |
| NSE_AR2025 / [FY2025 annual report, complete NSE copy](https://nsearchives.nseindia.com/corporate/SHEETAL_08092025163652_Final_report_Sheetal_2025__signed.pdf) | 2025-09-08 (NSE submission date; audits30May2025) / FY2025 complete annual report / PDF52/88 stock-return concerns; PDF55/91 internal audit; PDF111 original CFO | 18289968449c13db323643a4ddc89e2fbfb1d265aca4415beb49616d516c0c43 |
| NSE_AR2024 / [FY2024 annual report, NSE copy](https://nsearchives.nseindia.com/annual_reports/SME_AR_26175_SHEETAL_2023_2024_0709202419142.pdf) | 2024-09-07 (NSE submission date) / FY2024 annual report, audits signed30May2024 / Original audit/PPE/CARO and financial statement vintages; audit ledger A04/A07 | 64cee68ce45a31cd6ed43bcd0bfd06304ba13c4dd8cf28a830e104285397b889 |
| RESIGN2025 / [Statutory auditor resignation, original NSE letter](https://nsearchives.nseindia.com/corporate/SHEETAL_02082025160530_Resignation_statutory_auditor_2025_Signed.pdf) | 2025-08-02 /  /  | e1c4d35fe02c2e874035acbed8e00799b2be8532a9b9db164a9209f896ab7aaa |
| SRC041 / [SHEETAL_17062026171640_Outcome_17062026.pdf](https://sheetaluniversal.com/wp-content/uploads/2026/09/SHEETAL_17062026171640_Outcome_17062026.pdf) | Date not independently established /  /  | c80140a707abcf00f36b6525e84e1a4b7b3ebf255c34f71db0dcf40733e73f72 |
| SRC042 / [SHEETAL_09042026190223_Reg_30_Intimation.pdf](https://sheetaluniversal.com/wp-content/uploads/2026/09/SHEETAL_09042026190223_Reg_30_Intimation.pdf) | Date not independently established /  /  | 67c510f9a5c438a28db1483b5c9f78fb90d89627ccbd67dbdcceb65def16c3f0 |
| SRC043 / [SHEETAL_23122025192655_Regulation_30.pdf](https://sheetaluniversal.com/wp-content/uploads/2026/09/SHEETAL_23122025192655_Regulation_30.pdf) | Date not independently established /  /  | 2d4f3f03e71e479a451782e59b2ce5a002321d34ea33f79dc9abc97f7e6ec837 |
| SRC044 / [SHEETAL_09022026200911_Outcome.pdf](https://sheetaluniversal.com/wp-content/uploads/2026/09/SHEETAL_09022026200911_Outcome.pdf) | Date not independently established /  /  | 0bf77ae72da0570ddf662b365c39a1b908b5c18c18a4b2abc4182a99547fcb62 |
| SRC045 / [SHEETAL_23072026153849_Outcome_23072026.pdf](https://sheetaluniversal.com/wp-content/uploads/2026/09/SHEETAL_23072026153849_Outcome_23072026.pdf) | Date not independently established /  /  | 4bd0b174183697e5ae740479253b6427c5718b23cee3a2f33099af633c7ab735 |
| SRC046 / [SHEETAL_02072026165656_Outcome_final_new_sign.pdf](https://sheetaluniversal.com/wp-content/uploads/2026/09/SHEETAL_02072026165656_Outcome_final_new_sign.pdf) | Date not independently established /  /  | 140fa4f29a25ce14edd7e879e051fd61187e91d29341c295230fb4ef401d2290 |
| SRC047 / [SHEETAL_02022026163859_Intimation_09022026.pdf](https://sheetaluniversal.com/wp-content/uploads/2026/09/SHEETAL_02022026163859_Intimation_09022026.pdf) | Date not independently established /  /  | 8dd8f4072bd9aa518000f6efb0431e9a5c04c30c84f0d8f8ccfd6130c3dd2ea3 |
| SRC048 / [SHEETAL_15072025115709_Clarification_financials_mar25_signed-1.pdf](https://sheetaluniversal.com/wp-content/uploads/2026/09/SHEETAL_15072025115709_Clarification_financials_mar25_signed-1.pdf) | Date not independently established /  /  | 7846105e6349f935ef50d52bc8cd0a07d99e3a2be81b9476de06ed7bb32d7084 |
| SRC049 / [SHEETAL_09022026200807_Outcome.pdf](https://sheetaluniversal.com/wp-content/uploads/2026/09/SHEETAL_09022026200807_Outcome.pdf) | Date not independently established /  /  | 0bf77ae72da0570ddf662b365c39a1b908b5c18c18a4b2abc4182a99547fcb62 |
| SRC050 / [SHEETAL_11112025192349_Regulation_30_signed.pdf](https://sheetaluniversal.com/wp-content/uploads/2026/09/SHEETAL_11112025192349_Regulation_30_signed.pdf) | Date not independently established /  /  | 25041830af42e222f5e189ced40818944e24c7277ccde7fc1014fb9f2ce95aec |
| SRC051 / [SHEETAL_14112025125004_Outcome_Final_SIGNED.pdf](https://sheetaluniversal.com/wp-content/uploads/2026/09/SHEETAL_14112025125004_Outcome_Final_SIGNED.pdf) | Date not independently established /  /  | 5168afc1ef5d1430c90d389d2a9ed2381fab47ab1e407baa884e027519b14af1 |
| SRC052 / [Sheetal Universal Limited has informed the Exchange regarding approval to incorporate Wholly-Owned Subsidiaries in UAE and Russia.](https://nsearchives.nseindia.com/corporate/SHEETAL_11112025192349_Regulation_30_signed.pdf) | Date not independently established /  /  | 25041830af42e222f5e189ced40818944e24c7277ccde7fc1014fb9f2ce95aec |
| SRC053 / [Shreeji final prospectus](https://nsearchives.nseindia.com/emerge/corporates/content/ShreejiGlobalFMCGLimited_PROSP.pdf) | Date not independently established /  /  | 664de2de6130343570e6d03b457b41ace090e051fc1b67b4ed39a9a38fd684cf |
| NSE_SECURITY_MASTER_20261019 / [NSE official security master, 19 October 2026](https://nsearchives.nseindia.com/content/cm/interop/NSE_CM_security_19102026.csv.gz) | 2026-10-19 / Identity, ISIN, board lot and dated EOD reference fields; not independently verified same-day intraday band /  | d3665d120c8b0379df3483321ad45f8230535c7124b9759de5c29961df326898 |

The 60 original market ZIP URLs, hashes, internal dates, selected ISIN rows and security-master hashes are individually retained in market_inputs.json and source_register.json. All sessions are observed; none is imputed as zero. CRISIL HTML original hashes are unavailable; any saved web-response capture hash is separately labeled and not represented as an original-file hash.

Highest-value open questions: a dated April–October cash/debt/working-capital bridge; actual current sanctioned and available facilities with covenants, rates, security and maturities; stock-return reconciliations accepted by lenders; receivable confirmations and subsequent collections; inventory quantity/cost/age and realization; gross capex/disposal/CWIP and title/lease evidence; current tax cash bridge; CSR and CARO corrections; product volume/revenue/capacity economics; current customer concentration; and receipt/collection evidence for the September export order. These are specific closure requirements, not assumed adverse answers.

Model inputs deliberately expose the assumptions that matter most: cash retention, collections and impairment, inventory carry and seasonality, supplier credit, continued bank lines, debt costs/maturities, realisations, commissioned capacity, capex intensity, economic reinvestment return, WACC and terminal growth. Decimal precision is for reproducibility, not a claim of forecasting accuracy. The compact and full archives differ only in compression and contain identical authored material. Running build.py regenerates calculations and readers from declared inputs; guarded fresh recovery and independent reproduction are separately attested.

| Research update | Old → current | Effect |
|---|---|---|
| 2026-10-24 | Original annual/prospectus/results and FY2022–FY2026 audits reconciled; FY2025 CFO original versus comparative retained. | Financial reliability Hold, not an adverse audit or fraud/default assertion. |
| 2026-10-24 | Current issued shares 12,875,999 replace stale tradable master share count; all warrants already converted. | Full claims and gross receipts reconciled; current retained cash remains ND. |
| 2026-10-24 | Superseded v1 paid-growth depreciation corrected to CWIP and commissioned PPE. | Original 175 trials retained; current returns use six-month commissioning and appropriate depreciation. |
| 2026-10-24 | Superseded v2 flat terminal transition replaced by the same monthly cohort/seasonality engine and trough-derived retained cash. | 195 current trials retain failed outcomes and suppress returns when transition funding or capacity fails. |
| 2026-10-24 | FY2026 PAT proxy 11.5078 crore, exact export fraction, FY2024 page locator and 0.0001 crore debt-rounding claim corrected. | Recomputed metrics and claims; no score change, NS preserved. |

| Quality check | Status | Evidence |
|---|---|---|
| 1 | PASS_DISCLOSURE | Correct identity, scope and dates: Exact ISIN, SME master, annual consolidated scope and dated close; original metadata retained. |
| 2 | PASS_DISCLOSURE | Primary material evidence: Original prospectus, annual/results, standalone/consolidated audit vintages and announcements read; guidance versus assumption distinguished. |
| 3 | PASS_DISCLOSURE | Audit, RPT, financing and dilution: Proportionate G1/G2/G3 findings; clean counterevidence retained; shares and gross receipts bridged. |
| 4 | PASS_DISCLOSURE | Comparable periods and units: Annual INR-lakh extracts converted to crore; original/restated cash bridges; no overlapping TTM or invented interim CFO. |
| 5 | PASS_DISCLOSURE | Revenue driver separation: Real FY23 production supported; recent mix/price/volume missing; REV NS, not assumed acquisition growth. |
| 6 | PASS_DISCLOSURE | Cash conversion ratio of sums: Three/five-year aggregate CFO divided by aggregate PAT; capex is below CFO, not an excuse. |
| 7 | PASS_DISCLOSURE | Incremental capital returns: NOPAT, denominator, timing and investment residual explicit; accounting proxy not CAP score. |
| 8 | PASS_DISCLOSURE | Consistent normalized earnings and claims: Other income, tax, rent economics, unpaid tax, debt rounding, full issued shares and fees explicit. |
| 9 | PASS_DISCLOSURE | Monthly scenarios and terminal funding: AR/AP/inventory cohorts, capacity/CWIP, new finance, maturity, whole shares and terminal reserve reconcile; failed returns suppressed. |
| 10 | PASS_DISCLOSURE | Canonical factors and weights: 13 factors used once; exact Decimal weights total 1 for BQS/GQS/IAS. |
| 11 | PASS_DISCLOSURE | Missingness and confidence: NS preserved, no renormalization; coverage, bounds and subject confidence explicit. |
| 12 | PASS_DISCLOSURE | Raw/final overrides: GQS ceiling5 from persistent CASH3; no unevidenced governance/default caps; G2 prevents ranking. |
| 13 | PASS_DISCLOSURE | Classification and compounder test: Pending evidence / Hold; compounder false. No unsupported action range. |
| 14 | PASS_DISCLOSURE | Position-sized liquidity: 60 observed sessions; ₹5 lakh reference, lot500 and 2/5/10% participation; live depth ND. |
| 15 | PASS_DISCLOSURE | Strongest bear/thesis break: Linked cash-collection, stock, supplier, renewal and dilution stress; specific break variable. |
| 16 | PASS_DISCLOSURE | Ranking/version/completion: Framework v3.0 hash bound; no numeric ranking or publication; research complete with investment evidence unresolved. |
