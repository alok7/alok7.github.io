# Independent review of Sheetal Universal Limited

Information cutoff: 20 October 2026. Market reference: official 19 October 2026 close of ₹375.05. NSE SHEETAL, ISIN INE04VX01019, dossier 364.

## Conclusion

The evidence supports **Hold unresolved / Pending evidence**, with BQS, GQS and IAS **NS**. The research is complete, but critical investment evidence is not. The conclusion is not an allegation of fraud, an adverse audit opinion or a finding of actual default.

The decisive distinction is between reported growth and collected, financed growth. FY2026 domestic revenue expanded while exports declined, and cumulative operating cash remains negative despite positive profits. New machinery, trial production, a specific export order, positive FY2025 CFO, new equity receipts and current unmodified main/IFC opinions are meaningful counterevidence. They do not establish current usable cash, lender capacity, sustainable product returns or closure of recurring reporting issues.

## Source reconciliation

The complete v3.0 framework was read and its exact hash verified. Material original prospectus, financial-result, annual-report, audit/CARO/IFC and allotment records were reconciled across vintages. FY2025 original versus comparative CFO is largely a classification bridge, not missing cash. FY2024/FY2025 stock-in-transit tables reconcile arithmetically; lender acceptance and later closure remain unverified. The resignation letter states workload, not withheld information. Primary economic peers were reviewed without inventing current peer valuations.

The 10 October allotment supports 12,875,999 issued shares, distinct from the stale 11,716,999 tradable-master share count. All warrants were converted. The ₹29.82 crore gross receipts are not verified current retained cash and cannot be counted again as future financing. March cash was ₹0.1489 crore. Majority control is supported by disclosed holdings; current group classification, pledge/encumbrance and tradable free float remain incomplete.

All 60 original official market archives, internal dates and selected ISIN records were checked. Missing sessions were not assigned zero turnover. Liquidity calculations recognize the 500-share lot, the ₹5 lakh reference budget and the difference between theoretical turnover-based exit time and actual executable depth.

## Independent calculations and recovery

A separately authored standard-library Decimal implementation reproduced all 195 paths from raw input JSON, without importing producer model or scenario modules. A fresh six-file clone contained only that script and its five raw input JSON files. Separate comparison covered 8,286 operating/terminal monthly rows, 604,878 monthly fields and 641,914 economic, metric, score and target values. All matched within the declared Decimal tolerance; dates, integer claims and states agreed. Explanatory annotations were reviewed separately.

The replay includes invoice and procurement cohorts, seasonality, working capital, restricted sources, debt coupons/fees/maturities/limits, whole-share financing and authorization, paid CWIP versus commissioned assets, and earned terminal reinvestment and retained operating cash. Failed paths suppress ordinary returns. All 135 failures are conditional model failures, not observed corporate defaults. The 60 remaining paths are also source-ineligible. None of the tested bounded or expanded five-/ten-year envelopes establishes a funded 12%, 15%, 18%, 5× or 10× crossing; finite-grid results do not prove impossibility outside the tested assumptions.

An independent fresh clone of all 28 declared runtime inputs regenerated all 13 build outputs byte-for-byte with inputs unchanged. The cooperative I/O guard prohibited network, subprocess and undeclared file access; it is not an operating-system security sandbox. The accompanying attestation identifies the exact report, company record, input aggregate, output aggregate and canonical-trace hashes separately.

## Review boundary

All 15 reader sections, 16 framework checks and 13 factors were reviewed. Exact Decimal score arithmetic preserves NS, coverage, bounds, dependency-aware IAS uncertainty and the GQS ceiling of 5. G2/G3 remain unresolved holds; no unsupported governance/default cap or ranking eligibility is introduced.

The Markdown and static HTML content/structure were reviewed. Browser screenshot rendering was unavailable in the execution setup, so no visual-render pass is claimed. This note accepts the local source-led research and reproducibility, not investment eligibility. Current Library archive/version recovery is separately verified after upload. Original PDFs, OCR, private transfer helpers and internal QA receipts are not delivery-archive contents.
