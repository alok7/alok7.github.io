"""Producer semantic assertions; independent raw-input replay remains separately required."""
from decimal import Decimal as D
TOL=D('1e-18')
def audit(p,i):
 n=0
 def equal(a,b,label):
  nonlocal n;n+=1
  assert abs(D(a)-D(b))<TOL,(p['path_id'],label,str(a),str(b))
 previous=None
 for r in p['monthly']:
  equal(r['cash_close'],r['cash_open']+r['customer_collections']+r['advance_release']+r['deposit_release']+r['debt_draw']+r['equity_gross']-r['supplier_payments']-r['opex']-r['tax_cash']-r['opening_tax_settlement']-r['interest']-r['bank_fees']-r['capex']-r['principal_term']-r['principal_unsecured']-r['principal_wc']-r['principal_new']-r['opa_movement']-r['debt_draw_fee']-r['equity_fee'],'cash')
  equal(r['ar_close'],r['ar_open']+r['sales']-r['customer_collections']-r['bad_debt'],'receivables')
  equal(r['ap_close'],r['ap_open']+r['purchases']-r['supplier_payments'],'payables')
  equal(r['inventory_close'],r['inventory_open']-r['inventory_impairment']+r['purchases']-r['material_cogs'],'inventory')
  equal(r['debt_close'],r['debt_open']+r['debt_draw']-r['principal_term']-r['principal_unsecured']-r['principal_wc']-r['principal_new'],'debt')
  equal(r['ppe_close'],r['ppe_open']+r['maintenance_capex']+r['commissioned_cost']-r['da'],'ppe')
  equal(r['cwip_close'],r['cwip_open']+r['growth_capex']-r['commissioned_cost'],'cwip')
  equal(r['equity_gross'],D(r['new_shares'])*r['equity_issue_price']/10000000,'whole share cash')
  equal(r['shares_close'],r['shares_open']+r['new_shares'],'share bridge')
  equal(r['ebitda'],r['sales']-r['material_cogs']-r['opex'],'ebitda')
  assert r['units_sold']<=r['capacity_tonnes']/12+TOL and r['purchases']>=0;n+=2
  assert isinstance(r['new_shares'],int) and r['shares_close']<=int(p['spec']['expanded_authorized_shares']if p['spec']['equity_authorization_gate']else i['authorized_shares']);n+=2
  if previous:
   for a,b in[('cash_open','cash_close'),('ar_open','ar_close'),('inventory_open','inventory_close'),('ap_open','ap_close'),('debt_open','debt_close'),('ppe_open','ppe_close')]:equal(r[a],previous[b],'opening carry')
  previous=r
 if p['failure']:
  assert p['terminal']is None and p['summary']['irr']is None and p['summary']['terminal_price']is None;n+=3
 else:
  t=p['terminal'];equal(t['fcff'],t['next_nopat']+t['next_da']-t['replacement_capex']-t['reinvestment'],'terminal fcff');equal(t['equity_value'],max(D(0),t['enterprise_value']+t['excess_cash']-t['debt']-t['unpaid_tax_claim']),'equity claims');equal(t['price'],t['equity_value']*10000000/t['shares'],'terminal diluted price');assert t['terminal_reinvestment_funded'];n+=1
 assert p['source_eligible']is False;n+=1
 return {'path_id':p['path_id'],'checks':n,'passed':True}
