"""Finite, fully retained sensitivity grid. No successful-only filtering or hidden optimizer."""
from model import default
from copy import deepcopy
from decimal import Decimal as D

def specifications():
 def make(name,changes,years,kind):
  s=default();s.update(changes);return name,s,years,kind
 main={
 'bear':{'volume_growth':'-.05','price_growth':'0','core_ebitda_margin':'.03','domestic_delay':5,'export_delay':6,'inventory_days':'150','supplier_delay':1,'old_ar_recovery':'.50','inventory_impairment':'.10','customer_loss':'.15','retained_warrant_cash':'0','capacity_ceiling_tonnes':'18000'},
 'base':{},
 'bull':{'volume_growth':'.20','core_ebitda_margin':'.10','domestic_delay':2,'export_delay':3,'inventory_days':'80','retained_warrant_cash':'29.82','old_ar_recovery':'.95','capacity_ceiling_tonnes':'100000','annual_capacity_addition_limit':'12000','incremental_debt_gate':True,'new_debt_limit':'15','new_debt_cumulative_limit':'30','debt_renewal_gate':True,'equity_gate':True},
 'strict_disclosed_balance':{'retained_warrant_cash':'0','wc_renewal':False},
 'no_new_finance_all_receipts_retained':{'retained_warrant_cash':'29.82'},
 'zero_retention':{'retained_warrant_cash':'0'},
 'no_bank_renewal':{'wc_renewal':False},
 'restricted_deposit_release':{'deposit_release':'1.1966'},
 'loan_advance_recovery':{'advance_recovery':'4.9706'},
 'maturity_no_rollover':{'incremental_debt_gate':True,'new_debt_limit':'15','new_debt_cumulative_limit':'30','debt_renewal_gate':False},
 'conditional_line_and_small_equity':{'incremental_debt_gate':True,'new_debt_limit':'15','new_debt_cumulative_limit':'30','debt_renewal_gate':True,'equity_gate':True},
 'expanded_financing':{'retained_warrant_cash':'29.82','incremental_debt_gate':True,'new_debt_limit':'40','new_debt_cumulative_limit':'100','debt_renewal_gate':True,'equity_gate':True,'equity_authorization_gate':True,'expanded_authorized_shares':25000000,'capacity_ceiling_tonnes':'200000','annual_capacity_addition_limit':'24000'},
 'legacy_12000_capacity':{'initial_capacity_tonnes':'12000'},
 'tax_paid_later':{'opening_tax_settlement_month':24},
 'lower_inventory_stock_release':{'inventory_days':'60'},
 'customer_export_linked_shock':{'customer_loss':'.20','export_price_shock':'-.15','domestic_delay':5,'export_delay':6,'core_ebitda_margin':'.03','inventory_days':'140','inventory_impairment':'.15','old_ar_recovery':'.50','supplier_delay':1},
 'higher_replacement_capex':{'maintenance_capex_ratio':'.025','capex_per_annual_tonne':'.004'},
 'large_forced_equity_authorized_only':{'equity_gate':True,'forced_equity_shares':2000000},
 'large_forced_equity_conditional_approval':{'equity_gate':True,'equity_authorization_gate':True,'forced_equity_shares':2000000}}
 for yr in[5,10]:
  for name,c in main.items():yield make(f'{name}_{yr}y',c,yr,'main'if name in['bear','base','bull']else'stress')
  for growth in['0','.05','.10','.15','.20','.30']:
   for margin in['.03','.06','.09','.12']:
    yield make(f'growth_margin_{yr}y_g{growth}_m{margin}',{'volume_growth':growth,'core_ebitda_margin':margin},yr,'growth_margin')
  for wacc in['.13','.16','.19']:
   for g in['.02','.04','.06']:
    yield make(f'terminal_{yr}y_w{wacc}_g{g}',{'wacc':wacc,'terminal_growth':g},yr,'wacc_growth')
  funded={'volume_growth':'.10','core_ebitda_margin':'.10','domestic_delay':2,'export_delay':3,'inventory_days':'80','retained_warrant_cash':'29.82','old_ar_recovery':'.95','incremental_debt_gate':True,'new_debt_limit':'15','new_debt_cumulative_limit':'30','debt_renewal_gate':True,'equity_gate':True,'capacity_ceiling_tonnes':'100000','annual_capacity_addition_limit':'12000'}
  yield make(f'funded_reference_{yr}y',funded,yr,'funded_reference')
  for wacc in['.13','.16','.19']:
   for g in['.02','.04','.06']:
    c=dict(funded,wacc=wacc,terminal_growth=g);yield make(f'funded_terminal_{yr}y_w{wacc}_g{g}',c,yr,'funded_wacc_growth')
  for family in['bounded','expanded']:
   for step in range(0,51,5):
    gr=str(D(step)/100);c={'volume_growth':gr,'retained_warrant_cash':'29.82','incremental_debt_gate':True,'new_debt_limit':'15','new_debt_cumulative_limit':'30','debt_renewal_gate':True,'equity_gate':True,'core_ebitda_margin':'.10','domestic_delay':2,'export_delay':3,'inventory_days':'80','old_ar_recovery':'.95','capacity_ceiling_tonnes':'100000','annual_capacity_addition_limit':'12000'}
    if family=='expanded':c.update({'equity_authorization_gate':True,'expanded_authorized_shares':40000000,'equity_last_month':60,'new_debt_limit':'75','new_debt_cumulative_limit':'200','capacity_ceiling_tonnes':'500000','annual_capacity_addition_limit':'50000','core_ebitda_margin':'.12'})
    yield make(f'reverse_{family}_{yr}y_g{gr}',c,yr,'reverse_'+family)

def refinements(summaries,specs):
 byid={p[0]:p for p in specs}
 # Refine every transition in funding status and every 12/15/18% or5x/10x crossing, retain each trial.
 for yr in[5,10]:
  for family in['bounded','expanded']:
   rows=sorted([r for r in summaries if r['years']==yr and r['kind']=='reverse_'+family],key=lambda r:D(r['volume_growth']))
   for a,b in zip(rows,rows[1:]):
    thresholds=[D('.12'),D('.15'),D('.18')];cross=a['status']!=b['status']
    if a['irr']is not None and b['irr']is not None:cross=cross or any((D(a['irr'])<t<=D(b['irr']))or(D(b['irr'])<t<=D(a['irr']))for t in thresholds)or any((D(a['terminal_price'])<t<=D(b['terminal_price']))or(D(b['terminal_price'])<t<=D(a['terminal_price']))for t in[D('375.05')*5,D('375.05')*10])
    if not cross:continue
    lo=D(a['volume_growth']);hi=D(b['volume_growth'])
    for k in range(1,10):
     g=lo+(hi-lo)*k/10;s=deepcopy(byid[a['path_id']][1]);s['volume_growth']=str(g);yield(f'refine_{family}_{yr}y_g{g}',s,yr,'refine_'+family)

def targets(rows,entry):
 out=[];entry=D(entry)
 for yr in[5,10]:
  for fam in['bounded','expanded']:
   a=[x for x in rows if x['years']==yr and x['kind']in['reverse_'+fam,'refine_'+fam]]
   for target in['hurdle12','hurdle15','hurdle18','5x','10x']:
    ok=[x for x in a if x['irr']is not None and(D(x['irr'])>=D(target[-2:])/100 if target.startswith('hurdle')else D(x['terminal_price'])>=entry*int(target[:-1]))];first=min(ok,key=lambda x:D(x['volume_growth']))if ok else None;funded=[x for x in a if x['irr']is not None];best=max(funded,key=lambda x:D(x['irr']))if funded else None
    out.append({'years':yr,'family':fam,'target':target,'status':'First tested funded crossing, not exact continuous solution'if first else'No supported crossing in retained conditional grid','first_growth':first['volume_growth']if first else None,'path':first['path_id']if first else None,'sales':first['terminal_sales']if first else None,'new_equity':first['equity_gross']if first else None,'capex':first['total_capex']if first else None,'best_funded_path':best['path_id']if best else None,'best_funded_irr':best['irr']if best else None,'source_eligible':False})
 return out
