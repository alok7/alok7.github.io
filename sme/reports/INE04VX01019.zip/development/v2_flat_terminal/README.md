# Superseded methodology archive

195 trials. Commissioned-CWIP mechanics repaired, but terminal transition still used flattened cash flows and lacked a full trough-derived reserve; superseded by current same-engine 12-month extension.

All original failed and funded trials are retained. scenario_inputs.json recovers full runtime specifications verbatim from retained traces. To replay, copy model.py, model_audit.py, scenarios.py, model_inputs.json, scenario_inputs.json, reproduce.py and retained_original_output_hashes.json into an empty directory, then run python reproduce.py. No current investment conclusion uses this version.
