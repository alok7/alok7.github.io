"""Reproduce explicitly superseded trials; do not use for current valuation."""
from pathlib import Path
import json,gzip,hashlib
from decimal import Decimal
import model,model_audit,scenarios
P=Path(__file__).resolve().parent
def js(x,pretty=False):return json.dumps(x,ensure_ascii=False,default=str,sort_keys=True,indent=2 if pretty else None,separators=None if pretty else(',',':'))
def main():
 i=json.loads((P/'model_inputs.json').read_text());qs=json.loads((P/'scenario_inputs.json').read_text())['specifications'];summary=[];checks=[]
 with (P/'canonical_paths.json.gz').open('wb')as f:
  with gzip.GzipFile(filename='',fileobj=f,mode='wb',mtime=0,compresslevel=9)as z:
   z.write(b'{')
   for k,q in enumerate(qs):
    x=model.run(i,q['spec'],q['years'],q['path_id']);x['summary']['kind']=q['kind'];summary.append(x['summary']);checks.append(model_audit.audit(x,i));z.write(((','if k else'')+js(q['path_id'])+':'+js(x)).encode())
   z.write(b'}')
 (P/'model_summary.json').write_text(js({'path_count':len(summary),'failed':sum(x['irr']is None for x in summary),'paths':summary,'targets':scenarios.targets(summary,i['entry_price'])},True))
 (P/'model_audit.json').write_text(js({'status':'PASS','paths':len(checks),'checks':sum(x['checks']for x in checks),'results':checks},True))
 expected=json.loads((P/'retained_original_output_hashes.json').read_text());actual={n:hashlib.sha256((P/n).read_bytes()).hexdigest()for n in expected};assert actual==expected,(actual,expected);(P/'superseded_reproduction_attestation.json').write_text(js({'status':'PASS','warning':'Superseded, not current economic conclusions','output_hashes':actual},True)+'\n');print('Superseded version reproduced',len(qs),'trials')
if __name__=='__main__':main()
