# Sheetal Universal Limited: business and peer research inputs

Information cutoff: 20 October 2026. Market cutoff: 19 October 2026. This appendix explains the operating business and comparable companies; the main report contains the reconciled accounts, scores and valuation. Framework v3.0 SHA-256 68d4de4255427df276318d0231530b867a453e740c74150e9768bf1387224137.

## Decision-useful result

Sheetal is a bulk agricultural-ingredient procurement and processing business with new value-added product optionality, not yet an evidenced branded food compounder. FY2023's revenue step-up had clear supporting production growth. However, the most recent revenue growth cannot be decomposed reliably into tonnes, price, product mix and new-line sales. FY2026 was overwhelmingly a domestic expansion while exports contracted. Installation and trial success for the new line are actually documented, but customer adoption, utilization, contribution margins and incremental cash returns are not. The correct conclusion is neither that capex never happened nor that machinery automatically creates a high-return runway. [BUS01, BUS02, BUS03]

## 1. Operating model and history

Incorporated on 20 August 2015, Sheetal established peanut processing in FY2017, added sesame/spice processing in 2018 and listed on NSE Emerge in December 2023. Its Gujarat factory sources agricultural commodities through farmers' agents, traders, market-yard participants and brokers; sorts, cleans, grades and packages ingredients; and sells principally to B2B food-industry buyers. Peanut butter, bakery, confectionery and other food manufacturers are described as end users, not evidence of named customer contracts. The historical oilseed category comprised 88.61% of FY2023 consolidated revenue, compared with 85.67% in FY2022 and 92.75% in FY2021. [BUS01 printed pp25, 125–140]

The economic value added is procurement accuracy, usable quality, grading, processing, reliability, logistics and customer credit execution. A large percentage of the sales invoice is the commodity itself. Spot raw-material purchasing without long-term supply agreements means higher selling prices are not automatically pricing power. The company produces against confirmed and expected orders, so inventory can represent risk-bearing stock, not just contracted pass-through. Revenue is recognized upon delivery/title transfer according to the FY2026 accounting policy; an order announcement is neither recognized revenue nor collected cash. [BUS01 printed pp27–29, 139; BUS02 accounting policies]

The historical export-country list includes Russia, Indonesia, Malaysia, Vietnam, UAE, Iran, Algeria, Israel, Turkey and Egypt. That is a destination list, not a current country revenue distribution. ISO/FSSAI and claimed EU peanut-export eligibility establish operating capability at the dates disclosed, not permanent exclusivity or proof that all present approvals remain current. CRISIL independently recognized the Gujarat crop-belt/port advantage and promoter experience, while identifying crop, foreign-exchange and customer risks. [BUS01 printed p125; BUS09 Key Rating Drivers]

## 2. Real growth versus nominal turnover

### Historical physical evidence

| Period | Peanut output, tonnes | Peanut capacity, tpa | Cumin/sesame output, tonnes | Cumin/sesame capacity, tpa |
|---|---:|---:|---:|---:|
| FY2021 | 3,848.10 | 9,000 | 1,561.23 | 6,000 |
| FY2022 | 2,176.40 | 9,000 | 1,528.47 | 6,000 |
| FY2023 | 8,898.43 | 12,000 in KPI table, conflicting 18,000 in business table | 3,500.24 | 6,000 |
| Five months to August 2023 | 3,345.72 | 18,000 | 1,092.61 | 6,000 |

Source: BUS01 printed pp94, 138–139. For FY2023, 8,898.43 / 12,000 = 74.15%, consistent with disclosed 74%; using 18,000 yields 49.44%. Both source entries are retained. The partial FY2024 figures of 18.58%/18.21% are five-month production divided by annual capacity, not comparable full-year utilization.

FY2023 peanut output grew 308.86%, cumin/sesame 129.00%, and their sum 234.66%, near the 232.95% reported consolidated revenue growth. This supports substantial physical growth in that particular year. It is not a complete revenue bridge: factory production is not consolidated sales tonnes, and the revenue perimeter includes grains/trading/other products. A blended selling price calculated from consolidated sales divided by those two factory outputs would be misleading. FY2024–FY2026 comparable product output and utilization were not found in the reviewed annual reports and announcements. [BUS01 printed pp93–94, 127]

### The domestic/export change is measurable

| Consolidated, ₹ crore | FY2023 | FY2025 | FY2026 |
|---|---:|---:|---:|
| Exports | 107.2612 | 78.1439 | 49.2040 |
| Domestic | 21.5510 | 27.5308 | 124.5588 |
| Revenue | 128.8122 | 105.6747 | 173.7628 |
| Export share | 83.27% | 73.95% | 28.32% |

Sources: BUS01 printed p127; BUS02 PDF p124, consolidated Note A. The FY2026 domestic addition of ₹97.0280 crore more than offset the ₹28.9399 crore export decline, producing ₹68.0881 crore net growth. Exports fell about 37.03%; domestic sales grew about 352.43%. Calling FY2026 an export-led acceleration would be wrong. No verified latest product or customer data attributes the domestic jump specifically to protein powder, branded nuts, price changes or particular counterparties.

The MDA's assertion that India is the only material geographical segment conflicts with its own disclosed export-sales line. Quantitative revenue geography is the safer evidence. This disclosure inconsistency is not itself proof of fabricated sales. [BUS02 printed p50; PDF p124]

## 3. Concentration and cash economics

| Period | Largest customer | Top three | Top five | Top ten | Top ten suppliers |
|---|---:|---:|---:|---:|---:|
| FY2021 | 22.03% | 44.91% | 56.90% | 79.28% | 33.36% |
| FY2022 | 6.73% | 19.92% | 31.57% | 56.16% | 43.75% |
| FY2023 | 14.77% | 36.55% | 47.05% | 66.07% | 31.28% |
| Five months to August 2023 | 27.19% | 49.83% | 58.04% | 72.41% | 41.03% |

Source: BUS01 printed pp27, 94. These are historical, not current FY2026 concentrations. CRISIL's August 2024 repetition of 72.41% does not establish a freshly measured FY2024 customer mix.

The relevant capital constraint is not just the cost of sorters or presses. Procurement cash, finished stock, shipping and credit extended to buyers must be financed. Unfavourable crop conditions can raise purchase prices before selling prices adjust; weak demand can simultaneously reduce throughput and lengthen inventory holding. A food-quality or aflatoxin-related rejection could worsen both margins and the cash cycle. These mechanisms are more useful than generic food-sector TAM figures. [BUS01 Risk Factors and procurement/inventory sections]

The IPO earmarked ₹12 crore for working capital, more than the ₹5.84 crore machinery amount. Its FY2025 working-capital plan assumed roughly 25–28 receivable days and 7–10 finished-goods holding days; these are projections, not historic achieved metrics. The financial bridge tests actual collection and inventory movements against those assumptions. Higher inventories do not become benign solely because a new factory exists. Capex belongs in investing cash flow; weak CFO must be explained through operating movements. [BUS01 printed pp78, 81–83]

## 4. New capacity: what has actually been delivered

The original prospectus proposed a defatted protein and cold-pressed oil line, quoting roughly 25 tonnes per day / 7,500 tonnes per annum and machinery cost ₹5.84 crore. The wording itself mixes a protein-only description with a peanut-oil-and-protein capacity note. It should not be turned into a precise single-output economic model. The original quotation excluded installation charges and was not externally appraised. [BUS01 printed pp79–81, 137–138]

The important subsequent evidence is the 21 May 2025 exchange filing. Management reported successful installation and trial production, ready for commercial operation, with these capacities:

- Flavoured nuts: up to 12 tonnes/day.
- Flavoured protein powder: up to 8 tonnes/day.
- Cold-pressed oil: up to 12 tonnes/day.
- Machinery investment: approximately ₹11.99 crore; building approximately ₹3 crore.
- Funding: IPO proceeds, internal accrual and debt. [BUS03 pp1–2]

This is positive execution evidence but a materially different scope/cost/output profile from the IPO quotation. Comparing ₹11.99 crore machinery with ₹5.84 crore gives about 2.05 times, not an established cost overrun on an identical specification. The project also added flavoured nuts and building work. The full reconciliation remains open. Do not add the three daily capacities into a single 32-tonne saleable-output assumption: oil/protein are co-products and concurrent operation, yields and utilization are not disclosed. Nor should 300 operating days be treated as a verified current schedule.

May 2025 also proposed KETTLEBELL product launches within a month in India and specified overseas markets. On 23 February 2026, another filing scheduled a domestic Kettlebell NUTZO launch for 24 February covering flavoured nuts, seeds and peanuts, with trademark application pending. FY2026 MDA confirms a new flavoured-nut line. This evidences launch activity, not a verified full-year branded sales stream. The documents do not prove whether the original protein/oil overseas launch timetable was met. [BUS03; BUS04 visually checked p1; BUS02 printed p48]

The timing matters: the FY2025 profit/margin jump predates the May 2025 ready-for-commercial disclosure. It cannot be attributed to a demonstrated full year of these new operations. Actual product tonnes, revenue, contribution margins, repeat customer orders and cash collections are needed before awarding a high CAP or durable brand-moat score.

## 5. Management promises, access and counterevidence

- May 2024: a YSM & K LLC strategic tie-up was announced to develop Russia/CIS markets for existing and new products. No quantified minimum purchase, committed off-take or achieved sales were located. It improves the market-access story but is not backlog. [BUS05 p1]
- November 2025: UAE and Russia subsidiaries approved. Russia's Helios Global LLC was incorporated on 5 March 2026 with RUB10,000 charter capital to import/wholesale food; it had not commenced operations by year-end. Incorporation is delivered, commercialization is not yet evidenced. UAE completion was not located. [BUS06 pp1–2; BUS02 printed p50]
- September 2026: Beacon Star General Trading LLC, Dubai, awarded a 1,000-tonne red-skin peanut-kernel order at USD1,220/tonne, total USD1.22 million, issuer-stated approximately ₹11.529 crore, for execution within one month. Management says no related-party interest. This is concrete demand evidence for the incumbent peanut business, not for protein powder. The cutoff precedes the one-month execution deadline, so absence of a completion notice is not evidence of lateness. Do not extrapolate one price/order across all products or assume collection. [BUS07 pp1–2]
- October 2025 and June 2026: CRISIL marked the issuer non-cooperating, then revised the long-term rating from BB+ to BB, with A4+ continuing, based on limited information. This is a current transparency/credit-risk warning, not proof of default or fraud. The June rationale's annual-labelled financial table conflicts with full-year accounts and appears to contain half-year amounts; it is excluded from the annual model. [BUS10; BUS11]

The factory property needs clarification. The prospectus narrative calls the facility owned, but its location/lease tables state leased and explicitly say the company owned no immovable property. Factory lessors include the promoter and a related party; the disclosed term ended in October 2024. Current title/renewal and the ₹3 crore building investment should be reconciled. Do not infer either freehold ownership or asset diversion. [BUS01 printed pp125–126, 140]

## 6. Moat assessment and peers

Gujarat procurement access, export execution, sorting quality and repeat B2B relationships are credible capabilities. Yet they are shared by many processors and traders. No reliable market share, structurally lower cost curve, proprietary processing technology, long contractual customer lock-in or durable branded premium was established. The new value-added lines could improve the mix, but the burden of proof is now sell-through and cash returns rather than factory installation alone.

Four useful comparators, with original primary PDFs retained:

| Company | FY2026 scope | Revenue, ₹ crore | PAT, ₹ crore | Reported PAT margin | Why included |
|---|---|---:|---:|---:|---|
| Shreeji Global FMCG | Standalone | 766.40 | 19.92 | 2.60% | Closest Gujarat processing/trading, SHETHJI and white-label ingredient channels |
| NHC Foods | Consolidated | 601.31 | 12.32 | 2.05% | Bulk spices/oilseeds/grains exporter; demonstrates diversification and working-capital complexity |
| Sakuma Exports | Consolidated | 1,708.28 | 9.51 | 0.56% | Bulk commodity trading downside and volatile thin spreads |
| Gujarat Ambuja Exports | Consolidated | 5,728.60 | 304.28 | 5.31% | Larger industrial integration and liquidity benchmark, not a direct valuation clone |

Sources and precise pages: PEER01–04 in peer_inputs.json and the source registry below. PAT includes reported non-operating effects; these are not like-for-like operating-margin scores. No market-price multiples or peer-quality rankings are asserted.

Shreeji has similar procurement/processing geography, but a more domestic and broader grain/spice mix. Its FY2026 inventory doubled to ₹98.59 crore and receivables rose to ₹83.58 crore while sales grew 18.10%, a useful reminder that growth requires operating capital. Its MDA uses inventory as a product-performance proxy, which must not be mistaken for product revenue. NHC's new water/beverage plant and Hong Kong trading acquisition make its consolidated growth less pure than its agro label suggests. Sakuma revenue and profit declined in FY2026; substantial other income means even its 0.56% PAT margin overstates pure trading profitability. [PEER01 pp59–66,105–106; PEER02 pp72–73,137; PEER03 p126]

GAEL's maize/soy derivatives and multi-plant scale are economically different, but its disclosed new fermentation capacity and larger liquid investment balance show what a stronger industrial platform looks like. Using a common operating definition excluding other income, consolidated pre-exception EBITDA is ₹466.45 crore, 8.14% of revenue, rather than the ₹574 crore headline including other income. Sheetal's latest reported operating margin therefore deserves explanation and persistence testing rather than an automatic branded-premium interpretation. None of this proves misstatement. [PEER04 PDF pp4,122; Sheetal financial bridge]

## 7. Scoreability and monitoring

Do not force REV from nominal CAGR when the current demand/volume bridge is opaque. FY2023 has volume corroboration; the most recent years do not. Leave CAP NS until project spending, commercial volumes, product profits, working capital and cash reconcile. Capacity establishes supply capability, not a five-year customer-demand runway. A numerical DUR assumption would also need demand access and sustainable economics, not just food-sector forecasts.

Monitor:

1. New product tonnes, sales and utilization by nuts/protein/oil, with yields and operating days.
2. Latest top-customer and country concentration, not the reused 2023 mix.
3. Domestic growth versus exports and branded versus bulk/traded sales.
4. FY2026 stock liquidation, aging/quality, collection of trade receivables and CFO conversion.
5. Actual margins and repeat purchases after product launch.
6. Full IPO project-spend and capacity reconciliation, including building/lease rights.
7. CRISIL cooperation status and the updated forward-looking liquidity assessment.
8. Fulfilment and collection of the Dubai order, with repeat orders separated from one-off demand.
9. Russia subsidiary commercialization and UAE status, with capital committed versus cash returned.

A falsifying path is straightforward: new capacity fails to create repeat demand; domestic turnover requires larger inventory/receivables; commodity margins normalize; working-capital borrowing and dilution fund the gap. The opposing path is also possible: verified repeat orders and clean cash collection demonstrate that value-added sales are genuinely driving growth. Present evidence has not resolved that fork.

## Source registry and retrieval integrity

Original PDFs and pdftotext derivatives are retained locally. HTML CRISIL pages were read through the web tool; direct raw-download attempts returned HTTP406, so no original-file hash is fabricated.

- BUS01: [SheetalUniversal_PROSP.pdf](https://nsearchives.nseindia.com/emerge/corporates/content/SheetalUniversal_PROSP.pdf). Date: 2023-11-28. Pages: Printed pp.25–32,77–83,93–95,125–140; PDF p100=printed94, p144=printed138. SHA-256: cacfb4b71beeae8a637550d28a5a72a6bc4bd824b8c9891f6217117a8fa5d784.
- BUS02: [Annual_Report_Year_2026.pdf](https://sheetaluniversal.com/wp-content/uploads/2026/09/Annual-Report_Final-2025-26-upload.pdf). Date: 2026-09-08. Pages: PDF pp49–51 MDA (printed48–50), p91 standalone noteA, p124 consolidated noteA; PDF p64 employee disclosure. SHA-256: 78545f7b3d5ce3ed6eb6c57f966f15ebf1bd670d7779388821e38a9561aa7bb2.
- BUS03: [SHEETAL_21052025171754_Disclosure_Signed.pdf](https://nsearchives.nseindia.com/corporate/SHEETAL_21052025171754_Disclosure_Signed.pdf). Date: 2025-05-21. Pages: PDF pp1–2. SHA-256: 709956af52f2a9d59f92a38584eff204bebef846b8b63de511199d329ff464b7.
- BUS04: [SHEETAL_23022026191013_Disclosure_-23-02-2026_Signed.pdf](https://nsearchives.nseindia.com/corporate/SHEETAL_23022026191013_Disclosure_-23-02-2026_Signed.pdf). Date: 2026-02-23. Pages: PDF p1, scanned; visually checked saved launch_feb26-1.png. SHA-256: e0419b3bd0bdb05f58454e178fe3f6a657060703f08554c3b57a15b8d8366b6e.
- BUS05: [SHEETAL_13052024190933_announcement.pdf](https://nsearchives.nseindia.com/corporate/SHEETAL_13052024190933_announcement.pdf). Date: 2024-05-13. Pages: PDF p1. SHA-256: 667bc57137a78f3919a087db3316fd28a5566e503d4aa5226cf2fb5b34593ea7.
- BUS06: [SHEETAL_06032026200957_Regulation_30_signed.pdf](https://nsearchives.nseindia.com/corporate/SHEETAL_06032026200957_Regulation_30_signed.pdf). Date: 2026-03-06. Pages: PDF pp1–2. SHA-256: 7852897ebcfe43b091af1840f5bc1d57e33f5f0ac8b972f5ca2a624eccc2fc4c.
- BUS07: [SHEETAL_23092026190411_Peanuts_from_a_UAE-based_Company__Signed.pdf](https://nsearchives.nseindia.com/corporate/SHEETAL_23092026190411_Peanuts_from_a_UAE-based_Company__Signed.pdf). Date: 2026-09-23. Pages: PDF pp1–2. SHA-256: 863e98b6d1eacc3a1992fe84079cee63e7713e63b15e8d38d7403a9221351016.
- BUS08: [Annual_Report_Year_2025.pdf](https://sheetaluniversal.com/wp-content/uploads/2025/09/Final-Report_Sheetal_2025.pdf). Date: 2025-09-08. Pages: PDF pp32–34 MDA, p103 revenue notes. SHA-256: e9f05c96609a626d3ff212aae2cabc4cdde9c5484bf2299d5305e9b26bac063a.
- BUS09: [CRISIL rating rationale 2024-08-02](https://www.crisil.com/mnt/winshare/Ratings/RatingList/RatingDocs/SheetalUniversalLimited_August%2002_%202024_RR_348996.html). Date: 2024-08-02. Pages: HTML: Rating Action, Detailed Rationale, Key Rating Drivers/About Group. SHA-256: not available; HTML read via web tool.
- BUS10: [CRISIL rating rationale 2025-10-23](https://www.crisil.com/mnt/winshare/Ratings/RatingList/RatingDocs/SheetalUniversalLimited_October%2023_%202025_RR_377942.html). Date: 2025-10-23. Pages: HTML: Rating Action, Detailed Rationale, Key Rating Drivers/About Group. SHA-256: not available; HTML read via web tool.
- BUS11: [CRISIL rating rationale 2026-06-30](https://www.crisil.com/mnt/winshare/Ratings/RatingList/RatingDocs/SheetalUniversalLimited_June%2030_%202026_RR_398716.html). Date: 2026-06-30. Pages: HTML: Rating Action, Detailed Rationale, Key Rating Drivers/About Group. SHA-256: not available; HTML read via web tool.
- PEER01: [Shreeji_FY26.pdf](https://nsearchives.nseindia.com/annual_reports/SME_AR_31887_SHETHJI_2025_2026_A_16442392_08092026172713.pdf). Date: 2026-09-08. Pages: PDF pp59–66 business / MDA,105 P&L,106 sales geography. SHA-256: f7f939f1ae53498166a90522edf80ee7d24089b808f0c6fa50842397984a4fc4.
- PEER02: [NHC_FY26.pdf](https://nhcgroup.com/legacy-assets/data/investors/34th%20Annual%20General%20Meeting/Annual%20Report%20FY%2025-26.pdf). Date: 2026-09-01 (AGM notice); audited accounts dated 2026-05-21. Pages: PDF pp72–73/printed70–71 MDA; PDF137/printed135 consolidated P&L. SHA-256: dd3c16739ed36f46469560f07db9e49129ad59baaf60ba2a29274fab1fb6974e.
- PEER03: [Sakuma_FY26.pdf](https://sakumaexportsltd.com/investors/annualreport/21st-Annual-Report-2025-2026.pdf). Date: 2026-09-03 (exchange cover letter). Pages: PDF pp25–27 MDA; PDF126/printed123 consolidated P&L. SHA-256: ab7a2343efc4538d8de92c2cfa6c772cd6eb32f3899fbeb061232342eb6e7245.
- PEER04: [annual-report-fy-2025-26.pdf](https://www.ambujagroup.com/documents/financials/annual-report/annual-report-fy-2025-26.pdf). Date: 2026-08-01 (Board report); AGM 2026-09-05. Pages: PDF p4 printed4–5 highlights;PDF p11 printed18–19 processing;PDF p122 printed240–241 consolidated accounts. SHA-256: db05128cb0cfae597bf3dbb96a1bd5742aeaaa4d290ad1bd68ab84f74d8a60c5.
