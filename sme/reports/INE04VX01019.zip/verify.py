"""Producer output/input binding and research-completeness attestation."""
from pathlib import Path
import json,re,hashlib,gzip
from decimal import Decimal as D
P=Path(__file__).resolve().parent

def sha(b):return hashlib.sha256(b).hexdigest()
def verify():
 import build,scoring
 r=json.loads((P/'company_record.json').read_text());checks=[]
 def ok(a,label):
  assert a,label;checks.append(label)
 for n,h in r['authored_input_sha256'].items():ok(sha((P/n).read_bytes())==h,'input:'+n)
 for n,h in r['output_sha256'].items():ok(sha((P/n).read_bytes())==h,'output:'+n)
 ok(r['framework_sha256']=='68d4de4255427df276318d0231530b867a453e740c74150e9768bf1387224137','framework exact')
 report=(P/'report.md').read_text();ok(len(re.findall(r'^## \d+\.',report,re.M))==15,'15 substantive sections');ok(len(json.loads((P/'quality_checks.json').read_text())['checks'])==16,'16 quality checks')
 j=json.loads((P/'judgments.json').read_text());ok(len(j['factors'])==13,'13 canonical factors');s=scoring.calculate(j);ok(all(v['display']=='NS'for v in s['composites'].values()),'NS intact');ok(s['composites']['GQS']['cap']==D(5),'GQS cap5');ok(not r['ranking_eligible'],'pending evidence not ranked')
 with gzip.open(P/'canonical_paths.json.gz','rt')as f:x=json.load(f)
 ok(len(x)==r['path_count'],'all retained paths');ok(all(not v['source_eligible']for v in x.values()),'no unsupported source eligibility');ok(all(v['terminal']is None and v['summary']['irr']is None for v in x.values()if v['failure']),'failed-path suppression')
 ok(all(not any(z['debt_draw']!='0' or z['new_shares']!=0 for z in v['monthly']if z['phase']=='terminal_transition')for v in x.values()),'no terminal new-finance rescue')
 ok(not any(x in report for x in['/workspace/','/home/agent/','file:///','localhost:']),'source-safe reader')
 out={'status':'PASS','kind':'producer_reproduction_attestation','company_record_sha256':sha((P/'company_record.json').read_bytes()),'authored_input_aggregate_sha256':r['authored_input_aggregate_sha256'],'report_sha256':r['report_sha256'],'canonical_sha256':r['canonical_sha256'],'checks_count':len(checks),'checks':checks,'scope':'Mechanical reproducibility/completeness, not resolution of disclosed investment evidence gaps.'};(P/'producer_attestation.json').write_text(json.dumps(out,sort_keys=True,indent=2)+'\n');print(json.dumps({'status':'PASS','checks':len(checks)}))
if __name__=='__main__':verify()
