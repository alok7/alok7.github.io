"""Financial and market calculations from explicit primary extracts. INR crore output."""
from decimal import Decimal as D
from statistics import median

def calculate(f,m):
 out=[];prev=None
 for src in f['financial_years']:
  r={k:(D(v)/100 if k not in ['source_id','pages','scope','unit','audit_status']and isinstance(v,str)else v)for k,v in src.items()}
  r['core_ebit']=r['pbt']+r['finance']-r['other_income'];r['core_ebitda']=r['core_ebit']+r['da'];r['nopat']=r['core_ebit']*(1-D(f['normalization']['tax_rate']));r['normalized_pat']=(r['core_ebit']-r['finance'])*(1-D(f['normalization']['tax_rate']));r['debt']=r['debt_long']+r['debt_short'];r['net_debt_march']=r['debt']-r['cash'];r['reported_fcf_proxy']=None if r['year']==2021 else r['cfo']-r['capex_cash_net'];r['basic_onwc']=r['ar']+r['inventory']-r['ap'];r['core_ic']=r['basic_onwc']+r['ppe']+r['cwip'];r['funding_ic_proxy']=r['equity']+r['debt']-r['cash']-r['investments'];r['ic_definition_gap']=r['funding_ic_proxy']-r['core_ic'];r['ebitda_margin']=r['core_ebitda']/r['revenue'];r['pat_margin']=r['pat_total']/r['revenue'];r['interest_coverage']=r['core_ebit']/r['finance'];r['net_debt_ebitda']=r['net_debt_march']/r['core_ebitda'] if r['core_ebitda']>0 else None
  r['cost_proxy']=r['revenue']-r['core_ebitda'] # includes opex; disclose compatible cost limitation
  if prev:
   r['revenue_addition']=r['revenue']-prev['revenue'];r['yoy']=r['revenue']/prev['revenue']-1;r['avg_ar_days']=(r['ar']+prev['ar'])/2/r['revenue']*365;r['inventory_days_cost_proxy']=(r['inventory']+prev['inventory'])/2/r['cost_proxy']*365;r['payable_days_cost_proxy']=(r['ap']+prev['ap'])/2/r['cost_proxy']*365;r['ccc_proxy']=r['avg_ar_days']+r['inventory_days_cost_proxy']-r['payable_days_cost_proxy'];r['roic_core']=r['nopat']/((r['core_ic']+prev['core_ic'])/2);r['roce_funding']=r['core_ebit']/((r['funding_ic_proxy']+prev['funding_ic_proxy'])/2);r['roe']=r['pat_owners']/((r['equity']+prev['equity'])/2)
  out.append(r);prev=r
 cagr=[]
 for yrs in[3,5]:
  a=out[-1-yrs];b=out[-1];cagr.append({'years':yrs,'start_year':a['year'],'end_year':b['year'],'start':a['revenue'],'end':b['revenue'],'cagr':(b['revenue']/a['revenue'])**(D(1)/yrs)-1,'basis':'Consolidated reported sales, not verified constant-price demand'})
 conversions=[]
 for n in[3,5]:
  a=out[-n:];cf=sum(x['cfo']for x in a);pat=sum(x['pat_total']for x in a);conversions.append({'years':n,'cfo':cf,'pat':pat,'ratio':cf/pat,'basis':'Ratio of sums, reported financing-interest-outside-CFO basis; reliability caveats apply','after_finance_cfo':cf-sum(x['finance']for x in a),'after_finance_ratio':(cf-sum(x['finance']for x in a))/pat})
 inc=[]
 for n in[3,5]:
  a=out[-n-1];b=out[-1];delta=b['funding_ic_proxy']-a['funding_ic_proxy'];ni=b['nopat']-a['nopat'];segment=out[-n:];gross=sum((x['capex_cash_net']for x in segment),D(0));da=sum(x['da']for x in segment);on=b['basic_onwc']-a['basic_onwc'];bridge=gross-da+on
  inc.append({'years':n,'from':a['year'],'to':b['year'],'delta_nopat':ni,'delta_funding_ic':delta,'observed_proxy':ni/delta if delta>0 else None,'reported_capex':gross,'da':da,'delta_core_onwc':on,'identified_net_reinvestment':bridge,'residual_vs_funding_ic':delta-bridge,'status':'Accounting proxy, not project IRR. Opaque advances, classification, net capex and margin/volume attribution prevent CAP scoring.'})
 sessions=[]
 for x in m['sessions']:
  # Preserve alternate series separately; regular SM alone supports regular-market implementation.
  rr=[r for r in x['rows']if r['SctySrs']=='SM'];sessions.append({'date':x['date'],'present':bool(rr),'value':sum((D(r['TtlTrfVal'])for r in rr),D(0))if rr else None,'volume':sum((int(r['TtlTradgVol'])for r in rr),0)if rr else None,'rows':rr})
 liquidity=[]
 for n in[20,60]:
  a=sessions[-n:];v=[r['value']for r in a if r['value']is not None];mu=sum(v)/len(v);med=median(v);den=min(mu,med);liquidity.append({'sessions':n,'observed':len(v),'missing':n-len(v),'zero_trade_rows':sum(vv==0 for vv in v),'mean_inr':mu,'median_inr':med,'capacity_basis_inr':den,'liquidation_days':{str(rate):D(500000)/(rate*den)if den>0 else None for rate in[D('.02'),D('.05'),D('.10')]}})
 last=sessions[-1]['rows'][0];price=D(last['ClsPric']);shares=f['shares']['oct20_issued'];cap=price*shares/D(10000000);latest=out[-1];ev=cap+latest['debt']-latest['cash'];lot=int(last['NewBrdLotQty']);lotval=price*lot;floor_lots=int(D(500000)//lotval)
 multiples={'price':price,'price_date':last['TradDt'],'issued_shares':shares,'market_cap':cap,'march_debt':latest['debt'],'march_cash':latest['cash'],'ev_march_bridge':ev,'pe_reported_current_shares':cap/latest['pat_owners'],'pe_normalized':cap/latest['normalized_pat']if latest['normalized_pat']>0 else None,'ev_ebitda_core':ev/latest['core_ebitda'],'pb_march':cap/latest['equity'],'fcf_yield_reported':latest['reported_fcf_proxy']/cap,'all_warrant_proceeds_retained_ev_sensitivity':ev-D('29.82'),'warning':'Current debt/cash not verified; known cash receipt is not retained cash.'}
 return {'history':out,'cagr':cagr,'cash_conversion':conversions,'incremental_returns':inc,'liquidity':liquidity,'multiples':multiples,'execution':{'lot':lot,'lot_value_inr':lotval,'budget_lots':floor_lots,'budget_shares':floor_lots*lot,'budget_spend_inr':floor_lots*lotval,'next_lot_spend_inr':(floor_lots+1)*lotval,'one_lot_days_at_5pct':lotval/(D('.05')*liquidity[-1]['capacity_basis_inr']),'disclaimer':'Time aggregation is theoretical, not ability to buy/sell fractions of a lot. Spread and live depth ND.'}}
