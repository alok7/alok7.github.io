"""Cooperative fresh-input and I/O audit guard. It is not an OS security sandbox."""
from pathlib import Path
import sys,json,hashlib,ast,runpy,os
P=Path(__file__).resolve().parent

def main():
 tree=ast.parse((P/'build.py').read_text());declarations={}
 for node in tree.body:
  if isinstance(node,ast.Assign):
   for target in node.targets:
    if isinstance(target,ast.Name)and target.id in['INPUTS','OUTPUTS']:declarations[target.id]=ast.literal_eval(node.value)
 inputs=declarations['INPUTS'];outputs=declarations['OUTPUTS']+['producer_attestation.json','independent_replay_results.json','recovery_attestation.json']
 if '--fresh'in sys.argv:
  forbidden=[n for n in outputs if(P/n).exists()]
  if forbidden:raise RuntimeError('Fresh recovery requires an empty inputs-only clone; existing outputs: '+', '.join(forbidden))
 for n in inputs:
  if not(P/n).is_file():raise FileNotFoundError(n)
 before={n:hashlib.sha256((P/n).read_bytes()).hexdigest()for n in inputs};reads=set();writes=set();sys.dont_write_bytecode=True
 allowed_read={(P/n).resolve()for n in inputs+outputs};allowed_write={(P/n).resolve()for n in outputs};stdlib=Path(os.__file__).resolve().parent
 def hook(event,args):
  if event.startswith('socket.')or event in['subprocess.Popen','os.system','os.posix_spawn']:raise RuntimeError('Network/subprocess prohibited during offline recovery: '+event)
  if event!='open' or isinstance(args[0],int):return
  path=Path(args[0]).resolve();mode=args[1];flags=args[2]if len(args)>2 else 0;writing=(isinstance(mode,str)and any(c in mode for c in'wa+'))or(bool(flags&(os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC))if isinstance(flags,int)else False)
  if writing:
   if path not in allowed_write:raise RuntimeError('Undeclared write: '+str(path))
   writes.add(str(path.relative_to(P)))
  else:
   if path.suffix=='.pyc' and path.is_relative_to(P):raise FileNotFoundError('Local bytecode is not a declared input')
   if path not in allowed_read and not path.is_relative_to(stdlib):raise RuntimeError('Undeclared read: '+str(path))
   if path.is_relative_to(P):reads.add(str(path.relative_to(P)))
 sys.addaudithook(hook)
 for script,args in[('build.py',[]),('verify.py',[]),('independent_replay.py',['--inputs',str(P),'--output',str(P/'independent_replay_results.json'),'--compare'])]:
  sys.argv=[str(P/script)]+args;runpy.run_path(str(P/script),run_name='__main__')
 after={n:hashlib.sha256((P/n).read_bytes()).hexdigest()for n in inputs};assert before==after
 r=json.loads((P/'company_record.json').read_text());out={'status':'PASS','kind':'fresh_inputs_only_guarded_recovery','network':'prohibited by cooperative audit hook','subprocess':'prohibited','input_files':before,'input_unchanged':True,'authored_input_aggregate_sha256':r['authored_input_aggregate_sha256'],'company_record_sha256':hashlib.sha256((P/'company_record.json').read_bytes()).hexdigest(),'read_files':sorted(reads),'written_files':sorted(writes),'limitation':'Python cooperative audit hook, not an OS sandbox; original-source verification remains separately attested.'};(P/'recovery_attestation.json').write_text(json.dumps(out,sort_keys=True,indent=2)+'\n')
if __name__=='__main__':main()
