# Monthly funding and earned value model

All monetary flows are in ₹ crore, prices in rupees per share, quantities in explicitly assumed peanut-equivalent tonnes and shares in whole numbers. Values use Decimal, not binary floating point. The November 2026 opening deliberately carries the March 2026 balance sheet, plus an explicit sensitivity for retained warrant proceeds. It is not a verified current balance. None of the paths is source eligible for an investment-return score.

## Operating mechanics

Each month records target and sold tonnes, lost demand, realized price, goods cost, operating expenses, cash collections, purchase obligations and supplier payments. Domestic and export invoice cohorts mature separately. Opening current receivables and old receivables have distinct collection schedules and recoveries. Historical aged receivables are not silently treated as cash. An unrecovered amount is written off without subtracting a second cash outflow. Opening payables are paid on an explicit schedule. New procurement equals goods consumed plus the target inventory change, floored at zero. An inventory write-down reduces stock and earnings but does not itself spend cash. Procurement seasonality is an assumption, not a fact established by monthly filings.

Opening other current assets and short advances are carried and receive an explicit incremental-investment ratio. The opaque long advances are not available cash; recovery is a separate scenario. Deposits remain restricted/nonavailable unless an explicitly hypothetical release is enabled. The tax provision is settled once on the assumed date. New tax is paid on positive earnings after financing expense, with no invented refund from losses.

## Physical capacity and investment

The operating proxy is not an observed product mix or a manufactured FY2026 selling price. The chosen ₹0.0145 crore/tonne realization converts reported revenue into a conditional equivalent quantity. Legacy 12,000/18,000-tonne capacity variants expose the historical disclosure conflict. New flavoured-nut, protein and oil nameplates are retained separately in inputs; they are not added together as saleable output because oil and protein can be joint products.

Expansion has a cash cost per annual tonne, annual addition ceiling, total ceiling and commissioning delay. Paid expansion first enters CWIP. Only commissioned assets enter PPE and depreciation. Maintenance capex is assumed immediately available. Legacy and newly commissioned net PPE depreciate separately; neither can fall below zero. Lost sales caused by capacity constraints do not create receivables or cash. A high assumed growth rate is therefore not automatically recognized as sales.

## Financing and shares

The reported ₹32.7866 crore working-capital debt, ₹3.9105 crore bank term debt and ₹1.4154 crore other long-term debt, plus the ₹0.0001 crore displayed-component rounding claim, begin outstanding. Continuing a callable working-capital facility is an explicit conditional gate. The historical ₹25 crore rated facility is not treated as incremental headroom. Current sanction, drawing power and full maturity evidence remain incomplete. Term repayments, coupons, bank fees, new-debt draw fees, cohort maturities, renewal permissions and renewal fees are all cash flows.

Automatic financing draws, when enabled, are bounded by outstanding and cumulative limits. Equity uses integer ceiling arithmetic at an assumed discounted issue price, subtracts issuance fees and respects the 13,000,000-share authorization unless an additional approval gate is explicitly assumed. The 1,420,000 converted warrants are already included in 12,875,999 opening issued shares; they never produce future conversion cash again. The ₹29.82 crore gross receipts are only an opening-retention sensitivity, not a second share issue. The remaining 124,001-share authorization is capacity for a hypothetical issue, not proof that an issue is approved or funded.

A path fails when cash cannot meet its disclosed operating reserve after the financing permitted in that path. This is a conditional modelling failure, not a finding of legal insolvency or actual default. Ordinary terminal price, IRR and hurdle entries are suppressed on failed paths. Failed terminal attempts retain operating/capacity/cash diagnostics without ordinary return fields.

## Earned terminal cash flow and claims

At the selected exit date, last-12-month earned EBITDA and depreciation anchor a mature next-year case. Terminal growth is 2%, 4% or 6%; WACC is separately sensitized at 13%, 16% and 19%. A 15% equity hurdle is not called WACC. Replacement capex is at least next-year depreciation and at least the maintenance policy. Incremental working capital and new physical capacity are explicit. Total growth reinvestment is the greater of those needs and next-year NOPAT × growth / the assumed 12% marginal post-tax return. This prevents high perpetual growth without investment.

Terminal FCFF = next NOPAT + next D&A − replacement capex − growth reinvestment. Enterprise value is positive FCFF / (WACC − terminal growth), not an unearned sales multiple. A separate EBITDA multiple cross-check uses earned earnings. Common equity adds only excess unrestricted cash after reserve and subtracts all remaining debt and unpaid tax claims. Deposits, opaque advances and CWIP are not added as free cash or counted again as non-operating assets. No dividend is paid by the forecast, so accumulated cash is counted only at exit.

The SAME operating engine extends twelve months, preserving AR/AP cohorts and procurement seasonality. It checks commissioning, pre-funded pipeline, new capacity orders, working-capital/replacement expenditure, coupons, principal, permitted renewals and the operating reserve. Paid pipeline is not bought twice. Required retained cash is derived from the largest actual monthly transition trough plus extra economic reinvestment. Only closing cash above that reserve is credited as non-operating value; it is removed before verifying each transition cash balance. No new borrowing or equity is permitted after the exit horizon. A terminal case that cannot supply assumed throughput or finance this transition fails. A current equity value is not computed by ignoring a failed terminal bridge.

With no interim distributions, total return is the exit-price ratio after assumed 1% entry and 1% exit execution costs, annualized over the horizon. Costs are assumptions, not measured market impact. Hurdle entry prices are calculated at 12%, 15% and 18%. All cash is retained, so the terminal business valuation supplies the operating value at exit; this is highly sensitive to mature margins, reinvestment and discount rates. It is not presented as an observable fair value.

## Trial retention and model limitations

The canonical trace includes every grid point and every funding/target-crossing refinement. Initial methodology iterations are retained in versioned development archives and clearly superseded, including the first version that incorrectly depreciated paid expansion before commissioning. No failing trial is silently dropped or reported as a funded multibagger. Finite grid failure is not a proof that no conceivable strategy could work.

The most important missing observations are current cash/debt and facility sanctions, product sales/tonnes/mix, lender drawing power, receipt timing and recovery of advances, fully reconciled cash-flow classifications and actual new-line unit returns. Precision in the calculations does not create precision in those assumptions.
