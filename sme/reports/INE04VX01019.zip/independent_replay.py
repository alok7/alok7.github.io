"""Independent Sheetal cash/claims replay from declared JSON inputs only.

No producer model, scenario, scoring, rendering, or build module is imported.
This reproduction checks an analytical conditional model, not actual solvency.
"""
from decimal import Decimal as D, ROUND_CEILING
from collections import defaultdict
from pathlib import Path
import argparse, json, gzip, hashlib, io

ZERO=D(0); ONE=D(1); CRORE=D(10000000)
SEASON=tuple(map(D,['.85','.85','.95','.95','1','1','1','1','1.05','1.10','1.10','1.15']))
assert sum(SEASON)==12

def dec(x):
    if isinstance(x,float):raise TypeError('Floating-point model input is prohibited')
    return D(str(x))

def date_for(t):
    x=2026*12+10+t-1
    return f'{x//12:04d}-{x%12+1:02d}'

def primitive(x):
    if isinstance(x,D):return str(x)
    if isinstance(x,list):return [primitive(y) for y in x]
    if isinstance(x,dict):return {k:primitive(v) for k,v in x.items()}
    return x

def cash_path(inputs,s,years):
    """Recreate purchases, collections, commitments, financing and claims afresh."""
    o={k:dec(v) for k,v in inputs['opening'].items()}
    a=lambda key:dec(s[key])
    cash=o['cash']+a('retained_warrant_cash')
    shares=inputs['issued_shares']; authorization=s['expanded_authorized_shares'] if s['equity_authorization_gate'] else inputs['authorized_shares']
    debt=[o['working_capital_debt'],o['bank_term_debt'],o['unsecured_debt']+o.get('unallocated_debt_rounding',ZERO),ZERO]
    capacity=a('initial_capacity_tonnes'); projects=[]; loans=[]; accumulated_capacity=defaultdict(lambda:ZERO)
    original_asset=o['ppe']; later_asset=ZERO; cwip=o['cwip']
    ar=o['ar_current']+o['ar_old']; inventory=o['inventory']; ap=o['payables']; opa=o['other_operating_assets_proxy']
    long_advance=o['long_advances']; deposits=o['restricted_deposits']; tax_claim=o['tax_provision']
    collections=defaultdict(lambda:ZERO); suppliers=defaultdict(lambda:ZERO)
    for t in range(1,s['opening_ar_months']+1):collections[t]+=o['ar_current']/s['opening_ar_months']
    for t in range(s['old_ar_start'],s['old_ar_start']+s['old_ar_months']):collections[t]+=o['ar_old']*a('old_ar_recovery')/s['old_ar_months']
    for t in range(1,s['opening_ap_months']+1):suppliers[t]+=ap/s['opening_ap_months']
    turnover=o['annual_sales']; baseline_units=turnover/a('initial_realisation_crore_per_tonne')
    cumulative_draw=cumulative_equity=cumulative_capex=ZERO; rejected_authorizations=0;rows=[];failed=None; exit_basis=None; end_month=12*years
    for t in range(1,end_month+13):
        y=(t-1)//12
        row={'month':t,'date':date_for(t),'year':y+1,'phase':'operating_horizon' if t<=end_month else 'terminal_transition','cash_open':cash,'ar_open':ar,'ap_open':ap,'inventory_open':inventory,'other_operating_assets_open':opa,'debt_open':sum(debt),'shares_open':shares,'ppe_open':original_asset+later_asset,'cwip_open':cwip}
        matured=[x for x in projects if x[0]==t]
        commissioned=sum((x[1] for x in matured),ZERO); commissioned_cost=sum((x[2] for x in matured),ZERO)
        capacity+=commissioned;cwip-=commissioned_cost;later_asset+=commissioned_cost
        projects=[x for x in projects if x[0]!=t]
        if t<=end_month:
            annual_units=baseline_units*(ONE+a('volume_growth'))**(y+1)
            intended=annual_units*SEASON[(t-1)%12]/12*(ONE-a('customer_loss'))
            realization=a('initial_realisation_crore_per_tonne')*(ONE+a('price_growth'))**(y+1)*(ONE+a('export_fraction')*a('export_price_shock'))
        else:
            annual_units=exit_basis['units']*(ONE+a('terminal_growth'))
            intended=annual_units*SEASON[(t-1)%12]/12
            realization=exit_basis['sales']/exit_basis['units']
        units=min(intended,capacity/12);sales=units*realization
        pending=sum((x[1] for x in projects),ZERO)
        commit=min(max(ZERO,annual_units*D('1.15')-capacity-pending),max(ZERO,a('capacity_ceiling_tonnes')-capacity-pending),max(ZERO,a('annual_capacity_addition_limit')-accumulated_capacity[y]))
        growth_spend=commit*a('capex_per_annual_tonne');cwip+=growth_spend;accumulated_capacity[y]+=commit
        if commit:projects.append((t+s['capacity_lead_months'],commit,growth_spend))
        maintenance=sales*a('maintenance_capex_ratio')
        if t>end_month:
            monthly_rate=a('da_new_assets_rate')/12
            replacement=(min(original_asset,a('da_opening_annual')/12)+later_asset*monthly_rate)/(ONE-monthly_rate)
            maintenance=max(maintenance,replacement)
        capex=growth_spend+maintenance;cumulative_capex+=capex
        cogs=sales*a('material_ratio'); impairment=inventory*a('inventory_impairment') if t==s['inventory_impairment_month'] else ZERO
        inventory-=impairment
        buffer=D('1.25') if s['procurement_seasonality'] and int(date_for(t)[5:]) in (10,11,12,1) else ONE
        required_stock=annual_units*realization*a('material_ratio')*a('inventory_days')/365*buffer
        purchases=max(ZERO,cogs+required_stock-inventory);inventory+=purchases-cogs
        suppliers[t+s['supplier_delay']]+=purchases;payment=suppliers.pop(t,ZERO);ap+=purchases-payment
        export=sales*a('export_fraction');collections[t+s['export_delay']]+=export;collections[t+s['domestic_delay']]+=sales-export
        received=collections.pop(t,ZERO);ar+=sales-received
        writeoff=o['ar_old']*(ONE-a('old_ar_recovery')) if t==s['old_ar_start']+s['old_ar_months']-1 else ZERO;ar-=writeoff
        expense_rate=ONE-a('material_ratio')-a('core_ebitda_margin');assert expense_rate>=0
        expense=expense_rate*(a('fixed_opex_fraction')*turnover/12+(ONE-a('fixed_opex_fraction'))*sales)
        ebitda=sales-cogs-expense
        later_asset+=maintenance;legacy_da=min(original_asset,a('da_opening_annual')/12);recent_da=min(later_asset,later_asset*a('da_new_assets_rate')/12)
        depreciation=legacy_da+recent_da;original_asset-=legacy_da;later_asset-=recent_da
        ebit=ebitda-depreciation-impairment-writeoff
        interest=sum(debt[z]*a(key) for z,key in enumerate(['wc_rate','bank_term_rate','unsecured_rate','new_debt_rate']))/12
        principal=[ZERO,min(debt[1],a('bank_term_principal_monthly')),ZERO,ZERO]
        if t==s['unsecured_repayment_month']:principal[2]=debt[2]
        if not s['wc_renewal'] and t==s['wc_call_month']:principal[0]=debt[0]
        rollover_fee=ZERO; next_loans=[]
        for due,amount in loans:
            if due!=t:next_loans.append((due,amount))
            elif s['debt_renewal_gate']:
                rollover_fee+=amount*a('debt_renewal_fee');next_loans.append((t+s['new_debt_tenor'],amount))
            else:principal[3]+=amount
        loans=next_loans;debt=[b-p for b,p in zip(debt,principal)]
        tax=max(ZERO,ebit-interest)*a('tax_rate');past_tax=tax_claim if t==s['opening_tax_settlement_month'] else ZERO;tax_claim-=past_tax
        opa_target=o['other_operating_assets_proxy']+max(ZERO,annual_units*realization-turnover)*a('operating_asset_growth_ratio');opa_change=opa_target-opa;opa=opa_target
        recovery=min(long_advance,a('advance_recovery')) if t==s['advance_recovery_month'] else ZERO;long_advance-=recovery
        release=min(deposits,a('deposit_release')) if t==s['deposit_release_month'] else ZERO;deposits-=release
        fees=a('annual_bank_fees')/12+rollover_fee
        cash_before=cash+received+recovery+release-payment-expense-tax-past_tax-interest-fees-capex-principal[1]-principal[2]-principal[0]-principal[3]-opa_change
        reserve=max(a('minimum_cash'),(cogs+expense)*a('reserve_cost_months'));gap=max(ZERO,reserve-cash_before)
        draw=draw_fee=ZERO
        if t<=end_month and s['incremental_debt_gate'] and gap>0:
            draw=min(gap/(ONE-a('debt_draw_fee')),max(ZERO,a('new_debt_limit')-debt[3]),max(ZERO,a('new_debt_cumulative_limit')-cumulative_draw))
            draw_fee=draw*a('debt_draw_fee');debt[3]+=draw;cumulative_draw+=draw
            if draw:loans.append((t+s['new_debt_tenor'],draw))
        cash_after_debt=cash_before+draw-draw_fee;gap=max(ZERO,reserve-cash_after_debt)
        issued=0;gross=equity_fee=ZERO;issue_price=dec(inputs['entry_price'])*(ONE-a('equity_price_discount'))
        forced=s['forced_equity_shares'] if t==s['forced_equity_month'] else 0
        if t<=end_month and s['equity_gate'] and t<=s['equity_last_month'] and (gap>0 or forced>0):
            wanted=max(forced,int((gap*CRORE/(issue_price*(ONE-a('equity_fee')))).to_integral_value(rounding=ROUND_CEILING)))
            issued=min(wanted,max(0,authorization-shares));rejected_authorizations+=int(issued<wanted)
            shares+=issued;gross=issued*issue_price/CRORE;equity_fee=gross*a('equity_fee');cumulative_equity+=gross
        cash=cash_after_debt+gross-equity_fee;short=max(ZERO,reserve-cash);failure=short>D('1e-24')
        row.update({'cash_close':cash,'cash_reserve':reserve,'cash_shortfall':short,'ar_close':ar,'inventory_close':inventory,'ap_close':ap,'other_operating_assets_close':opa,'long_advances_close':long_advance,'restricted_deposits_close':deposits,'tax_claim_close':tax_claim,'sales':sales,'units_sold':units,'units_lost':intended-units,'unitprice':realization,'capacity_tonnes':capacity,'capacity_added':commissioned,'capacity_committed':commit,'growth_capex':growth_spend,'maintenance_capex':maintenance,'capex':capex,'ppe_close':original_asset+later_asset,'cwip_close':cwip,'commissioned_cost':commissioned_cost,'legacy_ppe':original_asset,'new_ppe':later_asset,'material_cogs':cogs,'purchases':purchases,'supplier_payments':payment,'customer_collections':received,'inventory_impairment':impairment,'bad_debt':writeoff,'opex':expense,'ebitda':ebitda,'da':depreciation,'ebit':ebit,'tax_cash':tax,'opening_tax_settlement':past_tax,'interest':interest,'bank_fees':fees,'advance_release':recovery,'deposit_release':release,'opa_movement':opa_change,'wc_debt_close':debt[0],'term_debt_close':debt[1],'unsecured_debt_close':debt[2],'new_debt_close':debt[3],'debt_close':sum(debt),'principal_term':principal[1],'principal_unsecured':principal[2],'principal_wc':principal[0],'principal_new':principal[3],'debt_draw':draw,'debt_draw_fee':draw_fee,'shares_close':shares,'new_shares':issued,'equity_issue_price':issue_price,'equity_gross':gross,'equity_fee':equity_fee,'cash_before_new_finance':cash_before,'failure':failure})
        rows.append(row)
        if t==end_month:
            exit_basis={key:sum(x[key] for x in rows[-12:]) for key in ['sales','ebitda','ebit']}
            exit_basis['units']=sum(x['units_sold'] for x in rows[-12:]);exit_basis['pending_tonnes']=sum((x[1] for x in projects),ZERO)
        if failure:
            failed={'month':t,'date':date_for(t),'shortfall_to_reserve':short,'negative_cash':cash<0};break
    terminal,attempt,terminal_failure=terminal_value(inputs,s,years,rows,failed,exit_basis)
    if terminal_failure:failed=terminal_failure
    annual=[]
    for y in range(1,years+2):
        period=[x for x in rows if x['year']==y]
        if not period:continue
        r={'year':y,'months':len(period)}
        for dest,key in [('sales','sales'),('ebitda','ebitda'),('ebit','ebit'),('interest','interest'),('tax','tax_cash'),('capex','capex'),('equity_gross','equity_gross'),('new_debt','debt_draw')]:r[dest]=sum(x[key] for x in period)
        for dest,key in [('cash_close','cash_close'),('ar_close','ar_close'),('inventory_close','inventory_close'),('ap_close','ap_close'),('debt_close','debt_close'),('shares_close','shares_close'),('capacity_close','capacity_tonnes'),('cwip_close','cwip_close'),('ppe_close','ppe_close')]:r[dest]=period[-1][key]
        annual.append(r)
    summary={'years':years,'status':'failed_conditional' if failed else 'funded_conditional','failure_month':failed['month'] if failed else None,'volume_growth':s['volume_growth'],'core_ebitda_margin':s['core_ebitda_margin'],'retained_warrant_cash':s['retained_warrant_cash'],'total_capex':sum(x['capex'] for x in rows if x['month']<=end_month),'transition_capex':sum(x['capex'] for x in rows if x['month']>end_month),'equity_gross':cumulative_equity,'new_debt_gross':cumulative_draw,'final_shares':shares,'authorization_rejections':rejected_authorizations,'terminal_sales':terminal['annual_sales'] if terminal else None,'terminal_price':terminal['price'] if terminal else None,'irr':terminal['irr'] if terminal else None,'hurdle_entries':terminal['hurdle_entries'] if terminal else None,'source_eligible':False}
    return {'monthly':rows,'annual':annual,'terminal':terminal,'terminal_attempt':attempt,'summary':summary,'failure':failed,'total_capex':cumulative_capex,'equity_gross':cumulative_equity,'new_debt_gross':cumulative_draw,'final_shares':shares,'authorization_rejections':rejected_authorizations,'state':{'cash':cash,'debt':debt,'loans':loans,'projects':projects,'ar':ar,'inventory':inventory,'ap':ap,'opa':opa,'taxclaim':tax_claim,'capacity':capacity,'cwip':cwip,'original_asset':original_asset,'later_asset':later_asset,'collections':dict(collections),'suppliers':dict(suppliers)}}

def terminal_value(inputs,s,years,rows,failed,basis):
    if failed:return None,None,None
    n=12*years;exit_row=rows[n-1];future=rows[n:]
    assert len(future)==12
    a=lambda key:dec(s[key])
    nopat=sum(max(ZERO,x['ebit'])*(ONE-a('tax_rate')) for x in future)
    da=sum(x['da'] for x in future);replacement=sum(x['maintenance_capex'] for x in future);physical=sum(x['growth_capex'] for x in future)
    onwc=lambda r:r['ar_close']+r['inventory_close']-r['ap_close']+r['other_operating_assets_close']
    onwc_delta=onwc(future[-1])-onwc(exit_row);wc_need=max(ZERO,onwc_delta)
    economic=nopat*a('terminal_growth')/a('terminal_roic');investment=max(physical+wc_need,economic);extra=investment-physical-wc_need
    fcff=nopat+da-replacement-investment
    exit_cash=exit_row['cash_close']
    retained=max(ZERO,exit_row['cash_reserve'],*(x['cash_reserve']-(x['cash_close']-exit_cash)+extra*(idx+1)/12 for idx,x in enumerate(future)))
    excess=max(ZERO,exit_cash-retained);lost=sum(x['units_lost'] for x in future)
    funded=exit_cash+D('1e-18')>=retained and lost<=D('1e-18')
    diagnostics=[{'month_after_exit':idx+1,'source_month':x['month'],'retained_cash_after_excess_distribution':x['cash_close']-excess-extra*(idx+1)/12,'reserve':x['cash_reserve'],'extra_reinvestment':extra/12,'capacity':x['capacity_tonnes'],'lost_units':x['units_lost'],'incremental_debt':x['debt_draw'],'new_shares':x['new_shares']} for idx,x in enumerate(future)]
    attempt={'annual_sales':basis['sales'],'annual_ebitda':basis['ebitda'],'annual_ebit':basis['ebit'],'next_sales':sum(x['sales'] for x in future),'next_nopat':nopat,'next_da':da,'replacement_capex':replacement,'capacity_expansion_cost':physical,'working_capital_reinvestment':wc_need,'actual_onwc_change':onwc_delta,'economic_reinvestment_floor':economic,'extra_reinvestment':extra,'reinvestment':investment,'fcff':fcff,'reserve':retained,'cash_at_exit':exit_cash,'excess_cash':excess,'debt':exit_row['debt_close'],'unpaid_tax_claim':exit_row['tax_claim_close'],'shares':exit_row['shares_close'],'already_paid_pipeline_tonnes':basis['pending_tonnes'],'uncommissioned_cwip':exit_row['cwip_close'],'terminal_reinvestment_funded':funded,'transition':diagnostics,'transition_engine_months':12,'terminal_lost_units':lost}
    if not funded:return None,attempt,{'month':n+1,'date':'terminal transition','shortfall_to_reserve':max(ZERO,retained-exit_cash),'negative_cash':False}
    assert a('terminal_growth')<a('wacc')
    enterprise=max(ZERO,fcff/(a('wacc')-a('terminal_growth')))
    common=max(ZERO,enterprise+excess-exit_row['debt_close']-exit_row['tax_claim_close'])
    price=common*CRORE/exit_row['shares_close'];exit_proceeds=price*(ONE-a('exit_cost'));entry=dec(inputs['entry_price'])*(ONE+a('entry_cost'))
    irr=(exit_proceeds/entry)**(ONE/years)-ONE if exit_proceeds>0 else D(-1)
    cross=max(ZERO,basis['ebitda']*a('exit_ebitda_multiple')+excess-exit_row['debt_close']-exit_row['tax_claim_close'])*CRORE/exit_row['shares_close']
    terminal=dict(attempt,enterprise_value=enterprise,equity_value=common,price=price,irr=irr,multiple_crosscheck_price=cross,terminal_value_at_entry=enterprise/(ONE+a('wacc'))**years,hurdle_entries={str(h):exit_proceeds/((ONE+h)**years*(ONE+a('entry_cost'))) for h in map(D,['.12','.15','.18'])})
    return terminal,attempt,None


def compare_number(got,expected):
    if isinstance(got,bool) or got is None:return got==expected
    if isinstance(got,(D,int)):
        return abs(dec(got)-dec(expected))<=D('1e-18')*max(ONE,abs(dec(got)))
    return got==expected

def differences(got,want,path=''):
    result=[]
    if isinstance(got,dict):
        if not isinstance(want,dict):return [(path,'type',str(type(want)))]
        for k,v in got.items():
            if k not in want:result.append((path+'/'+k,'missing',None))
            else:result.extend(differences(v,want[k],path+'/'+k))
    elif isinstance(got,list):
        if not isinstance(want,list) or len(got)!=len(want):result.append((path+'/length',len(got),len(want) if isinstance(want,list) else None))
        if isinstance(want,list):
            for k,(v,w) in enumerate(zip(got,want)):result.extend(differences(v,w,path+'/'+str(k)))
    elif not compare_number(got,want):result.append((path,str(got),str(want)))
    return result

def target_checks(rows,entry):
    outcomes=[]
    for years in [5,10]:
        for family in ['bounded','expanded']:
            candidates=[x for x in rows if x['years']==years and x['kind'] in ('reverse_'+family,'refine_'+family)]
            funded=[x for x in candidates if x['irr'] is not None]
            best=max(funded,key=lambda x:x['irr']) if funded else None
            for goal in ['hurdle12','hurdle15','hurdle18','5x','10x']:
                passed=[x for x in funded if (x['irr']>=D(goal[-2:])/100 if goal.startswith('hurdle') else x['terminal_price']>=entry*int(goal[:-1]))]
                first=min(passed,key=lambda x:D(x['volume_growth'])) if passed else None
                outcomes.append({'years':years,'family':family,'target':goal,'status':'First tested funded crossing, not exact continuous solution' if first else 'No supported crossing in retained conditional grid','first_growth':first['volume_growth'] if first else None,'path':first['path_id'] if first else None,'sales':first['terminal_sales'] if first else None,'new_equity':first['equity_gross'] if first else None,'capex':first['total_capex'] if first else None,'best_funded_path':best['path_id'] if best else None,'best_funded_irr':best['irr'] if best else None,'source_eligible':False})
    return outcomes

def derive_metrics(financial,market):
    history=[];tax=dec(financial['normalization']['tax_rate']);previous=None
    excluded={'source_id','pages','scope','unit','audit_status'}
    for raw in financial['financial_years']:
        r={k:dec(v)/100 if isinstance(v,str) and k not in excluded else v for k,v in raw.items()}
        debt=r['debt_long']+r['debt_short'];ebit=r['pbt']+r['finance']-r['other_income'];ebitda=ebit+r['da'];onwc=r['ar']+r['inventory']-r['ap'];funding=r['equity']+debt-r['cash']-r['investments'];core=onwc+r['ppe']+r['cwip']
        r.update(core_ebit=ebit,core_ebitda=ebitda,nopat=ebit*(1-tax),normalized_pat=(ebit-r['finance'])*(1-tax),debt=debt,net_debt_march=debt-r['cash'],reported_fcf_proxy=None if r['year']==2021 else r['cfo']-r['capex_cash_net'],basic_onwc=onwc,core_ic=core,funding_ic_proxy=funding,ic_definition_gap=funding-core,ebitda_margin=ebitda/r['revenue'],pat_margin=r['pat_total']/r['revenue'],interest_coverage=ebit/r['finance'],net_debt_ebitda=(debt-r['cash'])/ebitda if ebitda>0 else None,cost_proxy=r['revenue']-ebitda)
        if previous:
            r.update(revenue_addition=r['revenue']-previous['revenue'],yoy=r['revenue']/previous['revenue']-1,avg_ar_days=(r['ar']+previous['ar'])/2/r['revenue']*365,inventory_days_cost_proxy=(r['inventory']+previous['inventory'])/2/r['cost_proxy']*365,payable_days_cost_proxy=(r['ap']+previous['ap'])/2/r['cost_proxy']*365,roic_core=r['nopat']/((core+previous['core_ic'])/2),roce_funding=ebit/((funding+previous['funding_ic_proxy'])/2),roe=r['pat_owners']/((r['equity']+previous['equity'])/2))
            r['ccc_proxy']=r['avg_ar_days']+r['inventory_days_cost_proxy']-r['payable_days_cost_proxy']
        history.append(r);previous=r
    cagr=[];conversion=[];incremental=[]
    for n in [3,5]:
        start,end=history[-n-1],history[-1];period=history[-n:]
        cagr.append({'years':n,'start_year':start['year'],'end_year':end['year'],'start':start['revenue'],'end':end['revenue'],'cagr':(end['revenue']/start['revenue'])**(ONE/n)-1})
        cfo=sum(x['cfo'] for x in period);pat=sum(x['pat_total'] for x in period);after=cfo-sum(x['finance'] for x in period)
        conversion.append({'years':n,'cfo':cfo,'pat':pat,'ratio':cfo/pat,'after_finance_cfo':after,'after_finance_ratio':after/pat})
        capital=end['funding_ic_proxy']-start['funding_ic_proxy'];income=end['nopat']-start['nopat'];capex=sum(x['capex_cash_net'] for x in period);da=sum(x['da'] for x in period);wc=end['basic_onwc']-start['basic_onwc'];reinvestment=capex-da+wc
        incremental.append({'years':n,'from':start['year'],'to':end['year'],'delta_nopat':income,'delta_funding_ic':capital,'observed_proxy':income/capital if capital>0 else None,'reported_capex':capex,'da':da,'delta_core_onwc':wc,'identified_net_reinvestment':reinvestment,'residual_vs_funding_ic':capital-reinvestment})
    liquidity=[];sessions=[]
    for session in market['sessions']:
        regular=[x for x in session['rows'] if x['SctySrs']=='SM']
        sessions.append(None if not regular else sum(dec(x['TtlTrfVal']) for x in regular))
    for n in [20,60]:
        observed=[x for x in sessions[-n:] if x is not None];ordered=sorted(observed);count=len(ordered);median=ordered[count//2] if count%2 else (ordered[count//2-1]+ordered[count//2])/2;mean=sum(observed)/count;capacity=min(mean,median)
        liquidity.append({'sessions':n,'observed':count,'missing':n-count,'zero_trade_rows':sum(x==0 for x in observed),'mean_inr':mean,'median_inr':median,'capacity_basis_inr':capacity,'liquidation_days':{str(rate):D(500000)/(rate*capacity) if capacity>0 else None for rate in map(D,['.02','.05','.10'])}})
    latest=history[-1];last=[x for x in market['sessions'][-1]['rows'] if x['SctySrs']=='SM'][0];price=dec(last['ClsPric']);shares=financial['shares']['oct20_issued'];cap=price*shares/CRORE;ev=cap+latest['debt']-latest['cash'];lot=int(last['NewBrdLotQty']);lotvalue=price*lot;lots=int(D(500000)//lotvalue)
    multiples={'price':price,'price_date':last['TradDt'],'issued_shares':shares,'market_cap':cap,'march_debt':latest['debt'],'march_cash':latest['cash'],'ev_march_bridge':ev,'pe_reported_current_shares':cap/latest['pat_owners'],'pe_normalized':cap/latest['normalized_pat'] if latest['normalized_pat']>0 else None,'ev_ebitda_core':ev/latest['core_ebitda'],'pb_march':cap/latest['equity'],'fcf_yield_reported':latest['reported_fcf_proxy']/cap,'all_warrant_proceeds_retained_ev_sensitivity':ev-D('29.82')}
    execution={'lot':lot,'lot_value_inr':lotvalue,'budget_lots':lots,'budget_shares':lots*lot,'budget_spend_inr':lots*lotvalue,'next_lot_spend_inr':(lots+1)*lotvalue,'one_lot_days_at_5pct':lotvalue/(D('.05')*liquidity[-1]['capacity_basis_inr'])}
    return {'history':history,'cagr':cagr,'cash_conversion':conversion,'incremental_returns':incremental,'liquidity':liquidity,'multiples':multiples,'execution':execution}

def derive_scores(judgments):
    from decimal import ROUND_HALF_UP
    weights={'BQS':{'GOV':'.20','MOAT':'.20','REV':'.12','DUR':'.10','CAP':'.12','CASH':'.10','BAL':'.08','EXEC':'.08'},'GQS':{'REV':'.40','DUR':'.20','EARN':'.15','CAP':'.15','CASH':'.10'},'IAS':{'BQS':'.25','R':'.35','D':'.20','P':'.10','L':'.10'}}
    factors=judgments['factors'];assert len(factors)==13
    result={}
    for name,w in weights.items():
        assert sum(map(D,w.values()))==1
        contributions={};missing=ZERO;known=ZERO
        for factor,weight in w.items():
            score=result['BQS']['final'] if factor=='BQS' else factors[factor]['score']
            if score is None:missing+=D(weight);contributions[factor]=None
            else:contributions[factor]=dec(score)*D(weight);known+=contributions[factor]
        raw=known if missing==0 else None;cap=None
        gov=factors['GOV']['score']
        if (gov is not None and gov<=3 or judgments['gates']['G1']['status']=='Fail — evidenced') and name in ['BQS','IAS']:cap=D(3)
        if name=='IAS' and judgments['gates']['G3']['status']=='Fail — evidenced':cap=D(3)
        if name=='GQS' and judgments['persistent_growth_override']:cap=D(5)
        final=raw if raw is None or cap is None else min(raw,cap)
        if name=='IAS' and any(judgments['gates'][key]['status'].startswith(('Hold','Fail')) for key in ['G2','G4']):final=None
        bounds=[known+missing,known+10*missing]
        result[name]={'weights':w,'contributions':contributions,'coverage':ONE-missing,'known_contribution':known,'raw':raw,'final':final,'display':'NS' if final is None else str(final.quantize(D('.1'),rounding=ROUND_HALF_UP)),'mathematical_bound':bounds,'cap':cap,'capped_bound':[min(x,cap) for x in bounds] if cap else bounds,'ranking_eligible':final is not None and not judgments['gates']['G2']['status'].startswith(('Hold','Fail'))}
    if result['BQS']['final'] is None:
        unknown=sum(D(weight) for factor,weight in weights['IAS'].items() if factor!='BQS' and factors[factor]['score'] is None)
        result['IAS']['dependency_aware_bound']=[result['IAS']['known_contribution']+D('.25')*result['BQS']['capped_bound'][0]+unknown,result['IAS']['known_contribution']+D('.25')*result['BQS']['capped_bound'][1]+10*unknown]
    else:result['IAS']['dependency_aware_bound']=result['IAS']['mathematical_bound']
    return {'composites':result}

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--inputs',default='.');ap.add_argument('--output',default='independent_replay_check.json');ap.add_argument('--compare',action='store_true');ap.add_argument('--trace',help='Optional gzip JSONL trace path generated entirely from inputs');args=ap.parse_args()
    p=Path(args.inputs);inputs=json.loads((p/'model_inputs.json').read_text());specs=json.loads((p/'scenario_inputs.json').read_text())['specifications']
    # Producer output is opened only for optional comparison, never to initialize calculations.
    reference=json.load(gzip.open(p/'canonical_paths.json.gz','rt')) if args.compare else None
    rows=[];summaries=[];mismatches=[];checked_fields=0;trace=io.TextIOWrapper(gzip.GzipFile(filename='',fileobj=open(args.trace,'wb'),mode='wb',mtime=0),encoding='utf-8') if args.trace else None
    for r in specs:
        independent=cash_path(inputs,r['spec'],r['years']);monthly=independent['monthly'];summary=independent['summary'];summary.update(path_id=r['path_id'],kind=r['kind']);summaries.append(summary)
        authorization=r['spec']['expanded_authorized_shares'] if r['spec']['equity_authorization_gate'] else inputs['authorized_shares']
        for row in monthly:
            assert type(row['shares_close']) is int and row['shares_close']<=authorization
            assert row['new_shares']>=0 and row['units_sold']<=row['capacity_tonnes']/12
            assert row['restricted_deposits_close']>=0 and row['long_advances_close']>=0
            assert abs(row['cash_close']-(row['cash_before_new_finance']+row['debt_draw']-row['debt_draw_fee']+row['equity_gross']-row['equity_fee']))<D('1e-18')
            if row['month']>12*r['years']:assert row['new_shares']==0 and row['debt_draw']==0
        if independent['failure']:
            assert independent['terminal'] is None
            assert all(summary[k] is None for k in ['terminal_price','irr','hurdle_entries','terminal_sales'])
        if reference is not None:
            expected=reference[r['path_id']]
            for field in ['monthly','annual','terminal','terminal_attempt','summary']:
                mismatches.extend(differences(independent[field],expected[field],r['path_id']+'/'+field))
            if independent['failure'] is None:
                if expected['failure'] is not None:mismatches.append((r['path_id']+'/failure',None,expected['failure']))
            else:mismatches.extend(differences(independent['failure'],expected['failure'],r['path_id']+'/failure'))
            assert expected['source_eligible'] is False
        checked_fields+=sum(len(x) for x in monthly)
        payload=json.dumps(primitive(monthly),sort_keys=True,separators=(',',':')).encode()
        rows.append({'path_id':r['path_id'],'months':len(monthly),'failure':independent['failure'],'terminal_funded':independent['terminal'] is not None,'monthly_independent_sha256':hashlib.sha256(payload).hexdigest()})
        if trace:
            clean={k:independent[k] for k in ['monthly','annual','failure','terminal','terminal_attempt','summary']};clean['path_id']=r['path_id'];trace.write(json.dumps(primitive(clean),sort_keys=True,separators=(',',':'))+'\n')
    if trace:trace.close()
    targets=target_checks(summaries,dec(inputs['entry_price']))
    metrics=derive_metrics(json.loads((p/'financial_inputs.json').read_text()),json.loads((p/'market_inputs.json').read_text()))
    scores=derive_scores(json.loads((p/'judgments.json').read_text()))
    if args.compare:
        if (p/'metrics.json').exists():mismatches.extend(differences(metrics,json.loads((p/'metrics.json').read_text()),'metrics'))
        for filename in ['scores.json','scorecard.json']:
            if (p/filename).exists():mismatches.extend(differences(scores,json.loads((p/filename).read_text()),'scores'));break
        model_summary=json.loads((p/'model_summary.json').read_text());mismatches.extend(differences(targets,model_summary['targets'],'targets'))
        mismatches.extend(differences({'path_count':len(rows),'failed':sum(x['failure'] is not None for x in rows)},model_summary,'model_summary'))
    result={'method':'Independent Decimal event derivation from declared input JSON only. No producer model/scenario module import. Complete operating and twelve-month terminal cohort/capacity/claims replay, earned FCFF, retained operating reserve, all hurdle and multibagger targets.','path_count':len(rows),'monthly_rows':sum(r['months'] for r in rows),'monthly_fields_rederived':checked_fields,'failed_paths':sum(r['failure'] is not None for r in rows),'paths':rows,'targets':targets,'independent_metrics':metrics,'independent_scores':scores,'comparison_requested':args.compare,'mismatches':mismatches,'tolerance':'1e-18 relative for Decimal recomputation; discrete shares/dates/states exact','status':'PASS' if not mismatches else 'MISMATCH'}
    Path(args.output).write_text(json.dumps(primitive(result),indent=2));print(json.dumps({k:v for k,v in result.items() if k not in ['paths','targets','mismatches','independent_metrics','independent_scores']}));print(json.dumps(mismatches[:8]))
if __name__=='__main__':main()
