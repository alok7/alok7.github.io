# Sheetal Universal Limited SME research 364

Information cutoff: 20 October 2026. Market close: 19 October 2026, ₹375.05. Original metadata “Sheetal Univer.”, SHEETAL and INE04VX01019 are preserved separately from the verified legal issuer. Framework v3.0; GQS means Growth Quality Score.

Read report.html or report.md. BQS, GQS and IAS remain NS because critical evidence is unresolved. This is a completed evidence-led research record, not an eligible investment recommendation, a finding of fraud/default, or permission to publish.

Run Python3 build.py, then verify.py. Runtime inputs are declared in build.INPUTS. Every monthly scenario and refinement is retained in canonical_paths.json.gz, including failed paths. scenario_inputs.json contains each scenario as data for independent replay. Prior methodology iterations are retained as explicit superseded versions. The current model separates cash-paid CWIP from commissioned productive assets and tests terminal reinvestment and financing.

For cold recovery, extract declared inputs only into a new empty directory and run guarded_rebuild.py --fresh. No existing outputs or attestations are to be reused. The guard constrains file access cooperatively; it is not an OS sandbox. The build and independent verifier must regenerate outputs offline. Original public PDFs, OCR, private helper code and secrets are not runtime dependencies and are not included in the source-safe archives. Exact primary URLs, dates, pages and hashes are retained.

The full and compact ZIPs contain the same authored inputs, outputs and reproduction attestations. Their compression differs, not their evidentiary content. Fresh current-version recovery and review are separate from local machine PASS. No Git, public-page, prior Library or batch-manifest mutation is implied.
