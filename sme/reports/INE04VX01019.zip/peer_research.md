# Sheetal Universal: economic peer comparison

Information cutoff: 20 October 2026. These are business comparators, not a scored investment universe or a peer-multiple valuation. Figures are FY2026, ₹ crore; reported group PAT for consolidated comparators.

Use the closest ingredient processor, a bulk exporter, a trading downside comparator and a stronger integrated benchmark. Sheetal’s 2023 statement that it had no listed peers does not preclude economic comparisons, including Shreeji, listed in November 2025.

Revenue and reported PAT use the disclosed scopes. Product mix and other income limit cross-peer comparison. No current P/E median, peer quality score or target multiple has been fabricated.

## Shreeji Global FMCG Limited

Closest processing/trading and SME comparator. Standalone revenue: ₹766.40 crore; PAT: ₹19.92 crore; reported PAT margin: 2.60%.

- Shared economics: Gujarat processing and trading of whole/ground spices, seeds/oilseeds, pulses/grains and atta, under SHETHJI and white-label institutional channels.
- Important differences: More domestically focused, broader spice/grain portfolio and larger scale; not a peanut powder pure play.
- What the comparison adds: A brand or processing label is not proof of high margins. Inventories of ₹98.59 crore versus ₹48.51 crore and receivables of ₹83.58 crore versus ₹51.47 crore illustrate substantial working-capital reinvestment alongside 18.10% revenue growth.
- Limitations: The MDA uses closing inventory as a product-performance proxy, not product revenue. Its borrowing narrative says reduced despite ₹30.45 crore increasing to ₹45.47 crore. Use underlying figures. FY2025 PAT in the FY2026 comparison differs from the restated IPO figure; do not silently mix them.

Source: [Shreeji_FY26.pdf](https://nsearchives.nseindia.com/annual_reports/SME_AR_31887_SHETHJI_2025_2026_A_16442392_08092026172713.pdf). 2026-09-08. PDF pp59–66 business / MDA,105 P&L,106 sales geography. SHA-256: f7f939f1ae53498166a90522edf80ee7d24089b808f0c6fa50842397984a4fc4.

## NHC Foods Limited

Bulk agri-export/trading comparator; diversification-risk example. Consolidated revenue: ₹601.31 crore; PAT: ₹12.32 crore; reported PAT margin: 2.05%.

- Shared economics: Whole/ground spices, oilseeds, grains and pulses exporter with processing and overseas channels.
- Important differences: Consolidation now includes international trading, a March 2026 Hong Kong acquisition trading metals/steel/agro products, and diversification into beverages and packaged water.
- What the comparison adds: FY2026 revenue of ₹601.31 crore produced ₹12.32 crore group PAT, a 2.05% margin. Commodity turnover growth can greatly exceed value captured.
- Limitations: The FY2026 report’s prior-year ownership-allocation line conflicts with group PAT; its narrative reverses standalone PAT years. Use group PAT, not an unsupported owner-EPS bridge. This is not a clean valuation clone.

Source: [NHC_FY26.pdf](https://nhcgroup.com/legacy-assets/data/investors/34th%20Annual%20General%20Meeting/Annual%20Report%20FY%2025-26.pdf). 2026-09-01 (AGM notice); audited accounts dated 2026-05-21. PDF pp72–73/printed70–71 MDA; PDF137/printed135 consolidated P&L. SHA-256: dd3c16739ed36f46469560f07db9e49129ad59baaf60ba2a29274fab1fb6974e.

## Sakuma Exports Limited

Weaker current profitability / bulk commodity trading downside comparator. Consolidated revenue: ₹1708.28 crore; PAT: ₹9.51 crore; reported PAT margin: 0.56%.

- Shared economics: Bulk agricultural procurement, imports/exports, logistics and working-capital economics.
- Important differences: Trading-led, broader commodity/geographic mix and much larger turnover; not a new protein/flavoured-nut manufacturer.
- What the comparison adds: Revenue declined from ₹2,289.55 crore to ₹1,708.28 crore in FY2026 and group PAT from ₹14.79 crore to ₹9.51 crore. Profit includes ₹9.17 crore other income, demonstrating a thin-spread and volatile-turnover failure path.
- Limitations: Weaker describes current disclosed operating profitability, not proven governance failure or permanent business inferiority. Do not impose its P/E on Sheetal.

Source: [Sakuma_FY26.pdf](https://sakumaexportsltd.com/investors/annualreport/21st-Annual-Report-2025-2026.pdf). 2026-09-03 (exchange cover letter). PDF pp25–27 MDA; PDF126/printed123 consolidated P&L. SHA-256: ab7a2343efc4538d8de92c2cfa6c772cd6eb32f3899fbeb061232342eb6e7245.

## Gujarat Ambuja Exports Limited

Stronger scale/integration/liquidity benchmark, not direct valuation peer. Consolidated revenue: ₹5728.60 crore; PAT: ₹304.28 crore; reported PAT margin: 5.31%.

- Shared economics: Agricultural procurement and industrial processing, oils/protein/feed co-products, and domestic/export customers.
- Important differences: Maize starch/derivatives, soybean and industrial ingredients at much larger scale, multiple plants and deeper processing, alongside cotton yarn. Not a peanut-processing clone.
- What the comparison adds: FY2026 commissioning included 30,000 tpa sodium gluconate and maltodextrin capacity expanded to 23,000 tpa. Current investments of ₹850.74 crore compare with ₹433.58 crore borrowings, before leases and other adjustments. This offers a documented integration and liquidity benchmark.
- Limitations: The headline EBITDA of ₹574 crore includes other income. Under a common pre-exception operating formula, ₹408.38 + ₹27.51 + ₹137.73 − ₹107.17 = ₹466.45 crore, or 8.14% of revenue. Reported PAT margin is 5.31%. Commodity cycles and capex returns still matter.

Source: [annual-report-fy-2025-26.pdf](https://www.ambujagroup.com/documents/financials/annual-report/annual-report-fy-2025-26.pdf). 2026-08-01 (Board report); AGM 2026-09-05. PDF p4 printed4–5 highlights;PDF p11 printed18–19 processing;PDF p122 printed240–241 consolidated accounts. SHA-256: db05128cb0cfae597bf3dbb96a1bd5742aeaaa4d290ad1bd68ab84f74d8a60c5.

## Exclusions

- Branded snack FMCG businesses lacking bulk ingredient/export economics: their multiples are not transferable.
- Pure basmati rice millers: aging inventory, varietal premiums and capital cycles differ.
- Unlisted processors may compete operationally but lack comparable public valuations.
