"""Explicit source-safe archive allowlist. Does not upload or publish anything."""
from pathlib import Path
import json,hashlib,zipfile,sys
import build
P=Path(__file__).resolve().parent
EXTRAS=['producer_attestation.json','independent_replay_results.json','recovery_attestation.json','independent_review.md','independent_attestation.json','package.py','PACKAGING.md']
VERSION_FILES=['README.md','model.py','model_audit.py','scenarios.py','model_inputs.json','scenario_inputs.json','reproduce.py','retained_original_output_hashes.json','canonical_paths.json.gz','model_summary.json','model_audit.json','superseded_reproduction_attestation.json']
def sha(b):return hashlib.sha256(b).hexdigest()
def main():
 names=sorted(set(build.INPUTS+build.OUTPUTS+EXTRAS+[f'development/{v}/{n}'for v in['v1','v2_flat_terminal']for n in VERSION_FILES]))
 for n in names:
  assert (P/n).is_file(),n
  assert not any(v in n for v in['private_qa','verifier_sources','__pycache__','fetch_','seed_'])
  assert not n.endswith(('.pdf','.png','.jpg','.txt','.pyc'))
 manifest={'format':'source-safe authored research archive v1','company':'Sheetal Universal Limited','sequence':364,'file_count':len(names),'files':{n:{'sha256':sha((P/n).read_bytes()),'bytes':(P/n).stat().st_size}for n in names},'policy':'No original PDFs, OCR, screenshots, private source locators, private transfer helpers, credentials or unpublished personal data. Exact source URLs/hashes and authored reproducibility inputs/code/outputs retained. Compact/full entries are identical; only ZIP compression differs.'}
 (P/'archive_manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,sort_keys=True,indent=2)+'\n');allnames=names+['archive_manifest.json'];out=[]
 for kind,method in[('compact',zipfile.ZIP_DEFLATED),('full',zipfile.ZIP_STORED)]:
  path=P/f'SME_364_Sheetal_Universal_20261020_source_safe_{kind}.zip'
  with zipfile.ZipFile(path,'w',compression=method,compresslevel=9 if method==zipfile.ZIP_DEFLATED else None)as z:
   for n in sorted(allnames):
    info=zipfile.ZipInfo('sheetal_universal/'+n,(2026,10,20,0,0,0));info.compress_type=method;info.external_attr=0o100644<<16;z.writestr(info,(P/n).read_bytes(),compresslevel=9 if method==zipfile.ZIP_DEFLATED else None)
  with zipfile.ZipFile(path)as z:
   assert z.testzip()is None
   for n in names:assert sha(z.read('sheetal_universal/'+n))==manifest['files'][n]['sha256']
  out.append({'kind':kind,'filename':path.name,'bytes':path.stat().st_size,'sha256':sha(path.read_bytes()),'entries':len(allnames)})
 # This external identity list is not placed in the ZIPs, avoiding self-hash cycles.
 (P/'archive_identities.json').write_text(json.dumps(out,sort_keys=True,indent=2)+'\n');print(json.dumps(out,indent=2))
if __name__=='__main__':main()
