# Sixteen v3.0 quality checks

1. Identity, security, scope and cutoff — Original issuer/ISIN confirmed; post-listing security and current tape limitations explicit.
2. Primary records and claim types — Final/draft/peer originals read; verified facts, management claims, calculations and assumptions separated with page locators.
3. Audit, related parties, funding and dilution — Restatement read; missing original annual/CARO/IFC creates a G2 hold, not fabricated clearance.
4. Comparable periods and units — FY23–26 annual figures converted to crore; H1FY26 not annualized; H1FY27 and TTM not available.
5. Revenue separated from profit — Three-year CAGR below5% and production/mix proxy; two-year rebound not substituted for the preselected window.
6. Cumulative cash conversion — Ratio of sums; creditor/tax sensitivities and capex versus CFO explained.
7. Incremental capital — Two-sided invested capital and investment bridge; negative denominator NM and CAP NS.
8. Valuation consistency — Post-IPO shares, fees excluding uncertain extra taxes, tagged source-restricted cash, claims and normalization explicit.
9. Scenarios and financing — Monthly event cash and physical capacity, whole-share funding, source eligibility, earned terminal continuation and failed-return suppression.
10. Canonical factor weights — Thirteen factors reused; exact weights sum to100% in each aggregate.
11. Missingness and confidence — BQS/GQS/IAS NS; original-weight coverage, bounds and weakest material confidence retained.
12. Raw/final scores and overrides — No unsupported extra haircut or cap; NS remains NS.
13. Classification and compounder criteria — Hold overrides the score matrix; compounder evidence criteria not satisfied.
14. Liquidity and position size — Illustrative5-lakh reference with whole lots;60-session history NA and official turnover ND;403 is not zero.
15. Bear case and falsification — Linked credit/margin/capex/callable-loan/legal risks and conditional asset recovery; avoidable source-allocation failures distinguished.
16. Ranking and batch boundary — v3.0 tie policy; incomplete evidence does not receive a bottom rank; no Git or manifest changes.

Addressed includes an explicitly disclosed unresolved gap. This is not a claim that all underlying evidence was retrieved.
