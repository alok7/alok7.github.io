"""Independent Sham Foam input-to-ledger verifier (standard library only).

No producer imports or execution. Reconstructs demand, paid capacity, cost and
working-capital schedules, cohort depreciation, ring-fenced funding, every cash
and financing event, continuation, terminal bridges and shareholder returns.

Usage: python model_audit.py ROOT TRACE[.gz] [REPORT.json] [--no-mutations]
REPORT is optional; without it the report is printed and no file is written.
The compressed trace is read one path at a time. Mutations are in memory only.
"""
from copy import deepcopy
from datetime import date
from decimal import Decimal as D, getcontext, ROUND_CEILING, ROUND_FLOOR
import argparse
import gzip
import hashlib
import json
from pathlib import Path

getcontext().prec = 44
ZERO, ONE, CRORE = D(0), D(1), D(10000000)
TOLERANCE, FAILURE_EPSILON = D('1e-20'), D('1e-24')
checks = 0


class AuditError(AssertionError):
    """A source input, serialized ledger, or reported result is inconsistent."""


def verify(condition, context):
    global checks
    checks += 1
    if not condition:
        raise AuditError(context)


def equal(actual, expected, context):
    global checks
    checks += 1
    if isinstance(expected, bool) or expected is None or isinstance(expected, str):
        ok = type(actual) is type(expected) and actual == expected
    elif isinstance(expected, (D, int)):
        try:
            ok = not isinstance(actual, bool) and actual is not None and abs(D(str(actual)) - D(expected)) <= TOLERANCE
        except Exception:
            ok = False
    else:
        ok = actual == expected
    if not ok:
        raise AuditError(f'{context}: got {actual!r}; expected {expected!r}')


def fields(actual, expected, context):
    verify(isinstance(actual, dict), context + ': expected mapping')
    for key, value in expected.items():
        verify(key in actual, context + ': missing ' + key)
        if isinstance(value, dict):
            fields(actual[key], value, context + '/' + key)
        elif isinstance(value, list):
            verify(isinstance(actual[key], list) and len(actual[key]) == len(value), context + '/' + key + ': list length')
            for index, item in enumerate(value):
                if isinstance(item, dict):
                    fields(actual[key][index], item, f'{context}/{key}/{index}')
                else:
                    equal(actual[key][index], item, f'{context}/{key}/{index}')
        else:
            equal(actual[key], value, context + '/' + key)


def decimals(mapping):
    return {key: D(str(value)) for key, value in mapping.items()}


def net_working_capital(state):
    return state['AR'] + state['inventory'] + state['other_CA'] - state['TP'] - state['other_CL']


def audit_irr(cashflows):
    """Solve discounted-cash polynomial in monthly discount factor, not rate.

    This intentionally uses different arithmetic/solver structure from producer.
    Bracket reproduces its documented annual -99.9% through 1000% range.
    """
    low = D(11) ** (-ONE / 12)
    high = D('.001') ** (-ONE / 12)

    def polynomial(factor):
        value = ZERO
        for amount in reversed(cashflows):
            value = value * factor + amount
        return value

    if polynomial(low) * polynomial(high) > 0:
        return None
    for _ in range(175):
        middle = (low + high) / 2
        if polynomial(middle) > 0:
            high = middle
        else:
            low = middle
    return ((low + high) / 2) ** -12 - ONE


def canonical_configurations(inputs):
    """Derive the named experiment inventory independently from public inputs."""
    configs = {}

    def register(name, scenario='base', mode='equity', years=5, overrides=None):
        configs[name] = {'scenario': scenario, 'funding_mode': mode, 'years': years,
                         'overrides': overrides or {}}

    for scenario in ('bear', 'base', 'bull'):
        for mode in ('none', 'bank', 'equity'):
            register(scenario + '_' + mode, scenario, mode)
    stress = {
        'collections': {'AR_days': '150'}, 'supplier_credit': {'TP_days': '30'},
        'capex_delay': {'commission_month': '19', 'capex_months': '12', 'capex_overrun': '.30'},
        'margin': {'COGS_ratio': '.84'}, 'promoter_call': {'promoter_repayment_month': '1'},
        'legal': {'legal_payment': '2.50', 'legal_month': '1'},
        'cash_unavailable': {'opening_cash_fraction': '.5', 'ipo_available_fraction': '.5'},
        'tax': {'tax': '.26'},
        'combined': {'AR_days': '150', 'TP_days': '30', 'COGS_ratio': '.84',
                     'promoter_repayment_month': '1', 'legal_payment': '2.50', 'capex_overrun': '.30'},
        'terminal_capital': {'terminal_extra_capital': '20'},
        'terminal_margin': {'terminal_margin_haircut': '.08'},
        'terminal_demand': {'terminal_revenue_factor': '.70'},
        'distribution': {'dividend_payout': '.50'},
        'no_postexit_bank': {'post_exit_bank_allowed': '0'},
        'FD_free_sensitivity': {'FD_access': '1'}}
    for label, overrides in stress.items():
        register('stress_' + label, overrides=overrides)
    register('stress_borrowing_base_collapse', scenario='bear',
             overrides={'terminal_revenue_factor': '.10'})
    register('stress_internal_first', overrides={'ordinary_internal_first': '1'})
    register('stress_IPO_fee_tax', overrides={'extra_issue_fee_tax': '.98586'})
    register('stress_legal_provenance',
             overrides={'opening_cash_fraction': '.01', 'legal_payment': '1', 'legal_month': '0'})
    for growth in ('.02', '.06', '.10', '.15', '.20'):
        for multiple in ('6', '9', '12'):
            register('grid_g' + growth + '_m' + multiple,
                     overrides={'volume_growth': growth, 'terminal_multiple': multiple})
    for wacc in ('.12', '.16', '.20'):
        for growth in ('.02', '.04', '.06'):
            register('DCF_w' + wacc + '_g' + growth,
                     overrides={'WACC': wacc, 'terminal_growth': growth})
    for growth in ('0', '.05', '.10', '.15', '.20', '.25', '.30', '.40', '.50'):
        register('reverse_g' + growth, overrides={'volume_growth': growth})
    for scenario in ('bear', 'base', 'bull'):
        register(scenario + '_10year', scenario, years=10)
    for years in (5, 10):
        for target in (5, 10):
            for multiple in ('6', '9'):
                required_revenue = D(inputs['entry_price']) * target * inputs['shares'] / CRORE / D(multiple) / D('.12')
                growth = (required_revenue / D(inputs['opening']['revenue'])) ** (ONE / years) - ONE
                register(f'target_{target}x_{years}y_m{multiple}', years=years,
                         overrides={'year1_volume_growth': growth, 'volume_growth': growth,
                                    'price_growth': ZERO, 'terminal_multiple': D(multiple)})
    return configs


def check_path_configuration(summary, inputs):
    name = summary['path_id']
    expected = canonical_configurations(inputs).get(name)
    if name.startswith('hurdle_'):
        expected = {'scenario': 'base', 'funding_mode': 'equity', 'years': 5, 'overrides': {}}
    if expected is None:
        return  # Additional explicitly named experiments may be added by caller.
    for key in ('scenario', 'funding_mode', 'years'):
        equal(summary[key], expected[key], name + '/configuration/' + key)
    verify(set(summary['overrides']) == set(expected['overrides']), name + ': override key set')
    for key, value in expected['overrides'].items():
        equal(summary['overrides'][key], D(str(value)), name + '/configuration/override/' + key)
    if not name.startswith('hurdle_'):
        equal(summary['entry_price'], D(inputs['entry_price']), name + '/configuration/entry')


def check_inventory(summaries, inputs):
    required = set(canonical_configurations(inputs))
    verify(required <= set(summaries), 'Missing canonical paths: ' + ', '.join(sorted(required - set(summaries))))
    for hurdle in ('.12', '.15', '.18'):
        prefix = 'hurdle_' + hurdle + '_iter'
        iterations = sorted(int(name[len(prefix):]) for name in summaries if name.startswith(prefix))
        base = summaries['base_equity']
        if base['failed']:
            verify(not iterations, prefix + ': failed base must not yield ordinary hurdle iteration')
            continue
        verify(bool(iterations), prefix + ': missing hurdle solve')
        verify(iterations == list(range(len(iterations))) and len(iterations) <= 12, prefix + ': noncontiguous iterations')
        expected_entry = base['hurdle_entry_prices'][str(D(hurdle))]
        for index in iterations:
            summary = summaries[prefix + str(index)]
            equal(summary['entry_price'], D(expected_entry), prefix + str(index) + ': fixed-point entry')
            expected_entry = summary['hurdle_entry_prices'][str(D(hurdle))]
            if expected_entry is None:
                verify(index == iterations[-1], prefix + ': continuing an infeasible iteration')
        final = summaries[prefix + str(iterations[-1])]
        if not final['failed'] and len(iterations) < 12:
            verify(abs(D(final['entry_price']) - D(final['hurdle_entry_prices'][str(D(hurdle))])) < D('1e-16'), prefix + ': premature fixed-point stop')
            verify(abs(D(final['IRR']) - D(hurdle)) < D('1e-14'), prefix + ': hurdle IRR does not attain target')
    return len(required)


def audit(path, inputs):
    summary = path['summary']
    check_path_configuration(summary, inputs)
    path_id = summary['path_id']
    years = int(summary['years'])
    horizon = 12 * years
    scenario, mode = summary['scenario'], summary['funding_mode']
    verify(scenario in inputs['scenarios'], path_id + ': unknown scenario')
    verify(mode in ('none', 'bank', 'equity'), path_id + ': unknown funding mode')
    verify(years > 0, path_id + ': nonpositive horizon')
    assumptions = decimals({**inputs['common'], **inputs['scenarios'][scenario], **summary['overrides']})
    funding, opening = decimals(inputs['funding']), decimals(inputs['opening'])
    verify(opening['project_internal_capex'] >= 0, path_id + ': negative internal project contribution')
    equal(D(inputs['common']['new_capacity_cost_per_tonne']),
          (opening['ipo_capex'] + opening['project_internal_capex']) / opening['committed_tonne_capacity'],
          path_id + ': full project cost per commissioned tonne')
    tax_rate = D(str(summary['overrides'].get('tax', inputs['tax'])))
    entry = D(str(summary['entry_price']))
    verify(entry > 0, path_id + ': nonpositive entry')
    verify(assumptions['WACC'] > assumptions['terminal_growth'], path_id + ': invalid DCF denominator')
    verify(assumptions['terminal_CAP'] > 0, path_id + ': invalid incremental return')
    verify(len(path['monthly']) == horizon and len(path['continuation_monthly']) == 12, path_id + ': monthly trace length')
    valuation_date = date.fromisoformat(inputs['valuation_date'])

    def event_date(month):
        serial = valuation_date.year * 12 + valuation_date.month - 1 + month
        return date(serial // 12, serial % 12 + 1, valuation_date.day).isoformat()

    state = opening.copy()
    state['cash'] = opening['cash'] * assumptions['opening_cash_fraction'] + opening['ipo_general'] * assumptions['ipo_available_fraction'] + opening['FD'] * assumptions['FD_access']
    state['FD'] = opening['FD'] * (ONE - assumptions['FD_access'])
    source_keys = ('cash_internal', 'cash_ipo_general', 'cash_financing', 'cash_restricted_transient')
    state.update({'cash_internal': opening['cash'] * assumptions['opening_cash_fraction'] + opening['FD'] * assumptions['FD_access'],
                  'cash_ipo_general': opening['ipo_general'] * assumptions['ipo_available_fraction'],
                  'cash_financing': ZERO, 'cash_restricted_transient': ZERO})
    pending_restricted_label = None
    for key in ('ipo_capex', 'ipo_working'):
        state[key] *= assumptions['ipo_available_fraction']
    shares = int(inputs['shares'])
    equity_gross = bank_draws = equity_fees = bank_fees = ZERO
    minimum_cash = initial_cash = state['cash']
    initial_pools = state['ipo_capex'] + state['ipo_working']
    reserve = initial_reserve = max(assumptions['minimum_cash'], opening['revenue'] * assumptions['reserve_sales'])
    events = path['events'] + path['continuation_events']
    event_index = month = 0
    monthly_fees = ZERO
    failures, reconstructed, pipeline = [], [], []
    reconstructed_events = []
    physical_basis = state['PPE']
    # Each fixed-basis cohort is (first depreciation month, basis, full life).
    # Producer uses rolling net-book-value/remaining-life; this uses original
    # cost and age, an independent straight-line reconstruction.
    cohorts = [(1, state['PPE'], int(assumptions['opening_remaining_life_months']))]
    collateral = {key: state[key] for key in ('AR', 'inventory')}
    borrowing_base_excesses = []

    def failure(reason, shortfall=ZERO, kind='cash'):
        failures.append({'month': month, 'date': event_date(month), 'kind': kind,
                         'reason': reason, 'shortfall': shortfall,
                         'cash': state['cash'], 'reserve': reserve})

    def cash_event(label, amount, kind, details=None):
        nonlocal event_index, minimum_cash, pending_restricted_label
        verify(event_index < len(events), f'{path_id}/{month}: missing event {label}')
        before = state['cash']
        sources_before = {key: state[key] for key in source_keys}
        equal(sum(sources_before.values(), ZERO), before, path_id + ': opening provenance sums to cash')
        internal_required = source_shortfall = overrun_component = overrun_shortfall = ZERO
        source_kind = None
        internal_labels = {'legal_stress_settlement': 'legal_funding',
                           'promoter_demand_repayment': 'promoter_funding',
                           'dividend': 'distribution_funding'}
        if amount >= 0:
            source = ('cash_restricted_transient' if kind == 'restricted_release'
                      else 'cash_financing' if label == 'conditional_financing' else 'cash_internal')
            state[source] += amount
            if kind == 'restricted_release':
                verify(pending_restricted_label is None, path_id + ': unmatched restricted release')
                pending_restricted_label = details['for_label']
        else:
            expense = -amount
            if label in internal_labels:
                internal_required, source_kind = expense, internal_labels[label]
            elif label == 'committed_project_capex':
                internal_required = opening['project_internal_capex'] / assumptions['capex_months']
                source_kind = 'project_internal_funding'
                overrun_component = (opening['ipo_capex'] + opening['project_internal_capex']) * assumptions['capex_overrun'] / assumptions['capex_months']
            source_shortfall = max(ZERO, internal_required - max(ZERO, state['cash_internal']))
            state['cash_internal'] -= internal_required
            # The prospectus separately restricts overruns to GCP/internal cash.
            # Borrowings, new equity and paired project releases cannot cure it.
            overrun_left = overrun_component
            overrun_shortfall = max(ZERO, overrun_component - max(ZERO, state['cash_ipo_general']) - max(ZERO, state['cash_internal']))
            overrun_priority = ('cash_internal', 'cash_ipo_general') if assumptions['ordinary_internal_first'] > 0 else ('cash_ipo_general', 'cash_internal')
            for key in overrun_priority:
                allocation = min(overrun_left, max(ZERO, state[key]))
                state[key] -= allocation
                overrun_left -= allocation
            state['cash_internal'] -= overrun_left
            unallocated = expense - internal_required - overrun_component
            verify(unallocated >= -TOLERANCE, path_id + ': source-required debit exceeds invoice')
            if label == 'IPO_extra_fee_tax':
                priority = ('cash_ipo_general', 'cash_internal', 'cash_financing', 'cash_restricted_transient')
            elif assumptions['ordinary_internal_first'] > 0:
                priority = ('cash_restricted_transient', 'cash_internal', 'cash_ipo_general', 'cash_financing')
            else:
                priority = ('cash_restricted_transient', 'cash_ipo_general', 'cash_financing', 'cash_internal')
            if state['cash_restricted_transient'] > FAILURE_EPSILON:
                equal(label, pending_restricted_label, path_id + ': restricted funds used by wrong expense')
            # Waterfall uses only positive eligible source balances; no IPO or
            # financing transfer is permitted to erase a mandatory internal deficit.
            for key in priority:
                allocation = min(unallocated, max(ZERO, state[key]))
                state[key] -= allocation
                unallocated -= allocation
            state['cash_internal'] -= unallocated
            if pending_restricted_label == label:
                equal(state['cash_restricted_transient'], ZERO, path_id + ': paired release not fully spent')
                pending_restricted_label = None
        sources_after = {key: state[key] for key in source_keys}
        source_delta = {key: sources_after[key] - sources_before[key] for key in source_keys}
        state['cash'] += amount
        equal(sum(sources_after.values(), ZERO), state['cash'], path_id + ': closing provenance sums to cash')
        equal(sum(source_delta.values(), ZERO), amount, path_id + ': source delta equals event amount')
        verify(all(state[key] >= -TOLERANCE for key in source_keys if key != 'cash_internal'), path_id + ': negative restricted/financing/GCP source')
        minimum_cash = min(minimum_cash, state['cash'])
        expected = {'month': month, 'date': event_date(month), 'label': label,
                    'kind': kind, 'cash_before': before, 'amount': amount,
                    'cash_after': state['cash'], 'reserve': reserve,
                    'shares': shares, 'CC': state['CC'],
                    'bank_debt': state['bank_debt'], 'promoter_debt': state['promoter_debt'],
                    'ipo_capex': state['ipo_capex'], 'ipo_working': state['ipo_working'],
                    'provenance_before': sources_before, 'provenance_after': sources_after,
                    'provenance_delta': source_delta, 'internal_required_amount': internal_required,
                    'internal_eligibility_shortfall': source_shortfall,
                    'project_overrun_component': overrun_component,
                    'overrun_eligibility_shortfall': overrun_shortfall, **(details or {})}
        fields(events[event_index], expected, f'{path_id}/event{event_index}/{label}')
        reconstructed_events.append(expected)
        event_index += 1
        if source_shortfall > FAILURE_EPSILON:
            failure(label + ' exceeds internally eligible cash under declared source policy', source_shortfall, source_kind)
        if overrun_shortfall > FAILURE_EPSILON:
            failure(label + ' overrun exceeds eligible general-purpose and internal cash', overrun_shortfall, 'project_overrun_funding')
        if state['cash'] < reserve - FAILURE_EPSILON:
            failure(label + ' breaches operating reserve', reserve - state['cash'])

    def borrowing_base():
        return (max(ZERO, collateral['AR']) * funding['AR_eligibility'] * funding['AR_advance']
                + max(ZERO, collateral['inventory']) * funding['inventory_eligibility'] * funding['inventory_advance'])

    def payment(label, amount, kind='operating', eligible=None, interest_sensitive=False):
        nonlocal shares, equity_gross, equity_fees, bank_draws, bank_fees, monthly_fees
        restricted = extra_interest = ZERO
        if amount < 0 and eligible in ('capex', 'working'):
            key = 'ipo_' + eligible
            # Only the scheduled IPO-funded component is eligible. Internal
            # project contributions and any cost overruns use unrestricted cash.
            need = min(-amount, opening['ipo_capex'] / assumptions['capex_months']) if eligible == 'capex' else max(ZERO, reserve - state['cash'] - amount)
            restricted = min(state[key], need)
            state[key] -= restricted
            verify(state[key] >= -TOLERANCE, path_id + ': negative restricted pool')
            if restricted:
                cash_event('restricted_' + eligible + '_payment_support', restricted, 'restricted_release',
                           {'for_label': label, 'pool_release': restricted})
        needed = max(ZERO, reserve - state['cash'] - amount)
        allowed = label not in ('legal_stress_settlement', 'promoter_demand_repayment', 'dividend') and mode != 'none' and (month <= horizon or assumptions['post_exit_bank_allowed'] > 0)
        if needed > FAILURE_EPSILON and allowed:
            base = borrowing_base()
            headroom = max(ZERO, min(funding['CC_limit'], base) - state['CC'])
            denominator = ONE - funding['draw_fee'] - (assumptions['CC_rate'] / 12 if interest_sensitive else ZERO)
            verify(denominator > 0, path_id + ': invalid financing denominator')
            draw = min(headroom, needed / denominator)
            fee = draw * funding['draw_fee']
            old_cc = state['CC']
            state['CC'] += draw
            bank_draws += draw
            bank_fees += fee
            monthly_fees += fee
            if interest_sensitive:
                extra_interest = draw * assumptions['CC_rate'] / 12
            verify(draw >= 0 and draw <= headroom + TOLERANCE, path_id + ': draw outside borrowing-base headroom')
            if draw:
                verify(state['CC'] <= min(funding['CC_limit'], base) + TOLERANCE, path_id + ': drawing beyond bank limit')
            verify(state['CC'] >= old_cc - TOLERANCE, path_id + ': unexplained bank repayment')
            residual = max(ZERO, reserve - state['cash'] - amount - draw + fee + extra_interest)
            issue_price = max(funding['issue_floor'], entry * funding['issue_entry_ratio'])
            new_shares, gross, issue_fee = 0, ZERO, ZERO
            if residual > FAILURE_EPSILON and mode == 'equity' and int(funding['equity_first_month']) <= month <= horizon:
                unit = issue_price / CRORE
                gross_left = max(ZERO, funding['equity_gross_limit'] - equity_gross)
                shares_needed = int((residual / (unit * (ONE - funding['equity_fee']))).to_integral_value(rounding=ROUND_CEILING))
                cash_cap_shares = int((gross_left / unit).to_integral_value(rounding=ROUND_FLOOR))
                new_shares = min(shares_needed, cash_cap_shares, max(0, inputs['authorized_shares'] - shares))
                gross = unit * new_shares
                issue_fee = gross * funding['equity_fee']
                shares += new_shares
                equity_gross += gross
                equity_fees += issue_fee
                monthly_fees += issue_fee
            verify(isinstance(new_shares, int) and new_shares >= 0, path_id + ': fractional equity issue')
            verify(shares <= inputs['authorized_shares'], path_id + ': authorized share ceiling')
            verify(equity_gross <= funding['equity_gross_limit'] + TOLERANCE, path_id + ': equity gross ceiling')
            if draw + gross > 0:
                cash_event('conditional_financing', draw - fee + gross - issue_fee, 'financing',
                           {'bank_draw': draw, 'bank_fee': fee, 'equity_gross': gross,
                            'equity_fee': issue_fee, 'issued': new_shares, 'issue_price': issue_price,
                            'borrowing_base': base, 'collateral_AR': collateral['AR'],
                            'collateral_inventory': collateral['inventory'],
                            'authorized_shares': inputs['authorized_shares']})
        cash_event(label, amount - extra_interest, kind,
                   {'extra_draw_interest': extra_interest, 'restricted_support': restricted})
        return extra_interest

    def annual_demand(t):
        year = (max(1, min(t, horizon)) - 1) // 12
        tonnes = opening['production_tonnes'] * (ONE + assumptions['year1_volume_growth']) * (ONE + assumptions['volume_growth']) ** year
        price = opening['revenue'] / opening['production_tonnes'] * (ONE + assumptions['price_growth']) ** (year + 1)
        if t > horizon:
            tonnes *= (ONE + assumptions['terminal_growth']) * assumptions['terminal_revenue_factor']
        return tonnes, price, tonnes * price

    def total_debt():
        return state['CC'] + state['bank_debt'] + state['promoter_debt']

    def invested_capital():
        return net_working_capital(state) + state['PPE'] + state['CWIP'] + sum((p['cost'] for p in pipeline), ZERO)

    payment('opening_reserve_test', ZERO, 'reserve')
    payment('IPO_extra_fee_tax', -assumptions['extra_issue_fee_tax'], 'issue_cost')
    if int(assumptions['legal_month']) == 0:
        payment('legal_stress_settlement', -assumptions['legal_payment'], 'legacy')
    all_months = path['monthly'] + path['continuation_monthly']
    for month, observed in enumerate(all_months, 1):
        if month == horizon + 1:
            month = horizon
            annual = {key: sum((r[key] for r in reconstructed[-12:]), ZERO)
                      for key in ('revenue', 'EBITDA', 'NOPAT', 'tonnes')}
            reserve = reconstructed[-1]['reserve_close']
            collateral = {key: state[key] for key in ('AR', 'inventory')}
            payment('terminal_current_capital_catchup', -assumptions['terminal_extra_capital'], 'terminal')
            payment('terminal_deferred_tax_settlement', -opening['DTL'], 'terminal')
            snapshot = deepcopy(state)
            terminal_shares, terminal_equity_gross, terminal_bank_draws = shares, equity_gross, bank_draws
            terminal_minimum = minimum_cash
            equal(event_index, len(path['events']), path_id + ': primary event cutoff')
            month = horizon + 1

        year = (month - 1) // 12
        tonnes, price, annual_revenue = annual_demand(month)
        revenue = annual_revenue / 12
        cogs = revenue * assumptions['COGS_ratio']
        old_reserve, cash_start, debt_start = reserve, state['cash'], total_debt()
        wc_start, ic_start, shares_start = net_working_capital(state), invested_capital(), shares
        reserve = max(assumptions['minimum_cash'], annual_revenue * assumptions['reserve_sales'])
        start = event_index
        monthly_fees = ZERO
        collateral = {key: state[key] for key in ('AR', 'inventory')}
        if state['CC'] > min(funding['CC_limit'], borrowing_base()) + TOLERANCE:
            borrowing_base_excesses.append({'month': month, 'CC': str(state['CC']), 'borrowing_base': str(borrowing_base())})
        payment('monthly_reserve_test', ZERO, 'reserve')
        mandatory_paydown = max(ZERO, state['CC'] - min(funding['CC_limit'], borrowing_base()))
        state['CC'] -= mandatory_paydown
        payment('borrowing_base_cure', -mandatory_paydown, 'financing')
        verify(state['CC'] <= min(funding['CC_limit'], borrowing_base()) + TOLERANCE, path_id + ': mandatory borrowing-base cure failed')
        commissioned = ZERO
        if month == int(assumptions['commission_month']):
            if month <= int(assumptions['capex_months']):
                failure('Committed plant requested before all project invoices paid', ZERO, 'capacity')
            else:
                commissioned += state['CWIP']
                state['PPE'] += state['CWIP']
                physical_basis += state['CWIP']
                cohorts.append((month, state['CWIP'], int(assumptions['new_capital_life_months'])))
                state['CWIP'] = ZERO
                state['tonne_capacity'] += opening['committed_tonne_capacity']
        for item in pipeline[:]:
            if item['due'] <= month:
                state['PPE'] += item['cost']
                physical_basis += item['cost']
                state['tonne_capacity'] += item['tonnes']
                cohorts.append((month, item['cost'], int(assumptions['new_capital_life_months'])))
                commissioned += item['cost']
                pipeline.remove(item)
        if tonnes > state['tonne_capacity'] + FAILURE_EPSILON:
            failure('Demand exceeds paid and commissioned effective tonne capacity', tonnes - state['tonne_capacity'], 'capacity')
        future_tonnes = annual_demand(month + int(assumptions['extra_capacity_lag']))[0] * assumptions['capacity_buffer']
        committed_pending = opening['committed_tonne_capacity'] if month < int(assumptions['commission_month']) else ZERO
        additional = max(ZERO, future_tonnes - state['tonne_capacity'] - sum((p['tonnes'] for p in pipeline), ZERO) - committed_pending)
        growth = additional * assumptions['new_capacity_cost_per_tonne']
        replacement = max(revenue * assumptions['maintenance_sales'], physical_basis / assumptions['new_capital_life_months'])
        depreciation = sum((basis / life for first, basis, life in cohorts if first <= month < first + life), ZERO)
        state['PPE'] -= depreciation
        fixed = assumptions['fixed_opex'] * (ONE + assumptions['opex_growth']) ** year / 12
        variable = revenue * (assumptions['variable_opex'] + (assumptions['terminal_margin_haircut'] if month > horizon else ZERO))
        ebitda = revenue - cogs - fixed - variable
        bad_debt = assumptions['AR_writeoff'] if month == 1 else ZERO
        obsolete = assumptions['inventory_writeoff'] if month == 1 else ZERO
        verify(bad_debt <= state['AR'] and obsolete <= state['inventory'], path_id + ': writeoff exceeds balance')
        ramp = min(ONE, D(month) / assumptions['transition_months'])
        target = {'AR': annual_revenue * assumptions['AR_days'] / 365,
                  'inventory': annual_revenue * assumptions['COGS_ratio'] * assumptions['inventory_days'] / 365,
                  'TP': annual_revenue * assumptions['COGS_ratio'] * assumptions['TP_days'] / 365,
                  'other_CA': annual_revenue * assumptions['other_CA_sales'],
                  'other_CL': annual_revenue * assumptions['other_CL_sales']}
        end = {key: opening[key] * (ONE - ramp) + value * ramp for key, value in target.items()}
        delta = {key: value - state[key] for key, value in end.items()}
        delta['AR'] += bad_debt
        delta['inventory'] += obsolete
        receipts, purchases = revenue - delta['AR'], cogs + delta['inventory']
        suppliers = purchases - delta['TP']
        if receipts < 0:
            failure('Negative customer receipts cannot fund this operating path', -receipts, 'working_capital')
        payment('customer_receipts_early', receipts * assumptions['early_receipts'])
        payment('supplier_payments_early', -suppliers * assumptions['early_supplier'], eligible='working')
        payment('payroll_and_other_early', -(fixed + variable) * assumptions['early_opex'], eligible='working')
        payment('other_operating_assets', -delta['other_CA'], eligible='working')
        payment('other_operating_liabilities', delta['other_CL'], eligible='working')
        committed = (opening['ipo_capex'] + opening['project_internal_capex']) * (ONE + assumptions['capex_overrun']) / assumptions['capex_months'] if month <= int(assumptions['capex_months']) else ZERO
        payment('committed_project_capex', -committed, 'investment', 'capex')
        state['CWIP'] += committed
        payment('additional_capacity_capex', -growth, 'investment')
        if growth:
            pipeline.append({'cost': growth, 'tonnes': additional, 'due': month + int(assumptions['extra_capacity_lag'])})
        payment('replacement_capex', -replacement, 'investment')
        state['PPE'] += replacement
        cohorts.append((month + 1, replacement, int(assumptions['new_capital_life_months'])))
        payment('customer_receipts_late', receipts * (ONE - assumptions['early_receipts']))
        payment('supplier_payments_late', -suppliers * (ONE - assumptions['early_supplier']), eligible='working')
        payment('payroll_and_other_late', -(fixed + variable) * (ONE - assumptions['early_opex']), eligible='working')
        legacy_tax = opening['tax_payable'] if month == 1 else ZERO
        employee = assumptions['employee_legacy_payment'] if month == 1 else ZERO
        legal = assumptions['legal_payment'] if month == int(assumptions['legal_month']) else ZERO
        payment('legacy_income_tax', -legacy_tax, 'legacy')
        payment('legacy_employee_benefits', -employee, 'legacy')
        payment('legal_stress_settlement', -legal, 'legacy')
        principal = min(state['bank_debt'], opening['bank_debt'] / assumptions['bank_repayment_months']) if month <= int(assumptions['bank_repayment_months']) else ZERO
        state['bank_debt'] -= principal
        payment('scheduled_bank_principal', -principal, 'financing')
        promoter = state['promoter_debt'] if month == int(assumptions['promoter_repayment_month']) else ZERO
        state['promoter_debt'] -= promoter
        payment('promoter_demand_repayment', -promoter, 'financing')
        interest = (state['bank_debt'] + principal) * assumptions['bank_rate'] / 12 + state['CC'] * assumptions['CC_rate'] / 12
        interest += payment('cash_interest', -interest, 'financing', interest_sensitive=True)
        ebit = ebitda - depreciation - bad_debt - obsolete
        cash_tax = max(ZERO, ebit - interest) * tax_rate
        payment('cash_income_tax', -cash_tax)
        profit = ebit - interest - cash_tax - monthly_fees
        dividend = max(ZERO, profit) * assumptions['dividend_payout']
        payment('dividend', -dividend, 'distribution')
        # Declaration uses pre-payment profit; realized PAT includes any fee
        # incurred when funding that declared distribution.
        profit = ebit - interest - cash_tax - monthly_fees
        state.update(end)
        wc_end, ic_end = net_working_capital(state), invested_capital()
        capex = committed + growth + replacement
        nopat = ebit - max(ZERO, ebit) * tax_rate
        cfo = ebitda - delta['AR'] - delta['inventory'] - delta['other_CA'] + delta['TP'] + delta['other_CL'] - cash_tax - employee - legal
        expected = {'month': month, 'date': event_date(month), 'year': year + 1,
                    'revenue': revenue, 'tonnes': tonnes / 12, 'revenue_per_produced_tonne': price,
                    'COGS': cogs, 'fixed_opex': fixed, 'variable_opex': variable, 'EBITDA': ebitda,
                    'DA': depreciation, 'EBIT': ebit, 'NOPAT': nopat, 'AR_writeoff': bad_debt,
                    'inventory_writeoff': obsolete, 'PAT': profit, 'interest': interest,
                    'tax': cash_tax, 'financing_fees': monthly_fees, 'CFO_before_financing_interest': cfo,
                    'FCF_before_financing_interest': cfo - capex, 'capex': capex,
                    'committed_capex': committed, 'growth_capex': growth, 'replacement_capex': replacement,
                    'legacy_tax': legacy_tax, 'legacy_employee': employee, 'legal_payment': legal,
                    'dividend': dividend, 'opening_cash': cash_start, 'closing_cash': state['cash'],
                    'opening_debt': debt_start, 'closing_debt': total_debt(),
                    'opening_shares': shares_start, 'closing_shares': shares,
                    'reserve_open': old_reserve, 'reserve_close': reserve,
                    'ONWC_open': wc_start, 'ONWC_close': wc_end, 'IC_open': ic_start, 'IC_close': ic_end,
                    'tonne_capacity': state['tonne_capacity'], 'commissioned_cost': commissioned,
                    'CWIP': state['CWIP'], 'PPE': state['PPE'],
                    'pipeline_capital': sum((p['cost'] for p in pipeline), ZERO),
                    'ipo_capex': state['ipo_capex'], 'ipo_working': state['ipo_working'],
                    'CC': state['CC'], 'bank_debt': state['bank_debt'], 'promoter_debt': state['promoter_debt'],
                    'customer_receipts': receipts, 'purchases': purchases, 'supplier_payments': suppliers,
                    'failed_to_date': bool(failures), 'event_start': start, 'event_end': event_index,
                    **{key: state[key] for key in source_keys}, **end}
        fields(observed, expected, f'{path_id}/month{month}')
        # Balance-sheet and cash-flow identities supplement field-by-field replay.
        equal(ic_end - ic_start, capex - depreciation + wc_end - wc_start, f'{path_id}/month{month}/capital identity')
        period_events = events[start:event_index]
        equal(state['cash'] - cash_start, sum((D(str(event['amount'])) for event in period_events), ZERO), f'{path_id}/month{month}/cash identity')
        reconstructed.append(expected)

    primary, continuation = reconstructed[:horizon], reconstructed[horizon:]
    next_nopat = sum((r['NOPAT'] for r in continuation), ZERO)
    next_da = sum((r['DA'] for r in continuation), ZERO)
    actual_growth = sum((r['capex'] - r['replacement_capex'] for r in continuation), ZERO) + continuation[-1]['ONWC_close'] - continuation[0]['ONWC_open']
    required_growth = max(ZERO, next_nopat * assumptions['terminal_growth'] / assumptions['terminal_CAP'], (next_nopat - annual['NOPAT']) / assumptions['terminal_CAP'])
    gap = max(ZERO, required_growth - actual_growth)
    payment('terminal_continuation_earned_capital_gap', -gap, 'investment')
    fcff = sum((r['NOPAT'] + r['DA'] - r['capex'] - (r['ONWC_close'] - r['ONWC_open']) - (r['reserve_close'] - r['reserve_open']) for r in continuation), ZERO) - gap
    if next_nopat <= 0 or fcff <= 0:
        failure('Terminal continuation has nonpositive sustainable operating cash', max(ZERO, -fcff), 'terminal')
    equal(event_index, len(events), path_id + ': final event cutoff')
    equal(len(path['failures']), len(failures), path_id + ': failures count')
    for index, expected in enumerate(failures):
        fields(path['failures'][index], expected, f'{path_id}/failure{index}')
    failed = bool(failures)
    terminal_reserve = primary[-1]['reserve_close']
    terminal_ev = max(ZERO, annual['EBITDA'] - annual['revenue'] * assumptions['terminal_margin_haircut']) * assumptions['terminal_multiple']
    restricted_recovery = (snapshot['ipo_capex'] + snapshot['ipo_working']) * assumptions['terminal_restricted_recovery']
    fd_recovery = snapshot['FD'] * assumptions['FD_terminal_recovery']
    terminal_debt = snapshot['CC'] + snapshot['bank_debt'] + snapshot['promoter_debt']
    terminal_equity = max(ZERO, terminal_ev + max(ZERO, snapshot['cash'] - terminal_reserve) + restricted_recovery + fd_recovery - terminal_debt)
    terminal_price = terminal_equity * CRORE / terminal_shares
    dividends = [r['dividend'] * CRORE / r['closing_shares'] for r in primary]
    cashflows = [-entry * (ONE + D(inputs['entry_cost']))] + dividends
    cashflows[-1] += terminal_price * (ONE - D(inputs['exit_cost']))
    wacc, growth = assumptions['WACC'], assumptions['terminal_growth']
    explicit_pv = sum(((r['NOPAT'] + r['DA'] - r['capex'] - (r['ONWC_close'] - r['ONWC_open']) - (r['reserve_close'] - r['reserve_open']) - r['legal_payment'] - r['legacy_employee']) / (ONE + wacc) ** (D(k) / 12) for k, r in enumerate(primary, 1)), ZERO)
    terminal_pv = fcff / (wacc - growth) / (ONE + wacc) ** years
    restricted_release_pv = sum((event['pool_release'] / (ONE + wacc) ** (D(event['month']) / 12)
                                 for event in reconstructed_events[:len(path['events'])]
                                 if event['kind'] == 'restricted_release'), ZERO)
    restricted_residual_pv = restricted_recovery / (ONE + wacc) ** years
    fd_pv = fd_recovery / (ONE + wacc) ** years
    dcf_equity = (explicit_pv + terminal_pv + initial_cash - initial_reserve
                  + restricted_release_pv + restricted_residual_pv + fd_pv
                  - opening['bank_debt'] - opening['promoter_debt'] - opening['CC']
                  - opening['tax_payable'] - opening['DTL']
                  - assumptions['terminal_extra_capital'] / (ONE + wacc) ** years
                  - assumptions['extra_issue_fee_tax']
                  - (assumptions['legal_payment'] if int(assumptions['legal_month']) == 0 else ZERO))
    hurdle_prices = {}
    for hurdle in (D('.12'), D('.15'), D('.18')):
        price = (sum((amount / (ONE + hurdle) ** (D(k) / 12) for k, amount in enumerate(dividends, 1)), ZERO)
                 + terminal_price * (ONE - D(inputs['exit_cost'])) / (ONE + hurdle) ** years) / (ONE + D(inputs['entry_cost']))
        hurdle_prices[str(hurdle)] = None if failed else price
    expected_summary = {'failed': failed, 'failure_count': len(failures),
                        'first_failure': failures[0] if failures else None,
                        'ordinary_return_suppressed': failed,
                        'IRR': None if failed else audit_irr(cashflows),
                        'terminal_price': None if failed else terminal_price,
                        'diagnostic_terminal_price_invalid_when_failed': terminal_price,
                        'terminal_equity': terminal_equity, 'terminal_EV': terminal_ev,
                        'ending_shares': terminal_shares, 'dilution': D(terminal_shares) / inputs['shares'] - ONE,
                        'equity_gross': terminal_equity_gross, 'CC_draws': terminal_bank_draws,
                        'CC': snapshot['CC'], 'ending_debt': terminal_debt,
                        'ending_cash': snapshot['cash'],
                        'ending_cash_provenance': {key: snapshot[key] for key in source_keys},
                        'minimum_cash': terminal_minimum,
                        'IPO_capex_remaining': snapshot['ipo_capex'], 'IPO_WC_remaining': snapshot['ipo_working'],
                        'FD': snapshot['FD'], 'FD_terminal_recovery': fd_recovery,
                        'restricted_terminal_recovery': restricted_recovery, 'terminal_reserve': terminal_reserve,
                        'yearN_revenue': annual['revenue'], 'yearN_EBITDA': annual['EBITDA'],
                        'yearN_tonnes': annual['tonnes'], 'terminal_capacity_tonnes': snapshot['tonne_capacity'],
                        'yearN_IC': primary[-1]['IC_close'], 'next_NOPAT': next_nopat,
                        'sustainable_FCFF': fcff, 'earned_growth_capital_required': required_growth,
                        'continuation_actual_growth_capital': actual_growth, 'continuation_capital_gap': gap,
                        'continuation_failed': any(r['month'] > horizon for r in failures),
                        'continuation_minimum_cash': minimum_cash, 'continuation_ending_debt': total_debt(),
                        'hurdle_entry_prices': hurdle_prices,
                        'DCF_equity_current_shares': None if failed else dcf_equity,
                        'DCF_price_current_shares': None if failed else max(ZERO, dcf_equity) * CRORE / inputs['shares'],
                        'DCF_terminal_fraction': terminal_pv / (terminal_pv + explicit_pv) if terminal_pv + explicit_pv else None,
                        'cashflows_per_original_share': None if failed else cashflows}
    fields(summary, expected_summary, path_id + '/summary')
    expected_terminal = {'FCFF': fcff, 'required_incremental_capital': required_growth,
                         'actual_incremental_capital': actual_growth, 'extra_cash_capital': gap,
                         'next_DA': next_da, 'DCF_explicit_PV': explicit_pv,
                         'DCF_terminal_PV': terminal_pv, 'DCF_equity_diagnostic': dcf_equity,
                         'restricted_release_PV': restricted_release_pv,
                         'restricted_remaining_recovery_PV': restricted_residual_pv,
                         'FD_recovery_PV': fd_pv}
    fields(path['terminal'], expected_terminal, path_id + '/terminal')
    verify(all(r['closing_shares'] == terminal_shares for r in continuation), path_id + ': post-exit equity issuance')
    if not failed and summary['IRR'] is not None:
        residual = sum((value / (ONE + D(summary['IRR'])) ** (D(k) / 12) for k, value in enumerate(cashflows)), ZERO)
        equal(residual, ZERO, path_id + ': independent shareholder NPV root')
    return {'path_id': path_id, 'months': horizon, 'continuation_months': 12,
            'events_checked': event_index, 'failed': failed, 'failure_count': len(failures),
            'ending_shares': terminal_shares, 'input_event_month_terminal_replay_complete': True,
            'borrowing_base_cures_required': borrowing_base_excesses,
            'source_failure_count': sum(r['kind'].endswith('_funding') for r in failures),
            'positive_cash_source_failure_count': sum(r['kind'].endswith('_funding') and r['cash'] > 0 for r in failures),
            'restricted_terminal_unrecovered': str((snapshot['ipo_capex'] + snapshot['ipo_working']) * (ONE - assumptions['terminal_restricted_recovery']))}


def readpaths(path):
    """Stream a top-level path-ID mapping, or a top-level list, from gzip/JSON.

    Supports a {"paths": {...}} envelope as well. At most one decoded path and
    one input buffer are retained by this parser, rather than the complete trace.
    """
    opener = gzip.open if str(path).endswith('.gz') else open
    decoder = json.JSONDecoder()
    with opener(path, 'rt', encoding='utf-8') as stream:
        buffer, position, eof = '', 0, False

        def refill():
            nonlocal buffer, position, eof
            buffer = buffer[position:] + stream.read(65536)
            position = 0
            if not buffer:
                eof = True

        def whitespace():
            nonlocal position
            while True:
                while position < len(buffer) and buffer[position].isspace():
                    position += 1
                if position < len(buffer) or eof:
                    return
                refill()

        def token():
            nonlocal position, buffer, eof
            whitespace()
            while True:
                try:
                    value, end = decoder.raw_decode(buffer, position)
                    position = end
                    return value
                except json.JSONDecodeError:
                    extra = stream.read(65536)
                    if not extra:
                        eof = True
                        raise AuditError('Truncated or invalid canonical JSON trace')
                    buffer = buffer[position:] + extra
                    position = 0

        def consume(character):
            nonlocal position
            whitespace()
            verify(position < len(buffer) and buffer[position] == character, 'Trace parser: expected ' + character)
            position += 1

        def members():
            nonlocal position
            consume('{')
            while True:
                whitespace()
                if position < len(buffer) and buffer[position] == '}':
                    position += 1
                    return
                key = token()
                consume(':')
                if key == 'paths':
                    yield from members()
                else:
                    value = token()
                    if isinstance(value, dict) and 'summary' in value:
                        equal(value['summary']['path_id'], key, 'Trace path ID matches mapping key')
                        yield value
                whitespace()
                if position < len(buffer) and buffer[position] == ',':
                    position += 1
                elif position < len(buffer) and buffer[position] == '}':
                    position += 1
                    return
                else:
                    raise AuditError('Trace parser: expected object separator')

        whitespace()
        verify(position < len(buffer), 'Empty canonical trace')
        if buffer[position] == '{':
            yield from members()
        elif buffer[position] == '[':
            position += 1
            while True:
                whitespace()
                if position < len(buffer) and buffer[position] == ']':
                    position += 1
                    break
                yield token()
                whitespace()
                if position < len(buffer) and buffer[position] == ',':
                    position += 1
                elif position < len(buffer) and buffer[position] == ']':
                    position += 1
                    break
                else:
                    raise AuditError('Trace parser: expected array separator')
        else:
            raise AuditError('Canonical trace must contain an object or list')
        whitespace()
        verify(eof and position == len(buffer), 'Extra data after canonical trace')


def mutation_tests(reference, failed_path, inputs, financed_path=None, cure_path=None, legal_path=None, fee_path=None, overrun_path=None):
    """Prove that otherwise-valid serialized paths reject isolated corruption."""
    cases = []

    def reject(label, source, mutate):
        altered = deepcopy(source)
        mutate(altered)
        try:
            audit(altered, inputs)
        except (AuditError, KeyError, ValueError, TypeError) as error:
            cases.append({'mutation': label, 'rejected': True, 'detected_at': str(error)[:240]})
        else:
            raise AuditError('Mutation escaped independent verifier: ' + label)

    def bump(obj, key, amount='1'):
        obj[key] = str(D(str(obj[key])) + D(amount))

    reject('event_cash_after', reference, lambda p: bump(p['events'][0], 'cash_after'))
    reject('event_payment_amount', reference, lambda p: bump(next(e for e in p['events'] if e['label'] == 'supplier_payments_early'), 'amount'))
    reject('whole_shares', reference, lambda p: p['events'][0].update(shares=inputs['shares'] + 1))
    reject('restricted_ipo_pool', reference, lambda p: bump(p['events'][0], 'ipo_working'))
    reject('committed_capex', reference, lambda p: bump(p['monthly'][0], 'committed_capex'))
    reject('commissioned_tonne_capacity', reference, lambda p: bump(p['monthly'][0], 'tonne_capacity'))
    reject('cohort_depreciation', reference, lambda p: bump(p['monthly'][1], 'DA'))
    reject('working_capital', reference, lambda p: bump(p['monthly'][0], 'AR'))
    reject('continuation_cash', reference, lambda p: bump(p['continuation_events'][0], 'cash_after'))
    reject('sustainable_FCFF', reference, lambda p: bump(p['terminal'], 'FCFF'))
    reject('earned_growth_capital', reference, lambda p: bump(p['terminal'], 'required_incremental_capital'))
    reject('restricted_release_valuation', reference, lambda p: bump(p['terminal'], 'restricted_release_PV'))
    reject('FD_discounting', reference, lambda p: bump(p['terminal'], 'FD_recovery_PV'))
    reject('restricted_release_amount', reference, lambda p: bump(next(e for e in p['events'] if e['kind'] == 'restricted_release'), 'pool_release'))
    reject('internal_project_cost_leaks_to_IPO_pool', reference,
           lambda p: next(e for e in p['events'] if e['label'] == 'restricted_capex_payment_support').update(
               pool_release=str(-D(next(e for e in p['events'] if e['label'] == 'committed_project_capex')['amount']))))
    if financed_path is not None:
        def financing(p):
            return next(e for e in p['events'] if e.get('issued', 0) > 0)
        reject('bank_draw', financed_path, lambda p: bump(financing(p), 'bank_draw'))
        reject('bank_borrowing_base', financed_path, lambda p: bump(financing(p), 'borrowing_base'))
        reject('issued_share_quantity', financed_path, lambda p: financing(p).update(issued=financing(p)['issued'] + 1))
        reject('equity_issue_price', financed_path, lambda p: bump(financing(p), 'issue_price'))
        reject('share_authorization', financed_path, lambda p: financing(p).update(authorized_shares=inputs['authorized_shares'] + 1))
        reject('equity_gross', financed_path, lambda p: bump(financing(p), 'equity_gross'))
    else:
        raise AuditError('Canonical set lacks an equity-financed path for funding mutation tests')
    if cure_path is not None:
        def cure(p):
            return next(e for e in p['events'] + p['continuation_events']
                        if e['label'] == 'borrowing_base_cure' and D(e['amount']) < 0)
        reject('mandatory_borrowing_base_cure_amount', cure_path, lambda p: bump(cure(p), 'amount'))
        reject('mandatory_borrowing_base_cure_debt', cure_path, lambda p: bump(cure(p), 'CC'))
    else:
        raise AuditError('Canonical set lacks a positive borrowing-base cure for required boundary tests')
    if failed_path is not None:
        reject('failed_IRR_unsuppressed', failed_path, lambda p: p['summary'].update(IRR='0.15'))
        reject('failed_terminal_price_unsuppressed', failed_path, lambda p: p['summary'].update(terminal_price='100'))
        reject('failed_DCF_unsuppressed', failed_path, lambda p: p['summary'].update(DCF_equity_current_shares='100'))
        reject('failed_hurdle_unsuppressed', failed_path, lambda p: p['summary']['hurdle_entry_prices'].update({'0.15': '100'}))
    else:
        raise AuditError('Canonical set lacks a failed path for required failed-return mutation test')

    def reallocate_event_end(event, donor, recipient, amount):
        amount = D(str(amount))
        for field in ('provenance_after', 'provenance_delta'):
            bump(event[field], donor, str(-amount))
            bump(event[field], recipient, str(amount))

    reject('cash_provenance_bucket', reference, lambda p: bump(p['events'][0]['provenance_after'], 'cash_internal'))
    reject('cash_provenance_delta', reference, lambda p: bump(p['events'][0]['provenance_delta'], 'cash_ipo_general'))
    reject('restricted_release_misclassified_as_internal', reference,
           lambda p: reallocate_event_end(next(e for e in p['events'] if e['kind'] == 'restricted_release'),
                                          'cash_restricted_transient', 'cash_internal', '1'))
    reject('internal_GST_requirement_removed', reference,
           lambda p: next(e for e in p['events'] if e['label'] == 'committed_project_capex').update(internal_required_amount='0'))
    reject('terminal_cash_provenance', reference,
           lambda p: bump(p['summary']['ending_cash_provenance'], 'cash_ipo_general'))
    if financed_path is not None:
        reject('fresh_financing_misclassified_as_internal', financed_path,
               lambda p: reallocate_event_end(next(e for e in p['events'] if e['label'] == 'conditional_financing'),
                                              'cash_financing', 'cash_internal', '.01'))
    if legal_path is None:
        raise AuditError('Missing positive-aggregate-cash legal provenance adversary')

    def entry_legal(p):
        return next(e for e in p['events'] if e['label'] == 'legal_stress_settlement' and e['month'] == 0)

    legal_event = entry_legal(legal_path)
    verify(D(legal_event['cash_after']) > D(legal_event['reserve']) and D(legal_event['internal_eligibility_shortfall']) > 0,
           'Legal provenance adversary must fail internal eligibility despite aggregate reserve surplus')
    reject('legal_GCP_rescue', legal_path,
           lambda p: reallocate_event_end(entry_legal(p), 'cash_ipo_general', 'cash_internal',
                                          entry_legal(p)['internal_eligibility_shortfall']))
    reject('legal_fresh_financing_rescue', legal_path,
           lambda p: reallocate_event_end(entry_legal(p), 'cash_financing', 'cash_internal',
                                          entry_legal(p)['internal_eligibility_shortfall']))
    reject('legal_source_shortfall_erased', legal_path,
           lambda p: entry_legal(p).update(internal_eligibility_shortfall='0'))
    reject('legal_source_failure_removed', legal_path,
           lambda p: p.update(failures=[r for r in p['failures'] if r['kind'] != 'legal_funding']))
    reject('entry_legal_DCF_offset_removed', legal_path,
           lambda p: bump(p['terminal'], 'DCF_equity_diagnostic', legal_path['summary']['overrides']['legal_payment']))
    if fee_path is None:
        raise AuditError('Missing IPO fee-tax sensitivity')
    reject('IPO_fee_tax_DCF_offset_removed', fee_path,
           lambda p: bump(p['terminal'], 'DCF_equity_diagnostic', fee_path['summary']['overrides']['extra_issue_fee_tax']))
    if overrun_path is None:
        raise AuditError('Missing overrun invoice with a financing-source balance for forbidden-source test')

    def overrun_invoice(p):
        return next(e for e in p['events']
                    if D(e['project_overrun_component']) > 0 and D(e['provenance_after']['cash_financing']) > D('.01'))

    reject('project_overrun_fresh_financing_rescue', overrun_path,
           lambda p: reallocate_event_end(overrun_invoice(p), 'cash_financing', 'cash_internal', '.01'))
    reject('project_overrun_eligibility_shortfall', overrun_path,
           lambda p: bump(overrun_invoice(p), 'overrun_eligibility_shortfall', '.01'))
    return cases


def file_hash(path):
    digest = hashlib.sha256()
    with open(path, 'rb') as stream:
        for chunk in iter(lambda: stream.read(1048576), b''):
            digest.update(chunk)
    return digest.hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('root', type=Path)
    parser.add_argument('trace', type=Path)
    parser.add_argument('report', type=Path, nargs='?')
    parser.add_argument('--no-mutations', action='store_true')
    args = parser.parse_args()
    input_path = args.root / 'model_inputs.json'
    inputs = json.loads(input_path.read_text())
    results, reference, failed_path, financed_path, cure_path, legal_path, fee_path, overrun_path, ids = [], None, None, None, None, None, None, None, set()
    summaries = {}
    for path in readpaths(args.trace):
        result = audit(path, inputs)
        verify(result['path_id'] not in ids, 'Duplicate canonical path ' + result['path_id'])
        ids.add(result['path_id'])
        results.append(result)
        summaries[result['path_id']] = path['summary']
        if financed_path is None and any(event.get('issued', 0) > 0 for event in path['events']):
            financed_path = path
        if cure_path is None and result['borrowing_base_cures_required']:
            cure_path = path
        if result['path_id'] == 'stress_legal_provenance':
            legal_path = path
        if result['path_id'] == 'stress_IPO_fee_tax':
            fee_path = path
        if overrun_path is None and any(D(event['project_overrun_component']) > 0 and D(event['provenance_after']['cash_financing']) > D('.01') for event in path['events']):
            overrun_path = path
        if reference is None or (reference['summary']['failed'] and not result['failed']):
            reference = path
        if failed_path is None and result['failed']:
            failed_path = path
    verify(bool(results), 'No canonical paths were audited')
    inventory_count = check_inventory(summaries, inputs)
    replay_checks = checks
    mutations = [] if args.no_mutations else mutation_tests(reference, failed_path, inputs, financed_path, cure_path, legal_path, fee_path, overrun_path)
    report = {'independent': True, 'imports_producer_code': False, 'precision': getcontext().prec,
              'absolute_tolerance': str(TOLERANCE), 'checks': checks, 'replay_checks': replay_checks,
              'paths': len(results), 'required_named_paths': inventory_count, 'results': results, 'mutation_tests': mutations,
              'mutation_tests_passed': bool(mutations) and all(r['rejected'] for r in mutations),
              'model_inputs_sha256': file_hash(input_path), 'trace_sha256': file_hash(args.trace)}
    serialized = json.dumps(report, indent=2) + '\n'
    if args.report:
        args.report.write_text(serialized)
        print(json.dumps({key: value for key, value in report.items() if key not in ('results', 'mutation_tests')}, indent=2))
    else:
        print(serialized, end='')


if __name__ == '__main__':
    main()
