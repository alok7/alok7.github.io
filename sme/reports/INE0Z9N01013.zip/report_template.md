# Sham Foam Limited SME research under Master Prompt v 3.0

Information cutoff: 20 October 2026, end of day Asia/Kolkata. Conditional price reference: INR 89.50, secondary close of 19 October 2026. All financial tables are INR crore unless expressly labelled otherwise. Prepared from dated primary records retrieved on 24 October 2026. Source limitations are part of the conclusion, not footnotes that can be ignored.

## 1. Executive Verdict

Sham Foam is principally a regional polyurethane-foam manufacturer selling through dealers, not a miniature pure-play branded mattress retailer. The strongest investment argument is an IPO-funded removal of cutting-machine bottlenecks, backed by an existing dealer network and a sharply improved FY26 operating result. The decisive counterargument is that the apparent earnings acceleration has outrun underlying revenue growth and demonstrably independent cash conversion: FY23–26 revenue CAGR is only {{CAGR}}, FY26 cash flow relies heavily on increased supplier balances, and additional-capital returns cannot yet be scored. The business owns neither the factory land nor all claimed brand rights outright, and the trademark case is contested, not resolved. BQS, Growth Quality and IAS are NS for specified missing evidence, not low numerical substitutes. This is a conditional small-manufacturer expansion/special-situation thesis, not an evidence-backed compounder. At the secondary INR 89.50 reference, the source-linked pro forma base returns {{BASE_IRR}} after assumed execution costs, below the 15% hurdle, but it is not a live valuation recommendation. Original statutory audit/CARO/IFC records, post-IPO cash/deployment, project unit economics and executable market evidence could change the hold. [FP] [DP] [M1] [M2]

## 2. Research Header, Gates and Data Confidence

Exact issuer: Sham Foam Limited, formerly Sham Foam Private Limited, CIN U36104HR2020PLC087011, ISIN INE0Z9N01013. The original prospectus establishes the legal entity and security; listing discovery identifies BSE SME SHAMFOAM, scrip 544869, trading from 18 August 2026. Do not confuse it with Sheela Foam, its much larger competitor and litigation counterparty. Incorporated 26 June 2020; fresh public-company certificate dated 20 September 2024. The financial appendix contains an inconsistent conversion-date description, so the specific legal-history/certificate description controls, without hiding that discrepancy. The issuer has no disclosed subsidiary, associate or JV in the reviewed offer documents. Generic consolidated wording in MD&A does not create a second accounting perimeter. [FP] [LIST]

Scope is standalone Indian GAAP/Companies Accounting Standards, not assumed Ind AS. Year ends are 31 March. Historical annual statements available are restated FY23–FY26; separate original statutory annual reports, CARO annexures and IFC opinions were not retrieved despite targeted primary-source searches. The restatement report dated 27 July 2026 expressly is not a reissued previous audit opinion. The corrected-cover prospectus file still bears 5 August 2026; all 48 scanned financial pages are identical to the earlier final by page-image hash comparison. [FP] [FPold] [DP]

Current assumed issued shares are 11,490,750 after 3,114,000 fresh IPO shares; authorized shares are 12,500,000. The prospectus and secondary listing notice agree on this capital arithmetic, but a cutoff-date original security master/share pattern was not verified. INR 89.50 is corroborated by two secondary histories, not an official executable close. The default horizon is five years, nominal equity hurdle 15% before personal tax, with 12%/18% sensitivities. WACC is separately assumed 14%–20%, not equated to the shareholder hurdle. Liquidity uses an illustrative INR 5 lakh position, not a recommended allocation. [FP] [LIST] [M1] [M2]

{{GATES}}

{{CONFIDENCE}}

G2 and G4 are unresolved-evidence holds, not findings that the accounts are fraudulent or the security is suspended. G3 is conditional rather than an evidenced failure: a modeled cash shortfall under adverse assumptions is not proof of an actual current unfinanceable obligation. Evidence needed to clear each hold is listed in Sections 13 and 15.

## 3. Scorecard and Calculation Audit

{{SCORES}}

BQS coverage is 88%, GQS 85%, and IAS 20%. CAP is NS because the observed incremental-capital denominator is negative and no defensible project/cohort substitute is established. IAS lacks a numeric BQS as well as R, P and L. Its ordinary missing-data bound is mathematical, not a probability interval; using the BQS bound rather than allowing quality to range independently from 1 to 10 gives the narrower dependency-aware IAS bound {{DEP_BOUND}}, still not a point estimate or ranking. [FP] [DP]

{{FACTORS}}

Exact unrounded Decimal contributions follow. The strings NS indicate missing contributions, not zeros; known contributions are sums of only scoreable original weights. The displayed mathematical lower and upper bounds insert 1 and 10 respectively for missing factors without redistributing any weight.

{{CONTRIBUTIONS}}

There is no governance cap: GOV is 4 and G1 has not failed. There is no funding cap because G3 is not an evidenced failure. No Growth Quality cap is invoked: CASH is 4, while CAP is missing rather than ≤3. An aggregate NS stays NS even if a separate gate implies a hold. Moving MOAT and CASH by one point shifts the BQS bound by at most 0.30; CASH shifts GQS by 0.10. This is judgment sensitivity, not a new overall score. The canonical factors total thirteen: nine business/growth factors plus R/D/P/L. Historical short/medium-confidence factors cannot receive 9–10 merely because the company recently listed.

## 4. Business Overview

The factory produces flexible PU foam, customized densities/grades, quilting foam, mattresses, cushions and related comfort products. FY26 PU foam revenue was INR 79.601 crore, 86.22% of sales; mattresses INR 5.0038 crore, 5.42%; quilting foam INR 5.7886 crore, 6.27%. The remaining mix is not silently called a high-margin consumer brand. Foam serves mattress/furniture makers and apparel, sports, seat-cover and other industrial applications. Featherfresh and Restivia are marketed brands; certain finished pillows are sourced through job workers. [FP, printed 122–140]

Management reports over 1,300 dealers across thirteen states/UTs and no owned retail stores. Eighty-five employees were reported in June 2026. The supplier base is concentrated in TDI/polyol and other material inputs with monthly price movements; a larger purchasing scale could improve terms but is not durable pricing power. Revenue is recognized under the disclosed risk-and-reward transfer policy, net of returns/taxes/discounts. Recognized sales are not cash collections, as INR 25.397 crore of receivables at March 2026 demonstrates. [FP, F7–F8, F29]

The 204,460-square-foot premises are leased from promoters for thirty years from 1 August 2025, not owned by the issuer, and also secure company machinery borrowings. Registered/used trademarks remain dependent on promoter/relative ownership and NOCs while assignment applications are pending. These arrangements are disclosed and are not inherently abusive; nevertheless a buyer cannot include promoter land or unassigned IP as unencumbered shareholder-owned assets. [FP, printed 22,27–29]

## 5. Moat and Industry Position

The proposed mechanism is regional distribution and fulfillment: existing dealers plus customized grades and proximity to furniture/mattress customers can reduce lead times and replacement friction. Evidence supports actual access and production, but not an exclusive channel or a structurally protected margin. Failure modes are input-price shocks, a rival's price/credit offer, dealer migration, logistics cost, brand restrictions and failure to service the higher volume after expansion. ISO/BIS certification and a promoter's distribution experience demonstrate capability, not a moat by themselves. For a capable entrant, the disclosed INR 15.3731 crore project adding 4,000 effective tonnes is only an order-of-magnitude plant-capital reference: it excludes a greenfield site, a new dealer network and customer acquisition. No source-backed replication timeline or quantified dealer-switching cost was established, so neither is invented as an entry barrier. [FP]

Top-ten customers represent 25.06% of FY26 sales, down from 26.83% and 28.02%, a useful counterweight to single-customer risk. Top-ten suppliers represent 78.56%, compared with 78.31%/86.85%, leaving materially greater procurement concentration. There are no verified long-term dealer/supplier contracts. Supplier credit is generally described as 50–70 days, while the accounting payable-day proxies and aged balances deserve closer analysis. No reliable accessible-market-share denominator was obtained; a precise market-share gain is not asserted. [FP, printed 23,137–138]

Three genuinely economic peers are used, with Sheela's two accounting scopes shown separately, not counted as two companies:

{{PEERS}}

Tirupati is the closest upstream mix/scale comparator and currently has weaker revenue and margins. Its CFO must be reduced for financing-classified interest and lease cash before comparing owner economics. Sheela is the stronger brand/distribution/scale benchmark; the FY26 report recasts FY25 standalone for Kurlon, so the old annual-report standalone revenue must not be mixed with the new perimeter. Wakefit is a downstream consumer/store comparator: its INR 189.175 crore FY26 PAT includes INR 98.071 crore deferred-tax credit against INR 91.104 crore PBT. Neither its headline P/E nor its pre-lease EBITDA can simply be imposed on Sham. No cutoff peer market multiples were verified, and no generic microcap P/E is used as intrinsic value. [P1] [P2] [P3] [P4]

## 6. Revenue Growth and Scale

{{GROWTH}}

The preselected comparable window is FY23–FY26: INR 79.823 crore to INR 92.3192 crore over three actual year intervals, CAGR {{CAGR}}. The two-year FY24 rebound is {{TWO_CAGR}} and is disclosed for context, not selected to obtain a higher REV. A five-year CAGR requires six observations and a ten-year CAGR eleven; those series were not retrieved, so both are ND. The six months to September 2025 show revenue INR 37.868 crore, PAT INR 3.1939 crore and CFO INR 0.8067 crore, but the matching prior half-year and H1FY27 were not available; no TTM or seasonal annualization is manufactured. [DP, printed 56–59] [FP, printed 49–52]

FY23–FY26 production rises from 4,878 to 5,257 tonnes, CAGR {{VOL_CAGR}}, while revenue per produced tonne increases at {{YIELD_CAGR}}. These factors algebraically bridge revenue, but production is not sold volume: inventory timing, quilting/mattress mix, scrap and pricing can alter the relationship. Management attributes FY26 growth to domestic demand, new dealers and regional expansion; these are attributed explanations, not a verified price/volume decomposition. No acquisition/disposal contribution was identified in the disclosed standalone perimeter. [FP] [DP]

FY26 Uttar Pradesh adds INR 7.9747 crore, Delhi 1.8614, Haryana 2.7517 and Maharashtra 1.4970, while Punjab declines 2.7012 crore. This is geographically uneven real scaling, not evidence that every served state accelerated. The four northern markets UP/Punjab/Haryana/Delhi together account for roughly 72.9% of FY26 sales. The new operating trajectory warrants attention, but the full-window schedule remains REV 2 with no extra small-base penalty or unsupported trajectory bonus. [FP, printed 197]

## 7. Growth Quality and Reinvestment Runway

Effective annual cutting capacity is 6,000 tonnes and FY26 output 5,257, or 87.62%. The headline 15,000 TPA is a different foaming/nameplate denominator; its utilization is only 35.05%. Total estimated project spending of INR 15.3731 crore, comprising INR 14.7165 crore IPO funds and INR 0.6566 crore internal cash on the aggregate bridge, adds 4,000 effective cutting tonnes, bringing available capacity to 10,000 while the disclosed headline installation remains 15,000. The document's confusing expansion table is not read as another 15,000 TPA of new capacity. [FP, printed 30,87–95,140]

The growth path requires customer demand, machinery orders, civil works, installation, staffing, stable foam quality and collections, not simply the capex cheque. All proposed machinery/construction orders were unplaced at signing. Funds were intended to be deployed in FY27, while working capital is INR 8.25 crore in FY27 and INR 6 crore in FY28/by June 2027. These dates were not yet all due at the research cutoff. No completed commissioning or actual unspent-proceeds statement was retrieved, so promised expansion is neither treated as achieved nor automatically called a miss. [FP, printed 42,85–96]

The civil schedule specifically allocates INR 65.65 lakh GST to internal accruals; the total-project bridge implies 65.66 lakh, a 0.01-lakh source-rounding difference. The model conservatively funds 65.66 lakh internally. Machine GST is capitalized with no input credit claimed, so no automatic GST cash reimbursement is assumed. [FP, printed 88–89,94]

The explicit model starts from 5,257 tonnes and uses scenario year-one/later tonne growth and pricing separately. Growth beyond the committed project requires more paid capacity and working capital. The implied marginal cost of INR 0.003843275 crore per tonne is an analyst extrapolation from the announced project, not an appraised cost curve. The source's demand narrative and dealer count do not establish a quantified accessible TAM. No export optionality, market-share gain or new customer contract is added without evidence.

Growth Quality is NS at 85% coverage. The missing CAP is decisive: high current ROIC on an old, small asset base with large supplier financing does not prove that the new INR 15.3731 crore project and incremental receivables will earn above a 14%–20% cost-of-capital range. The source does not supply mature cohorts, incremental unit cash economics or a project IRR that can repair the negative historical incremental-IC denominator. Financing and terminal earnings therefore remain explicitly conditional rather than deserving a high growth rating.

## 8. Management, Governance and Execution

Governance analysis does not infer fraud from SME status, family ownership, a fresh IPO or litigation. There was no OFS, and interest-free promoter funding and disclosed related-party terms are positive counterevidence. On the other hand, thirteen delayed ROC filings and statutory-payment delays constitute a recurring process weakness, not merely low disclosure volume. Management reports remediation and no show-cause proceedings on those filing delays at prospectus date; that does not prove all future exposures are eliminated. [FP, printed 30–33]

The factory lease, trademarks and similarly engaged group entities create dependencies requiring commercial discipline. FY24 occupancy was rent-free, so later rental costs also affect historical operating comparability. A non-compete agreement with Aggarwal Comfort Products mitigates one overlap but is not a blanket elimination of group conflicts. The financial related-party debtor is separately named Aggarwal Comforts: FY26 related sales INR 0.3032 crore versus closing receivable INR 0.8470 crore, up from 0.6143/0.5663. Its age/collectibility should be confirmed. The near equality of that balance to the INR 0.8469 crore over-three-year receivable bucket is not proof that they are the same claim, so the stress model never double counts both. [FP, F42–F43]

FY26 disclosed related-party loan repayments total INR 4.9345 crore, with no new related borrowing in the reviewed transaction table; INR 3.5231 crore remains owed to two promoters and is callable. Repayment is not itself diversion, but must be considered alongside supplier credit, IPO use restrictions and minority funding economics. Quoted IPO issue expenses are INR 5.477 crore, 13.53% of gross proceeds, expressly excluding GST and other taxes. The INR 35.005 crore net allocation is therefore offer-document arithmetic before unquantified extra taxes, not verified realized usable proceeds. The base assumes no incremental fee-tax cash charge only as an explicit conditional assumption; a separate stress pays INR 0.98586 crore, equal to an illustrative 18% of the quoted fee amount, without claiming that all charges attract that tax or that reimbursement is available. Share dilution bought less usable cash than gross issue size suggests. [FP, printed 85–99,F42–F43]

Vijay Gupta & Jain are the restatement auditors and no statutory auditor change was reported for the last three years. The unmodified restated opinion is limited evidence of reliability, not a full independent inspection of all statutory audit/CARO/IFC vintages. F10's lack of gratuity/leave-encashment provisioning and unavailable MSME supplier status conflict with the simplistic interpretation of a nil MSME-dues table. Management states that no employee had completed five years of service and that no MSME-interest claims had been received. Those are relevant mitigating explanations, not proof of zero actuarial or statutory obligations. Quantified obligations are ND, not zero. [FP, F5–F10,F23,F47]

{{DELIVERY}}

The Sheela trademark action alleges passing off/infringement and seeks injunction/recall, accounts and INR 2.001 crore damages. Sham contests it; the prospectus stated a 27 November 2026 hearing, not an adjudicated outcome. July 2026 GST ITC notice of INR 0.320111423 crore is pending after response. The eleven cheque-dishonour proceedings are collection cases initiated by Sham, not criminal accusations against it. A promoter's personal land dispute is not silently added as issuer debt. No independent later court docket ruling was verified by cutoff. [FP, printed 208–214]

## 9. Financial Forensics

{{HISTORY}}

{{BALANCES}}

Historical figures above use final restated FY24–FY26 and the earlier draft for FY23. Gross profit is ND in a full compatible manufacturing-cost sense; the material value-added proxy subtracts material consumption and stock changes, but omits production payroll/overheads and must not be labelled reported gross margin. No exceptional items are reported in these P&Ls. Normalization below removes all other income after a common 17.16% tax as a conservative diagnostic, not a certified recurring-earnings estimate, since some rebates/FX may be operating. [FP] [DP]

{{MARGINS}}

Operating EBITDA here adds all finance costs back to PBT and excludes other income. The issuer's EBITDA adds only interest-on-borrowings, leaving recurring bank/LC charges in costs: FY26 INR 10.9987 crore versus our INR 11.1695 crore. Both are shown, not silently mixed. Low coupon expense partly reflects interest-free promoter finance. FY26 reported PAT growth is 141.51%, versus sales 13.77%; the stock-cost swing from INR 3.2171 crore expense in FY25 to INR 2.6184 crore capitalization in FY26 contributes INR 5.8355 crore to the year-on-year cost bridge. This is normal cost matching in principle, but inventory existence/realizability and underlying input-price/mix effects need independent confirmation before treating the peak margin as permanent. [FP, printed 50,193,F28,F34–F40]

Cumulative earnings-to-cash realization uses sums, never an average of annual ratios:

{{CASH}}

FY26 CFO INR 12.7771 crore includes INR 9.4959 crore of increased trade payables. Removing that increase gives INR 3.2812 crore as a dependence diagnostic, not adjusted statutory CFO. FY24 likewise benefited from INR 6.724 crore of creditor expansion. FY25 CFO was just INR 0.2164 crore while receivables absorbed INR 4.782 crore. Capital spending affects investing cash and FCF; it does not explain weak CFO. [FP, printed 51] [DP, printed 58]

Three accounting distinctions are material:

- FY24 INR 4.2075 crore equity allotment was conversion of an existing loan. The cash-flow presentation shows both share/premium inflow and the matching debt decrease; subtracting the same noncash amount from both sides gives cash debt repayment INR 4.0871 crore rather than INR 8.2946 crore. Net financing cash remains negative INR 4.4027 crore after coupon interest. It was not an actual fresh-cash injection. [FP, printed 67–69,F16,52]
- FY26 operating cash adds INR 0.4225 crore of income-tax payable increase and deducts INR 1.7817 crore labelled direct taxes paid, equal to current tax expense. The implied net cash tax differs from the caption; retain original CFO and the separate caption uncertainty rather than silently correct it. A sensitivity excluding the payable addition would reduce FY26 CFO by INR 0.4225 crore. [FP, F25,51]
- Original-to-restated PAT in the reconciliation is INR 865.88/368.39/300.83 lakh to 865.08/358.19/296.64 lakh, but the main FY26 P&L repeatedly uses 865.06. The INR 0.02 lakh discrepancy is retained as a printing/reconciliation issue, not used to fabricate an exact bridge or allege material falsification. [FP, F11,F47]

Receivables older than six months increase from INR 3.0848 to 4.6218 to 5.8402 crore. FY26 over-one-year receivables total INR 3.7257 crore, without a disclosed doubtful-debt provision. Payables older than three years are INR 1.0227 crore. These are collection/settlement risks even though management calls balances good and the dispute column nil. [FP, F23,F29]

{{WC}}

Days above use average opening/closing balances, not the year-end closing-balance shortcut. Receivable days use total sales as credit-sales proxy; inventory uses material consumption plus finished/WIP stock change; payable days use raw-material purchases. The resulting CCC is a labelled proxy with nonidentical economic denominators, not a precise cash cycle. Rising aged balances matter beyond a single ratio.

Invested capital is ONWC plus net PPE/intangibles and operating security deposits. ONWC includes receivables/inventory/other operating assets less supplier/other operating liabilities and trade deposits, excluding GST/current tax, cash, debt and financial FDs. The financing-side reconciliation is equity + gross debt + current tax payable + net deferred tax liability − free cash − FDs − excluded GST asset. Operating rent remains expensed consistently. [FP, F13–F34] [DP, financial notes]

{{CAPITAL}}

{{INC}}

Negative FY23–FY26 incremental capital makes the endpoint ratio NM. The two-year and lagged numerator/denominator diagnostics are shown separately because their enormous apparent returns depend on a small denominator, margin recovery and supplier funding; they are not new-project IRRs. Net cash capex less depreciation plus ONWC and operating-deposit movements explains the capital change within disclosed rounding residual. A five-year incremental-return window is unavailable. CAP therefore remains NS rather than rewarding an accounting artifact.

March net cash excludes INR 0.9463 crore of FDs from operating liquidity. The FD may ultimately be available, but no maturity/lien proof was found, so access is a sensitivity. Debt totals INR 3.9908 crore, including INR 3.5231 crore callable promoter loans and INR 0.4677 crore secured debt by note arithmetic; a risk-text line says 0.4678, a retained rounding discrepancy. No current undrawn bank limit is verified. Income-tax payable INR 1.018 crore, legal risks and unquantified employee/MSME obligations prevent a casual debt-free characterization. [FP]

Bonus-adjusted weighted EPS and current issued shares are distinct. The July 2024 44-for-1 and July 2025 1-for-50 bonuses are not dilution, while the fresh IPO increases shares from 8,376,750 to 11,490,750 and reduces old holders' percentage ownership by 27.10%. Only 1,009,250 shares remain beneath the present authorized ceiling. Hypothetical additional shares must carry proceeds and fees, not appear as free rescue capital. [FP, printed 67–84,F16]

## 10. Valuation and Market Expectations

Every figure in this section is conditional on the secondary INR 89.50 quote and the stated share/cash assumptions. The primary cutoff quote, current post-IPO balance and execution tape are not verified. A historical low P/E is not proof of a margin of safety.

{{VALUATION}}

The current-share FY26 P/E is the relevant post-IPO denominator, not INR 89.50 divided by pre-IPO EPS 10.33. Historical-cash EV intentionally excludes IPO cash because its actual deployment is unknown. Fee-adjusted pro forma book equity adds the disclosed INR 35.005 crore allocation, not gross INR 40.482 crore; unquantified extra issue-fee taxes remain a stated uncertainty. Neither that pro forma book value nor a historical FCF yield is a stand-alone fair value. The explicit cash model below provides the investment/funding bridge, with a DCF cross-check and economic peer comparisons rather than a fabricated peer-multiple average. [FP] [M1] [M2]

{{ASSUMPTIONS}}

The opening state combines March balances with hypothetically unspent IPO proceeds. The capex IPO pool of INR 14.7165 crore and working pool INR 14.25 crore are ring-fenced. Each project invoice separates its IPO component, internally funded civil-GST residual and any overrun. Civil GST may consume only modeled internal cash; permitted overrun may use only internal or general-purpose cash, not fresh-financing cash. Its source shortfall creates a separate retained funding failure. The offer document prohibits using any IPO proceeds, including general purposes, for adverse litigation or regulatory penalties. Each event therefore reconciles internal cash, IPO general cash, fresh-financing cash and a transient restricted-release bucket. Modeled adverse litigation/regulatory-outcome payments must debit internal cash only and fail permanently if insufficient, even when total cash is positive. Legacy non-IPO cash is an assumed internal-availability proxy, not verified bank provenance. [FP, printed 21,31,89,94–101] Legacy cash INR 7.9387 crore and general-purpose INR 6.0385 crore start available but remain separately tagged by provenance. Ordinary eligible costs first use paired restricted releases, then IPO general cash, fresh financing and internal cash; this preserves internal cash for expressly restricted obligations. The base assumes that lawful allocation is executed, not that bank segregation was independently verified. A separate internal-first policy stress tests the conservative alternative. Promoter repayments and dividends are also internal-only by conservative analyst choice, not an asserted blanket legal prohibition: the document allows loan repayment generally but qualifies promoter/group payments by normal-course/compliance conditions. No operating access is presumed to the INR 0.9463 crore FD. Every month orders cash events, pays capital before commissioning, restricts bank credit to a hypothetical borrowing base, rounds equity to whole shares, respects the authorized ceiling and retains any intra-month failure. The base settles callable promoter loans in month 18; the bear calls them immediately. No forecast assumes a promoter rescues the firm without terms.

{{CORE_MODEL}}

The base's {{BASE_IRR}} return does not need new bank/equity funding under these pro forma assumptions, but actual October cash could differ materially. At exit, INR {{BASE_WC_REMAIN}} crore of unspent working-purpose IPO pool remains excluded from realizable free cash in the base, by conservative model policy. The bullish path is a conditional scaling/margin illustration, not a probability forecast. The bearish equity path may accumulate apparent terminal wealth but still fails the continuation cash/FCFF test; ordinary IRR is therefore suppressed, not shown as an attractive return.

There are {{COUNTS}}. Every path includes all monthly and event-level ledgers plus a separately funded twelve-month terminal continuation. The continuation earns its physical and economic capital: additional NOPAT cannot be capitalized unless replacement, ONWC, reserves and required incremental capital have been funded. Its cash is not added to five-year investor wealth. The base sustainable continuation FCFF is INR {{BASE_FCFF}} crore. Failed paths also have null DCF/hurdle prices, not merely a warning next to a positive return.

{{STRESS}}

Hypothetical bank capacity is INR 5 crore, not an observed sanction. Equity is capped at INR 8 crore gross and current authorization, priced at max(INR 50, 80% of entry) with 4% costs, and prohibited after exit. The borrowing-base-collapse experiment deliberately tests mandatory paydown after collateral deteriorates; it is an adversarial model test, not a prediction. The FD-access case is similarly an assumption sensitivity, not a discovery that the deposit is unrestricted. Funding-policy sensitivities are not probability estimates. An internal-first failure can be avoidable under another lawful allocation; it is not proof of insolvency. The adversarial entry-legal case has positive total cash but insufficient internal cash and must fail rather than use IPO general proceeds. No new borrowing or share issue cures that eligibility failure. Earlier repayment may also change eligible working-pool use; such timing effects are not an intrinsic economic benefit from accelerating debt.

Two-way later tonne growth versus terminal multiple sensitivity:

{{GRID}}

DCF is a separate unlevered operating cross-check. It includes actual explicit capex and reserve needs, and capitalizes earned continuation FCFF, not accounting EBITDA. Incremental issue-fee tax and any entry-date legal payment are deducted once in DCF. Restricted IPO balances enter asset value only at the discounted date they are released for eligible use; unused trapped cash receives no default value. FD recovery is discounted to exit. The base current-share DCF diagnostic is INR {{BASE_DCF}}, with {{BASE_TERMINAL_FRACTION}} of enterprise present value from the terminal period, so discount/capital-return assumptions dominate. It is not a dilution-adjusted investor IRR or observable fair value.

{{DCF_GRID}}

The following are entry prices at which the rebuilt conditional base meets the alternative equity hurdles after execution costs. The model is rerun at each candidate price, because issue pricing could otherwise change dilution. These are assumption-dependent research levels, not executable limit orders or a promise that the underlying evidence is adequate.

{{HURDLES}}

Reverse expectations retain the full growth trials rather than displaying only a favorable solved case. Growth in this table is later annual tonnes, with first-year growth/price/margins held to the defined base assumptions; it is not the same as an unconstrained revenue CAGR.

{{REVERSE}}

## 11. Bear Case and Permanent-Loss Path

The strongest counterargument is not simply “small company” or “the IPO fell.” It is that the dramatic profit increase comes from a modestly growing, input-sensitive manufacturer whose receivable quality and supplier financing are weaker than the headline CFO suggests. The single most important thesis variable is cash collected per unit of genuinely saleable incremental output after supplier payments, replacement capex and all claims. If expansion creates more old receivables rather than recurring cash, the apparent extra capacity has little value per share.

A credible linked failure path is: input cost/mix normalizes unfavorably → margin narrows → dealers seek longer credit → aged debt grows while suppliers shorten terms → callable promoter loans and project overruns consume free cash → capex-specific funds cannot cure unrelated claims → hypothetical bank limits or authorized equity headroom become binding → diluted owners inherit weaker economics. A trademark injunction can add channel/recall disruption beyond the damages claim, although no adverse judgment is assumed. Existing investor quoted drawdown, inability to exit, funding breach and permanent loss of earning power are separate risks.

Illustrative recovery stress values cash, FD at 50%, receivables at 60%, inventory/PPE at 40%, then deducts 10% realization costs and source debt/trade/current claims plus assumed legal/employee payments. The two rows bracket unspent IPO availability; they are not probabilities or a verified current liquidation balance. Promoter land/IP are not counted as issuer-owned assets.

{{RECOVERY}}

Impairment risk is High on a conditional new-purchase basis: the adverse linked case can fail even after modeled financing, a large part of asset value is collections/stock rather than owned property, and a thinly verified exit cannot be assumed. Counterevidence is meaningful: diversified customers, interest-free sponsor loans, a fresh equity raise, genuine production, lower secured borrowing and a source-supported base that survives without fresh rescue. These positives justify continued research, not an unsupported allegation of insolvency or wrongdoing.

## 12. Five Times and Ten Times Feasibility

Business growth, EV, equity value and stock return must be separated. In a positive-earnings regime, price multiplication equals revenue multiplication × attributable net-margin change × original/diluted shares × exit/entry P/E. Dividends are separate. Here a simplistic EPS target is especially misleading because current margins, share issuance, restricted cash and funding needs can change together.

The algebraic diagnostic below assumes 12% operating margin, terminal EV/EBITDA 6x or 9x, no excess cash and no extra dilution only to establish a starting revenue/capacity burden. It then runs that required growth through the actual monthly cash/physical-capacity engine, including real modeled issuance and failures. The resulting ordinary price multiple can differ from the algebraic target; a failed case has no ordinary return. These particular equal-CAGR target paths require immediate first-year output beyond the initial 6,000-TPA cutting capacity before expansion commissions, and therefore fail in month 1. That is a path-specific ramp constraint, not proof that every phased 5x/10x route is impossible. The phased bullish ten-year case below is a counterexample under its more optimistic growth/margin assumptions, but not evidence those assumptions will occur. Required additional-capacity cost excludes the first 10,000 TPA already in the planned project but is not the full financing requirement: receivables, inventories, maintenance, reserves and claims must also be funded.

{{TARGETS}}

For perspective, 5x price needs roughly 38.0% annual growth over five years or 17.5% over ten; 10x needs 58.5% over five or 25.9% over ten. Those stock-return requirements do not create production demand or funding. The observed three-year sales CAGR is {{CAGR}}, physical output CAGR {{VOL_CAGR}}, and new-project returns remain unverified. A lower 6x exit multiple is explicitly retained rather than assuming perpetual re-rating.

{{TEN_YEAR}}

Classification: Speculative / unsupported as an evidence-backed 5x/10x thesis today. A cash-feasible long-duration scenario would still require sustained dealer demand, input spreads, collectible receivables, owned/secure operating rights and above-cost returns not demonstrated in the current record. No success probability is assigned. The upside diagnostic is not the investment verdict.

## 13. Monitoring Plan

This is a research monitoring plan, not an automated schedule or trading instruction. Thresholds are tied to the source baseline; an alert means investigate unless a thesis-break event is explicitly stated.

| KPI or event | Cutoff baseline | Milestone or expected range | Warning threshold | Thesis-break evidence | Review source/timing |
|---|---|---|---|---|---|
| IPO deployment and cash | Net 35.005 crore; actual unspent ND | Reconcile bank balances, fees, object-wise spending and commitments | Unexplained gap between proceeds and eligible spend/cash | Proven unauthorized material diversion or unfinanceable obligation | First post-IPO results/utilization filing |
| Effective cutting capacity | 6000 TPA,5257FY26output | Paid/installed/qualified 10000 TPA, statedFY27plan | Orders/installation drift without revised funded timetable | Added output cannot cover capital/working needs at realistic prices | Supplier invoices, commissioning proof, each half-year |
| Receivable quality |25.397 crore total;5.8402older 6months;3.7257older 1year | Collection and counterparty confirmation of aged buckets | Older 6 month balance grows faster than sales for two comparable periods | Material unprovided noncollection destroys proforma cash/funding | Ageing/receipts notes and debtor confirmations |
| Supplier finance |21.2985croreTP;1.0227older 3 years | Explain maturity and MSME identification; normalize terms | Unexplained extension beyond disclosed 50–70day terms or legal claims | Supply interruption/overdue obligations that cannot be paid | Ageing, supplier disputes and cash-flow bridge |
| Revenue versus margin |92.3192sales;13.77%YoY;11.17EBITDA | Separate sold volume, mix/input prices and inventory movements | Earnings accelerate while real volume/collections stagnate | Normalized EBITDA/cash falls below replacement and claims needs | Comparable annual/half-year statements |
| Restricted cash and bank headroom |FD0.9463; no verified undrawnCC | Lien/maturity letters and sanction/drawing-power evidence | Free-cash claim includes earmarked or unavailable balances | No lawful funding for a committed payment | Bank notes, use-of-proceeds and ratings if available |
| Promoter/group funding and RPTs |Callable loans 3.5231;RPdebtor 0.8470 | Written terms, repayments and receivable settlements | RP balances rise without ordinary commercial explanation | Substantiated minority-harming extraction or material undisclosed guarantee | RPT balances, board approvals and subsequent collections |
| Trademark/GST/operating rights |Contested 2.001damages claim;0.3201GSTnotice | Verified docket orders, responses and assignment completion | Adverse interim order or blocked dealer branding | Enforceable injunction/recall materially impairs continuing cash economics | Original court/issuer filings; stated 27Nov 2026hearing not assumed outcome |
| Financial-reliability gaps |Restated opinion only;employee/MSMEliabilityND | Obtain original annual audit/CARO/IFC and exact restatement bridge | Scope limitation, unexplained balances or inconsistent provisioning | Material unresolved reliability issue persists | Original signed annual filings and auditor annexures |
| Market execution |Secondary 89.50;1000historiclot;actualturnoverND | Official since-listing/20session values,spread,circuit,lot,lock-in | One-sided sessions,large spread orlot mismatch | Effective inability to execute/exit reference position | Exchange security master/tape, not a price-only aggregator |

## 14. Final Classification and Conditional Action

Final classification: Hold — unresolved / incomplete quality evidence. Action category: research watchlist pending evidence, not eligible for a favorable new-purchase conclusion. The matrix is subordinate to G2/G4 and missing CAP; no mathematical-bound midpoint is promoted to a BQS, GQS or IAS score. Even the upper current GQS bound is below the compounder threshold, and GOV/MOAT/REV/CAP criteria are not satisfied.

Price alone cannot clear the missing-evidence holds or improve BQS/GQS. A lower entry may improve a conditional return calculation, but official execution, cash availability and genuine incremental economics must be established first. Conversely, a verified governance failure, materially unreliable accounts or an actual funding default would change the gate/status, not merely lower a multiple. The presently available record supports neither “fraud” nor “safe compounder.”

For batch use, place this record in Pending evidence rather than the bottom of numeric quality rankings. It is not an overall SME winner/loser judgment. The same v 3.0 weights, common cutoff and one-decimal tie policy apply to scoreable records; this one has no point score to tie. No portfolio sale count, allocation or trade is inferred, and no Git publication or manifest change is part of this research artifact.

## 15. Sources, Assumptions and Open Questions

{{SOURCES}}

Primary source hierarchy is explicit: original offer documents and audited peer filings support historical facts; management statements support what was promised; secondary price histories only support a conditional quote. The issuer's investor-page file labelled IPO listing is actually a newspaper offer advertisement, not proof that listing completed. The corrected-cover final supersedes its earlier cover typo but not the identical financial appendix. The BSE original listing notice, official tape and later insider/price-clarification attachments were inaccessible; a 403 or cache miss is not zero trading or an adverse issuer fact.

Material open questions:

1. Obtain original FY23–FY26 statutory annual reports, audit/CARO/IFC annexures and signed restatement adjustments. Resolve the tax cash caption, noncash conversion presentation and small PAT reconciliation typo without silently rewriting primary numbers.
2. Reconcile actual net IPO receipts, invoiced fees, object-wise deployment, bank balances/earmarks and remaining commitments as of the cutoff. Establish whether the cash model's hypothetical unspent starting funds exist.
3. Establish incremental project revenue, contribution, collection needs and paid/commissioned capital with a seasoned cohort or credible unit-return bridge. Do not use the negative-IC historical endpoint or a tiny denominator to assign high CAP.
4. Confirm aged receivables, related-party collections, old supplier balances, MSME status/interest and employee-benefit obligations. Obtain FD maturity/lien and actual loan/drawing-power documents.
5. Verify trademark assignment, current court/GST status, postlisting capital/shareholding/lock-in/encumbrance, and official executable market tape. Secondary promoter-purchase snippets are not promoted into verified primary facts.

Definitions: CAGR uses actual positive annual endpoints; NOPAT uses operating EBIT at common 17.16% normalized tax, with 26%model sensitivity; CFO/PAT is a ratio of sums; FCF proxy is reportedCFO less cashoperatingcapex and is not FCFF; ROIC uses average defined operatingIC; nominal WACC is independent of the 15%equityhurdle. Maintenancespending, marginal capacity cost, timing, legal settlements, debt availability, equity pricing and terminalmultiple/growth are analyst assumptions, explicitly separated from historical facts. The scenario model is a decision diagnostic, not an estimate of precise future outcomes.

The complete source-linked input set, all generated ledgers, independent recurrence checker and sixteen quality checks are preserved in the source-safe research archives. The separate original documents are retained but not redistributed. Input fingerprint: {{INPUT_FP}}. Canonical compressed trace SHA256: {{TRACE_HASH}}. These are audit identifiers, not the report-file hash; company_record.json records the distinct report SHA256.
