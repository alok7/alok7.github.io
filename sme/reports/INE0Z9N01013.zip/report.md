# Sham Foam Limited SME research under Master Prompt v 3.0

Information cutoff: 20 October 2026, end of day Asia/Kolkata. Conditional price reference: INR 89.50, secondary close of 19 October 2026. All financial tables are INR crore unless expressly labelled otherwise. Prepared from dated primary records retrieved on 24 October 2026. Source limitations are part of the conclusion, not footnotes that can be ignored.

## 1. Executive Verdict

Sham Foam is principally a regional polyurethane-foam manufacturer selling through dealers, not a miniature pure-play branded mattress retailer. The strongest investment argument is an IPO-funded removal of cutting-machine bottlenecks, backed by an existing dealer network and a sharply improved FY26 operating result. The decisive counterargument is that the apparent earnings acceleration has outrun underlying revenue growth and demonstrably independent cash conversion: FY23–26 revenue CAGR is only 4.97%, FY26 cash flow relies heavily on increased supplier balances, and additional-capital returns cannot yet be scored. The business owns neither the factory land nor all claimed brand rights outright, and the trademark case is contested, not resolved. BQS, Growth Quality and IAS are NS for specified missing evidence, not low numerical substitutes. This is a conditional small-manufacturer expansion/special-situation thesis, not an evidence-backed compounder. At the secondary INR 89.50 reference, the source-linked pro forma base returns 11.90% after assumed execution costs, below the 15% hurdle, but it is not a live valuation recommendation. Original statutory audit/CARO/IFC records, post-IPO cash/deployment, project unit economics and executable market evidence could change the hold. [FP](https://shamfoam.com/custom/final_prospectus_10_aug.pdf) [DP](https://shamfoam.com/custom/investors/Draft%20Prospectus%20-%20Sham%20Foam%20Limited.pdf) [M1](https://www.equitypandit.com/historical-data/544869) [M2](https://anandrathi.com/stocks/sham-foam-ltd/share-price-history)

## 2. Research Header, Gates and Data Confidence

Exact issuer: Sham Foam Limited, formerly Sham Foam Private Limited, CIN U36104HR2020PLC087011, ISIN INE0Z9N01013. The original prospectus establishes the legal entity and security; listing discovery identifies BSE SME SHAMFOAM, scrip 544869, trading from 18 August 2026. Do not confuse it with Sheela Foam, its much larger competitor and litigation counterparty. Incorporated 26 June 2020; fresh public-company certificate dated 20 September 2024. The financial appendix contains an inconsistent conversion-date description, so the specific legal-history/certificate description controls, without hiding that discrepancy. The issuer has no disclosed subsidiary, associate or JV in the reviewed offer documents. Generic consolidated wording in MD&A does not create a second accounting perimeter. [FP](https://shamfoam.com/custom/final_prospectus_10_aug.pdf) [LIST](https://exchangecirculars.com/circulars/bse/2026/bse-2026-08-17-1d15949155cdd929-listing-of-equity-shares-of-sham-foam-limited/)

Scope is standalone Indian GAAP/Companies Accounting Standards, not assumed Ind AS. Year ends are 31 March. Historical annual statements available are restated FY23–FY26; separate original statutory annual reports, CARO annexures and IFC opinions were not retrieved despite targeted primary-source searches. The restatement report dated 27 July 2026 expressly is not a reissued previous audit opinion. The corrected-cover prospectus file still bears 5 August 2026; all 48 scanned financial pages are identical to the earlier final by page-image hash comparison. [FP](https://shamfoam.com/custom/final_prospectus_10_aug.pdf) [FPold](https://shamfoam.com/custom/investors/final_prospectus.pdf) [DP](https://shamfoam.com/custom/investors/Draft%20Prospectus%20-%20Sham%20Foam%20Limited.pdf)

Current assumed issued shares are 11,490,750 after 3,114,000 fresh IPO shares; authorized shares are 12,500,000. The prospectus and secondary listing notice agree on this capital arithmetic, but a cutoff-date original security master/share pattern was not verified. INR 89.50 is corroborated by two secondary histories, not an official executable close. The default horizon is five years, nominal equity hurdle 15% before personal tax, with 12%/18% sensitivities. WACC is separately assumed 14%–20%, not equated to the shareholder hurdle. Liquidity uses an illustrative INR 5 lakh position, not a recommended allocation. [FP](https://shamfoam.com/custom/final_prospectus_10_aug.pdf) [LIST](https://exchangecirculars.com/circulars/bse/2026/bse-2026-08-17-1d15949155cdd929-listing-of-equity-shares-of-sham-foam-limited/) [M1](https://www.equitypandit.com/historical-data/544869) [M2](https://anandrathi.com/stocks/sham-foam-ltd/share-price-history)

| Gate | Status | Reason |
|---|---|---|
| G1 | Conditional | Disclosure and no OFS counterbalance governance/control and related-party dependency risks. No substantiated diversion/manipulation or severe minority harm established. Trademark/tax claims are allegations, not adverse judgments. |
| G2 | Hold — unresolved | Restated statements read and source inconsistencies retained, but separate original statutory audit/CARO/IFC not retrieved; employee/MSME obligations unquantified, cash-flow classification/tax captions need reconciliation. Not an evidenced fraud finding. |
| G3 | Conditional | Proforma IPO-funded base passes; latest unspent cash, use-of-proceeds, callable promoter terms and bank capacity not verified. Model stress failure is conditional and does not prove an actual current unfinanceable obligation. |
| G4 | Hold — unresolved | Official cutoff tape and current lot/surveillance/exitcapacity absent; incomplete history not evidenced suspension or zero liquidity. |

| Subject | Confidence boundary |
|---|---|
| identity | High for issuer/ISIN in final prospectus; Medium for post-listing share state pending original exchange notice |
| historical_financials | Medium on restated FY23–26; original statutory audit/CARO/IFC absent |
| governance | Medium, short record and disclosed unresolved controls/legal issues |
| growth_decomposition | Medium on revenue and production; Low on true sold-volume/price/mix split |
| capital_returns | Low for incremental returns and post-IPO project economics |
| valuation_inputs | Low current cash/official price; conditional calculations accurately reproducible |
| overall | Low, weakest material capital/valuation evidence controls conclusion |

G2 and G4 are unresolved-evidence holds, not findings that the accounts are fraudulent or the security is suspended. G3 is conditional rather than an evidenced failure: a modeled cash shortfall under adverse assumptions is not proof of an actual current unfinanceable obligation. Evidence needed to clear each hold is listed in Sections 13 and 15.

## 3. Scorecard and Calculation Audit

| Measure | Raw point | Known contribution | Coverage | Mathematical bound | Final |
|---|---|---|---|---|---|
| BQS | NS | 3.540 | 88.00% | 3.660 – 4.740 | NS |
| GQS | NS | 2.950 | 85.00% | 3.100 – 4.450 | NS |
| IAS | NS | 0.600 | 20.00% | 1.400 – 8.600 | NS |

BQS coverage is 88%, GQS 85%, and IAS 20%. CAP is NS because the observed incremental-capital denominator is negative and no defensible project/cohort substitute is established. IAS lacks a numeric BQS as well as R, P and L. Its ordinary missing-data bound is mathematical, not a probability interval; using the BQS bound rather than allowing quality to range independently from 1 to 10 gives the narrower dependency-aware IAS bound 2.065 – 7.285, still not a point estimate or ranking. [FP](https://shamfoam.com/custom/final_prospectus_10_aug.pdf) [DP](https://shamfoam.com/custom/investors/Draft%20Prospectus%20-%20Sham%20Foam%20Limited.pdf)

| Factor | Score | Confidence | Evidence and counterevidence |
|---|---|---|---|
| GOV | 4 | Medium | Fresh-only IPO has no selling-shareholder cash-out. Promoter loans are disclosed and interest-free. Issuer discloses legal claims, related-party premises and repeated delayed filings rather than concealing these in the offer document. Contrary: Thirteen delayed ROC filings, past statutory-payment delays, incomplete MSME identification, no quantified employee benefit provision and brands/premises remaining related-party dependent are recurring stewardship weaknesses. Litigation is contested, not proven misconduct. [FP](https://shamfoam.com/custom/final_prospectus_10_aug.pdf) [DP](https://shamfoam.com/custom/investors/Draft%20Prospectus%20-%20Sham%20Foam%20Limited.pdf) |
| MOAT | 4 | Medium | More than 1,300 dealers and customers across 13 states support practical distribution access. Custom PU grades and proximity to regional furniture/mattress customers help fulfillment; top 10 customers only 25.06%. Contrary: PU foam is a contestable manufacturing product; top 10 suppliers 78.56%, monthly input pricing, no long-term contracts, leased premises and disputed/unassigned brand IP constrain durable bargaining power. [FP](https://shamfoam.com/custom/final_prospectus_10_aug.pdf) [P1](https://res.cloudinary.com/dduaiugsj/images/v1783938174/Annual-Report-2025-26_4250c389d/Annual-Report-2025-26_4250c389d.pdf?_i=AA) [P2](https://nsearchives.nseindia.com/corporate/WAKEFIT2025_21052026203139_Stockexchange.pdf) [P3](https://nsearchives.nseindia.com/corporate/WAKEFIT2025_28052026130007_Stockexchange.pdf) [P4](https://tirupatifoam.com/wp-content/uploads/2019/06/Annual-Report-2025-2026.pdf) |
| REV | 2 | Medium | Four comparable restated annual revenue observations FY23–26 give 3-year CAGR 4.9674537%, not the 11.8995% two-year rebound. FY25 andFY 26 grew 10.06% and 13.77%; production rose 4779 to 5257 tonnes inFY 26. Contrary: FY24 revenue contracted 7.63%; FY23–26 production CAGR only about 2.53%. Revenue per produced tonne is a mix/price proxy, not verified constant-price sold volume. [FP](https://shamfoam.com/custom/final_prospectus_10_aug.pdf) [DP](https://shamfoam.com/custom/investors/Draft%20Prospectus%20-%20Sham%20Foam%20Limited.pdf) |
| DUR | 5 | Medium | Approved IPO objects target cutting capacity 6000→10000 TPA within existing 15000 TPA foaming installation. Furniture, mattresses, apparel and industrial foam provide several customer applications with domestic regional expansion. Contrary: All proposed plant orders were unplaced at prospectus date; commissioning/customer conversion by cutoff unverified. Concentration in northern states and commodity competition constrain accessible runway; market-share/TAM denominator not verified. [FP](https://shamfoam.com/custom/final_prospectus_10_aug.pdf) |
| CAP | NS | Low | Historical EBIT improves sharply and FY26 average operating capital returns are high on the reconstructed asset base. Committed effective-capacity project and working-capital funding are identified in the IPO objects. Contrary: FY23–26 operating capital declines while NOPAT rises, so incremental-ROIC endpoint is NM. Profit expansion also reflects input/mix/inventory effects on old assets; no mature new-project or reliable cohort return disclosure substitutes. Five-year capital history and post-IPO deployment absent. [FP](https://shamfoam.com/custom/final_prospectus_10_aug.pdf) [DP](https://shamfoam.com/custom/investors/Draft%20Prospectus%20-%20Sham%20Foam%20Limited.pdf) |
| CASH | 4 | Medium | FY24–26 reported cumulative CFO/PAT 1.3353 and all three annual CFO positive. FY26 cash/current accounts 7.9387 crore and debt reduction are visible in primary restated accounts. Contrary: FY25 CFO 0.2164 crore againstPAT 3.5819; FY26 CFO 12.7771 includes 9.4959 crore supplier financing, and receivables older than 6 months 5.8402 crore. More than 3-year creditors 1.0227 crore and tax-caption ambiguity weaken sustainable realization. [FP](https://shamfoam.com/custom/final_prospectus_10_aug.pdf) [DP](https://shamfoam.com/custom/investors/Draft%20Prospectus%20-%20Sham%20Foam%20Limited.pdf) |
| BAL | 5 | Medium | March secured debt only 0.4677 crore; interest-free promoter loans 3.5231 crore disclosed. Fresh IPO net proceeds of 35.005 crore could support the full 15.3731 crore project and 14.25 crore working-capital allocation. The project includes 0.6566 crore internal funding beyond its 14.7165 crore IPO pool;6.0385 crore is originally allocated to general purposes. Contrary: Actual cutoff unspent proceeds unverified, allocations are not free operating cash, promoter debt is callable, and no sanctioned undrawn CC facility confirmed. Linked stress can exhaust cash and authorized equity capacity. [FP](https://shamfoam.com/custom/final_prospectus_10_aug.pdf) [LIST](https://exchangecirculars.com/circulars/bse/2026/bse-2026-08-17-1d15949155cdd929-listing-of-equity-shares-of-sham-foam-limited/) |
| EXEC | 5 | Medium | Production rose 4692→4779→5257 tonnes FY24–26, and revenue reached 92.3192 crore. Network expanded geographically;13 states served and new product/dealer applications disclosed. Contrary: The larger post-IPO project has not had an independently verified commission/utilization result by cutoff. All orders unplaced when prospectus signed; do not treat an unelapsed target as a proven miss. [FP](https://shamfoam.com/custom/final_prospectus_10_aug.pdf) [DP](https://shamfoam.com/custom/investors/Draft%20Prospectus%20-%20Sham%20Foam%20Limited.pdf) |
| EARN | 5 | Medium | FY26 PAT 8.6506 crore mainly accompanies operatingEBIT expansion; other income only 0.0679 crore. Current-share FY26 profit diagnostic improves materially after separating July 2024/July 2025 bonus shares from actual IPO issuance. Contrary: PAT rises 141.5% on 13.77% sales; FG/WIP inventory capitalization changes 5.8355 crore versus prior expense and input/mix economics unseparated. FY23 bad-debt recovery, tax advantage and non-cash loan conversion complicate comparability. [FP](https://shamfoam.com/custom/final_prospectus_10_aug.pdf) [DP](https://shamfoam.com/custom/investors/Draft%20Prospectus%20-%20Sham%20Foam%20Limited.pdf) |
| R | NS | Low | Conditional pro forma base monthly model is provided with 15% equity hurdle and 12%/18% sensitivity. No fresh-financing base case can be tested using source-defined IPO pools. Contrary: Actual post-IPO deployment/cash, current balance and primary valuation tape are unavailable; conditional modeled IRR is not a sufficiently established live prospective-return score. [FP](https://shamfoam.com/custom/final_prospectus_10_aug.pdf) [M1](https://www.equitypandit.com/historical-data/544869) [M2](https://anandrathi.com/stocks/sham-foam-ltd/share-price-history) |
| D | 3 | Medium | Proforma base survives without rescue while original assets/current cash and fresh IPO provide potential support. Related-party loans are interest-free; small secured debt limits lender priority relative to major debt-heavy peers. Contrary: Linked credit/margin/capex/legal stress fails even with capped bank/equity support or loses sustainable terminal cash; litigation injunction could impair brand sales beyond damages. Asset realizations are deeply assumption dependent. [FP](https://shamfoam.com/custom/final_prospectus_10_aug.pdf) |
| P | NS | Low | Two secondary sources corroborate 19 Octclose 89.50; explicit reverse revenue/multiple/DCF grids are retained. Fee-adjusted IPO equity and diluted common share count make conditional multiples reproducible. Contrary: No primary cutoff close/current cash confirmation; one-year peakish margin and restricted proceeds sharply change implied expectations. [M1](https://www.equitypandit.com/historical-data/544869) [M2](https://anandrathi.com/stocks/sham-foam-ltd/share-price-history) [FP](https://shamfoam.com/custom/final_prospectus_10_aug.pdf) |
| L | NS | Low | IPO lot 1000 and limited since-Augustlisting history disclosed; reference 5 lakh is quantized into 5 or 6 lots. Secondary 42 rowprice/volume history is preserved only as observations. Contrary: No actual exchange traded values/spreads/circuit/restriction verification;60 post-listing sessions unavailable. Missing rows/403 do not show zero trades; close×volume not turnover. [FP](https://shamfoam.com/custom/final_prospectus_10_aug.pdf) [LIST](https://exchangecirculars.com/circulars/bse/2026/bse-2026-08-17-1d15949155cdd929-listing-of-equity-shares-of-sham-foam-limited/) [M1](https://www.equitypandit.com/historical-data/544869) [M2](https://anandrathi.com/stocks/sham-foam-ltd/share-price-history) |

Exact unrounded Decimal contributions follow. The strings NS indicate missing contributions, not zeros; known contributions are sums of only scoreable original weights. The displayed mathematical lower and upper bounds insert 1 and 10 respectively for missing factors without redistributing any weight.

BQS: GOV × .20 = 0.800; MOAT × .20 = 0.800; REV × .12 = 0.240; DUR × .10 = 0.500; CAP × .12 = NS; CASH × .10 = 0.400; BAL × .08 = 0.400; EXEC × .08 = 0.400.

GQS: REV × .40 = 0.800; DUR × .20 = 1.000; EARN × .15 = 0.750; CAP × .15 = NS; CASH × .10 = 0.400.

IAS: BQS × .25 = NS; R × .35 = NS; D × .20 = 0.600; P × .10 = NS; L × .10 = NS.

There is no governance cap: GOV is 4 and G1 has not failed. There is no funding cap because G3 is not an evidenced failure. No Growth Quality cap is invoked: CASH is 4, while CAP is missing rather than ≤3. An aggregate NS stays NS even if a separate gate implies a hold. Moving MOAT and CASH by one point shifts the BQS bound by at most 0.30; CASH shifts GQS by 0.10. This is judgment sensitivity, not a new overall score. The canonical factors total thirteen: nine business/growth factors plus R/D/P/L. Historical short/medium-confidence factors cannot receive 9–10 merely because the company recently listed.

## 4. Business Overview

The factory produces flexible PU foam, customized densities/grades, quilting foam, mattresses, cushions and related comfort products. FY26 PU foam revenue was INR 79.601 crore, 86.22% of sales; mattresses INR 5.0038 crore, 5.42%; quilting foam INR 5.7886 crore, 6.27%. The remaining mix is not silently called a high-margin consumer brand. Foam serves mattress/furniture makers and apparel, sports, seat-cover and other industrial applications. Featherfresh and Restivia are marketed brands; certain finished pillows are sourced through job workers. [FP, printed 122–140](https://shamfoam.com/custom/final_prospectus_10_aug.pdf)

Management reports over 1,300 dealers across thirteen states/UTs and no owned retail stores. Eighty-five employees were reported in June 2026. The supplier base is concentrated in TDI/polyol and other material inputs with monthly price movements; a larger purchasing scale could improve terms but is not durable pricing power. Revenue is recognized under the disclosed risk-and-reward transfer policy, net of returns/taxes/discounts. Recognized sales are not cash collections, as INR 25.397 crore of receivables at March 2026 demonstrates. [FP, F7–F8, F29](https://shamfoam.com/custom/final_prospectus_10_aug.pdf)

The 204,460-square-foot premises are leased from promoters for thirty years from 1 August 2025, not owned by the issuer, and also secure company machinery borrowings. Registered/used trademarks remain dependent on promoter/relative ownership and NOCs while assignment applications are pending. These arrangements are disclosed and are not inherently abusive; nevertheless a buyer cannot include promoter land or unassigned IP as unencumbered shareholder-owned assets. [FP, printed 22,27–29](https://shamfoam.com/custom/final_prospectus_10_aug.pdf)

## 5. Moat and Industry Position

The proposed mechanism is regional distribution and fulfillment: existing dealers plus customized grades and proximity to furniture/mattress customers can reduce lead times and replacement friction. Evidence supports actual access and production, but not an exclusive channel or a structurally protected margin. Failure modes are input-price shocks, a rival's price/credit offer, dealer migration, logistics cost, brand restrictions and failure to service the higher volume after expansion. ISO/BIS certification and a promoter's distribution experience demonstrate capability, not a moat by themselves. For a capable entrant, the disclosed INR 15.3731 crore project adding 4,000 effective tonnes is only an order-of-magnitude plant-capital reference: it excludes a greenfield site, a new dealer network and customer acquisition. No source-backed replication timeline or quantified dealer-switching cost was established, so neither is invented as an entry barrier. [FP](https://shamfoam.com/custom/final_prospectus_10_aug.pdf)

Top-ten customers represent 25.06% of FY26 sales, down from 26.83% and 28.02%, a useful counterweight to single-customer risk. Top-ten suppliers represent 78.56%, compared with 78.31%/86.85%, leaving materially greater procurement concentration. There are no verified long-term dealer/supplier contracts. Supplier credit is generally described as 50–70 days, while the accounting payable-day proxies and aged balances deserve closer analysis. No reliable accessible-market-share denominator was obtained; a precise market-share gain is not asserted. [FP, printed 23,137–138](https://shamfoam.com/custom/final_prospectus_10_aug.pdf)

Three genuinely economic peers are used, with Sheela's two accounting scopes shown separately, not counted as two companies:

| Economic scope | FY26 sales | FY25 sales | FY26 PAT | FY26 CFO | Lease cash in financing | Key distinction |
|---|---|---|---|---|---|---|
| Sheela Foam consolidated | 3820.84 | 3439.2 | 159.61 | 409.32 | 55.24 | Stronger scale/brand benchmark,11,000 dealers and 5,500 brandoutlets. FY25 standalone includesrecast Kurlon; consolidatedJVprofit 21.39/exceptionalgain 7.93, leasecash 55.24. Not puredomesticmix. [P1](https://res.cloudinary.com/dduaiugsj/images/v1783938174/Annual-Report-2025-26_4250c389d/Annual-Report-2025-26_4250c389d.pdf?_i=AA) |
| Sheela Foam standalone with Kurlon restatement | 2962.27 | 2675.25 | 130.57 | 258.63 | 20.99 | Stronger scale/brand benchmark,11,000 dealers and 5,500 brandoutlets. FY25 standalone includesrecast Kurlon; consolidatedJVprofit 21.39/exceptionalgain 7.93, leasecash 55.24. Not puredomesticmix. [P1](https://res.cloudinary.com/dduaiugsj/images/v1783938174/Annual-Report-2025-26_4250c389d/Annual-Report-2025-26_4250c389d.pdf?_i=AA) |
| Wakefit Innovations standalone | 1488.943 | 1273.691 | 189.175 | 244.528 | 76.822 | Downstream consumer 61.4% mattress 29.3% furniture;139 stores 76 cities. PAT 98.071 croredeferredtaxcredit; reported PBT 91.104 farbelowPAT 189.175. IndAS 116 leasecash 76.822. [P2](https://nsearchives.nseindia.com/corporate/WAKEFIT2025_21052026203139_Stockexchange.pdf) |
| Tirupati Foam standalone | 95.0053 | 106.0263 | 1.9246 | 4.7352 | 0.2237 | Closest mix/scale:82.69% PUfoam,16.03% mattress/articles, allsalesdomestic. Revenue−10.39%, PATmargin 2.03%; interest 3.4919+lease.2237 financingcash. CFOlessinterest/lease/capex.0950=.9246. Proposed Noidaassetsale not recurring value. [P4](https://tirupatifoam.com/wp-content/uploads/2019/06/Annual-Report-2025-2026.pdf) |

Tirupati is the closest upstream mix/scale comparator and currently has weaker revenue and margins. Its CFO must be reduced for financing-classified interest and lease cash before comparing owner economics. Sheela is the stronger brand/distribution/scale benchmark; the FY26 report recasts FY25 standalone for Kurlon, so the old annual-report standalone revenue must not be mixed with the new perimeter. Wakefit is a downstream consumer/store comparator: its INR 189.175 crore FY26 PAT includes INR 98.071 crore deferred-tax credit against INR 91.104 crore PBT. Neither its headline P/E nor its pre-lease EBITDA can simply be imposed on Sham. No cutoff peer market multiples were verified, and no generic microcap P/E is used as intrinsic value. [P1](https://res.cloudinary.com/dduaiugsj/images/v1783938174/Annual-Report-2025-26_4250c389d/Annual-Report-2025-26_4250c389d.pdf?_i=AA) [P2](https://nsearchives.nseindia.com/corporate/WAKEFIT2025_21052026203139_Stockexchange.pdf) [P3](https://nsearchives.nseindia.com/corporate/WAKEFIT2025_28052026130007_Stockexchange.pdf) [P4](https://tirupatifoam.com/wp-content/uploads/2019/06/Annual-Report-2025-2026.pdf)

## 6. Revenue Growth and Scale

| FY | Revenue | Annual addition | YoY | Production tonnes | Revenue per produced tonne INR |
|---|---|---|---|---|---|
| 2023 | 79.82 | ND | ND | 4878 | 163638.79 |
| 2024 | 73.73 | -6.09 | -7.63% | 4692 | 157136.83 |
| 2025 | 81.15 | 7.42 | 10.06% | 4779 | 169801.63 |
| 2026 | 92.32 | 11.17 | 13.77% | 5257 | 175611.95 |

The preselected comparable window is FY23–FY26: INR 79.823 crore to INR 92.3192 crore over three actual year intervals, CAGR 4.97%. The two-year FY24 rebound is 11.90% and is disclosed for context, not selected to obtain a higher REV. A five-year CAGR requires six observations and a ten-year CAGR eleven; those series were not retrieved, so both are ND. The six months to September 2025 show revenue INR 37.868 crore, PAT INR 3.1939 crore and CFO INR 0.8067 crore, but the matching prior half-year and H1FY27 were not available; no TTM or seasonal annualization is manufactured. [DP, printed 56–59](https://shamfoam.com/custom/investors/Draft%20Prospectus%20-%20Sham%20Foam%20Limited.pdf) [FP, printed 49–52](https://shamfoam.com/custom/final_prospectus_10_aug.pdf)

FY23–FY26 production rises from 4,878 to 5,257 tonnes, CAGR 2.53%, while revenue per produced tonne increases at 2.38%. These factors algebraically bridge revenue, but production is not sold volume: inventory timing, quilting/mattress mix, scrap and pricing can alter the relationship. Management attributes FY26 growth to domestic demand, new dealers and regional expansion; these are attributed explanations, not a verified price/volume decomposition. No acquisition/disposal contribution was identified in the disclosed standalone perimeter. [FP](https://shamfoam.com/custom/final_prospectus_10_aug.pdf) [DP](https://shamfoam.com/custom/investors/Draft%20Prospectus%20-%20Sham%20Foam%20Limited.pdf)

FY26 Uttar Pradesh adds INR 7.9747 crore, Delhi 1.8614, Haryana 2.7517 and Maharashtra 1.4970, while Punjab declines 2.7012 crore. This is geographically uneven real scaling, not evidence that every served state accelerated. The four northern markets UP/Punjab/Haryana/Delhi together account for roughly 72.9% of FY26 sales. The new operating trajectory warrants attention, but the full-window schedule remains REV 2 with no extra small-base penalty or unsupported trajectory bonus. [FP, printed 197](https://shamfoam.com/custom/final_prospectus_10_aug.pdf)

## 7. Growth Quality and Reinvestment Runway

Effective annual cutting capacity is 6,000 tonnes and FY26 output 5,257, or 87.62%. The headline 15,000 TPA is a different foaming/nameplate denominator; its utilization is only 35.05%. Total estimated project spending of INR 15.3731 crore, comprising INR 14.7165 crore IPO funds and INR 0.6566 crore internal cash on the aggregate bridge, adds 4,000 effective cutting tonnes, bringing available capacity to 10,000 while the disclosed headline installation remains 15,000. The document's confusing expansion table is not read as another 15,000 TPA of new capacity. [FP, printed 30,87–95,140](https://shamfoam.com/custom/final_prospectus_10_aug.pdf)

The growth path requires customer demand, machinery orders, civil works, installation, staffing, stable foam quality and collections, not simply the capex cheque. All proposed machinery/construction orders were unplaced at signing. Funds were intended to be deployed in FY27, while working capital is INR 8.25 crore in FY27 and INR 6 crore in FY28/by June 2027. These dates were not yet all due at the research cutoff. No completed commissioning or actual unspent-proceeds statement was retrieved, so promised expansion is neither treated as achieved nor automatically called a miss. [FP, printed 42,85–96](https://shamfoam.com/custom/final_prospectus_10_aug.pdf)

The civil schedule specifically allocates INR 65.65 lakh GST to internal accruals; the total-project bridge implies 65.66 lakh, a 0.01-lakh source-rounding difference. The model conservatively funds 65.66 lakh internally. Machine GST is capitalized with no input credit claimed, so no automatic GST cash reimbursement is assumed. [FP, printed 88–89,94](https://shamfoam.com/custom/final_prospectus_10_aug.pdf)

The explicit model starts from 5,257 tonnes and uses scenario year-one/later tonne growth and pricing separately. Growth beyond the committed project requires more paid capacity and working capital. The implied marginal cost of INR 0.003843275 crore per tonne is an analyst extrapolation from the announced project, not an appraised cost curve. The source's demand narrative and dealer count do not establish a quantified accessible TAM. No export optionality, market-share gain or new customer contract is added without evidence.

Growth Quality is NS at 85% coverage. The missing CAP is decisive: high current ROIC on an old, small asset base with large supplier financing does not prove that the new INR 15.3731 crore project and incremental receivables will earn above a 14%–20% cost-of-capital range. The source does not supply mature cohorts, incremental unit cash economics or a project IRR that can repair the negative historical incremental-IC denominator. Financing and terminal earnings therefore remain explicitly conditional rather than deserving a high growth rating.

## 8. Management, Governance and Execution

Governance analysis does not infer fraud from SME status, family ownership, a fresh IPO or litigation. There was no OFS, and interest-free promoter funding and disclosed related-party terms are positive counterevidence. On the other hand, thirteen delayed ROC filings and statutory-payment delays constitute a recurring process weakness, not merely low disclosure volume. Management reports remediation and no show-cause proceedings on those filing delays at prospectus date; that does not prove all future exposures are eliminated. [FP, printed 30–33](https://shamfoam.com/custom/final_prospectus_10_aug.pdf)

The factory lease, trademarks and similarly engaged group entities create dependencies requiring commercial discipline. FY24 occupancy was rent-free, so later rental costs also affect historical operating comparability. A non-compete agreement with Aggarwal Comfort Products mitigates one overlap but is not a blanket elimination of group conflicts. The financial related-party debtor is separately named Aggarwal Comforts: FY26 related sales INR 0.3032 crore versus closing receivable INR 0.8470 crore, up from 0.6143/0.5663. Its age/collectibility should be confirmed. The near equality of that balance to the INR 0.8469 crore over-three-year receivable bucket is not proof that they are the same claim, so the stress model never double counts both. [FP, F42–F43](https://shamfoam.com/custom/final_prospectus_10_aug.pdf)

FY26 disclosed related-party loan repayments total INR 4.9345 crore, with no new related borrowing in the reviewed transaction table; INR 3.5231 crore remains owed to two promoters and is callable. Repayment is not itself diversion, but must be considered alongside supplier credit, IPO use restrictions and minority funding economics. Quoted IPO issue expenses are INR 5.477 crore, 13.53% of gross proceeds, expressly excluding GST and other taxes. The INR 35.005 crore net allocation is therefore offer-document arithmetic before unquantified extra taxes, not verified realized usable proceeds. The base assumes no incremental fee-tax cash charge only as an explicit conditional assumption; a separate stress pays INR 0.98586 crore, equal to an illustrative 18% of the quoted fee amount, without claiming that all charges attract that tax or that reimbursement is available. Share dilution bought less usable cash than gross issue size suggests. [FP, printed 85–99,F42–F43](https://shamfoam.com/custom/final_prospectus_10_aug.pdf)

Vijay Gupta & Jain are the restatement auditors and no statutory auditor change was reported for the last three years. The unmodified restated opinion is limited evidence of reliability, not a full independent inspection of all statutory audit/CARO/IFC vintages. F10's lack of gratuity/leave-encashment provisioning and unavailable MSME supplier status conflict with the simplistic interpretation of a nil MSME-dues table. Management states that no employee had completed five years of service and that no MSME-interest claims had been received. Those are relevant mitigating explanations, not proof of zero actuarial or statutory obligations. Quantified obligations are ND, not zero. [FP, F5–F10,F23,F47](https://shamfoam.com/custom/final_prospectus_10_aug.pdf)

| Date | Original commitment | Outcome by cutoff |
|---|---|---|
| 2020-06-26 | Incorporation and establish manufacturing [FP154–155] | Operations sinceFY 21, fouryear audited restated revenue history retrieved; long promoter distribution history is not sixyears of issueraccounts. |
| 2026-07-28 | Engineer-certified 5257 TPA output/6000 TPA effective capacity FY26 [FP30,140] | Certified reported metric; capacity calculation inputs not independently plant-inspected. |
| 2026-08-05 | 15.3731 crore total project, including 14.7165 crore IPO-funded capex, expands effective cutting capacity to 10000 TPA inFY 27 [FP85–95] | Funding plan and IPO terms known; no commissioning or use-of-proceeds proof by 20 Octcutoff. Not yet a proven missed FY27 deadline. |
| 2026-08-05 | Workingcapital 14.25 crore,8.25 FY27+6 FY28 by June 2027 [FP85–96] | Management cashconversion assumptions and marginbenefits not guaranteed;25.397 crore receivables require collection. |
| 2026-03 | Trademark assignment applications filed [FP27–29] | No completed issuerownership or courtclearance independently established bycutoff. |

The Sheela trademark action alleges passing off/infringement and seeks injunction/recall, accounts and INR 2.001 crore damages. Sham contests it; the prospectus stated a 27 November 2026 hearing, not an adjudicated outcome. July 2026 GST ITC notice of INR 0.320111423 crore is pending after response. The eleven cheque-dishonour proceedings are collection cases initiated by Sham, not criminal accusations against it. A promoter's personal land dispute is not silently added as issuer debt. No independent later court docket ruling was verified by cutoff. [FP, printed 208–214](https://shamfoam.com/custom/final_prospectus_10_aug.pdf)

## 9. Financial Forensics

| FY | Revenue | Material value added proxy | Operating EBITDA | EBIT | PAT | CFO | Cash capex | FCF proxy |
|---|---|---|---|---|---|---|---|---|
| 2023 | 79.82 | 5.24 | 1.39 | 0.64 | 0.70 | -3.99 | 0.38 | -4.37 |
| 2024 | 73.73 | 8.80 | 4.55 | 3.90 | 2.97 | 7.30 | 0.72 | 6.58 |
| 2025 | 81.15 | 11.94 | 4.84 | 4.18 | 3.58 | 0.22 | 0.31 | -0.09 |
| 2026 | 92.32 | 22.24 | 11.17 | 10.60 | 8.65 | 12.78 | 1.18 | 11.60 |

| FY | Equity | Debt | Free cash | FD excluded | Receivables | Inventory | Payables | PPE and intangible |
|---|---|---|---|---|---|---|---|---|
| 2023 | 1.71 | 18.40 | 1.42 | 0.01 | 14.70 | 6.55 | 5.19 | 4.73 |
| 2024 | 8.88 | 10.11 | 3.60 | 0.01 | 17.12 | 7.74 | 11.91 | 4.80 |
| 2025 | 12.46 | 9.22 | 2.54 | 0.01 | 21.90 | 7.28 | 11.80 | 4.45 |
| 2026 | 21.11 | 3.99 | 7.94 | 0.95 | 25.40 | 9.50 | 21.30 | 5.06 |

Historical figures above use final restated FY24–FY26 and the earlier draft for FY23. Gross profit is ND in a full compatible manufacturing-cost sense; the material value-added proxy subtracts material consumption and stock changes, but omits production payroll/overheads and must not be labelled reported gross margin. No exceptional items are reported in these P&Ls. Normalization below removes all other income after a common 17.16% tax as a conservative diagnostic, not a certified recurring-earnings estimate, since some rebates/FX may be operating. [FP](https://shamfoam.com/custom/final_prospectus_10_aug.pdf) [DP](https://shamfoam.com/custom/investors/Draft%20Prospectus%20-%20Sham%20Foam%20Limited.pdf)

| FY | EBITDA margin | Issuer after-bank-charge EBITDA | PAT margin | Conservative PAT ex all other income | Reported bonus-adjusted EPS | PAT/current shares diagnostic |
|---|---|---|---|---|---|---|
| 2023 | 1.74% | 1.34 | 0.87% | 0.11 | 0.84 | 0.61 |
| 2024 | 6.17% | 4.43 | 4.02% | 2.83 | 3.57 | 2.58 |
| 2025 | 5.96% | 4.69 | 4.41% | 3.19 | 4.28 | 3.12 |
| 2026 | 12.10% | 11.00 | 9.37% | 8.59 | 10.33 | 7.53 |

Operating EBITDA here adds all finance costs back to PBT and excludes other income. The issuer's EBITDA adds only interest-on-borrowings, leaving recurring bank/LC charges in costs: FY26 INR 10.9987 crore versus our INR 11.1695 crore. Both are shown, not silently mixed. Low coupon expense partly reflects interest-free promoter finance. FY26 reported PAT growth is 141.51%, versus sales 13.77%; the stock-cost swing from INR 3.2171 crore expense in FY25 to INR 2.6184 crore capitalization in FY26 contributes INR 5.8355 crore to the year-on-year cost bridge. This is normal cost matching in principle, but inventory existence/realizability and underlying input-price/mix effects need independent confirmation before treating the peak margin as permanent. [FP, printed 50,193,F28,F34–F40](https://shamfoam.com/custom/final_prospectus_10_aug.pdf)

Cumulative earnings-to-cash realization uses sums, never an average of annual ratios:

| Window | Sum CFO | Sum PAT | Ratio of sums | Sum capex | FCF |
|---|---|---|---|---|---|
| FY24_FY26 | 20.30 | 15.20 | 1.3353 | 2.20 | 18.10 |
| FY23_FY26 | 16.31 | 15.90 | 1.0261 | 2.58 | 13.73 |

FY26 CFO INR 12.7771 crore includes INR 9.4959 crore of increased trade payables. Removing that increase gives INR 3.2812 crore as a dependence diagnostic, not adjusted statutory CFO. FY24 likewise benefited from INR 6.724 crore of creditor expansion. FY25 CFO was just INR 0.2164 crore while receivables absorbed INR 4.782 crore. Capital spending affects investing cash and FCF; it does not explain weak CFO. [FP, printed 51](https://shamfoam.com/custom/final_prospectus_10_aug.pdf) [DP, printed 58](https://shamfoam.com/custom/investors/Draft%20Prospectus%20-%20Sham%20Foam%20Limited.pdf)

Three accounting distinctions are material:

- FY24 INR 4.2075 crore equity allotment was conversion of an existing loan. The cash-flow presentation shows both share/premium inflow and the matching debt decrease; subtracting the same noncash amount from both sides gives cash debt repayment INR 4.0871 crore rather than INR 8.2946 crore. Net financing cash remains negative INR 4.4027 crore after coupon interest. It was not an actual fresh-cash injection. [FP, printed 67–69,F16,52](https://shamfoam.com/custom/final_prospectus_10_aug.pdf)
- FY26 operating cash adds INR 0.4225 crore of income-tax payable increase and deducts INR 1.7817 crore labelled direct taxes paid, equal to current tax expense. The implied net cash tax differs from the caption; retain original CFO and the separate caption uncertainty rather than silently correct it. A sensitivity excluding the payable addition would reduce FY26 CFO by INR 0.4225 crore. [FP, F25,51](https://shamfoam.com/custom/final_prospectus_10_aug.pdf)
- Original-to-restated PAT in the reconciliation is INR 865.88/368.39/300.83 lakh to 865.08/358.19/296.64 lakh, but the main FY26 P&L repeatedly uses 865.06. The INR 0.02 lakh discrepancy is retained as a printing/reconciliation issue, not used to fabricate an exact bridge or allege material falsification. [FP, F11,F47](https://shamfoam.com/custom/final_prospectus_10_aug.pdf)

Receivables older than six months increase from INR 3.0848 to 4.6218 to 5.8402 crore. FY26 over-one-year receivables total INR 3.7257 crore, without a disclosed doubtful-debt provision. Payables older than three years are INR 1.0227 crore. These are collection/settlement risks even though management calls balances good and the dispute column nil. [FP, F23,F29](https://shamfoam.com/custom/final_prospectus_10_aug.pdf)

| FY | Average AR days | Inventory material-cost proxy days | Payables raw-purchase proxy days | CCC proxy |
|---|---|---|---|---|
| 2024 | 78.77 | 40.18 | 47.19 | 71.77 |
| 2025 | 87.75 | 39.61 | 62.96 | 64.41 |
| 2026 | 93.50 | 43.69 | 83.55 | 53.63 |

Days above use average opening/closing balances, not the year-end closing-balance shortcut. Receivable days use total sales as credit-sales proxy; inventory uses material consumption plus finished/WIP stock change; payable days use raw-material purchases. The resulting CCC is a labelled proxy with nonidentical economic denominators, not a precise cash cycle. Rising aged balances matter beyond a single ratio.

Invested capital is ONWC plus net PPE/intangibles and operating security deposits. ONWC includes receivables/inventory/other operating assets less supplier/other operating liabilities and trade deposits, excluding GST/current tax, cash, debt and financial FDs. The financing-side reconciliation is equity + gross debt + current tax payable + net deferred tax liability − free cash − FDs − excluded GST asset. Operating rent remains expensed consistently. [FP, F13–F34](https://shamfoam.com/custom/final_prospectus_10_aug.pdf) [DP, financial notes](https://shamfoam.com/custom/investors/Draft%20Prospectus%20-%20Sham%20Foam%20Limited.pdf)

| FY | ONWC | Asset IC | Financing IC | Residual lakh | ROIC | ROCE | ROE |
|---|---|---|---|---|---|---|---|
| 2023 | 13.90 | 18.68 | 18.68 | 0.010 | ND | ND | ND |
| 2024 | 11.02 | 15.87 | 15.87 | 0.000 | 18.71% | 22.58% | 56.03% |
| 2025 | 15.22 | 19.72 | 19.72 | 0.010 | 19.45% | 23.48% | 33.56% |
| 2026 | 11.98 | 17.09 | 17.09 | 0.000 | 47.70% | 57.59% | 51.53% |

| 3-year investment bridge | INR crore |
|---|---|
| three_year_delta_NOPAT | 8.25 |
| three_year_delta_IC | -1.59 |
| net_cash_capex_less_DA | 0.32 |
| ONWC_change | -1.92 |
| operating_deposit_change | 0.01 |
| investment_bridge_total | -1.59 |
| bridge_residual | 0.00 |
| two_year_delta_NOPAT | 5.55 |
| two_year_delta_IC | 1.23 |
| lagged_delta_NOPAT_FY24to26 | 5.55 |
| lagged_delta_IC_FY23to25 | 1.04 |

Negative FY23–FY26 incremental capital makes the endpoint ratio NM. The two-year and lagged numerator/denominator diagnostics are shown separately because their enormous apparent returns depend on a small denominator, margin recovery and supplier funding; they are not new-project IRRs. Net cash capex less depreciation plus ONWC and operating-deposit movements explains the capital change within disclosed rounding residual. A five-year incremental-return window is unavailable. CAP therefore remains NS rather than rewarding an accounting artifact.

March net cash excludes INR 0.9463 crore of FDs from operating liquidity. The FD may ultimately be available, but no maturity/lien proof was found, so access is a sensitivity. Debt totals INR 3.9908 crore, including INR 3.5231 crore callable promoter loans and INR 0.4677 crore secured debt by note arithmetic; a risk-text line says 0.4678, a retained rounding discrepancy. No current undrawn bank limit is verified. Income-tax payable INR 1.018 crore, legal risks and unquantified employee/MSME obligations prevent a casual debt-free characterization. [FP](https://shamfoam.com/custom/final_prospectus_10_aug.pdf)

Bonus-adjusted weighted EPS and current issued shares are distinct. The July 2024 44-for-1 and July 2025 1-for-50 bonuses are not dilution, while the fresh IPO increases shares from 8,376,750 to 11,490,750 and reduces old holders' percentage ownership by 27.10%. Only 1,009,250 shares remain beneath the present authorized ceiling. Hypothetical additional shares must carry proceeds and fees, not appear as free rescue capital. [FP, printed 67–84,F16](https://shamfoam.com/custom/final_prospectus_10_aug.pdf)

## 10. Valuation and Market Expectations

Every figure in this section is conditional on the secondary INR 89.50 quote and the stated share/cash assumptions. The primary cutoff quote, current post-IPO balance and execution tape are not verified. A historical low P/E is not proof of a margin of safety.

| Conditional measure and unit | Result |
|---|---|
| Price (INR/share) | 89.5000 |
| Market capitalization (crore) | 102.8422 |
| FY26 P/E, current shares (times) | 11.8884 |
| FY25 P/E, current shares (times) | 28.7116 |
| Misleading pre-IPO EPS P/E diagnostic (times) | 8.6667 |
| EV using historical cash, no IPO credit (crore) | 98.8943 |
| Historical-cash EV / FY26 EBITDA (times) | 8.8540 |
| Pro forma equity before extra fee taxes (crore) | 56.1192 |
| Pro forma price/book (times) | 1.8326 |
| Historical price/book (times) | 4.8708 |
| Historical FCF yield (percent) | 11.28% |
| EBIT/all finance costs (times) | 47.3228 |
| EBIT/coupon interest (times) | 199.2538 |
| Authorized share headroom (whole shares) | 1009250 |
| IPO percentage ownership dilution (percent) | 27.10% |
| Quoted IPO costs/gross proceeds (percent) | 13.53% |

The current-share FY26 P/E is the relevant post-IPO denominator, not INR 89.50 divided by pre-IPO EPS 10.33. Historical-cash EV intentionally excludes IPO cash because its actual deployment is unknown. Fee-adjusted pro forma book equity adds the disclosed INR 35.005 crore allocation, not gross INR 40.482 crore; unquantified extra issue-fee taxes remain a stated uncertainty. Neither that pro forma book value nor a historical FCF yield is a stand-alone fair value. The explicit cash model below provides the investment/funding bridge, with a DCF cross-check and economic peer comparisons rather than a fabricated peer-multiple average. [FP](https://shamfoam.com/custom/final_prospectus_10_aug.pdf) [M1](https://www.equitypandit.com/historical-data/544869) [M2](https://anandrathi.com/stocks/sham-foam-ltd/share-price-history)

| Case | Tonne growth first / later | Annual price proxy | Material cost ratio | AR / inventory / TP days | Commission month | Exit EBITDA multiple |
|---|---|---|---|---|---|---|
| bear | -12.00% / 2.00% | -1.00% | 82.00% | 135 / 65 / 40 | 13 | 6 |
| base | 5.00% / 8.00% | 1.00% | 77.00% | 100 / 50 / 60 | 7 | 9 |
| bull | 8.00% / 18.00% | 2.00% | 74.00% | 90 / 45 / 70 | 4 | 12 |

The opening state combines March balances with hypothetically unspent IPO proceeds. The capex IPO pool of INR 14.7165 crore and working pool INR 14.25 crore are ring-fenced. Each project invoice separates its IPO component, internally funded civil-GST residual and any overrun. Civil GST may consume only modeled internal cash; permitted overrun may use only internal or general-purpose cash, not fresh-financing cash. Its source shortfall creates a separate retained funding failure. The offer document prohibits using any IPO proceeds, including general purposes, for adverse litigation or regulatory penalties. Each event therefore reconciles internal cash, IPO general cash, fresh-financing cash and a transient restricted-release bucket. Modeled adverse litigation/regulatory-outcome payments must debit internal cash only and fail permanently if insufficient, even when total cash is positive. Legacy non-IPO cash is an assumed internal-availability proxy, not verified bank provenance. [FP, printed 21,31,89,94–101](https://shamfoam.com/custom/final_prospectus_10_aug.pdf) Legacy cash INR 7.9387 crore and general-purpose INR 6.0385 crore start available but remain separately tagged by provenance. Ordinary eligible costs first use paired restricted releases, then IPO general cash, fresh financing and internal cash; this preserves internal cash for expressly restricted obligations. The base assumes that lawful allocation is executed, not that bank segregation was independently verified. A separate internal-first policy stress tests the conservative alternative. Promoter repayments and dividends are also internal-only by conservative analyst choice, not an asserted blanket legal prohibition: the document allows loan repayment generally but qualifies promoter/group payments by normal-course/compliance conditions. No operating access is presumed to the INR 0.9463 crore FD. Every month orders cash events, pays capital before commissioning, restricts bank credit to a hypothetical borrowing base, rounds equity to whole shares, respects the authorized ceiling and retains any intra-month failure. The base settles callable promoter loans in month 18; the bear calls them immediately. No forecast assumes a promoter rescues the firm without terms.

| Path | Funding / capacity / terminal | Exit-year sales | EBITDA | Fresh equity | Shares | Exit INR | Net IRR |
|---|---|---|---|---|---|---|---|
| bear_none | FAIL cash m2 | 83.63 | 1.79 | 0.00 | 11490750 | SUPPRESSED | SUPPRESSED |
| bear_bank | FAIL cash m3 | 83.63 | 1.79 | 0.00 | 11490750 | SUPPRESSED | SUPPRESSED |
| bear_equity | FAIL cash m3 | 83.63 | 1.79 | 6.70 | 12426469 | SUPPRESSED | SUPPRESSED |
| base_none | Conditional pass | 138.61 | 16.43 | 0.00 | 11490750 | 160.21 | 11.90% |
| base_bank | Conditional pass | 138.61 | 16.43 | 0.00 | 11490750 | 160.21 | 11.90% |
| base_equity | Conditional pass | 138.61 | 16.43 | 0.00 | 11490750 | 160.21 | 11.90% |
| bull_none | Conditional pass | 213.42 | 36.99 | 0.00 | 11490750 | 445.28 | 37.29% |
| bull_bank | Conditional pass | 213.42 | 36.99 | 0.00 | 11490750 | 445.28 | 37.29% |
| bull_equity | Conditional pass | 213.42 | 36.99 | 0.00 | 11490750 | 445.28 | 37.29% |

The base's 11.90% return does not need new bank/equity funding under these pro forma assumptions, but actual October cash could differ materially. At exit, INR 14.25 crore of unspent working-purpose IPO pool remains excluded from realizable free cash in the base, by conservative model policy. The bullish path is a conditional scaling/margin illustration, not a probability forecast. The bearish equity path may accumulate apparent terminal wealth but still fails the continuation cash/FCFF test; ordinary IRR is therefore suppressed, not shown as an attractive return.

There are 75 paths, including 18 failed paths. Every path includes all monthly and event-level ledgers plus a separately funded twelve-month terminal continuation. The continuation earns its physical and economic capital: additional NOPAT cannot be capitalized unless replacement, ONWC, reserves and required incremental capital have been funded. Its cash is not added to five-year investor wealth. The base sustainable continuation FCFF is INR 10.07 crore. Failed paths also have null DCF/hurdle prices, not merely a warning next to a positive return.

| Path | Funding / capacity / terminal | Exit-year sales | EBITDA | Fresh equity | Shares | Exit INR | Net IRR |
|---|---|---|---|---|---|---|---|
| stress_collections | Conditional pass | 138.61 | 16.43 | 0.00 | 11490750 | 153.96 | 11.01% |
| stress_supplier_credit | Conditional pass | 138.61 | 16.43 | 0.00 | 11490750 | 156.80 | 11.42% |
| stress_capex_delay | Conditional pass | 138.61 | 16.43 | 0.00 | 11490750 | 156.19 | 11.33% |
| stress_margin | Conditional pass | 138.61 | 6.73 | 0.00 | 11490750 | 60.58 | -7.88% |
| stress_promoter_call | Conditional pass | 138.61 | 16.43 | 0.00 | 11490750 | 162.30 | 12.19% |
| stress_legal | Conditional pass | 138.61 | 16.43 | 0.00 | 11490750 | 159.47 | 11.80% |
| stress_cash_unavailable | Conditional pass | 138.61 | 16.43 | 3.45 | 11972016 | 147.42 | 10.05% |
| stress_tax | Conditional pass | 138.61 | 16.43 | 0.00 | 11490750 | 155.60 | 11.25% |
| stress_combined | FAIL cash m3 | 138.61 | 6.73 | 7.23 | 12500000 | SUPPRESSED | SUPPRESSED |
| stress_terminal_capital | Conditional pass | 138.61 | 16.43 | 0.00 | 11490750 | 142.80 | 9.36% |
| stress_terminal_margin | Conditional pass | 138.61 | 16.43 | 0.00 | 11490750 | 73.36 | -4.28% |
| stress_terminal_demand | Conditional pass | 138.61 | 16.43 | 0.00 | 11490750 | 160.21 | 11.90% |
| stress_distribution | Conditional pass | 138.61 | 16.43 | 0.00 | 11490750 | 141.40 | 13.30% |
| stress_no_postexit_bank | Conditional pass | 138.61 | 16.43 | 0.00 | 11490750 | 160.21 | 11.90% |
| stress_FD_free_sensitivity | Conditional pass | 138.61 | 16.43 | 0.00 | 11490750 | 160.45 | 11.94% |
| stress_internal_first | FAIL project_internal_funding m4 | 138.61 | 16.43 | 0.00 | 11490750 | SUPPRESSED | SUPPRESSED |
| stress_IPO_fee_tax | Conditional pass | 138.61 | 16.43 | 0.00 | 11490750 | 159.70 | 11.83% |
| stress_legal_provenance | FAIL legal_funding m0 | 138.61 | 16.43 | 0.00 | 11490750 | SUPPRESSED | SUPPRESSED |
| stress_borrowing_base_collapse | FAIL cash m3 | 83.63 | 1.79 | 6.70 | 12426469 | SUPPRESSED | SUPPRESSED |

Hypothetical bank capacity is INR 5 crore, not an observed sanction. Equity is capped at INR 8 crore gross and current authorization, priced at max(INR 50, 80% of entry) with 4% costs, and prohibited after exit. The borrowing-base-collapse experiment deliberately tests mandatory paydown after collateral deteriorates; it is an adversarial model test, not a prediction. The FD-access case is similarly an assumption sensitivity, not a discovery that the deposit is unrestricted. Funding-policy sensitivities are not probability estimates. An internal-first failure can be avoidable under another lawful allocation; it is not proof of insolvency. The adversarial entry-legal case has positive total cash but insufficient internal cash and must fail rather than use IPO general proceeds. No new borrowing or share issue cures that eligibility failure. Earlier repayment may also change eligible working-pool use; such timing effects are not an intrinsic economic benefit from accelerating debt.

Two-way later tonne growth versus terminal multiple sensitivity:

| Later annual tonne growth | 6x exit IRR | 9x exit IRR | 12x exit IRR |
|---|---|---|---|
| 2.00% | -0.44% | 5.49% | 10.32% |
| 6.00% | 3.32% | 9.82% | 15.06% |
| 10.00% | 6.92% | 13.93% | 19.55% |
| 15.00% | 10.95% | 18.63% | 24.71% |
| 20.00% | 14.38% | 22.79% | 29.37% |

DCF is a separate unlevered operating cross-check. It includes actual explicit capex and reserve needs, and capitalizes earned continuation FCFF, not accounting EBITDA. Incremental issue-fee tax and any entry-date legal payment are deducted once in DCF. Restricted IPO balances enter asset value only at the discounted date they are released for eligible use; unused trapped cash receives no default value. FD recovery is discounted to exit. The base current-share DCF diagnostic is INR 55.16, with 95.48% of enterprise present value from the terminal period, so discount/capital-return assumptions dominate. It is not a dilution-adjusted investor IRR or observable fair value.

| WACC | g2% DCF INR | g4% DCF INR | g6% DCF INR |
|---|---|---|---|
| 12.00% | 77.67 | 84.68 | 95.63 |
| 16.00% | 53.44 | 55.16 | 57.19 |
| 20.00% | 40.27 | 40.58 | 40.76 |

The following are entry prices at which the rebuilt conditional base meets the alternative equity hurdles after execution costs. The model is rerun at each candidate price, because issue pricing could otherwise change dilution. These are assumption-dependent research levels, not executable limit orders or a promise that the underlying evidence is adequate.

| Hurdle | Rebuilt entry INR | Verified IRR | Fixed point |
|---|---|---|---|
| 12.00% | 89.11 | 12.00% | True |
| 15.00% | 78.07 | 15.00% | True |
| 18.00% | 68.64 | 18.00% | True |

Reverse expectations retain the full growth trials rather than displaying only a favorable solved case. Growth in this table is later annual tonnes, with first-year growth/price/margins held to the defined base assumptions; it is not the same as an unconstrained revenue CAGR.

| Later annual tonne growth | IRR | Cash/capacity feasible |
|---|---|---|
| 0.00% | 3.23% | True |
| 5.00% | 8.76% | True |
| 10.00% | 13.93% | True |
| 15.00% | 18.63% | True |
| 20.00% | 22.79% | True |
| 25.00% | 27.12% | True |
| 30.00% | 30.63% | True |
| 40.00% | SUPPRESSED | False |
| 50.00% | SUPPRESSED | False |

## 11. Bear Case and Permanent-Loss Path

The strongest counterargument is not simply “small company” or “the IPO fell.” It is that the dramatic profit increase comes from a modestly growing, input-sensitive manufacturer whose receivable quality and supplier financing are weaker than the headline CFO suggests. The single most important thesis variable is cash collected per unit of genuinely saleable incremental output after supplier payments, replacement capex and all claims. If expansion creates more old receivables rather than recurring cash, the apparent extra capacity has little value per share.

A credible linked failure path is: input cost/mix normalizes unfavorably → margin narrows → dealers seek longer credit → aged debt grows while suppliers shorten terms → callable promoter loans and project overruns consume free cash → capex-specific funds cannot cure unrelated claims → hypothetical bank limits or authorized equity headroom become binding → diluted owners inherit weaker economics. A trademark injunction can add channel/recall disruption beyond the damages claim, although no adverse judgment is assumed. Existing investor quoted drawdown, inability to exit, funding breach and permanent loss of earning power are separate risks.

Illustrative recovery stress values cash, FD at 50%, receivables at 60%, inventory/PPE at 40%, then deducts 10% realization costs and source debt/trade/current claims plus assumed legal/employee payments. The two rows bracket unspent IPO availability; they are not probabilities or a verified current liquidation balance. Promoter land/IP are not counted as issuer-owned assets.

| Cash availability stress | Gross assets | Claims | Equity residual | Per share | Price downside |
|---|---|---|---|---|---|
| IPO_available | 64.48 | 30.62 | 27.41 | 23.85 | -73.35% |
| IPO_unavailable | 29.47 | 30.62 | 0.00 | 0.00 | -100.00% |

Impairment risk is High on a conditional new-purchase basis: the adverse linked case can fail even after modeled financing, a large part of asset value is collections/stock rather than owned property, and a thinly verified exit cannot be assumed. Counterevidence is meaningful: diversified customers, interest-free sponsor loans, a fresh equity raise, genuine production, lower secured borrowing and a source-supported base that survives without fresh rescue. These positives justify continued research, not an unsupported allegation of insolvency or wrongdoing.

## 12. Five Times and Ten Times Feasibility

Business growth, EV, equity value and stock return must be separated. In a positive-earnings regime, price multiplication equals revenue multiplication × attributable net-margin change × original/diluted shares × exit/entry P/E. Dividends are separate. Here a simplistic EPS target is especially misleading because current margins, share issuance, restricted cash and funding needs can change together.

The algebraic diagnostic below assumes 12% operating margin, terminal EV/EBITDA 6x or 9x, no excess cash and no extra dilution only to establish a starting revenue/capacity burden. It then runs that required growth through the actual monthly cash/physical-capacity engine, including real modeled issuance and failures. The resulting ordinary price multiple can differ from the algebraic target; a failed case has no ordinary return. These particular equal-CAGR target paths require immediate first-year output beyond the initial 6,000-TPA cutting capacity before expansion commissions, and therefore fail in month 1. That is a path-specific ramp constraint, not proof that every phased 5x/10x route is impossible. The phased bullish ten-year case below is a counterexample under its more optimistic growth/margin assumptions, but not evidence those assumptions will occur. Required additional-capacity cost excludes the first 10,000 TPA already in the planned project but is not the full financing requirement: receivables, inventories, maintenance, reserves and claims must also be funded.

| Target / years / exit multiple | Algebraic sales at12%margin | Required revenue CAGR | Required tonnes | Further capacity cost | Actual shares | Cash-funded ordinary price multiple |
|---|---|---|---|---|---|---|
| 5x / 5y / 6x | 714.18 | 50.56% | 40668 | 117.87 | 12500000 | FAIL m1 |
| 5x / 5y / 9x | 476.12 | 38.83% | 27112 | 65.77 | 12500000 | FAIL m1 |
| 10x / 5y / 6x | 1428.36 | 72.95% | 81336 | 274.17 | 12500000 | FAIL m1 |
| 10x / 5y / 9x | 952.24 | 59.47% | 54224 | 169.97 | 12500000 | FAIL m1 |
| 5x / 10y / 6x | 714.18 | 22.70% | 40668 | 117.87 | 11637856 | FAIL m1 |
| 5x / 10y / 9x | 476.12 | 17.83% | 27112 | 65.77 | 11490750 | FAIL m1 |
| 10x / 10y / 6x | 1428.36 | 31.51% | 81336 | 274.17 | 12500000 | FAIL m1 |
| 10x / 10y / 9x | 952.24 | 26.28% | 54224 | 169.97 | 12500000 | FAIL m1 |

For perspective, 5x price needs roughly 38.0% annual growth over five years or 17.5% over ten; 10x needs 58.5% over five or 25.9% over ten. Those stock-return requirements do not create production demand or funding. The observed three-year sales CAGR is 4.97%, physical output CAGR 2.53%, and new-project returns remain unverified. A lower 6x exit multiple is explicitly retained rather than assuming perpetual re-rating.

| Path | Funding / capacity / terminal | Exit-year sales | EBITDA | Fresh equity | Shares | Exit INR | Net IRR |
|---|---|---|---|---|---|---|---|
| bear_10year | FAIL cash m3 | 87.81 | -0.38 | 7.23 | 12500000 | SUPPRESSED | SUPPRESSED |
| base_10year | Conditional pass | 214.05 | 26.98 | 0.00 | 11490750 | 293.72 | 12.39% |
| bull_10year | Conditional pass | 539.08 | 102.73 | 0.00 | 11490750 | 1268.22 | 30.10% |

Classification: Speculative / unsupported as an evidence-backed 5x/10x thesis today. A cash-feasible long-duration scenario would still require sustained dealer demand, input spreads, collectible receivables, owned/secure operating rights and above-cost returns not demonstrated in the current record. No success probability is assigned. The upside diagnostic is not the investment verdict.

## 13. Monitoring Plan

This is a research monitoring plan, not an automated schedule or trading instruction. Thresholds are tied to the source baseline; an alert means investigate unless a thesis-break event is explicitly stated.

| KPI or event | Cutoff baseline | Milestone or expected range | Warning threshold | Thesis-break evidence | Review source/timing |
|---|---|---|---|---|---|
| IPO deployment and cash | Net 35.005 crore; actual unspent ND | Reconcile bank balances, fees, object-wise spending and commitments | Unexplained gap between proceeds and eligible spend/cash | Proven unauthorized material diversion or unfinanceable obligation | First post-IPO results/utilization filing |
| Effective cutting capacity | 6000 TPA,5257FY26output | Paid/installed/qualified 10000 TPA, statedFY27plan | Orders/installation drift without revised funded timetable | Added output cannot cover capital/working needs at realistic prices | Supplier invoices, commissioning proof, each half-year |
| Receivable quality |25.397 crore total;5.8402older 6months;3.7257older 1year | Collection and counterparty confirmation of aged buckets | Older 6 month balance grows faster than sales for two comparable periods | Material unprovided noncollection destroys proforma cash/funding | Ageing/receipts notes and debtor confirmations |
| Supplier finance |21.2985croreTP;1.0227older 3 years | Explain maturity and MSME identification; normalize terms | Unexplained extension beyond disclosed 50–70day terms or legal claims | Supply interruption/overdue obligations that cannot be paid | Ageing, supplier disputes and cash-flow bridge |
| Revenue versus margin |92.3192sales;13.77%YoY;11.17EBITDA | Separate sold volume, mix/input prices and inventory movements | Earnings accelerate while real volume/collections stagnate | Normalized EBITDA/cash falls below replacement and claims needs | Comparable annual/half-year statements |
| Restricted cash and bank headroom |FD0.9463; no verified undrawnCC | Lien/maturity letters and sanction/drawing-power evidence | Free-cash claim includes earmarked or unavailable balances | No lawful funding for a committed payment | Bank notes, use-of-proceeds and ratings if available |
| Promoter/group funding and RPTs |Callable loans 3.5231;RPdebtor 0.8470 | Written terms, repayments and receivable settlements | RP balances rise without ordinary commercial explanation | Substantiated minority-harming extraction or material undisclosed guarantee | RPT balances, board approvals and subsequent collections |
| Trademark/GST/operating rights |Contested 2.001damages claim;0.3201GSTnotice | Verified docket orders, responses and assignment completion | Adverse interim order or blocked dealer branding | Enforceable injunction/recall materially impairs continuing cash economics | Original court/issuer filings; stated 27Nov 2026hearing not assumed outcome |
| Financial-reliability gaps |Restated opinion only;employee/MSMEliabilityND | Obtain original annual audit/CARO/IFC and exact restatement bridge | Scope limitation, unexplained balances or inconsistent provisioning | Material unresolved reliability issue persists | Original signed annual filings and auditor annexures |
| Market execution |Secondary 89.50;1000historiclot;actualturnoverND | Official since-listing/20session values,spread,circuit,lot,lock-in | One-sided sessions,large spread orlot mismatch | Effective inability to execute/exit reference position | Exchange security master/tape, not a price-only aggregator |

## 14. Final Classification and Conditional Action

Final classification: Hold — unresolved / incomplete quality evidence. Action category: research watchlist pending evidence, not eligible for a favorable new-purchase conclusion. The matrix is subordinate to G2/G4 and missing CAP; no mathematical-bound midpoint is promoted to a BQS, GQS or IAS score. Even the upper current GQS bound is below the compounder threshold, and GOV/MOAT/REV/CAP criteria are not satisfied.

Price alone cannot clear the missing-evidence holds or improve BQS/GQS. A lower entry may improve a conditional return calculation, but official execution, cash availability and genuine incremental economics must be established first. Conversely, a verified governance failure, materially unreliable accounts or an actual funding default would change the gate/status, not merely lower a multiple. The presently available record supports neither “fraud” nor “safe compounder.”

For batch use, place this record in Pending evidence rather than the bottom of numeric quality rankings. It is not an overall SME winner/loser judgment. The same v 3.0 weights, common cutoff and one-decimal tie policy apply to scoreable records; this one has no point score to tie. No portfolio sale count, allocation or trade is inferred, and no Git publication or manifest change is part of this research artifact.

## 15. Sources, Assumptions and Open Questions

| ID | Date | Source and location | Boundary |
|---|---|---|---|
| FP | 2026-08-05 | [Final prospectus preferred corrected cover version](https://shamfoam.com/custom/final_prospectus_10_aug.pdf); Printed 21–42,49–52,67–99,122–140,154–155,188, F 1–F 48,189–214 | Offer-document restated accounts, not original annual/CARO/IFC. Retrieved after cutoff; date and financial page equality checked. Claims of future capacity are management estimates. |
| FPold | 2026-08-05 | [Final prospectus earlier cover version](https://shamfoam.com/custom/investors/final_prospectus.pdf); Same financial pagesF 1–F 48 | Only front two pages differ. Corrected version controls front-cover terms; older premium typo not used. |
| DP | 2026-02-23 | [Draft prospectus FY23–25 and H1FY26 vintage](https://shamfoam.com/custom/investors/Draft%20Prospectus%20-%20Sham%20Foam%20Limited.pdf); Printed 56–59 and financial appendix; production/risks | Earlier vintage suppliesFY 23 and interim; not an original standalone statutory annual report. |
| LIST | 2026-08-17 | [Listing notice discovery and original link](https://exchangecirculars.com/circulars/bse/2026/bse-2026-08-17-1d15949155cdd929-listing-of-equity-shares-of-sham-foam-limited/); Listing summary and originalBSE 20260817-50 link | Original https://www.bseindia.com/downloads/UploadDocs/Notices/20260817-50/20260817-50.pdf returned 403. Listing summary corroborates final prospectus expected 11,490,750 shares,1000 lot; current master unverified. |
| M1 | 2026-10-19 | [Secondary historical price observations](https://www.equitypandit.com/historical-data/544869); Cutoff row; later rows quarantined | ₹89.50 close corroborated but no official turnover/spread data. Sources may share upstream feeds; never treat as independent official quotes. |
| M2 | 2026-10-19 | [Secondary historical price observations](https://anandrathi.com/stocks/sham-foam-ltd/share-price-history); Cutoff row; later rows quarantined | ₹89.50 close corroborated but no official turnover/spread data. Sources may share upstream feeds; never treat as independent official quotes. |
| P1 | 2026-05-14 | [Sheela Foam FY26 annual report](https://res.cloudinary.com/dduaiugsj/images/v1783938174/Annual-Report-2025-26_4250c389d/Annual-Report-2025-26_4250c389d.pdf?_i=AA); PDF 124/126 standalone;210/213 group;192 merger;13 positioning | Statement signaturedate; source published beforecutoff. FY25 standalone recast, IndAS 116 lease cash financing and JV/exceptional effects require bridge. |
| P2 | 2026-05-21 | [Wakefit audited annual exchange results](https://nsearchives.nseindia.com/corporate/WAKEFIT2025_21052026203139_Stockexchange.pdf); PDF 5 P&L,7 cash flow,8 scope/tax | Not original full annual report. PATincludes 98.071 crore deferred-tax credit, materialleases; no subsidiaries/JV/associate. |
| P3 | 2026-05-28 | [Wakefit FY26 results call](https://nsearchives.nseindia.com/corporate/WAKEFIT2025_28052026130007_Stockexchange.pdf); PDF 3–4 | Management attribution for 139 stores/categorymix, not independent audited segmentation. |
| P4 | 2026-07-20 | [Tirupati Foam FY26 annual report](https://tirupatifoam.com/wp-content/uploads/2019/06/Annual-Report-2025-2026.pdf); PDF 69 P&L,71 CF,98 productmix,93 borrowings | Audited statements 29 May 2026; Board report 20 July. Old uploadfolder notreportdate. Auditedtax/PAT override Board narrative typos. |

Primary source hierarchy is explicit: original offer documents and audited peer filings support historical facts; management statements support what was promised; secondary price histories only support a conditional quote. The issuer's investor-page file labelled IPO listing is actually a newspaper offer advertisement, not proof that listing completed. The corrected-cover final supersedes its earlier cover typo but not the identical financial appendix. The BSE original listing notice, official tape and later insider/price-clarification attachments were inaccessible; a 403 or cache miss is not zero trading or an adverse issuer fact.

Material open questions:

1. Obtain original FY23–FY26 statutory annual reports, audit/CARO/IFC annexures and signed restatement adjustments. Resolve the tax cash caption, noncash conversion presentation and small PAT reconciliation typo without silently rewriting primary numbers.
2. Reconcile actual net IPO receipts, invoiced fees, object-wise deployment, bank balances/earmarks and remaining commitments as of the cutoff. Establish whether the cash model's hypothetical unspent starting funds exist.
3. Establish incremental project revenue, contribution, collection needs and paid/commissioned capital with a seasoned cohort or credible unit-return bridge. Do not use the negative-IC historical endpoint or a tiny denominator to assign high CAP.
4. Confirm aged receivables, related-party collections, old supplier balances, MSME status/interest and employee-benefit obligations. Obtain FD maturity/lien and actual loan/drawing-power documents.
5. Verify trademark assignment, current court/GST status, postlisting capital/shareholding/lock-in/encumbrance, and official executable market tape. Secondary promoter-purchase snippets are not promoted into verified primary facts.

Definitions: CAGR uses actual positive annual endpoints; NOPAT uses operating EBIT at common 17.16% normalized tax, with 26%model sensitivity; CFO/PAT is a ratio of sums; FCF proxy is reportedCFO less cashoperatingcapex and is not FCFF; ROIC uses average defined operatingIC; nominal WACC is independent of the 15%equityhurdle. Maintenancespending, marginal capacity cost, timing, legal settlements, debt availability, equity pricing and terminalmultiple/growth are analyst assumptions, explicitly separated from historical facts. The scenario model is a decision diagnostic, not an estimate of precise future outcomes.

The complete source-linked input set, all generated ledgers, independent recurrence checker and sixteen quality checks are preserved in the source-safe research archives. The separate original documents are retained but not redistributed. Input fingerprint: 920026cd2ee667f7ef61adbf30bf7dee3683492b91b3fac6cd1a9d45fef67945. Canonical compressed trace SHA256: 1e46632de5e30ccce94d1ddb15def7bc14823933cd43c4bdb364544fc0849870. These are audit identifiers, not the report-file hash; company_record.json records the distinct report SHA256.
