# Sham Foam Limited SME research

Information cutoff 20 October 2026, end of day Asia/Kolkata; conditional market reference 19 October 2026. ISIN INE0Z9N01013; BSE SME SHAMFOAM 544869. Start with report.md. This is equity research, not a trade instruction or an allocation recommendation.

This source-safe package contains authored evidence extracts, source URLs and original-document hashes, explicit assumptions and deterministic calculations. Original PDFs, OCR, images, downloaded HTML, private research and transfer helpers are retained separately. They are excluded from both delivered archives and are not runtime dependencies.

Run python build.py followed by python verify.py. In a fresh, isolated extraction, run python guarded_rebuild.py --clean. The compact archive contains every declared authored input; the full archive additionally contains generated outputs and attestations. The guard poisons and removes only the explicit generated inventory in that isolated recovery copy, then rebuilds all outputs and both attestations while blocking undeclared reads, network and subprocess use. Report bytes and authored-input aggregate fingerprint have separate hashes.

Important: CAP is unscored because observed incremental capital contracts and no reliable project/cohort substitute is available. BQS and Growth Quality are therefore NS, not estimated midpoints. IAS is also NS. A historical restatement audit is not a complete original statutory audit/CARO/IFC review. Conditional monthly scenarios are based on historical cash plus hypothetical unspent IPO proceeds, not an observed October balance sheet. All failed paths are retained and ordinary returns are suppressed.
