"""Independent recovery checks: streamed model recurrence, scores, history, claims and output binding.
No producer calculations are used; build is imported solely for declared file inventories.
"""
from pathlib import Path
from decimal import Decimal as D, getcontext
from copy import deepcopy
import json, hashlib, re, csv
import model_audit
P=Path(__file__).resolve().parent
T=D('1e-20'); checks=0

def rd(n):return json.loads((P/n).read_text())
def H(n):
 h=hashlib.sha256()
 with (P/n).open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
def ok(c,label):
 global checks
 checks+=1
 assert c,label

def same(a,b,label='Decimal equality'):
 ok(a is not None and abs(D(str(a))-D(str(b)))<=T,(label,a,b))

def score_check(s,j):
 F=j['factors'];ok(set(F)==set('GOV MOAT REV DUR CAP CASH BAL EXEC EARN R D P L'.split()),'13 canonical factors')
 W={'BQS':{'GOV':'.20','MOAT':'.20','REV':'.12','DUR':'.10','CAP':'.12','CASH':'.10','BAL':'.08','EXEC':'.08'},'GQS':{'REV':'.40','DUR':'.20','EARN':'.15','CAP':'.15','CASH':'.10'},'IAS':{'BQS':'.25','R':'.35','D':'.20','P':'.10','L':'.10'}}
 finals={};bounds={}
 for name,w in W.items():
  q=s['composites'][name];ok(q['weights']==w,name+' exact weights');same(sum(D(v)for v in w.values()),1)
  vals={k:(finals['BQS']if k=='BQS'else F[k]['score'])for k in w};coverage=sum((D(v)for k,v in w.items()if vals[k]is not None),D(0));known=sum((D(v)*D(str(vals[k]))for k,v in w.items()if vals[k]is not None),D(0));point=known if coverage==1 else None
  same(q['coverage'],coverage);same(q['known_contribution'],known)
  for k,v in w.items():
   if vals[k]is None:ok(q['contributions'][k]is None,'NS contribution '+k)
   else:same(q['contributions'][k],D(v)*D(str(vals[k])))
  lo=known+1-coverage;hi=known+10*(1-coverage);bounds[name]=(lo,hi)
  same(q['raw_bounds'][0],lo);same(q['raw_bounds'][1],hi)
  gf=(F['GOV']['score']is not None and F['GOV']['score']<=3)or j['gates']['G1']['status'].startswith('Fail');ff=j['gates']['G3']['status'].startswith('Fail');cf=any(F[k]['score']is not None and F[k]['score']<=3 for k in('CAP','CASH'))
  cap=D(3)if (gf and name in('BQS','IAS'))or(ff and name=='IAS')else D(5)if cf and name=='GQS'else None
  if cap is None:ok(q['cap']is None,'No unsupported cap')
  else:same(q['cap'],cap)
  final=None if point is None else min(point,cap)if cap is not None else point
  if name=='IAS'and any(j['gates'][g]['status'].startswith(('Hold','Fail'))for g in('G2','G4')):final=None
  finals[name]=final
  if point is None:ok(q['raw_point']is None,'Raw NS retained')
  else:same(q['raw_point'],point)
  if final is None:ok(q['final_point']is None and q['display']=='NS','Final NS retained')
  else:same(q['final_point'],final)
  for a,b in zip(q['final_bounds'],(lo,hi)):same(a,min(b,cap)if cap is not None else b)
 same(s['composites']['IAS']['dependency_aware_bounds'][0],D(str(F['D']['score']))*D('.2')+D('.25')*bounds['BQS'][0]+D('.55'))
 same(s['composites']['IAS']['dependency_aware_bounds'][1],D(str(F['D']['score']))*D('.2')+D('.25')*bounds['BQS'][1]+D('5.5'))
 ok(s['overrides']==j['overrides']==[],'No hidden overrides')
 for k,v in F.items():ok(v['positive'] and v['contrary'] and v['source_ids'] and v['confidence'],'Evidence and counterevidence '+k)


def history_check(m,f,i):
 rows={x['year']:x for x in f['history']};derived={x['year']:x for x in m['history']};ok(set(rows)==set(range(2023,2027)),'Four comparable annual vintages')
 ic={};np={};wc={}
 for y,r in rows.items():
  q=derived[y];d=lambda k:D(str(r[k]));ebit=d('pbt')+d('finance_cost')-d('other_income');ebitda=ebit+d('da');nopat=ebit*D('.8284');onwc=d('AR')+d('inventory')+d('other_CA')-d('nonoperating_current_tax_GST_asset')-d('TP')-d('other_CL')-d('trade_deposit');asset=onwc+d('PPE')+d('intangibles')+d('other_NCA')-d('FD');fin=d('equity')+d('gross_debt')+d('tax_payable')+d('DTL')-d('free_cash')-d('FD')-d('nonoperating_current_tax_GST_asset');ic[y]=asset;np[y]=nopat;wc[y]=onwc
  for k,v in {'EBIT':ebit,'EBITDA':ebitda,'NOPAT':nopat,'ONWC':onwc,'IC_asset':asset,'IC_financing':fin,'IC_residual_lakh':asset-fin,'FCF_proxy':d('cfo')-d('cash_capex'),'EPS_reported_recalculated':d('pat')*100000/r['diluted_weighted_shares_bonus_adjusted'],'PAT_per_current_share':d('pat')*100000/i['shares'],'conservative_normalized_PAT':d('pat')-d('other_income')*D('.8284')}.items():same(q[k],v,str(y)+k)
  ok(abs(asset-fin)<=D('.03'),'Balance-sheet source rounding bounded')
  if y-1 in rows:same(q['ROIC'],nopat/((asset+ic[y-1])/2));same(q['ROCE'],ebit/((asset+ic[y-1])/2))
 for label,ys in [('FY24_FY26',[2024,2025,2026]),('FY23_FY26',[2023,2024,2025,2026])]:
  c=sum(D(rows[y]['cfo'])for y in ys);p=sum(D(rows[y]['pat'])for y in ys);cap=sum(D(rows[y]['cash_capex'])for y in ys)
  for k,v in {'CFO_lakh':c,'PAT_lakh':p,'CFO_PAT':c/p,'cash_capex_lakh':cap,'FCF_lakh':c-cap}.items():same(m['cash_conversion'][label][k],v)
 cagr=(D(rows[2026]['revenue'])/D(rows[2023]['revenue']))**(D(1)/3)-1;same(m['growth']['three_year_CAGR'],cagr);ok(cagr<D('.05'),'REV strictly below 5 percent, not rounded up')
 same(m['incremental']['three_year_delta_IC'],ic[2026]-ic[2023]);same(m['incremental']['three_year_delta_NOPAT'],np[2026]-np[2023]);ok(ic[2026]-ic[2023]<0 and m['incremental']['three_year_proxy']is None,'Negative incremental denominator NM')
 same(m['incremental']['net_cash_capex_less_DA'],sum(D(rows[y]['cash_capex'])-D(rows[y]['da'])for y in(2024,2025,2026)));same(m['incremental']['ONWC_change'],wc[2026]-wc[2023])


VERIFIED_URLS = ['https://anandrathi.com/stocks/sham-foam-ltd/share-price-history', 'https://api.bseindia.com/BseIndiaAPI/api/StockReachGraph/w?scripcode=544869&flag=0&fromdate=20260818&todate=20261019&seriesid=', 'https://exchangecirculars.com/circulars/bse/2026/bse-2026-08-17-1d15949155cdd929-listing-of-equity-shares-of-sham-foam-limited/', 'https://nsearchives.nseindia.com/corporate/WAKEFIT2025_21052026203139_Stockexchange.pdf', 'https://nsearchives.nseindia.com/corporate/WAKEFIT2025_28052026130007_Stockexchange.pdf', 'https://res.cloudinary.com/dduaiugsj/images/v1783938174/Annual-Report-2025-26_4250c389d/Annual-Report-2025-26_4250c389d.pdf?_i=AA', 'https://shamfoam.com/custom/final_prospectus_10_aug.pdf', 'https://shamfoam.com/custom/investors/Draft%20Prospectus%20-%20Sham%20Foam%20Limited.pdf', 'https://shamfoam.com/custom/investors/final_prospectus.pdf', 'https://tirupatifoam.com/wp-content/uploads/2019/06/Annual-Report-2025-2026.pdf', 'https://www.bseindia.com/download/BhavCopy/Equity/BhavCopy_BSE_CM_0_0_0_20261019_F_0000.CSV', 'https://www.bseindia.com/downloads/UploadDocs/Notices/20260817-50/20260817-50.pdf', 'https://www.equitypandit.com/historical-data/544869']

def url_check(text, label):
 found=re.findall(r"https://[A-Za-z0-9][^\s<>\"'\)\]]*",text)
 for value in found:
  value=value.rstrip('.,;')
  ok(value in VERIFIED_URLS,'URL differs from original-source inventory: '+label+' '+value)
 return found

def verify():
 global checks
 checks=0;model_audit.checks=0;getcontext().prec=44
 import build
 getcontext().prec=44
 i=rd('model_inputs.json');s=rd('scores.json');m=rd('metrics.json');r=rd('company_record.json');j=rd('judgments.json');f=rd('financial_inputs.json');market=rd('market_extract.json');src=rd('source_inputs.json');ms=rd('model_summary.json')
 score_check(s,j);history_check(m,f,i)
 ok(j['factors']['CAP']['score']is None and j['factors']['REV']['score']==2,'CAP NS / REV 2')
 ok(r['ISIN']==market['ISIN']=='INE0Z9N01013'and r['position']==360,'Issuer and list position');ok(r['segment']=='SME'and r['framework']=='v3.0','Segment framework')
 ok(all(r[k]is None for k in('BQS','GQS','IAS'))and not any(r['ranking_eligible'].values()),'No NS ranking');ok(market['official_close']is None and market['current_lot']is None,'Missing executable market evidence retained');ok(all(x['date']<='2026-10-19'for x in market['observed_secondary_rows']),'Market cutoff enforced')
 same(D(market['secondary_close'])*i['shares']/10000000,m['valuation']['market_cap']);same(m['valuation']['P_E_FY26_current_shares'],D(m['valuation']['market_cap'])/(D(f['history'][-1]['pat'])/100));same(m['valuation']['equity_headroom'],1009250)
 receipts=[];summaries={};reference=failed=financed=cure=legal_path=fee_path=overrun_path=None;annual_rows={ (x['path_id'],int(x['year'])):x for x in csv.DictReader((P/'annual_model.csv').open()) };csv_paths={x['path_id']:x for x in csv.DictReader((P/'trial_index.csv').open())};summary_by={x['path_id']:x for x in ms['paths']}
 for path in model_audit.readpaths(P/'canonical_paths.json.gz'):
  receipt=model_audit.audit(path,i);q=path['summary'];pid=q['path_id'];ok(pid not in summaries,'No duplicate path');summaries[pid]=q;receipts.append(receipt);ok(summary_by[pid]==q,'Canonical summary matches generated index');ok(csv_paths[pid]['failed']==str(q['failed']),'CSV failure state')
  if reference is None and not q['failed']:reference=path
  if failed is None and q['failed']:failed=path
  if financed is None and any(e.get('issued',0)>0 for e in path['events']):financed=path
  if cure is None and receipt['borrowing_base_cures_required']:cure=path
  if pid=='stress_legal_provenance':legal_path=path
  if pid=='stress_IPO_fee_tax':fee_path=path
  if overrun_path is None and any(D(e.get('project_overrun_component','0'))>0 and D(e['provenance_after']['cash_financing'])>D('.01')for e in path['events']+path['continuation_events']):overrun_path=path
  for year in range(1,q['years']+1):
   rr=[x for x in path['monthly']if x['year']==year];row=annual_rows[(pid,year)]
   for k in('revenue','tonnes','EBITDA','EBIT','NOPAT','PAT','CFO_before_financing_interest','capex','committed_capex','growth_capex','replacement_capex','dividend'):same(row[k],sum(D(x[k])for x in rr),pid+' annual '+k)
   for out,key in [('closing_cash','closing_cash'),('closing_debt','closing_debt'),('closing_shares','closing_shares'),('IPO_WC_remaining','ipo_working')]:same(row[out],rr[-1][key])
 inventory=model_audit.check_inventory(summaries,i);ok(len(receipts)==r['model_paths']==ms['count']==len(summary_by)==len(csv_paths),'Complete trace inventory');ok(sum(q['failed']for q in summaries.values())==ms['failed']==r['failed_paths'],'Failed inventory')
 for row in ms['reverse']['hurdles']:
  q=summaries[row['path_id']];ok(not q['failed'] and row['fixed_point_pass'],'Hurdle rerun feasible');same(row['entry'],q['entry_price']);same(row['IRR'],q['IRR']);ok(abs(D(row['IRR'])-D(row['hurdle']))<D('1e-14'),'Hurdle realized')
 for row in ms['reverse']['reverse_growth_grid']:
  q=summaries[row['path_id']];ok(row['IRR']==q['IRR']and row['failed']==q['failed'],'Reverse grid actual path')
 for row in ms['reverse']['multibagger_targets']:
  q=summaries[row['path_id']];req=D(i['entry_price'])*row['target']*i['shares']/10000000/D(row['exit_multiple'])/D('.12');same(row['required_revenue_at12pct_margin'],req);same(row['required_revenue_CAGR'],(req/D(i['opening']['revenue']))**(D(1)/row['years'])-1);ok(row['actual_ending_shares']==q['ending_shares']and row['failed']==q['failed'],'Target financing path')
  if q['failed']:ok(row['actual_ordinary_price_multiple']is None,'Failed target suppressed')
  else:same(row['actual_ordinary_price_multiple'],D(q['terminal_price'])/D(i['entry_price']))
 replay_checks=model_audit.checks;mutations=model_audit.mutation_tests(reference,failed,i,financed,cure,legal_path,fee_path,overrun_path);model_mutation_count=len(mutations)
 def reject(label,fn):
  try:fn()
  except(AssertionError,KeyError,ValueError,TypeError)as error:mutations.append({'mutation':label,'rejected':True,'detected_at':str(error)[:240]})
  else:raise AssertionError('Mutation escaped: '+label)
 bad=deepcopy(s);bad['composites']['BQS']['coverage']='1';reject('score_missingness_reweighting',lambda:score_check(bad,j))
 bad=deepcopy(s);bad['composites']['IAS']['final_point']='3';reject('NS_replaced_with_cap',lambda:score_check(bad,j))
 bad=deepcopy(m);bad['cash_conversion']['FY23_FY26']['CFO_lakh']=str(D(bad['cash_conversion']['FY23_FY26']['CFO_lakh'])+D('797.16'));reject('historical_CFO_sign',lambda:history_check(bad,f,i))
 bad=dict(summaries);del bad['base_none'];reject('missing_canonical_path',lambda:model_audit.check_inventory(bad,i))
 report=(P/'report.md').read_text();ok(re.findall(r'^## (\d+)\. ',report,re.M)==[str(x)for x in range(1,16)],'15 substantive sections');ok('{{'not in report,'No unexpanded report');ok(len(re.findall(r'^\d+\. ',(P/'quality_checks.md').read_text(),re.M))==16,'16 quality checks');ok(r['report_sha256']==H('report.md'),'Report byte hash')
 reject('report_byte_hash',lambda:ok(hashlib.sha256((report+'MUTATION').encode()).hexdigest()==r['report_sha256'],'Report altered'))
 expected=[{'path':n,'sha256':H(n)}for n in build.INPUTS];ok(r['authored_file_bindings']==expected,'Every authored input bound');fingerprint=hashlib.sha256(''.join(x['path']+'\0'+x['sha256']+'\n'for x in expected).encode()).hexdigest();ok(r['authored_aggregate_fingerprint']==fingerprint and fingerprint!=r['report_sha256'],'Aggregate and report hashes distinct')
 source_ids={x['id']for x in src['sources']};ok(len(source_ids)==len(src['sources']),'Unique source IDs');ok(all(set(x['source_ids'])<=source_ids|{x['id']for x in i['assumption_evidence']}|{'MODEL','CALC'}for x in j['factors'].values()),'Source factors resolve')
 for source in src['sources']:
  ok(source['url'].startswith('https://')and source['limitation'],'Source URL and scope limit');
  if 'sha256'in source:ok(re.fullmatch('[a-f0-9]{64}',source['sha256'])is not None and source['bytes']>0,'Original receipt format')
 url_count=0
 for name in build.INPUTS+['report.md','source_map.md','evidence_ledger.json','limitations.json']:
  url_count+=len(url_check((P/name).read_text(),name))
 reject('URL_whitespace_corruption',lambda:url_check(next(v for v in VERIFIED_URLS if '/UploadDocs/'in v).replace('UploadDocs','Upload Docs'),'adversarial source link'))
 result={'verified_distinct_source_urls':len(VERIFIED_URLS),'url_occurrences_checked':url_count,'status':'PASS','independent_model_recurrence':True,'producer_imported_by_independent_model_audit':False,'precision':44,'absolute_tolerance':str(T),'paths':len(receipts),'required_named_paths':inventory,'checks':checks+model_audit.checks,'replay_checks':replay_checks,'model_mutations':model_mutation_count,'mutations':mutations,'report_sha256':H('report.md'),'canonical_sha256':H('canonical_paths.json.gz'),'authored_aggregate_fingerprint':fingerprint,'output_hashes':{n:H(n)for n in build.OUTPUTS},'path_receipts':receipts,'limits':'Arithmetic and reconstruction verified, not a substitute for inaccessible primary records or assumptions becoming facts.'}
 (P/'verification.json').write_text(json.dumps(result,indent=2)+'\n');return result
if __name__=='__main__':
 r=verify();print(json.dumps({k:v for k,v in r.items()if k not in('path_receipts','output_hashes','mutations')}))
