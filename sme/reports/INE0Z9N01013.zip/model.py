"""Purpose-restricted monthly physical-capacity and shareholder cash model.
All quantities use Decimal. Public inputs contain no raw-source dependencies.
A failed path remains serialized and never yields an ordinary investor return.
"""
from decimal import Decimal as D,getcontext,ROUND_CEILING,ROUND_FLOOR
from datetime import date
from copy import deepcopy
getcontext().prec=36
Z=D(0);O=D(1);CR=D(10000000);EPS=D('1e-24')
def dec(x):return {k:D(str(v)) for k,v in x.items()}
def ceil(x):return int(x.to_integral_value(rounding=ROUND_CEILING))
def floor(x):return int(x.to_integral_value(rounding=ROUND_FLOOR))
def clean(x):
 if isinstance(x,D):return str(x)
 if isinstance(x,dict):return {k:clean(v)for k,v in x.items()}
 if isinstance(x,(list,tuple)):return [clean(v)for v in x]
 return x
def dt(m):return date(2026+(9+m)//12,(9+m)%12+1,19).isoformat()
def onwc(s):return s['AR']+s['inventory']+s['other_CA']-s['TP']-s['other_CL']
def irr(cfs):
 lo=D('-.999');hi=D('10')
 def f(r):return sum((x/(O+r)**(D(k)/12) for k,x in enumerate(cfs)),Z)
 if f(lo)*f(hi)>0:return None
 for _ in range(150):
  mid=(lo+hi)/2
  if f(mid)>0:lo=mid
  else:hi=mid
 return (lo+hi)/2
class Engine:
 def __init__(self,i):self.i=i;self.paths={}
 def run(self,pid,scenario='base',mode='none',years=5,overrides=None,entry=None):
  i=self.i;a=dec({**i['common'],**i['scenarios'][scenario],**(overrides or{})});f=dec(i['funding']);o=dec(i['opening']);N=12*years;tax=D(str((overrides or{}).get('tax',i['tax'])));entry=D(str(entry or i['entry_price']));s=deepcopy(o)
  s['cash']=o['cash']*a['opening_cash_fraction']+o['ipo_general']*a['ipo_available_fraction'];s['ipo_capex']*=a['ipo_available_fraction'];s['ipo_working']*=a['ipo_available_fraction'];s['cash']+=s['FD']*a['FD_access'];s['FD']*=O-a['FD_access'];s['shares']=i['shares'];s['equity_gross']=Z;s['CC_draws']=Z;s['equity_fees']=Z;s['bank_fees']=Z;s['minimum_cash']=s['cash'];s['failed']=False;s['cash_internal']=o['cash']*a['opening_cash_fraction']+o['FD']*a['FD_access'];s['cash_ipo_general']=o['ipo_general']*a['ipo_available_fraction'];s['cash_financing']=Z;s['cash_restricted_transient']=Z
  events=[];months=[];failures=[];pipeline=[];cohorts=[[s['PPE'],int(a['opening_remaining_life_months'])]];m=0;fees=Z;initial_cash=s['cash'];initial_pools=s['ipo_capex']+s['ipo_working'];physical_basis=s['PPE'];reserve=max(a['minimum_cash'],o['revenue']*a['reserve_sales']);initial_reserve=reserve;collateral={'AR':s['AR'],'inventory':s['inventory']}
  def fail(reason,shortfall=Z,kind='cash'):
   s['failed']=True;failures.append({'month':m,'date':dt(m),'kind':kind,'reason':reason,'shortfall':shortfall,'cash':s['cash'],'reserve':reserve})
  def record(label,amount,kind,details=None):
   before=s['cash'];keys=('cash_internal','cash_ipo_general','cash_financing','cash_restricted_transient');pb={k:s[k]for k in keys};internal_required=Z;provenance_shortfall=Z;failure_kind=None;overrun=Z;overrun_shortfall=Z
   if amount>=0:
    target='cash_restricted_transient'if kind=='restricted_release'else'cash_financing'if label=='conditional_financing'else'cash_internal';s[target]+=amount
   else:
    expense=-amount
    if label=='legal_stress_settlement':internal_required=expense;failure_kind='legal_funding'
    elif label=='promoter_demand_repayment':internal_required=expense;failure_kind='promoter_funding'
    elif label=='dividend':internal_required=expense;failure_kind='distribution_funding'
    elif label=='committed_project_capex':internal_required=o['project_internal_capex']/a['capex_months'];failure_kind='project_internal_funding';overrun=(o['ipo_capex']+o['project_internal_capex'])*a['capex_overrun']/a['capex_months']
    provenance_shortfall=max(Z,internal_required-max(Z,s['cash_internal']));s['cash_internal']-=internal_required;overrun_left=overrun
    for key in (('cash_internal','cash_ipo_general')if a['ordinary_internal_first']>0 else('cash_ipo_general','cash_internal')):
     used=min(max(Z,s[key]),overrun_left);s[key]-=used;overrun_left-=used
    overrun_shortfall=overrun_left
    if overrun_left>0:s['cash_internal']-=overrun_left
    remaining=expense-internal_required-overrun
    order=('cash_ipo_general','cash_internal','cash_financing','cash_restricted_transient')if label=='IPO_extra_fee_tax'else(('cash_restricted_transient','cash_internal','cash_ipo_general','cash_financing')if a['ordinary_internal_first']>0 else('cash_restricted_transient','cash_ipo_general','cash_financing','cash_internal'))
    for key in order:
     used=min(max(Z,s[key]),remaining);s[key]-=used;remaining-=used
    if remaining>0:s['cash_internal']-=remaining
   s['cash']+=amount;s['minimum_cash']=min(s['minimum_cash'],s['cash']);pa={k:s[k]for k in keys};pd={k:pa[k]-pb[k]for k in keys};assert abs(sum(pa.values(),Z)-s['cash'])<D('1e-20')
   events.append({'month':m,'date':dt(m),'label':label,'kind':kind,'cash_before':before,'amount':amount,'cash_after':s['cash'],'reserve':reserve,'shares':s['shares'],'CC':s['CC'],'bank_debt':s['bank_debt'],'promoter_debt':s['promoter_debt'],'ipo_capex':s['ipo_capex'],'ipo_working':s['ipo_working'],'provenance_before':pb,'provenance_after':pa,'provenance_delta':pd,'internal_required_amount':internal_required,'internal_eligibility_shortfall':provenance_shortfall,'project_overrun_component':overrun,'overrun_eligibility_shortfall':overrun_shortfall,**(details or{})})
   if provenance_shortfall>EPS:fail(label+' exceeds internally eligible cash under declared source policy',provenance_shortfall,failure_kind)
   if overrun_shortfall>EPS:fail(label+' overrun exceeds eligible general-purpose and internal cash',overrun_shortfall,'project_overrun_funding')
   if s['cash']<reserve-EPS:fail(label+' breaches operating reserve',reserve-s['cash'])
  def pay(label,amount,kind='operating',eligible=None,interest_sensitive=False):
   nonlocal fees
   amount=D(amount);restricted=Z
   if amount<0 and eligible in ('capex','working'):
    key='ipo_'+eligible
    # Project funds settle only project invoices. WC funds are used only as needed for operating payments.
    eligible_need=min(-amount,o['ipo_capex']/a['capex_months']) if eligible=='capex' else max(Z,reserve-s['cash']-amount)
    restricted=min(s[key],eligible_need);s[key]-=restricted
    if restricted:record('restricted_'+eligible+'_payment_support',restricted,'restricted_release',{'for_label':label,'pool_release':restricted})
   extra=Z;needed=max(Z,reserve-s['cash']-amount)
   bank_allowed=label not in('legal_stress_settlement','promoter_demand_repayment','dividend') and mode!='none' and(m<=N or a['post_exit_bank_allowed']>0)
   if needed>EPS and bank_allowed:
    bb=max(Z,collateral['AR'])*f['AR_eligibility']*f['AR_advance']+max(Z,collateral['inventory'])*f['inventory_eligibility']*f['inventory_advance']
    room=max(Z,min(f['CC_limit'],bb)-s['CC']);draw=min(room,needed/(O-f['draw_fee']-(a['CC_rate']/12 if interest_sensitive else Z)));fee=draw*f['draw_fee'];s['CC']+=draw;s['CC_draws']+=draw;s['bank_fees']+=fee;fees+=fee
    if interest_sensitive:extra=draw*a['CC_rate']/12
    residual=max(Z,reserve-s['cash']-amount-draw+fee+extra);gross=eqfee=Z;issued=0;issue=max(f['issue_floor'],entry*f['issue_entry_ratio'])
    if residual>EPS and mode=='equity' and int(f['equity_first_month'])<=m<=N:
     unit=issue/CR;issued=min(ceil(residual/(unit*(O-f['equity_fee']))),floor(max(Z,f['equity_gross_limit']-s['equity_gross'])/unit),max(0,i['authorized_shares']-s['shares']));gross=unit*issued;eqfee=gross*f['equity_fee'];s['shares']+=issued;s['equity_gross']+=gross;s['equity_fees']+=eqfee;fees+=eqfee
    if draw+gross>0:record('conditional_financing',draw-fee+gross-eqfee,'financing',{'bank_draw':draw,'bank_fee':fee,'equity_gross':gross,'equity_fee':eqfee,'issued':issued,'issue_price':issue,'borrowing_base':bb,'collateral_AR':collateral['AR'],'collateral_inventory':collateral['inventory'],'authorized_shares':i['authorized_shares']})
   record(label,amount-extra,kind,{'extra_draw_interest':extra,'restricted_support':restricted});return extra
  def demand(t):
   y=(max(1,t)-1)//12
   if t>N:
    last=demand(N);return {'tonnes':last['tonnes']*(O+a['terminal_growth'])*a['terminal_revenue_factor'],'price':last['price'],'revenue':last['revenue']*(O+a['terminal_growth'])*a['terminal_revenue_factor']}
   tonnes=o['production_tonnes']*(O+a['year1_volume_growth'])*(O+a['volume_growth'])**y;price=o['revenue']/o['production_tonnes']*(O+a['price_growth'])**(y+1)
   return {'tonnes':tonnes,'price':price,'revenue':tonnes*price}
  pay('opening_reserve_test',Z,'reserve')
  pay('IPO_extra_fee_tax',-a['extra_issue_fee_tax'],'issue_cost')
  if int(a['legal_month'])==0:pay('legal_stress_settlement',-a['legal_payment'],'legacy')
  def step():
   nonlocal reserve,fees,collateral,physical_basis
   y=(m-1)//12;d=demand(m);rev=d['revenue']/12;cogs=rev*a['COGS_ratio'];reserve0=reserve;reserve=max(a['minimum_cash'],d['revenue']*a['reserve_sales']);cash0=s['cash'];debt0=s['bank_debt']+s['promoter_debt']+s['CC'];wc0=onwc(s);ic0=wc0+s['PPE']+s['CWIP']+sum((r['cost']for r in pipeline),Z);shares0=s['shares'];eventstart=len(events);fees=Z;collateral={k:s[k]for k in('AR','inventory')};pay('monthly_reserve_test',Z,'reserve')
   borrowing_base=max(Z,collateral['AR'])*f['AR_eligibility']*f['AR_advance']+max(Z,collateral['inventory'])*f['inventory_eligibility']*f['inventory_advance']
   mandatory_paydown=max(Z,s['CC']-min(f['CC_limit'],borrowing_base));s['CC']-=mandatory_paydown;pay('borrowing_base_cure',-mandatory_paydown,'financing')
   commissioned=Z
   if m==int(a['commission_month']):
    if m<=int(a['capex_months']):fail('Committed plant requested before all project invoices paid',Z,'capacity')
    else:
     commissioned+=s['CWIP'];s['PPE']+=s['CWIP'];physical_basis+=s['CWIP'];cohorts.append([s['CWIP'],int(a['new_capital_life_months'])]);s['CWIP']=Z;s['tonne_capacity']+=o['committed_tonne_capacity']
   for p in list(pipeline):
    if p['due']<=m:s['PPE']+=p['cost'];physical_basis+=p['cost'];s['tonne_capacity']+=p['tonnes'];cohorts.append([p['cost'],int(a['new_capital_life_months'])]);commissioned+=p['cost'];pipeline.remove(p)
   if d['tonnes']>s['tonne_capacity']+EPS:fail('Demand exceeds paid and commissioned effective tonne capacity',d['tonnes']-s['tonne_capacity'],'capacity')
   future=demand(m+int(a['extra_capacity_lag']))['tonnes']*a['capacity_buffer'];committed_pending=o['committed_tonne_capacity']if m<int(a['commission_month'])else Z;inflight=sum((p['tonnes']for p in pipeline),Z);additional=max(Z,future-s['tonne_capacity']-inflight-committed_pending);growthcap=additional*a['new_capacity_cost_per_tonne'];maintenance=max(rev*a['maintenance_sales'],physical_basis/a['new_capital_life_months']);da=Z
   for c in cohorts:
    dep=c[0]/c[1]if c[1]else Z;c[0]-=dep;c[1]=max(0,c[1]-1);da+=dep
   s['PPE']-=da
   fixed=a['fixed_opex']*(O+a['opex_growth'])**y/12;variable=rev*(a['variable_opex']+(a['terminal_margin_haircut']if m>N else Z));ebitda=rev-cogs-fixed-variable;bad=a['AR_writeoff']if m==1 else Z;obsolete=a['inventory_writeoff']if m==1 else Z
   assert bad<=s['AR'] and obsolete<=s['inventory'];ramp=min(O,D(m)/a['transition_months']);targets={'AR':d['revenue']*a['AR_days']/365,'inventory':d['revenue']*a['COGS_ratio']*a['inventory_days']/365,'TP':d['revenue']*a['COGS_ratio']*a['TP_days']/365,'other_CA':d['revenue']*a['other_CA_sales'],'other_CL':d['revenue']*a['other_CL_sales']};end={k:o[k]*(O-ramp)+v*ramp for k,v in targets.items()};delta={k:end[k]-s[k]for k in targets};delta['AR']+=bad;delta['inventory']+=obsolete;receipts=rev-delta['AR'];purchases=cogs+delta['inventory'];supplier=purchases-delta['TP']
   if receipts<0:fail('Negative customer receipts cannot fund this operating path',-receipts,'working_capital')
   pay('customer_receipts_early',receipts*a['early_receipts']);pay('supplier_payments_early',-supplier*a['early_supplier'],eligible='working');pay('payroll_and_other_early',-(fixed+variable)*a['early_opex'],eligible='working');pay('other_operating_assets',-delta['other_CA'],eligible='working');pay('other_operating_liabilities',delta['other_CL'],eligible='working')
   committed=(o['ipo_capex']+o['project_internal_capex'])*(O+a['capex_overrun'])/a['capex_months']if m<=int(a['capex_months'])else Z
   pay('committed_project_capex',-committed,'investment','capex');s['CWIP']+=committed
   pay('additional_capacity_capex',-growthcap,'investment')
   if growthcap:pipeline.append({'cost':growthcap,'tonnes':additional,'due':m+int(a['extra_capacity_lag'])})
   pay('replacement_capex',-maintenance,'investment');s['PPE']+=maintenance;cohorts.append([maintenance,int(a['new_capital_life_months'])])
   pay('customer_receipts_late',receipts*(O-a['early_receipts']));pay('supplier_payments_late',-supplier*(O-a['early_supplier']),eligible='working');pay('payroll_and_other_late',-(fixed+variable)*(O-a['early_opex']),eligible='working')
   legacy_tax=o['tax_payable']if m==1 else Z;employee=a['employee_legacy_payment']if m==1 else Z;legal=a['legal_payment']if m==int(a['legal_month'])else Z
   pay('legacy_income_tax',-legacy_tax,'legacy');pay('legacy_employee_benefits',-employee,'legacy');pay('legal_stress_settlement',-legal,'legacy')
   principal=min(s['bank_debt'],o['bank_debt']/a['bank_repayment_months'])if m<=int(a['bank_repayment_months'])else Z;s['bank_debt']-=principal;pay('scheduled_bank_principal',-principal,'financing');prom=s['promoter_debt']if m==int(a['promoter_repayment_month'])else Z;s['promoter_debt']-=prom;pay('promoter_demand_repayment',-prom,'financing')
   interest=(s['bank_debt']+principal)*a['bank_rate']/12+s['CC']*a['CC_rate']/12;interest+=pay('cash_interest',-interest,'financing',interest_sensitive=True);ebit=ebitda-da-bad-obsolete;taxcash=max(Z,ebit-interest)*tax;pay('cash_income_tax',-taxcash);pat=ebit-interest-taxcash-fees;dividend=max(Z,pat)*a['dividend_payout'];pay('dividend',-dividend,'distribution');pat=ebit-interest-taxcash-fees;s.update(end);wc1=onwc(s);ic1=wc1+s['PPE']+s['CWIP']+sum((p['cost']for p in pipeline),Z);capex=committed+growthcap+maintenance;nopat=ebit-max(Z,ebit)*tax;cfo=ebitda-delta['AR']-delta['inventory']-delta['other_CA']+delta['TP']+delta['other_CL']-taxcash-employee-legal
   months.append({'month':m,'date':dt(m),'year':y+1,'revenue':rev,'tonnes':d['tonnes']/12,'revenue_per_produced_tonne':d['price'],'COGS':cogs,'fixed_opex':fixed,'variable_opex':variable,'EBITDA':ebitda,'DA':da,'EBIT':ebit,'NOPAT':nopat,'AR_writeoff':bad,'inventory_writeoff':obsolete,'PAT':pat,'interest':interest,'tax':taxcash,'financing_fees':fees,'CFO_before_financing_interest':cfo,'FCF_before_financing_interest':cfo-capex,'capex':capex,'committed_capex':committed,'growth_capex':growthcap,'replacement_capex':maintenance,'legacy_tax':legacy_tax,'legacy_employee':employee,'legal_payment':legal,'dividend':dividend,'opening_cash':cash0,'closing_cash':s['cash'],'opening_debt':debt0,'closing_debt':s['bank_debt']+s['promoter_debt']+s['CC'],'opening_shares':shares0,'closing_shares':s['shares'],'reserve_open':reserve0,'reserve_close':reserve,'ONWC_open':wc0,'ONWC_close':wc1,'IC_open':ic0,'IC_close':ic1,'tonne_capacity':s['tonne_capacity'],'commissioned_cost':commissioned,'CWIP':s['CWIP'],'PPE':s['PPE'],'pipeline_capital':sum((p['cost']for p in pipeline),Z),'ipo_capex':s['ipo_capex'],'ipo_working':s['ipo_working'],'CC':s['CC'],'bank_debt':s['bank_debt'],'promoter_debt':s['promoter_debt'],'customer_receipts':receipts,'purchases':purchases,'supplier_payments':supplier,'cash_internal':s['cash_internal'],'cash_ipo_general':s['cash_ipo_general'],'cash_financing':s['cash_financing'],'cash_restricted_transient':s['cash_restricted_transient'],'failed_to_date':s['failed'],'event_start':eventstart,'event_end':len(events),**end})
  for m in range(1,N+1):step()
  annual={k:sum((r[k]for r in months[-12:]),Z)for k in('revenue','EBITDA','NOPAT','tonnes')};m=N;reserve=months[-1]['reserve_close'];collateral={k:s[k]for k in('AR','inventory')};pay('terminal_current_capital_catchup',-a['terminal_extra_capital'],'terminal');pay('terminal_deferred_tax_settlement',-o['DTL'],'terminal');snapshot=deepcopy(s);eventcut=len(events);monthcut=len(months)
  for m in range(N+1,N+13):step()
  guard=months[monthcut:];nextnopat=sum((r['NOPAT']for r in guard),Z);nextda=sum((r['DA']for r in guard),Z);growthactual=sum((r['capex']-r['replacement_capex']for r in guard),Z)+guard[-1]['ONWC_close']-guard[0]['ONWC_open'];required=max(Z,nextnopat*a['terminal_growth']/a['terminal_CAP'],(nextnopat-annual['NOPAT'])/a['terminal_CAP']);gap=max(Z,required-growthactual);pay('terminal_continuation_earned_capital_gap',-gap,'investment');fcff=sum((r['NOPAT']+r['DA']-r['capex']-(r['ONWC_close']-r['ONWC_open'])-(r['reserve_close']-r['reserve_open'])for r in guard),Z)-gap
  if nextnopat<=0 or fcff<=0:fail('Terminal continuation has nonpositive sustainable operating cash',max(Z,-fcff),'terminal')
  continuation_events=events[eventcut:];continuation_end=deepcopy(s);failed=s['failed'];s=deepcopy(snapshot);s['failed']=failed;primary=months[:monthcut];events=events[:eventcut];reserve=primary[-1]['reserve_close'];terminal_ev=max(Z,annual['EBITDA']-annual['revenue']*a['terminal_margin_haircut'])*a['terminal_multiple'];restricted_terminal=(s['ipo_capex']+s['ipo_working'])*a['terminal_restricted_recovery'];fd=s['FD']*a['FD_terminal_recovery'];debt=s['CC']+s['bank_debt']+s['promoter_debt'];equity=max(Z,terminal_ev+max(Z,s['cash']-reserve)+restricted_terminal+fd-debt);price=equity*CR/s['shares'];dividends=[r['dividend']*CR/r['closing_shares']for r in primary];cfs=[-entry*(O+D(i['entry_cost']))]+dividends;cfs[-1]+=price*(O-D(i['exit_cost']));ret=None if failed else irr(cfs)
  w=a['WACC'];g=a['terminal_growth'];assert w>g;explicit=sum(((r['NOPAT']+r['DA']-r['capex']-(r['ONWC_close']-r['ONWC_open'])-(r['reserve_close']-r['reserve_open'])-r['legal_payment']-r['legacy_employee'])/(O+w)**(D(k)/12)for k,r in enumerate(primary,1)),Z);terminalpv=fcff/(w-g)/(O+w)**years;restricted_release_pv=sum((r['pool_release']/(O+w)**(D(r['month'])/12)for r in events if r['kind']=='restricted_release'),Z);restricted_residual_pv=restricted_terminal/(O+w)**years;fd_pv=fd/(O+w)**years;dcf=explicit+terminalpv+initial_cash-initial_reserve+restricted_release_pv+restricted_residual_pv+fd_pv-o['bank_debt']-o['promoter_debt']-o['CC']-o['tax_payable']-o['DTL']-a['terminal_extra_capital']/(O+w)**years-a['extra_issue_fee_tax']-(a['legal_payment']if int(a['legal_month'])==0 else Z)
  hurdle={str(h):None if failed else(sum((v/(O+h)**(D(k)/12)for k,v in enumerate(dividends,1)),Z)+price*(O-D(i['exit_cost']))/(O+h)**years)/(O+D(i['entry_cost']))for h in(D('.12'),D('.15'),D('.18'))}
  summary={'path_id':pid,'scenario':scenario,'funding_mode':mode,'years':years,'entry_price':entry,'overrides':overrides or{},'failed':failed,'failure_count':len(failures),'first_failure':failures[0]if failures else None,'ordinary_return_suppressed':failed,'IRR':ret,'terminal_price':None if failed else price,'diagnostic_terminal_price_invalid_when_failed':price,'terminal_equity':equity,'terminal_EV':terminal_ev,'ending_shares':s['shares'],'dilution':D(s['shares'])/i['shares']-O,'equity_gross':s['equity_gross'],'CC_draws':s['CC_draws'],'CC':s['CC'],'ending_debt':debt,'ending_cash':s['cash'],'ending_cash_provenance':{k:s[k]for k in('cash_internal','cash_ipo_general','cash_financing','cash_restricted_transient')},'minimum_cash':s['minimum_cash'],'IPO_capex_remaining':s['ipo_capex'],'IPO_WC_remaining':s['ipo_working'],'FD':s['FD'],'FD_terminal_recovery':fd,'restricted_terminal_recovery':restricted_terminal,'terminal_reserve':reserve,'yearN_revenue':annual['revenue'],'yearN_EBITDA':annual['EBITDA'],'yearN_tonnes':annual['tonnes'],'terminal_capacity_tonnes':s['tonne_capacity'],'yearN_IC':primary[-1]['IC_close'],'next_NOPAT':nextnopat,'sustainable_FCFF':fcff,'earned_growth_capital_required':required,'continuation_actual_growth_capital':growthactual,'continuation_capital_gap':gap,'continuation_failed':any(r['month']>N for r in failures),'continuation_minimum_cash':continuation_end['minimum_cash'],'continuation_ending_debt':continuation_end['CC']+continuation_end['bank_debt']+continuation_end['promoter_debt'],'hurdle_entry_prices':hurdle,'DCF_equity_current_shares':None if failed else dcf,'DCF_price_current_shares':None if failed else max(Z,dcf)*CR/i['shares'],'DCF_terminal_fraction':terminalpv/(terminalpv+explicit)if terminalpv+explicit else None,'cashflows_per_original_share':None if failed else cfs,'limitation':'Conditional pro forma IPO funding; not observed current cash. Hypothetical bank/equity finance is not a sanction or legal authorization. Failed diagnostics are not attainable returns.'}
  self.paths[pid]={'summary':summary,'monthly':primary,'events':events,'continuation_monthly':guard,'continuation_events':continuation_events,'failures':failures,'terminal':{'FCFF':fcff,'required_incremental_capital':required,'actual_incremental_capital':growthactual,'extra_cash_capital':gap,'next_DA':nextda,'DCF_explicit_PV':explicit,'DCF_terminal_PV':terminalpv,'DCF_equity_diagnostic':dcf,'restricted_release_PV':restricted_release_pv,'restricted_remaining_recovery_PV':restricted_residual_pv,'FD_recovery_PV':fd_pv}}
  return summary

def run_all(i):
 e=Engine(i)
 for sc in ('bear','base','bull'):
  for mode in ('none','bank','equity'):e.run(sc+'_'+mode,sc,mode)
 for label,ov in {'collections':{'AR_days':'150'},'supplier_credit':{'TP_days':'30'},'capex_delay':{'commission_month':'19','capex_months':'12','capex_overrun':'.30'},'margin':{'COGS_ratio':'.84'},'promoter_call':{'promoter_repayment_month':'1'},'legal':{'legal_payment':'2.50','legal_month':'1'},'cash_unavailable':{'opening_cash_fraction':'.5','ipo_available_fraction':'.5'},'tax':{'tax':'.26'},'combined':{'AR_days':'150','TP_days':'30','COGS_ratio':'.84','promoter_repayment_month':'1','legal_payment':'2.50','capex_overrun':'.30'},'terminal_capital':{'terminal_extra_capital':'20'},'terminal_margin':{'terminal_margin_haircut':'.08'},'terminal_demand':{'terminal_revenue_factor':'.70'},'distribution':{'dividend_payout':'.50'},'no_postexit_bank':{'post_exit_bank_allowed':'0'},'FD_free_sensitivity':{'FD_access':'1'}}.items():e.run('stress_'+label,'base','equity',overrides=ov)
 e.run('stress_internal_first','base','equity',overrides={'ordinary_internal_first':'1'})
 e.run('stress_IPO_fee_tax','base','equity',overrides={'extra_issue_fee_tax':'.98586'})
 e.run('stress_legal_provenance','base','equity',overrides={'opening_cash_fraction':'.01','legal_payment':'1','legal_month':'0'})
 e.run('stress_borrowing_base_collapse','bear','equity',overrides={'terminal_revenue_factor':'.10'})
 for growth in ('.02','.06','.10','.15','.20'):
  for mult in ('6','9','12'):e.run('grid_g'+growth+'_m'+mult,'base','equity',overrides={'volume_growth':growth,'terminal_multiple':mult})
 for w in ('.12','.16','.20'):
  for g in ('.02','.04','.06'):e.run('DCF_w'+w+'_g'+g,'base','equity',overrides={'WACC':w,'terminal_growth':g})
 validation=[]
 for h in ('.12','.15','.18'):
  base=e.paths['base_equity']['summary'];entry=base['hurdle_entry_prices'][str(D(h))]
  if entry is None:validation.append({'hurdle':h,'entry':None,'IRR':None,'failed':True,'fixed_point_pass':False});continue
  for k in range(12):
   q=e.run('hurdle_'+h+'_iter'+str(k),'base','equity',entry=entry);new=q['hurdle_entry_prices'][str(D(h))]
   if new is None:break
   if abs(new-entry)<D('1e-16'):break
   entry=new
  validation.append({'hurdle':h,'entry':entry,'IRR':q['IRR'],'failed':q['failed'],'fixed_point_pass':not q['failed']and abs(q['IRR']-D(h))<D('1e-14'),'path_id':q['path_id']})
 reverse=[]
 for g in ('0','.05','.10','.15','.20','.25','.30','.40','.50'):
  q=e.run('reverse_g'+g,'base','equity',overrides={'volume_growth':g});reverse.append({'growth':g,'IRR':q['IRR'],'failed':q['failed'],'path_id':q['path_id']})
 for sc in ('bear','base','bull'):e.run(sc+'_10year','%s'%sc,'equity',years=10)
 targets=[]
 for years in(5,10):
  for target in(5,10):
   for multiple in('6','9'):
    # Algebraic business requirement uses no excess cash and no future dilution; actual funded model follows.
    required_rev=D(i['entry_price'])*D(target)*i['shares']/CR/D(multiple)/D('.12');growth=(required_rev/D(i['opening']['revenue']))**(O/D(years))-O
    q=e.run('target_'+str(target)+'x_'+str(years)+'y_m'+multiple,'base','equity',years=years,overrides={'year1_volume_growth':str(growth),'volume_growth':str(growth),'price_growth':'0','terminal_multiple':multiple})
    targets.append({'target':target,'years':years,'exit_multiple':multiple,'required_revenue_at12pct_margin':required_rev,'required_revenue_CAGR':growth,'required_tonnes_at_FY26_yield':required_rev/(D(i['opening']['revenue'])/D(i['opening']['production_tonnes'])),'required_incremental_capacity_capex':max(Z,required_rev/(D(i['opening']['revenue'])/D(i['opening']['production_tonnes']))-D('10000'))*D(i['common']['new_capacity_cost_per_tonne']),'path_id':q['path_id'],'failed':q['failed'],'first_failure':q['first_failure'],'actual_ending_shares':q['ending_shares'],'actual_equity_gross':q['equity_gross'],'actual_ordinary_price_multiple':None if q['failed']else q['terminal_price']/D(i['entry_price'])})
 return e,{'hurdles':validation,'reverse_growth_grid':reverse,'multibagger_targets':targets}
