"""Delete generated outputs and attestations; rebuild AND verify under isolation.
Run from a newly extracted recovery directory: python guarded_rebuild.py --clean.
"""
from pathlib import Path
import sys,os,io,builtins,json,hashlib,socket,subprocess
P=Path(__file__).resolve().parent
sys.path.insert(0,str(P))
import build,verify,model,model_audit
ATTESTATIONS=['verification.json','guard_attestation.json']
def main():
 if '--clean'not in sys.argv:raise SystemExit('Use --clean inside an extracted recovery copy.')
 poisoned=[]
 for name in build.OUTPUTS+ATTESTATIONS:
  (P/name).write_bytes(b'STALE_POISON_MUST_NOT_BE_READ_OR_REUSED\n');poisoned.append(name)
 removed=[]
 for name in build.OUTPUTS+ATTESTATIONS:
  p=P/name
  if p.exists():p.unlink();removed.append(name)
 assert all(not(P/n).exists()for n in build.OUTPUTS+ATTESTATIONS)
 allowed={(P/n).resolve()for n in build.INPUTS};written=set();reads=set();denials=[];active_probe=None;probes=[]
 oldopen=builtins.open;oldio=io.open;oldos=os.open;oldsocket=socket.socket;oldprocess=subprocess.Popen
 def deny(reason):
  denials.append({'probe':active_probe,'reason':reason});raise PermissionError(reason)
 def check(file,mode='r'):
  if isinstance(file,int):return
  p=Path(file).resolve();mode=str(mode);r='r'in mode or'+'in mode;w=any(x in mode for x in 'wax+')
  if r and p not in allowed and p not in written:deny('Undeclared or stale read: '+p.name)
  if r:reads.add(p.name)
  if w:
   if p.parent!=P or p.name not in build.OUTPUTS+ATTESTATIONS:deny('Undeclared write: '+p.name)
   written.add(p)
 def op(file,mode='r',*a,**k):check(file,mode);return oldopen(file,mode,*a,**k)
 def iop(file,mode='r',*a,**k):check(file,mode);return oldio(file,mode,*a,**k)
 def osop(file,flags,*a,**k):
  mode='r+'if flags&os.O_RDWR else'w'if flags&(os.O_WRONLY|os.O_CREAT)else'r';check(file,mode);return oldos(file,flags,*a,**k)
 def net(*a,**k):deny('Network forbidden')
 def proc(*a,**k):deny('Subprocess forbidden')
 builtins.open=op;io.open=iop;os.open=osop;socket.socket=net;subprocess.Popen=proc
 try:
  for label,action in [('undeclared_read',lambda:builtins.open(P/'undeclared_probe.json','r')),('stale_generated_read',lambda:io.open(P/'scores.json','r')),('network',lambda:socket.socket()),('process',lambda:subprocess.Popen(['not-executed']))]:
   active_probe=label
   try:action()
   except PermissionError:probes.append({'probe':label,'status':'DENIED_AS_REQUIRED'})
   else:raise AssertionError('Isolation probe unexpectedly permitted: '+label)
   active_probe=None
  result=build.main()
  assert set(build.OUTPUTS)=={p.name for p in written}
  checked=verify.verify()
  assert(P/'verification.json').resolve()in written
  assert all(x['probe']is not None for x in denials),'Unexpected blocked access during actual rebuild/verification.'
  outputs={n:hashlib.sha256((P/n).read_bytes()).hexdigest()for n in build.OUTPUTS+['verification.json']}
  record={'status':'PASS','all_outputs_and_attestations_poisoned':poisoned,'outputs_and_attestations_removed':removed,'all_generated_absent_before_build':True,'declared_authored_inputs':build.INPUTS,'reads':sorted(reads),'writes':sorted([p.name for p in written]+['guard_attestation.json']),'denial_probes':probes,'denials':denials,'unexpected_denials':[],'external_data_dependency':False,'network_subprocess_forbidden':True,'verification_within_guard':True,'attestation_within_guard':True,'generated_reads_only_after_current_run_write':True,'rebuild':result,'canonical_sha256':checked['canonical_sha256'],'outputs_sha256':outputs,'note':'Only declared authored inputs and newly written generated files were readable during rebuild, verification and attestation. No external source/helper dependency.'}
  (P/'guard_attestation.json').write_text(json.dumps(record,indent=2)+'\n')
  assert set(build.OUTPUTS+ATTESTATIONS)=={p.name for p in written}
 finally:builtins.open=oldopen;io.open=oldio;os.open=oldos;socket.socket=oldsocket;subprocess.Popen=oldprocess
 print(json.dumps({'status':'PASS','canonical_sha256':record['canonical_sha256'],'paths':result['paths'],'checks':checked['checks'],'denial_probes':len(probes),'verification_within_guard':True}))
if __name__=='__main__':main()
