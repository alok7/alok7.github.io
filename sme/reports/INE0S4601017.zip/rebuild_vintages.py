import json,hashlib,tempfile,subprocess,sys,shutil
from pathlib import Path
P=Path(__file__).resolve().parent
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
manifest=json.loads((P/'vintage_manifest.json').read_text());out=[]
for v in manifest:
 with tempfile.TemporaryDirectory(prefix='sjp_vintage_') as t:
  q=Path(t)
  for n in ['model.py','financial_inputs.json','market_inputs.json']:shutil.copyfile(P/'model_vintages'/v['name']/n,q/n)
  subprocess.run([sys.executable,str(q/'model.py')],cwd=q,check=True,stdout=subprocess.DEVNULL)
  hashes={n:h(q/n) for n in v['outputs']};assert hashes==v['outputs'],hashes
  out.append({'name':v['name'],'status':'PASS','outputs':hashes,'offline':True,'original_generated_outputs_absent_before_run':True,'role':v['role']})
(P/'vintage_rebuild_proof.json').write_text(json.dumps(out,indent=2)+'\n')
