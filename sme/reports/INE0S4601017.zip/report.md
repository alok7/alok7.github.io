# SJP Ultrasonics Limited — Position 381

**Wallstrat SME research • Framework v 3.0 • Information cutoff 20 October 2026 (IST) • Market reference 19 October 2026**

## 1. Executive Verdict
SJP supplies plastic-joining machinery, custom industrial automation and laser solutions—not medical ultrasound. It has application-engineering know-how and growing recent automation orders, but the decisive weakness is cash realization: FY 2024–26 ₹12.8171 crore restated PAT generated **negative ₹5.4261 crore CFO**. Five-year revenue CAGR is only 5.74%, not the superficially attractive 32.36% three-year recovery. Fresh IPO capital can support the machinery/WC expansion, but it is committed capital, not free surplus. At the dated secondary ₹96.22 reference, the base model returns about 7.6%, below the 15% hurdle; IAS remains NS because executable liquidity is unverified. This is a mixed-quality capital-expenditure execution watchlist, not an evidence-backed compounder. Collections, supplier-advance conversion and independently verified commissioning—not a higher quote—would improve the thesis. [S01;S03;S04;S06;C01;A01]

## 2. Research Header, Gates and Data Confidence
Exact legal identity is **SJP Ultrasonics Limited**, formerly SJP Ultrasonics Private Limited; CIN U29253MH2012PLC226489; ISIN **INE0S4601017**; BSE SME **544980 / SJP**. No NSE listing inferred from the interoperability master’s SJP$ rows. October 8,2026 listing,12,940,000 shares,₹10 face and2,000-share lot are corroborated by issuer capital structure, mirrored BSE notice20261007-37 and exchange security-master rows. [S01;S05;security_master_evidence.json]

Standalone AS/Indian GAAP, not Ind AS; no subsidiaries. Units ₹crore unless indicated. Five-year illustrative investment horizon ends 20 October 2031; nominal pre-investor-tax equity hurdle 15%, tested 12%/18%. DCF WACC14–18%, independently assumed—not equated to the equity hurdle. Illustrative liquidity reference ₹5 lakh, not a recommended position. FY 2027 comparable interim/TTM is ND as of cutoff. Data retrieved 25 October but only pre-cutoff facts used; undated peer pages corroborate products only. [S01;S02;A01]

The ₹96.22 observation is a **19 October dated secondary intraday LTP**, not a verified BSE closing/executable price. It is 0calendar days stale versus market reference,1 day before information cutoff. Later quotes excluded. Calculated market cap ₹124.50868 crore rejects the secondary article’s inconsistent ₹118.58 crore. One lot ₹192,440; two ₹384,880; three ₹577,320. Round-lot constraints make an exact ₹5 lakh purchase impossible at this quote. [S06;C01]

| Gate | State | Evidence / consequence |
|---|---|---|
| G1 | Conditional | Compliance lapses/admitted unpaid historical contributions; no demonstrated material diversion or severe minority harm. No governance override. |
| G2 | Conditional | Audited/restated core statements usable with exact reconciliation; .0036 crore equity and asset-label/marketing KPI discrepancies retained, not treated as proven unreliable entire accounts. Balance confirmations and development classification must improve. |
| G3 | Conditional | IPO proforma supports core bear; actual cutoff liquidity/deployment and callable funding uncertain. Historical EMI delays disclosed; not ongoing proved default. Linked-model gap not G3 Fail evidence. |
| G4 | Hold — unresolved | BSE daily series/spread not verified;8 potential sessions and circuits. L NS; quote not executable. |


**Confidence:** Medium on restated financial inputs, identity, business and governance disclosures; Medium on growth direction but low on clean price/volume separation; Medium on proxy capital-return evidence, low on exact operating-IC bridge; Medium on assumption-driven valuation and low on actual cutoff liquidity and trading implementation. The weakest material area for a new-purchase conclusion is liquidity: Hold. All quality factors remain individually assessed; missing liquidity does not turn business quality into zero or genericNS.

## 3. Scorecard and Calculation Audit
| Measure | Raw | Final | Coverage | Eligible | Missing bound / override |
|---|---|---|---|---|---|
| BQS | 4.300 | 4.3 | 100.00% | True | [4.3, 4.3]; No override |
| GQS | 4.400 | 4.4 | 100.00% | True | [4.4, 4.4]; GQS cap 5 for persistent CASH 2; raw below cap |
| IAS | NS | NS | 90.00% | False | [2.875, 3.775]; No override |

| Factor | Score | BQS contribution | GQS contribution | Evidence / interpretation |
|---|---|---|---|---|
| GOV | 4 | 0.800 | 0.000 | S01 pp 18–20,51–57,190; repeated statutory lapses and unresolved quantified exposure/confirmation, countered by disclosed regularization, no severe minority harm proved. |
| MOAT | 5 | 1.000 | 0.000 | S01 pp 125–149, peer evidence: custom qualification/application know-how but concentrated PO customers and no evidenced pricing power. |
| REV | 5 | 0.600 | 2.000 | S01 and S03/S04: fixed five-year 5.74% gives 4 plus 1 for sustained FY 2024–26 expansion; not 3 yr 32.36% cherry-pick. |
| DUR | 5 | 0.500 | 1.000 | S01 pp 76–89: existing utilization 89% but proposed tripling uncommissioned, FY 2026 automation-led demand. |
| CAP | 4 | 0.480 | 0.600 | S01 audited reinvestment bridge: incremental 2024–26 proxy below 14–18% cost-of-capital range; large WC capital, no proven high-return IPO cohort. |
| CASH | 2 | 0.200 | 0.200 | S01 FY 2024–26 cumulative CFO/PAT−.423; persistent negative conversion despite profits, not just capex; cash score 2 triggers GQS cap 5. |
| BAL | 5 | 0.400 | 0.000 | S01 debt EBITDA<1 x and fresh IPO support, offset demand bank loans and high working capital; core bear funded but linked shock fails. |
| EXEC | 4 | 0.320 | 0.000 | S01 capacity utilization stable; machine growth 2.37% FY 2026, old low revenue years, delayed development and IPO machinery still quotations; no strong multicycle delivery. |
| EARN | 4 | 0.000 | 0.600 | Restated profit increases but FY 2026 weightedEPS5.55 vs 6.75; cash conversion distinct CASH, here mix-led margins and dilution lower per-share growth quality. |
| IAS factor | Score | Weight | Contribution |
|---|---|---|---|
| Q | 4.300 | 25.00% | 1.075 |
| R | 2.000 | 35.00% | 0.700 |
| D | 3.000 | 20.00% | 0.600 |
| P | 4.000 | 10.00% | 0.400 |
| L | NS | 10.00% | ND |

R uses base IRR 7.59% minus 15% = -7.407 percentage points: v 3.0 spread −10 to <−7 gives R = 2. D = 3 reflects funded bear price loss and linked financing risk; P = 4 reflects demanding cash/terminal assumptions, not duplicate penalties.

Nine canonical factors reused exactly. EARN enters GQS, not BQS. IAS uses final unrounded BQS once; GQS is not added again. All weights match v 3.0. GOV 4 is not a governance-override trigger; compliance deficiencies do not establish diversion. CASH 2 reflects persistent poor realization, so GQS cap 5 applies, although raw GQS already lies below it. No G3 funding-failure cap is imposed from a hypothetical stress path. BQS/GQS are quality-ranking eligible at Medium material confidence; IAS is not. The IAS missing-data interval is mathematical, not a confidence interval or rankable score. A one-point change in both GOV/MOAT shifts BQS by 0.4; REV/CAP ±1 shifts GQS by 0.55. Adjacent scores should not be overinterpreted.

## 4. Business Overview
SJP designs/integrates custom plastic joining, industrial automation and laser machinery, tooling and service solutions. Its B2B clients are principally automotive manufacturers, with applications in medical, electronics, textiles, packaging and others. These application lists do not establish balanced end-market revenue. Vasai manufacturing and regional demonstration/service presence enable design, delivery, installation and support. Imported machine technology combines with local tools and integration. Revenue is collected through customer orders/advances and subsequent receivables, exposing the supplier to OEM credit terms. Purchase orders, rather than long-term offtake contracts, dominate. [S01 pp 125–149]

FY 2026 domestic sales ₹22.7802 crore, SEZ ₹.1078 crore and other exports ₹3.6697 crore total ₹26.5577 crore. Manufacturing/sales/service mix changed substantially; no clean same-product ASP series exists. Reported segment and machine-count bridges below are preferable to claiming all growth is volume. [S01 p 211]

## 5. Moat / Industry Position
Custom application knowledge, qualified fixtures, integration and installed-process familiarity create switching friction. They do not demonstrate industry-wide pricing power, patented monopoly or dominant share. Customer concentration remains material: top 10/top 5 FY 2026 sales 55.28%/38.52%, versus 54.46%/41.58% FY 2025. Supplier concentration worsened: top 10/top 5 purchases 88.64%/77.18%, versus 58.76%/40.66%. No binding long-term supplier contracts eliminate supply/FX risk. [S01 pp 20–22]

| Comparator | Evidence period/scope | Revenue ₹cr | EBITDA margin | Economic use |
|---|---|---:|---:|---|
| SJP |FY 2025 restated standalone|21.0573|32.47%|High margin, negative CFO|
| Rinco Ultrasonics India |FY 2025 issuer-reproduced MCA accounts|12.2081|16.65%|Closest unlisted ultrasonic specialist; technology-backed competition|
| Unique Circle Automation |FY 2025 issuer-reproduced MCA accounts|26.2812|9.57%|Near-scale custom automotive automation; weaker margins|
| TEAL |FY 2025 CRISIL, includes TEAL USA|~868|~19%|Stronger parent-supported automation/aerospace comparator; not pure peer|

No listed pure peer is established; no fabricated median P/E. Rinco / Unique primary corporate sites corroborate products, but their statutory financials were not independently downloaded; the prospectus is primary issuer disclosure of peer data, not independent verification. TEAL’s official 2 July 2025 CRISIL rationale cites 246-day gross-current-assets,₹511 crore adjusted net worth and 0.17 x gearing. Parent support/scale and aerospace change its economics. SJP’s cash weakness cannot be excused simply because the industry uses working capital. Peer CFO is ND; malformed prospectus pp 123–124 copied/shifted rows were excluded rather than treated as evidence. [S01 pp 95–98;PEER-R;PEER-U;PEER-T]

## 6. Revenue Growth & Scale
| FY | Revenue ₹cr | YoY ₹ addition | YoY % |
|---|---|---|---|
| 2021 | 20.0918000 | ND | NA |
| 2022 | 11.7114157 | -8.380 | -41.71% |
| 2023 | 11.4532648 | -0.258 | -2.20% |
| 2024 | 15.2107000 | 3.757 | 32.81% |
| 2025 | 21.0573000 | 5.847 | 38.44% |
| 2026 | 26.5577000 | 5.500 | 26.12% |

Five-year FY 2021–26: (26.5577 / 20.0918)^(1/5) − 1 = 5.74%; three-year FY 2023–26 = 32.36%. Five-year average annual addition is ₹1.29318 crore, not the latest annual addition.

The measurement window was fixed at five years because six audited revenue observations exist. FY 2021 was not discarded: no evidenced COVID windfall or accounting/perimeter break was located. FY 2024’s move toward higher-value custom special-purpose machines changes mix, not necessarily comparability. REV starts 4 for 5.74% CAGR, then rises at most 1 for three consecutive years of expansion; no further small-base penalty or TAM bonus. The 32.36% three-year CAGR is contextual, not the scoring window. [S03;S04;S01]

| Segment ₹cr |FY 2024|FY 2025|FY 2026|FY 2026 addition|
|---|---:|---:|---:|---:|
|Plastic joining|8.4587|15.6724|12.3553|-3.3171|
|Industrial automation|6.0930|5.1651|13.4052|8.2401|
|Laser|.6590|.2198|.7972|.5774|

Machine output 579/634/649 grew 9.50% then 2.37%, versus revenue 38.44% then 26.12%. FY 2026 plastic joining declined 21.16%; automation rose 159.53%. Growth is mix/order-value led, not proven equivalent volume growth. Revenue per machine is not a valid unit ASP because products/services/trading and machine complexity differ. No acquired-revenue contribution is disclosed; this does not make constant-price organic growth measurable. [S01 pp 17,85,125]

## 7. Growth Quality & Reinvestment Runway
Installed capacity 650/700/730 machines and utilization 89%/90%/89% FY 2024–26 indicate existing activity, but planned capacity 2,150/2,300 and production 2,050/2,150 FY 2027/28 remain estimates, not orders. IPO gross ₹23.45 crore less expenses ₹2.2636 crore gives net ₹21.1864 crore: machinery ₹13.2164 crore, working capital ₹4.92 crore, general corporate ₹3.05 crore. Machinery was at quotation stage without definitive purchase contracts at prospectus date; all deployment targeted FY 2027. [S01 pp 76–89]

Capex is roughly 16times FY 2026 net tangible PPE, making commissioning/customer qualification substantial execution work. The affordable runway is narrower than the addressable market: profits are tied up in stock, supplier advances and collections. Historical incremental funding-IC proxy returns 11.56% FY 2024–26 fall below the 14–18% assumed cost-of-capital range despite high historical average ROCE. This is not proof every new machine destroys value, but it does not substantiate superior reinvestment. Revenue must become cash before repeated dilution is ruled out. CASH 2 caps GQS5; no capex excuse is used for CFO weakness. [C01;A01]

## 8. Management, Governance & Execution
Repeated admitted control deficiencies matter: EPF/ESIC registration and contributions were not complied with before 15 June 2024; notices to authorities were sent July/August 2025. No fine had been imposed as of prospectus, but exposure is not zero and quantum remains unresolved. ROC forms were delayed up to 4,079 days, subsequently regularized with fees. An unregistered historical loan charge was disclosed with loan stated repaid. These are factual compliance weaknesses—not automatic fraud, abusive RPT or current default. [S01 pp 18–24]

Auditor changes in 2023 and 2024 cite professional reasons/pre-occupancy; current auditor Chirag N Shah appointed 16 September 2024. FY 2026 audit opinion is unmodified, with an emphasis concerning ₹.641619 crore Pune project not yet capitalized; elsewhere the restated prospectus labels the same amount software under development. That identity/asset-use discrepancy remains open. An audit-report template reference to a qualified opinion is not elevated over the actual opinion paragraph without clarification. Balance confirmations are qualified by notes as subject to confirmation/reconciliation. These limit confidence but are not proof all earnings fictitious. [S01 pp 195–227;S02]

FY 2026 three Toyota EMIs were delayed September–November 2025; FY 2025 one Anand Rathi EMI was delayed. CARO says not declared wilful defaulter. Review settled/current status rather than label an active default without evidence. ₹.136235 crore disputed income-tax dues and ₹.618723 crore accumulated MSME interest are relevant obligations. [S01 p 205–206;S02 CARO]

Promoter demand loans ₹1.0772 crore at FY 2026 support financing but create callable exposure. Related-party FY 2026 sale ₹.01 crore and repayments/advances are disclosed; LUFT advance ₹.0586 crore FY 2024 was repaid FY 2025. Director accrual remuneration ₹.18 crore/₹.1501 crore should not be confused with cash paid. No severe minority harm is demonstrated. A reciprocal India noncompete with the promoter-linked partnership contains prior-consent/permitted-activity carve-outs; it does not irrevocably assign every opportunity to SJP. [S01 pp 51–52,190]

|Dated statement/milestone|Evidence by cutoff|Assessment|
|---|---|---|
|FY 2024 shift to custom SPM|Machine counts/revenue mix diverge FY 2025–26|Executed mix change; pricing power not established|
|26 May 2026 engineer capacity certificate|FY 2026 actual 649 machines/89% utilization|Historical utilization verified disclosure, forecast 2,050 not actual|
|24 September 2026 machinery plan|Quotations; no definitive orders|Commissioning pending, not failed promise yet|
|June 2026 development capitalization|₹.6416 crore still incomplete after 2 years|Execution watch; asset-label clarification required|
|Historical statutory lapse remediation|Registration and self-intimation disclosed|Partial action; final liability/closure not established|

## 9. Financial Forensics
| ₹cr unless EPS/shares | FY 2024 | FY 2025 | FY 2026 |
|---|---|---|---|
| revenue | 15.2107 | 21.0573 | 26.5577 |
| other_income | 0.0129 | 0.0974 | 0.0770 |
| ebitda | 5.4150 | 6.8368 | 8.2381 |
| ebit | 5.0963 | 6.3319 | 7.8361 |
| pat | 3.4020 | 4.1725 | 5.2426 |
| eps | 6.1900 | 6.7500 | 5.5500 |
| cfo | 0.1494 | -2.8768 | -2.6987 |
| capex | 0.9280 | 0.5860 | 0.4024 |
| fcf_proxy | -0.7786 | -3.4628 | -3.1011 |
| debt | 2.0061 | 2.4192 | 5.7809 |
| cash | 1.0790 | 1.0313 | 0.4789 |
| equity | 6.7349 | 14.8473 | 20.0899 |
| inventory | 8.7915 | 10.6025 | 16.4303 |
| receivables | 4.0485 | 11.6257 | 9.7819 |
| payables | 1.8314 | 2.5652 | 2.4020 |
| supplier_advances | 0.8561 | 1.3683 | 5.9239 |
| ppe | 1.1448 | 1.0537 | 0.8279 |
| intangibles | 0.4266 | 0.2760 | 0.1835 |
| development | 0.0000 | 0.3229 | 0.6416 |
| shares_crore | 0.1100 | 0.9440 | 0.9440 |

Restated FY 2024–26 are a consistent standalone perimeter. Older FY 2021–23 statutory vintages are retained separately below, not merged into cash conversion. No quarter or TTM cash flow invented. Gross profit is analytically revenue less materials, traded purchases and inventory movement, excluding payroll/overhead—not a directly comparable peer gross margin. It equals 75.30%/64.22%/61.58%; contradictory prospectus marketing gross-margin rows are not used. FY 2026 recurring EBITDA includes the ₹.0328 crore prior-period charge conservatively; no automatic addback. [S01 pp 47–49,211–224]

| Older original vintage | FY 2021 | FY 2022 | FY 2023 |
|---|---|---|---|
| revenue | 20.0918000 | 11.7114157 | 11.4532648 |
| pat | 0.6236270 | 0.2574071 | 1.6479363 |
| cfo | ND | ND | ND |

Full older balance-sheet facts and conflicting presentations remain in older_financials.json; no unsupported normalized CFO.

FY 2022 original CFO has ambiguous presentation/tax sign; FY 2023 CFO was not located. FY 2023 original receivables₹4.599267crore differ from the prospectus risk-table₹3.1629crore. Negative FY 2022 receivables suggest historical presentation/netting issues; they are not silently recast into normalized receivables. Revenue history is still usable at Medium confidence; five-year CFO/ROIC is not claimed. [S03;S04;older_financials.json]

FY 2025 statutory PAT ₹4.1524 crore−income-tax adjustment ₹.0612 crore+deferred-tax adjustment ₹.0813 crore=restated ₹4.1725 crore. FY 2024₹3.5240−₹.1220=₹3.4020 crore. Restated equity FY 2024 face ₹6.7349 crore versus reconciliation ₹6.7313 crore differs ₹.0036 crore; face retained and sensitivity bounded rather than forcing equality. Gratuity accounting-policy conversion is separately disclosed; not subtracted a second time. [S01 p 220]

FY 2026 CFO bridge: PBT ₹7.0235+DA ₹.4020+finance ₹.8896+gratuity ₹.0812−other income ₹.0770=₹8.3193 crore before working capital. Inventory−₹5.8278, receivables+₹1.8438, loans/advances−₹4.5396, other assets−₹.1239, payables−₹.1632 and other liabilities−₹.4538 lead to−₹.9452 crore before tax; tax paid ₹1.7535 gives CFO−₹2.6987 crore. Interest ₹.8896 crore is financing cash flow, so reported CFO is before financing interest. Cash capex ₹.4024 gives FCF proxy−₹3.1011 crore; interest-paid cash deficit is worse. Inventory/supplier-advance accumulation, not just capital expenditure, explains weak CFO. [S01 p 49]

Receivables fell to ₹9.7819 crore, but ₹3.1152 crore is over 1 year, including ₹.6933 crore over 3 years; all classified good without doubt allowance in the note. Improvement in headline AR does not prove recovery of old balances. Cash ₹.4789 crore is mainly ₹.4585 crore cash on hand, bank only ₹.0204 crore; bank-only sensitivity is retained. Inventory ₹16.4303 crore comprises raw ₹6.7424, WIP ₹5.5893 and finished ₹4.0986. Supplier advances ₹5.9239 crore require delivery/recovery checks. The IPO’s 4.92 croreWC allocation is not the entire economic working-capital requirement. [S01 pp 209–211]

| Calculated measure (funding IC in INR crore) | FY 2024 | FY 2025 | FY 2026 |
|---|---|---|---|
| closing_ar_sales_days | 97.149 | 201.516 | 134.439 |
| inventory_sales_days | 210.963 | 183.780 | 225.812 |
| netdebt_ebitda | 0.171 | 0.203 | 0.644 |
| interest_cover | 13.871 | 6.847 | 8.809 |
| funding_ic_proxy | 7.6620 | 16.2352 | 25.3919 |
| roe | ND | 38.67% | 30.01% |
| roce_funding_proxy | ND | 52.99% | 37.65% |
| roic_funding_proxy | ND | 39.65% | 28.17% |
| incremental_roic_proxy | ND | 10.78% | 12.29% |

Cumulative CFO/PAT = -5.4261/12.8171 = -0.42335 x. Cash capex ₹1.9164; FCF proxy ₹-7.3425. FY 2024–26 incremental NOPAT/funding-IC = 11.56%. FY 2025–26 operating-IC increment ₹8.1664; incremental NOPAT ₹1.1256, ratio 13.78%.

Funding IC proxy=equity+interest-bearing debt−cash; average opening/closing denominators; NOPAT=EBIT×74.83%. It includes tax/other non-operating differences and is **not exact operating ROIC**. Direct FY 2026 ONWC from receivables+inventory+supplier advances+prepaids−supplier payables−customer advances−expense accruals is ₹25.8837 crore; add PPE/intangibles/development/deposits for operating IC. Funding/operating definitions differ because provisions/tax/other claims are not identically classified; detailed metric JSON preserves both, no false reconciliation. FY 2025–26 incremental operating proxy is a cross-check, not causal cohort economics. Pre-IPO rights/IPO timing can distort average-capital measures. [C01]

Bonus 4:1 July 2024 was not financing; rights 3.94 million shares at ₹10 January 2025 raised ₹3.94 crore. FY 2024 EPS denominator 5.5 million bonus-adjusted differs actual 1.1 million; FY 2025 weighted 6.180055 million differs closing 9.44 million. IPO adds 3.5 million, taking 12.94 million: FY 2026 profit on current shares is ₹4.0515 EPS, not historical ₹5.55. No warrants/options/convertibles disclosed in prospectus capital structure; future stress equity is an explicit assumption, not an existing claim. [S01 pp 63–65,228]

## 10. Valuation & Market Expectations
At ₹96.22, calculated current-share FY 2026P/E23.75 x. Market cap ₹124.50868 crore+March debt ₹5.7809−March cash ₹.4789=EV ₹129.81068 crore. Proforma adding netIPO ₹21.1864 gives EV ₹108.62428 crore/EBITDA13.19 x; proforma P/B3.02 x. Neither is actual October EV because intervening operations/deployment are ND. FCF yield is negative and not an attractive positive-yield claim. No peer P/E average manufactured. [S01;S06;C01]

The monthly model starts with FY 2026 operating scale and synthetic cash ₹21.6653 crore (March cash+netIPO). It spends machinery ₹13.2164 crore in 6 months **once**, plus maintenance 2.5% sales; retains ₹1 crore minimum cushion; repays ₹1.0772 crore demand debt month 1 and remaining original debt month 12 without assumed rollover. Straight annual revenue steps are allocated monthly, not claimed seasonal forecasts. ONWC moves over 6 months to scenario revenue ratios; the ratios summarize receivable/inventory/advance/customer-credit stress, not a forecast of a single line. Depreciation 15% WDV across opening/new operating assets is a simplification including development; it is not statutory guidance. Tax 25.17%, no tax credit for losses; interest 12% on opening debt. Operating rents stay in EBITDA; no fictitious Ind AS lease capitalization. No dividends. [A01]

| Case | Growth Y1–5 | EBITDA margin Y1–5 | ONWC/sales | Exit multiple | Exit ₹ | Return | Minimum cash | Funded |
|---|---|---|---|---|---|---|---|---|
| bear | [-0.15, 0, 0.03, 0.05, 0.05] | [0.18, 0.19, 0.2, 0.2, 0.2] | 1.1 | 7 | 40.42 | -15.92% | 6.199 | True |
| base | [0.2, 0.18, 0.15, 0.12, 0.1] | [0.29, 0.28, 0.27, 0.27, 0.27] | 0.9 | 11 | 138.74 | 7.59% | 1.458 | True |
| bull | [0.3, 0.25, 0.22, 0.2, 0.18] | [0.31, 0.31, 0.31, 0.31, 0.31] | 0.78 | 15 | 289.48 | 24.64% | 2.836 | True |
| linked_failure | [-0.35, -0.1, 0, 0.02, 0.02] | [0.04, 0.06, 0.1, 0.12, 0.12] | 1.65 | 5 | 12.22 | -33.82% DIAGNOSTIC | -0.248 | False |
| Case | Year 5 sales | Year 5 EBITDA | Cash | Debt | Shares crore | EV | Equity |
|---|---|---|---|---|---|---|---|
| bear | 25.635 | 5.127 | 16.418 | 0.000 | 1.294 | 35.888 | 52.306 |
| base | 53.280 | 14.386 | 21.284 | 0.000 | 1.294 | 158.241 | 179.525 |
| bull | 74.553 | 23.112 | 27.916 | 0.000 | 1.294 | 346.673 | 374.589 |
| linked_failure | 16.164 | 1.940 | 6.109 | 0.000 | 1.294 | 9.698 | 15.807 |

The bear’s lower growth releases more working capital than base and therefore can have a higher cash minimum despite poorer terminal value: funding is not monotonic in growth. Linked failure combines customer loss, lower utilization/margin and slower stock/collections/supplier advances; month 12 gap occurs on debt repayment. Report both cushion shortfall and cash below zero. Diagnostic continuation after failure is **not a realizable investment IRR**, insolvency finding or forecast recovery. Alternative rescue issues equity at 60% entry price, with cash and dilution linked; no such financing is committed. Actual losses could exceed modeled continuation value. [A01]

| Path parameters | Min cash | First floor gap month | Max unfunded gap | Equity raised | Dilution | Return validity |
|---|---|---|---|---|---|---|
| base {'growth_shift': 0, 'margin_shift': 0, 'multiple': 11, 'opening_cash': 16.6653, 'capex_delay': 0, 'rescue': False, 'wc_shift': 0, 'capex_overrun': 0} | -3.542 | 12 | 4.542 | 0.000 | 0.00% | False |
| base {'growth_shift': 0, 'margin_shift': 0, 'multiple': 11, 'opening_cash': 11.665299999999998, 'capex_delay': 0, 'rescue': False, 'wc_shift': 0, 'capex_overrun': 0} | -8.542 | 5 | 9.542 | 0.000 | 0.00% | False |
| bear {'growth_shift': 0, 'margin_shift': 0, 'multiple': 7, 'opening_cash': 16.6653, 'capex_delay': 0, 'rescue': False, 'wc_shift': 0, 'capex_overrun': 0} | 1.199 | None | 0.000 | 0.000 | 0.00% | True |
| bear {'growth_shift': 0, 'margin_shift': 0, 'multiple': 7, 'opening_cash': 11.665299999999998, 'capex_delay': 0, 'rescue': False, 'wc_shift': 0, 'capex_overrun': 0} | -3.801 | 6 | 4.801 | 0.000 | 0.00% | False |
| linked_failure {'growth_shift': 0, 'margin_shift': 0, 'multiple': 5, 'opening_cash': 16.6653, 'capex_delay': 0, 'rescue': False, 'wc_shift': 0, 'capex_overrun': 0} | -5.248 | 6 | 6.248 | 0.000 | 0.00% | False |
| linked_failure {'growth_shift': 0, 'margin_shift': 0, 'multiple': 5, 'opening_cash': 11.665299999999998, 'capex_delay': 0, 'rescue': False, 'wc_shift': 0, 'capex_overrun': 0} | -10.248 | 4 | 11.248 | 0.000 | 0.00% | False |
| linked_failure {'growth_shift': 0, 'margin_shift': 0, 'multiple': 5, 'opening_cash': 21.6653, 'capex_delay': 0, 'rescue': True, 'wc_shift': 0, 'capex_overrun': 0} | 1.000 | 12 | 0.000 | 1.248 | 1.67% | True |
| base {'growth_shift': 0, 'margin_shift': 0, 'multiple': 11, 'opening_cash': 21.6653, 'capex_delay': 12, 'rescue': False, 'wc_shift': 0, 'capex_overrun': 0} | 3.480 | None | 0.000 | 0.000 | 0.00% | True |
| base {'growth_shift': -0.1, 'margin_shift': 0, 'multiple': 11, 'opening_cash': 21.6653, 'capex_delay': 12, 'rescue': False, 'wc_shift': 0, 'capex_overrun': 0} | 8.475 | None | 0.000 | 0.000 | 0.00% | True |
| base {'growth_shift': 0, 'margin_shift': 0, 'multiple': 11, 'opening_cash': 21.6653, 'capex_delay': 0, 'rescue': False, 'wc_shift': 0.2, 'capex_overrun': 0} | -6.063 | 12 | 7.063 | 0.000 | 0.00% | False |
| base {'growth_shift': 0, 'margin_shift': -0.06, 'multiple': 11, 'opening_cash': 21.6653, 'capex_delay': 0, 'rescue': False, 'wc_shift': 0, 'capex_overrun': 0} | -0.113 | 13 | 1.113 | 0.000 | 0.00% | False |
| base {'growth_shift': 0, 'margin_shift': 0, 'multiple': 11, 'opening_cash': 21.6653, 'capex_delay': 0, 'rescue': False, 'wc_shift': 0, 'capex_overrun': 0.2} | -1.105 | 13 | 2.105 | 0.000 | 0.00% | False |
| bear {'growth_shift': 0, 'margin_shift': 0, 'multiple': 7, 'opening_cash': 16.6653, 'capex_delay': 0, 'rescue': False, 'wc_shift': 0, 'capex_overrun': 0.2} | -1.372 | 12 | 2.372 | 0.000 | 0.00% | False |
| base {'growth_shift': 0, 'margin_shift': 0, 'multiple': 11, 'opening_cash': 21.206799999999998, 'capex_delay': 0, 'rescue': False, 'wc_shift': 0, 'capex_overrun': 0} | 1.000 | 13 | 0.000 | 0.000 | 0.00% | False |
| linked_failure {'growth_shift': 0, 'margin_shift': 0, 'multiple': 5, 'opening_cash': 21.6653, 'capex_delay': 0, 'rescue': True, 'wc_shift': 0, 'capex_overrun': 0.2} | 1.000 | 12 | 0.000 | 3.891 | 5.21% | True |

Deferred-expenditure-only 12 month delay is explicitly a timing sensitivity, not an execution downside. A separate linked 12 monthdelay/−10 ppgrowth-shift case addresses commissioning/demand slippage. Additional bank-only liquidity,₹5/10 crore opening-cash shortfalls,20% capex overrun, margin−6 pp and WCratio+20 pp are retained. Proforma opening funds therefore cannot conceal deployment uncertainty. In the timing-only 12-month deferred-capex base sensitivity, subtracting the remaining machinery commitment from modeled cash leaves a minimum residual of ₹1.0574 crore, versus approximately ₹3.480 crore minimum aggregate cash. These minima occur at different months. Aggregate modeled cash is not free surplus; restricted proceeds and actual deployment status do not establish available bank liquidity at the cutoff.

| Base WACC | Terminal g | DCF ₹/original share | Terminal PV / EV |
|---|---|---|---|
| 14.00% | 2.00% | 39.72 | 100.61% |
| 14.00% | 4.00% | 40.26 | 100.60% |
| 14.00% | 5.00% | 40.53 | 100.59% |
| 16.00% | 2.00% | 33.35 | 102.94% |
| 16.00% | 4.00% | 33.16 | 102.97% |
| 16.00% | 5.00% | 32.97 | 102.99% |
| 18.00% | 2.00% | 28.67 | 106.30% |
| 18.00% | 4.00% | 28.16 | 106.50% |
| 18.00% | 5.00% | 27.80 | 106.66% |

Terminal share exceeds 100% where explicit-horizon FCFF present value is negative: this is disclosed, not clipped. DCF ~₹27.80–40.53 is substantially below the multiple-model hurdle-entry ₹68.98 because an 11 x terminal EBITDA exit capitalizes earnings more generously than a mature 14% marginal-ROIC cash model. The disagreement is a warning about terminal economics, not evidence to choose the higher valuation.

DCF FCFF=EBIT−cash operating tax+DA−capex−ΔONWC. Add opening cash and subtract opening debt once; terminal equity multiple separately adds terminal retained cash, with no dividends double count. Mature reinvestment uses growth/14% marginalROIC, explicitly lower than average historical returns. WACC14–18%, terminal growth 2/4/5%; all g<WACC. Enterprise DCF assumes a surviving operation; after unfunded failure it is diagnostic only, and rescue DCF is pre-financing—not diluted incumbent fair value. [A01]

| Exit multiple | Rescue assumed | Growth-shift regime | Funded / equity required / hurdle met |
|---|---|---|---|
| 7 | False | -35.00% to 0.00% | [True, False, False] |
| 7 | False | 1.00% to 100.00% | [False, False, False] |
| 11 | False | -35.00% to 0.00% | [True, False, False] |
| 11 | False | 1.00% to 100.00% | [False, False, False] |
| 15 | False | -35.00% to 0.00% | [True, False, False] |
| 15 | False | 1.00% to 100.00% | [False, False, False] |
| 7 | True | -35.00% to 0.00% | [True, False, False] |
| 7 | True | 1.00% to 100.00% | [True, True, False] |
| 11 | True | -35.00% to 0.00% | [True, False, False] |
| 11 | True | 1.00% to 14.00% | [True, True, False] |
| 11 | True | 15.00% to 100.00% | [True, True, True] |
| 15 | True | -35.00% to 0.00% | [True, False, False] |
| 15 | True | 1.00% to 1.00% | [True, True, False] |
| 15 | True | 2.00% to 100.00% | [True, True, True] |

Reverse expectations enumerate every1ppgrowth-shift point from−35to+100pp at7/11/15x multiples, with separate no-rescue and conditional-rescue regimes. Feasible regions, equity-issue regions and hurdle-met regions are recorded, not collapsed into a monotonic root. Gaps or disconnected intervals remain visible. The grid cannot claim sub-grid exact thresholds; `model_outputs.json` retains all816reverse points and funding states. [A01]

| Growth-shift | Multiple | Exit ₹ | IRR | Funded |
|---|---|---|---|---|
| -10.00% | 7 | 71.99 | -5.64% | True |
| -10.00% | 11 | 100.19 | 0.81% | True |
| -10.00% | 15 | 128.39 | 5.94% | True |
| 0.00% | 7 | 94.27 | -0.41% | True |
| 0.00% | 11 | 138.74 | 7.59% | True |
| 0.00% | 15 | 183.20 | 13.75% | True |
| 10.00% | 7 | 124.79 | 5.34% | False |
| 10.00% | 11 | 192.29 | 14.85% | False |
| 10.00% | 15 | 259.78 | 21.97% | False |
| Hurdle | Base conditional entry ₹ |
|---|---|
| 12.00% | 78.72 |
| 15.00% | 68.98 |
| 18.00% | 60.64 |
| One-way friction each end | Base net IRR |
|---|---|
| 1.00% | 7.16% |
| 3.00% | 6.31% |

Full growth × margin × multiple grid (27 paths), all rows and funding flags retained in model_outputs.json.

Hurdle 12/15/18% conditional base entry prices are reported with scenarios; these are assumption-dependent return thresholds, not observable fair value or buy recommendations. Illustrative 1%/3% one-way entry/exit friction sensitivities reduce returns; actual spread/market impact ND. L remainsNS: the formula ₹500,000/(participation×min(mean 60,median 60)) at 2/5/10% cannot be evaluated without a reliable series. Eight potential weekdays since listing are not 60 observations; absent/prelisting days must not be filled with zero. Circuit-lock reports prevent equating traded price to execution. [S05;S06]

## 11. Bear Case & Permanent-Loss Path
The key thesis-break variable is **collection and conversion of working capital into cash**. Customer loss can reduce utilization/margins while existing inventory and advances remain stranded; debt maturity then consumes the cushion, forcing capital raising or contraction just as IPO machinery needs utilization. Aged balances and concentrated suppliers make this linked path credible. Deteriorating operational earning power and dilution are permanent-loss mechanisms; a circuit-bound quoted drawdown alone is not. Impairment risk **High**, not a proven current distress event. Counterevidence: real recurring profits, improving headline receivables inFY 2026, netIPO cash and low historical net-debt/EBITDA permit the core bear to fund itself in the proforma model. Those facts prevent a blanket default/fraud narrative. [S01;A01]

The financial-reliability question is proportionate: asset-label/old-account discrepancies, unconfirmed balances and mixed source tables require monitoring, but small bounded presentation differences do not alone establish earnings falsification. Evidence of disputed unrecoverable assets or material adverse audit changes would alterG2; explicit diversion would alterG1. Actual unfinanceable obligations would alterG3. Conditional model failure alone does none of those.

## 12. 5× / 10× Feasibility
Unsupported as a central investment thesis. Five-year 5 x/10 x price outcomes require 37.97%/58.49% annual returns. With unchanged share count and 20 x exitP/E,₹481.10/₹962.20 target prices require ₹31.1272/₹62.2543 crorePAT; at 20% netmargin that means ₹155.636/₹311.271 croresales, around 42.4%/63.6% five-year revenueCAGR fromFY 2026. Growth of that scale would need substantially more working capital and operating capability than the present evidence establishes; equity issuance raises the requirement further. These are algebraic feasibility hurdles, not forecasts or probabilities. Lower 10 xexitP/E doubles required earnings again. Even the modeled bull does not establish 5 x. [C01;A01]

## 13. Monitoring Plan
|KPI/event|Baseline/date|Milestone|Warning|Thesis-break evidence|Review|
|---|---|---|---|---|---|
|CFO/PAT|FY 2024–26−.423 x|Positive cumulative operating cash as expansion matures|Another negative year despite profit|Material unrecoverable collections, not simply one weak half|Next audited/interim cash flow|
|Agedreceivables|FY 2026over 1 year ₹3.1152 cr|Demonstrated collection without write-off/re-aging|Over 1 year pool rises while sales slow|Material confirmed customer default/write-off undermines equity|Ageing note/results|
|Inventory/supplier advances|FY 2026₹16.4303/₹5.9239 cr|Documented conversion to delivery/invoices/cash|Growth outpaces orders/collections|Major stranded/connected advance loss|Results plus auditor notes|
|IPO machinery|₹13.2164 crplanned; quotation stage 24Sep|Orders→delivery→commissioningFY 2027|No staged proof while funds consumed|Material diversion/abandonment|Use-of-proceeds disclosures|
|Funding cushion|Synthetic minbase ₹1.4582 cr|Actual bank cash/facilities/debt bridge reconciled|Actual cushion below ₹1 cr assumption|Verified unfinanceable maturity|Nextbalance/proceeds report|
|Capacity/orders|649 actualFY 2026vs 2050 estimatedFY 2027|Qualified utilization not just equipmentcount|Output/revenue mix misses commissioning case|Sustained inability to monetize capacity|Operational update|
|Statutory exposure|EPF/ESICquantumND|Authority closure and accrued liability|New demands without provisioning|Material established concealment/diversion|Audit/official orders|
|Governance/assets|₹.6416 crsoftware/Pune discrepancy|Single asset identity/ready-use evidence|Further inconsistent asset/confirmation notes|Material adverse reliability opinion|Nextaudit|
|Trading|2,000 lot; short circuit-prone history|Verified 20 / 60 session data andtwo-way depth|Repeated one-sided sessions|Suspension/effectively untradeable|Before anyimplementation|

Thresholds are investigation triggers, not automated trading instructions or reminders. No recurring task created.

## 14. Final Classification & Conditional Action
**Hold — unresolved implementation; mixed-quality cash-conversion/capex execution watchlist.** BQS/GQS describe supported historical quality; IAS cannot be ranked becauseL isNS andG4 unresolved. No numeric matrix cell is forced for anNS aggregate. Even ignoring liquidity, base 7.6% modeled return misses 15% hurdle; this is not an attractive-entry designation. GOV/MOAT/REV/DUR/CAP andBQS/GQS also fail compounder requirements. Research priority: reconcile actual bank funds/proceeds, aged receivables/advances, commissioning and trading series before investment consideration. A lower price improves price-sensitive return only, not governance/cash quality. No buy/sell, portfolio allocation, global ranking or publication acceptance is authorized by this research handoff.

## 15. Sources, Assumptions & Open Questions
| ID | Type/date | Link or artifact | Claims / limit |
|---|---|---|---|
| S01 | V/M / 2026-09-24 | [S01](https://www.sjpultrasonics.in/static/files/ipo/SJP_Prospectus_24.09.2026_F.pdf) | FY 2024–26 restated accounts; cash/debt/ageing; capital/proceeds; estimates labeled M; Core tables reconciled; disclosure errors retained; no guarantee of balances/counterparty collections |
| S02 | V / 2026-06-19 | [S02](https://www.sjpultrasonics.in/static/files/financial-details/Annual%20Report/Annual%20Report_2025-26.pdf) | Audit unmodified with development EOM; historical3EMI delays; no wilful defaulter; customer advances/expense payable; CWIP Pune label versus prospectus software-development label unresolved; template qualified-opinion cross-reference inconsistent with opinion paragraph |
| S03 | V / 2022-08-18 | [S03](https://www.sjpultrasonics.in/static/files/financial-details/Annual%20Report/Annual%20Report%202022.pdf) | FY 2021 revenue20.0918cr, FY 2022 rounded11.7114cr; Older vintage not restated; no inventedCOVID windfall |
| S04 | V / 2023-09-05 | [S04](https://www.sjpultrasonics.in/static/files/financial-details/Annual%20Report/Annual%20Report%202023.pdf) | FY 2022/FY 2023 exact revenue and PAT; older capital structure; CFO ND; old AR balance differs later prospectus risk summary; not silently combined |
| S05 | V via secondary mirror / 2026-10-07 | [S05](https://noticeblue.com/circulars/7bf43394-a8f8-4050-866d-d08879aba8e8) | 544980/SJP/ISIN;Oct8listing;12.94mshares;2,000 lot;10daysTFT; Official notice PDF403; corroborated issuer capital table and exchange interoperability master, not proofNSElisting |
| S06 | Secondary dated market data / 2026-10-19 | [S06](https://univest.in/blogs/why-sjp-share-upper-circuit-consecutive-2026) | 96.22INR quote19 Oct, circuit report; Reject erroneous118.58crcap/22.62PE; no primaryclose/orderbook; later datesexcluded |
| C01 | C / derived | financial_metrics.json | 5 yrCAGR5.7388%;3 yr32.3591%; cumulativeCFO/PAT−.42335; ratios and bridges; Funding IC proxy is not fully reconciled operating IC; older accounts separate |
| A01 | A / derived | model_inputs.json | Scenario growth/margins/WC;14–18%WACC;15%equityhurdle;14%matureROIC;funding/capex policy; Proforma cash notactual20 Oct; financing availability not presumed |
| SJP-P | Official issuer prospectus / 2026-09-24 | [SJP-P](https://www.sjpultrasonics.in/static/files/ipo/SJP_Prospectus_24.09.2026_F.pdf) | 17–24,51–57,63–65,76–86,95–98,125–149,190;  |
| SJP-22 | Official audited annual report / 2022-08-18 | [SJP-22](https://www.sjpultrasonics.in/static/files/financial-details/Annual%20Report/Annual%20Report%202022.pdf) | PDF46 note16;  |
| SJP-23 | Official audited annual report / 2023-09-05 | [SJP-23](https://www.sjpultrasonics.in/static/files/financial-details/Annual%20Report/Annual%20Report%202023.pdf) | PDF3 directors report;  |
| PEER-R | Official competitor product page / None | [PEER-R](https://www.rincoultrasonics.com/en-in/) | ; Undated live page read25Oct2026; product corroboration only, not historical numerical input |
| PEER-U | Official competitor product page / None | [PEER-U](https://www.uniquecircleautomation.com/) | ; Undated live page read25Oct2026; product corroboration only |
| PEER-T | Official rating agency rationale / 2025-07-02 | [PEER-T](https://www.crisil.com/mnt/winshare/Ratings/RatingList/RatingDocs/TitanEngineeringandAutomationLimited_July%2002_%202025_RR_366558.html) | Detailed rationale/key rating drivers;  |

Primary PDFs/OCR/images remain private research inputs and are excluded from source-safe archives. Public packages retain compact analyst-transcribed facts, source URLs, calculations, all scenario inputs, raw current outputs and reproducible vintages—not entire source documents or personal identifiers. Source references adjacent to claims distinguish Vverified disclosure, Ccalculation, Mmanagement estimate and Aanalyst assumption; a filing containing management estimates does not verify outcomes.

**Open questions:** actual20 Oct cash andproceeds utilization; bank facility renewals/covenants andsettlement of delayed instalments; EPF/ESICquantum; collection of>1yearAR; delivery/recoverability ofsupplier advances; Pune-versussoftware asset identity; comparable old balance-sheet bridge; independent peer CFO; primary BSE trading history/spread. Blocked retrieval actions are recorded in`market_inputs.json`; BSE listingPDF403 was not bypassed/retried. Official prospectus was too large for web reader but standard public download completed successfully; this was a size limitation, not an access-control denial. No local Chromium, escalation, global registry, Library upload or public Git publication was used.

**Update log:**v 1 retained the initial coherent five-year cash/valuation engine. v 2 adds 20% capex overrun, bank-only cash, lower opening-liquidity cases, and explicit linked commissioning-delay/revenue stress alongside timing-only deferral. Core quality evidence did not change; robustness tests were expanded. A v 1 metadata label feasible_without_rescue incorrectly treated rescued paths as feasible; v 2 corrects it, while v 1 equity amounts and funding dates remain intact and its limitation is recorded in the vintage manifest. Both versions retain failure states and exact inputs; archive cold rebuild deletes generated outputs and reconstructs them offline before comparison. Independent review/acceptance remains with the parent; producer tests are not self-acceptance.
