# SJP Ultrasonics — Wallstrat position 381

Private frozen producer handoff, not independent acceptance or publication.

Read `report.html` or `report.md`. Identity: BSE SME 544980 / SJP; ISIN INE0S4601017.

Run `python rebuild.py` with Python 3 and pandoc available. It needs no network, source PDFs, OCR, browser, sibling folders, credentials or absolute private paths. Source data are compact human-verified transcriptions in `prepare_inputs.py`, `older_financials.json`, source ledgers and business notes.

`model_outputs.json` retains every current monthly path, all funding failures, rescue dilution, two-/three-way sensitivity paths and 816 reverse-expectation grid points. Regimes are enumerated rather than assumed monotonic. `model_vintages/v1` preserves the earlier coherent engine and exact inputs. Full archive retains its generated raw output; compact omits that output but independently recreates and hash-checks it using `rebuild_vintages.py` and `vintage_manifest.json`.

Producer verification is arithmetic/structural, not investment validation. `company_record.json` has separate BQS/GQS/IAS eligibility. No ZIP or manifest hashes itself. Archives omit all private original PDFs/OCR/images and unnecessary personal identifiers. All source links remain public original references; source documents are not redistributed.
