import json,math,hashlib,subprocess,tempfile,shutil,re,importlib.util
from pathlib import Path
P=Path(__file__).resolve().parent
O=json.loads((P/'model_outputs.json').read_text());F=json.loads((P/'financial_inputs.json').read_text());S=json.loads((P/'scores.json').read_text());M=json.loads((P/'model_inputs.json').read_text())
errors=[];checks=0
def ck(b,m):
 global checks
 checks+=1
 if not b:errors.append(m)
def eq(a,b,m,t=1e-8):ck(abs(a-b)<t,m)
for pi,p in enumerate(O['paths']+O['sensitivities']):
 prevcash=p['parameters']['opening_cash'];prevdebt=M['opening_debt'];prevshares=1.294;prevwc=M['opening_wc'];prevppe=M['opening_ppe']
 for r in p['rows']:
  tag=f'{pi}/{r["month"]}'
  eq(r['opening_cash'],prevcash,tag+'opening');eq(r['closing_cash'],prevcash+r['cfo']-r['capex']-r['repayment']+r['equity_raise'],tag+'cash');eq(r['cfo'],r['pat']+r['da']-r['delta_wc'],tag+'CFO');eq(r['fcff'],r['ebit']-max(r['ebit'],0)*.2517+r['da']-r['capex']-r['delta_wc'],tag+'FCFF');eq(r['shares'],prevshares+r['newshares'],tag+'shares');eq(r['newshares'],r['equity_raise']/(96.22*.6),tag+'raise');eq(r['debt'],prevdebt-r['repayment'],tag+'debt');eq(r['wc'],prevwc+r['delta_wc'],tag+'WC');eq(r['ppe'],prevppe+r['capex']-r['da'],tag+'PPE')
  prevcash=r['closing_cash'];prevshares=r['shares'];prevdebt=r['debt'];prevwc=r['wc'];prevppe=r['ppe']
 z=p['summary'];eq(sum(r['repayment'] for r in p['rows']),M['opening_debt'],str(pi)+'repay once');eq(sum(r['expansion'] for r in p['rows']),13.2164*(1+p['parameters'].get('capex_overrun',0)),str(pi)+'capex once');eq(z['terminal_equity'],max(0,z['terminal_ev']+z['terminal_cash']-z['terminal_debt']),str(pi)+'EVbridge');eq(z['exit_price'],z['terminal_equity']/z['terminal_shares'],str(pi)+'exit');eq(z['diagnostic_irr'],(z['exit_price']/96.22)**.2-1 if z['exit_price'] else -1,str(pi)+'IRR');ck(bool(z['valid_return'])==(len(p['funding_failures'])==0),str(pi)+'failure flag');ck(z['feasible_without_rescue']==(z['first_funding_month'] is None),str(pi)+'unassisted funding flag')
 for d in z['dcf']:
  rate,g=d['rate'],d['g'];np=sum(r['ebit'] for r in p['rows'][-12:])*.7483;tv=max(0,np*(1+g)*(1-g/.14))/(rate-g)/(1+rate)**5;ev=sum(r['fcff']/(1+rate)**(r['month']/12) for r in p['rows'])+tv;eq(ev,d['enterprise'],str(pi)+'DCF');eq(d['equity_per_original_share'],max(0,ev+p['parameters']['opening_cash']-M['opening_debt'])/1.294,str(pi)+'DCFbridge')
for k in ['BQS','GQS']:
 z=S['scores'][k];eq(sum(z['weights'].values()),1,k+'weights');eq(sum(S['factors'][f]*w for f,w in z['weights'].items()),z['raw'],k+'weighted')
ck(S['scores']['IAS']['final']=='NS' and not S['scores']['IAS']['ranking_eligible'],'IASNS');ck(S['scores']['BQS']['final']==4.3 and S['scores']['GQS']['final']==4.4,'expected factors');ck(len(re.findall(r'^## \d+\.',(P/'report.md').read_text(),re.M))==15,'15sections');ck('{{' not in (P/'report.md').read_text(),'placeholders');ck('<table' in (P/'report.html').read_text(),'htmltables');ck('<script' not in (P/'report.html').read_text(),'staticHTML');ck(len(O['reverse_expectations'])==6,'reverse6regimes');ck(sum(len(x['grid']) for x in O['reverse_expectations'])==816,'reverse816points')
# Recompute every reverse point; no assumed monotonicity.
spec=importlib.util.spec_from_file_location('sjpmodel',P/'model.py');mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
for regime in O['reverse_expectations']:
 for q in regime['grid']:
  r=mod.run('base',shift=q['growth_shift'],multiple=regime['multiple'],rescue=regime['rescue'])['summary'];eq(r['diagnostic_irr'],q['irr'],'reverseIRR');ck(r['valid_return']==q['funded'],'reverse funding');eq(r['equity_raised'],q['equity_raised'],'reverse equity')
# Independent balance arithmetic and ratio-of-sums.
for y,f in F['years'].items():eq(f['fcf_proxy'],f['cfo']-f['capex'],y+'FCF')
C=json.loads((P/'financial_metrics.json').read_text());eq(C['cash_conversion'],sum(f['cfo'] for f in F['years'].values())/sum(f['pat'] for f in F['years'].values()),'ratio of sums')
(P/'verification.json').write_text(json.dumps({'status':'PASS' if not errors else 'FAIL','checks':checks,'errors':errors,'scope':'Producer arithmetic/structural checks; not independent acceptance','all_current_rows_checked':sum(len(p['rows']) for p in O['paths']+O['sensitivities']),'reverse_points_recomputed':816,'source_pdf_or_ocr_required':False,'browser_qa':'Static HTML parsed; no local Chromium or live cloud browser'},indent=2)+'\n')
assert not errors,errors
print('PASS',checks)
