from pathlib import Path
import subprocess,sys
P=Path(__file__).resolve().parent
for n in ['prepare_inputs.py','model.py','analyze.py','build_report.py','verify.py','rebuild_vintages.py','finalize.py']:
 r=subprocess.run([sys.executable,str(P/n)],cwd=P,capture_output=True,text=True)
 if r.returncode:raise RuntimeError(n+'\n'+r.stdout+r.stderr)
print('Offline complete rebuild PASS')
