# SJP Ultrasonics Limited — Position 381

**Wallstrat SME research • Framework v3.0 • Information cutoff 20 October 2026 (IST) • Market reference 19 October 2026**

## 1. Executive Verdict
SJP supplies plastic-joining machinery, custom industrial automation and laser solutions—not medical ultrasound. It has application-engineering know-how and growing recent automation orders, but the decisive weakness is cash realization: FY24–26 ₹12.8171 crore restated PAT generated **negative ₹5.4261 crore CFO**. Five-year revenue CAGR is only5.74%, not the superficially attractive32.36% three-year recovery. Fresh IPO capital can support the machinery/WC expansion, but it is committed capital, not free surplus. At the dated secondary ₹96.22 reference, the base model returns about7.6%, below the15% hurdle; IAS remains NS because executable liquidity is unverified. This is a mixed-quality capital-expenditure execution watchlist, not an evidence-backed compounder. Collections, supplier-advance conversion and independently verified commissioning—not a higher quote—would improve the thesis. [S01;S03;S04;S06;C01;A01]

## 2. Research Header, Gates and Data Confidence
Exact legal identity is **SJP Ultrasonics Limited**, formerly SJP Ultrasonics Private Limited; CIN U29253MH2012PLC226489; ISIN **INE0S4601017**; BSE SME **544980 / SJP**. No NSE listing inferred from the interoperability master’s SJP$ rows. October8,2026 listing,12,940,000 shares,₹10 face and2,000-share lot are corroborated by issuer capital structure, mirrored BSE notice20261007-37 and exchange security-master rows. [S01;S05;security_master_evidence.json]

Standalone AS/Indian GAAP, not Ind AS; no subsidiaries. Units₹crore unless indicated. Five-year illustrative investment horizon ends20October2031; nominal pre-investor-tax equity hurdle15%, tested12%/18%. DCF WACC14–18%, independently assumed—not equated to the equity hurdle. Illustrative liquidity reference₹5lakh, not a recommended position. FY27 comparable interim/TTM is ND as of cutoff. Data retrieved25October but only pre-cutoff facts used; undated peer pages corroborate products only. [S01;S02;A01]

The ₹96.22 observation is a **19October dated secondary intraday LTP**, not a verified BSE closing/executable price. It is0calendar days stale versus market reference,1day before information cutoff. Later quotes excluded. Calculated market cap₹124.50868crore rejects the secondary article’s inconsistent₹118.58crore. One lot₹192,440; two₹384,880; three₹577,320. Round-lot constraints make an exact₹5lakh purchase impossible at this quote. [S06;C01]

{{GATES}}

**Confidence:** Medium on restated financial inputs, identity, business and governance disclosures; Medium on growth direction but low on clean price/volume separation; Medium on proxy capital-return evidence, low on exact operating-IC bridge; Medium on assumption-driven valuation and low on actual cutoff liquidity and trading implementation. The weakest material area for a new-purchase conclusion is liquidity: Hold. All quality factors remain individually assessed; missing liquidity does not turn business quality into zero or genericNS.

## 3. Scorecard and Calculation Audit
{{SCORES}}
{{FACTORS}}
Nine canonical factors reused exactly. EARN enters GQS, not BQS. IAS uses final unrounded BQS once; GQS is not added again. All weights match v3.0. GOV4 is not a governance-override trigger; compliance deficiencies do not establish diversion. CASH2 reflects persistent poor realization, so GQS cap5 applies, although raw GQS already lies below it. No G3 funding-failure cap is imposed from a hypothetical stress path. BQS/GQS are quality-ranking eligible at Medium material confidence; IAS is not. The IAS missing-data interval is mathematical, not a confidence interval or rankable score. A one-point change in both GOV/MOAT shifts BQS by0.4; REV/CAP ±1 shifts GQS by0.55. Adjacent scores should not be overinterpreted.

## 4. Business Overview
SJP designs/integrates custom plastic joining, industrial automation and laser machinery, tooling and service solutions. Its B2B clients are principally automotive manufacturers, with applications in medical, electronics, textiles, packaging and others. These application lists do not establish balanced end-market revenue. Vasai manufacturing and regional demonstration/service presence enable design, delivery, installation and support. Imported machine technology combines with local tools and integration. Revenue is collected through customer orders/advances and subsequent receivables, exposing the supplier to OEM credit terms. Purchase orders, rather than long-term offtake contracts, dominate. [S01 pp125–149]

FY26 domestic sales₹22.7802crore, SEZ₹.1078crore and other exports₹3.6697crore total₹26.5577crore. Manufacturing/sales/service mix changed substantially; no clean same-product ASP series exists. Reported segment and machine-count bridges below are preferable to claiming all growth is volume. [S01 p211]

## 5. Moat / Industry Position
Custom application knowledge, qualified fixtures, integration and installed-process familiarity create switching friction. They do not demonstrate industry-wide pricing power, patented monopoly or dominant share. Customer concentration remains material: top10/top5 FY26 sales55.28%/38.52%, versus54.46%/41.58% FY25. Supplier concentration worsened: top10/top5 purchases88.64%/77.18%, versus58.76%/40.66%. No binding long-term supplier contracts eliminate supply/FX risk. [S01 pp20–22]

| Comparator | Evidence period/scope | Revenue₹cr | EBITDA margin | Economic use |
|---|---|---:|---:|---|
| SJP |FY25 restated standalone|21.0573|32.47%|High margin, negative CFO|
| Rinco Ultrasonics India |FY25 issuer-reproduced MCA accounts|12.2081|16.65%|Closest unlisted ultrasonic specialist; technology-backed competition|
| Unique Circle Automation |FY25 issuer-reproduced MCA accounts|26.2812|9.57%|Near-scale custom automotive automation; weaker margins|
| TEAL |FY25 CRISIL, includes TEAL USA|~868|~19%|Stronger parent-supported automation/aerospace comparator; not pure peer|

No listed pure peer is established; no fabricated median P/E. Rinco/Unique primary corporate sites corroborate products, but their statutory financials were not independently downloaded; the prospectus is primary issuer disclosure of peer data, not independent verification. TEAL’s official2July2025 CRISIL rationale cites246-day gross-current-assets,₹511crore adjusted net worth and0.17x gearing. Parent support/scale and aerospace change its economics. SJP’s cash weakness cannot be excused simply because the industry uses working capital. Peer CFO is ND; malformed prospectus pp123–124 copied/shifted rows were excluded rather than treated as evidence. [S01 pp95–98;PEER-R;PEER-U;PEER-T]

## 6. Revenue Growth & Scale
{{GROWTH}}
The measurement window was fixed at five years because six audited revenue observations exist. FY21 was not discarded: no evidenced COVID windfall or accounting/perimeter break was located. FY24’s move toward higher-value custom special-purpose machines changes mix, not necessarily comparability. REV starts4 for5.74%CAGR, then rises at most1 for three consecutive years of expansion; no further small-base penalty or TAM bonus. The32.36% three-year CAGR is contextual, not the scoring window. [S03;S04;S01]

| Segment₹cr |FY24|FY25|FY26|FY26 addition|
|---|---:|---:|---:|---:|
|Plastic joining|8.4587|15.6724|12.3553|-3.3171|
|Industrial automation|6.0930|5.1651|13.4052|8.2401|
|Laser|.6590|.2198|.7972|.5774|

Machine output579/634/649 grew9.50% then2.37%, versus revenue38.44% then26.12%. FY26 plastic joining declined21.16%; automation rose159.53%. Growth is mix/order-value led, not proven equivalent volume growth. Revenue per machine is not a valid unit ASP because products/services/trading and machine complexity differ. No acquired-revenue contribution is disclosed; this does not make constant-price organic growth measurable. [S01 pp17,85,125]

## 7. Growth Quality & Reinvestment Runway
Installed capacity650/700/730 machines and utilization89%/90%/89% FY24–26 indicate existing activity, but planned capacity2,150/2,300 and production2,050/2,150 FY27/28 remain estimates, not orders. IPO gross₹23.45crore less expenses₹2.2636crore gives net₹21.1864crore: machinery₹13.2164crore, working capital₹4.92crore, general corporate₹3.05crore. Machinery was at quotation stage without definitive purchase contracts at prospectus date; all deployment targeted FY27. [S01 pp76–89]

Capex is roughly16times FY26 net tangible PPE, making commissioning/customer qualification substantial execution work. The affordable runway is narrower than the addressable market: profits are tied up in stock, supplier advances and collections. Historical incremental funding-IC proxy returns11.56% FY24–26 fall below the14–18% assumed cost-of-capital range despite high historical average ROCE. This is not proof every new machine destroys value, but it does not substantiate superior reinvestment. Revenue must become cash before repeated dilution is ruled out. CASH2 caps GQS5; no capex excuse is used for CFO weakness. [C01;A01]

## 8. Management, Governance & Execution
Repeated admitted control deficiencies matter: EPF/ESIC registration and contributions were not complied with before15June2024; notices to authorities were sent July/August2025. No fine had been imposed as of prospectus, but exposure is not zero and quantum remains unresolved. ROC forms were delayed up to4,079days, subsequently regularized with fees. An unregistered historical loan charge was disclosed with loan stated repaid. These are factual compliance weaknesses—not automatic fraud, abusive RPT or current default. [S01 pp18–24]

Auditor changes in2023 and2024 cite professional reasons/pre-occupancy; current auditor Chirag N Shah appointed16September2024. FY26 audit opinion is unmodified, with an emphasis concerning₹.641619crore Pune project not yet capitalized; elsewhere the restated prospectus labels the same amount software under development. That identity/asset-use discrepancy remains open. An audit-report template reference to a qualified opinion is not elevated over the actual opinion paragraph without clarification. Balance confirmations are qualified by notes as subject to confirmation/reconciliation. These limit confidence but are not proof all earnings fictitious. [S01 pp195–227;S02]

FY26 three Toyota EMIs were delayed September–November2025; FY25 one Anand Rathi EMI was delayed. CARO says not declared wilful defaulter. Review settled/current status rather than label an active default without evidence. ₹.136235crore disputed income-tax dues and₹.618723crore accumulated MSME interest are relevant obligations. [S01 p205–206;S02 CARO]

Promoter demand loans₹1.0772crore at FY26 support financing but create callable exposure. Related-party FY26 sale₹.01crore and repayments/advances are disclosed; LUFT advance₹.0586crore FY24 was repaid FY25. Director accrual remuneration₹.18crore/₹.1501crore should not be confused with cash paid. No severe minority harm is demonstrated. A reciprocal India noncompete with the promoter-linked partnership contains prior-consent/permitted-activity carve-outs; it does not irrevocably assign every opportunity to SJP. [S01 pp51–52,190]

|Dated statement/milestone|Evidence by cutoff|Assessment|
|---|---|---|
|FY24 shift to custom SPM|Machine counts/revenue mix diverge FY25–26|Executed mix change; pricing power not established|
|26May2026 engineer capacity certificate|FY26 actual649machines/89% utilization|Historical utilization verified disclosure, forecast2,050not actual|
|24September2026 machinery plan|Quotations; no definitive orders|Commissioning pending, not failed promise yet|
|June2026 development capitalization|₹.6416crore still incomplete after2years|Execution watch; asset-label clarification required|
|Historical statutory lapse remediation|Registration and self-intimation disclosed|Partial action; final liability/closure not established|

## 9. Financial Forensics
{{FINANCIALS}}
Restated FY24–26 are a consistent standalone perimeter. Older FY21–23 statutory vintages are retained separately below, not merged into cash conversion. No quarter or TTM cash flow invented. Gross profit is analytically revenue less materials, traded purchases and inventory movement, excluding payroll/overhead—not a directly comparable peer gross margin. It equals75.30%/64.22%/61.58%; contradictory prospectus marketing gross-margin rows are not used. FY26 recurring EBITDA includes the₹.0328crore prior-period charge conservatively; no automatic addback. [S01 pp47–49,211–224]

{{OLDER}}
FY22 original CFO has ambiguous presentation/tax sign; FY23 CFO was not located. FY23 original receivables₹4.599267crore differ from the prospectus risk-table₹3.1629crore. Negative FY22 receivables suggest historical presentation/netting issues; they are not silently recast into normalized receivables. Revenue history is still usable at Medium confidence; five-year CFO/ROIC is not claimed. [S03;S04;older_financials.json]

FY25 statutory PAT₹4.1524crore−income-tax adjustment₹.0612crore+deferred-tax adjustment₹.0813crore=restated₹4.1725crore. FY24₹3.5240−₹.1220=₹3.4020crore. Restated equity FY24 face₹6.7349crore versus reconciliation₹6.7313crore differs₹.0036crore; face retained and sensitivity bounded rather than forcing equality. Gratuity accounting-policy conversion is separately disclosed; not subtracted a second time. [S01 p220]

FY26 CFO bridge: PBT₹7.0235+DA₹.4020+finance₹.8896+gratuity₹.0812−other income₹.0770=₹8.3193crore before working capital. Inventory−₹5.8278, receivables+₹1.8438, loans/advances−₹4.5396, other assets−₹.1239, payables−₹.1632 and other liabilities−₹.4538 lead to−₹.9452crore before tax; tax paid₹1.7535 gives CFO−₹2.6987crore. Interest₹.8896crore is financing cash flow, so reported CFO is before financing interest. Cash capex₹.4024 gives FCF proxy−₹3.1011crore; interest-paid cash deficit is worse. Inventory/supplier-advance accumulation, not just capital expenditure, explains weak CFO. [S01 p49]

Receivables fell to₹9.7819crore, but₹3.1152crore is over1year, including₹.6933crore over3years; all classified good without doubt allowance in the note. Improvement in headline AR does not prove recovery of old balances. Cash₹.4789crore is mainly₹.4585crore cash on hand, bank only₹.0204crore; bank-only sensitivity is retained. Inventory₹16.4303crore comprises raw₹6.7424, WIP₹5.5893 and finished₹4.0986. Supplier advances₹5.9239crore require delivery/recovery checks. The IPO’s4.92croreWC allocation is not the entire economic working-capital requirement. [S01 pp209–211]

{{RETURNS}}
Funding IC proxy=equity+interest-bearing debt−cash; average opening/closing denominators; NOPAT=EBIT×74.83%. It includes tax/other non-operating differences and is **not exact operating ROIC**. Direct FY26 ONWC from receivables+inventory+supplier advances+prepaids−supplier payables−customer advances−expense accruals is₹25.8838crore; add PPE/intangibles/development/deposits for operating IC. Funding/operating definitions differ because provisions/tax/other claims are not identically classified; detailed metric JSON preserves both, no false reconciliation. FY25–26 incremental operating proxy is a cross-check, not causal cohort economics. Pre-IPO rights/IPO timing can distort average-capital measures. [C01]

Bonus4:1 July2024 was not financing; rights3.94million shares at₹10 January2025 raised₹3.94crore. FY24 EPS denominator5.5million bonus-adjusted differs actual1.1million; FY25 weighted6.180055million differs closing9.44million. IPO adds3.5million, taking12.94million: FY26 profit on current shares is₹4.0515EPS, not historical₹5.55. No warrants/options/convertibles disclosed in prospectus capital structure; future stress equity is an explicit assumption, not an existing claim. [S01 pp63–65,228]

## 10. Valuation & Market Expectations
At₹96.22, calculated current-share FY26P/E23.75x. Market cap₹124.50868crore+March debt₹5.7809−March cash₹.4789=EV₹129.81068crore. Proforma adding netIPO₹21.1864 gives EV₹108.62428crore/EBITDA13.19x; proforma P/B3.02x. Neither is actual October EV because intervening operations/deployment are ND. FCF yield is negative and not an attractive positive-yield claim. No peer P/E average manufactured. [S01;S06;C01]

The monthly model starts with FY26 operating scale and synthetic cash₹21.6653crore (March cash+netIPO). It spends machinery₹13.2164crore in6months **once**, plus maintenance2.5%sales; retains₹1crore minimum cushion; repays₹1.0772crore demand debt month1 and remaining original debt month12 without assumed rollover. Straight annual revenue steps are allocated monthly, not claimed seasonal forecasts. ONWC moves over6months to scenario revenue ratios; the ratios summarize receivable/inventory/advance/customer-credit stress, not a forecast of a single line. Depreciation15%WDV across opening/new operating assets is a simplification including development; it is not statutory guidance. Tax25.17%, no tax credit for losses; interest12% on opening debt. Operating rents stay in EBITDA; no fictitious Ind AS lease capitalization. No dividends. [A01]

{{SCENARIOS}}
The bear’s lower growth releases more working capital than base and therefore can have a higher cash minimum despite poorer terminal value: funding is not monotonic in growth. Linked failure combines customer loss, lower utilization/margin and slower stock/collections/supplier advances; month12 gap occurs on debt repayment. Report both cushion shortfall and cash below zero. Diagnostic continuation after failure is **not a realizable investment IRR**, insolvency finding or forecast recovery. Alternative rescue issues equity at60%entry price, with cash and dilution linked; no such financing is committed. Actual losses could exceed modeled continuation value. [A01]

{{STRESS}}
Deferred-expenditure-only12month delay is explicitly a timing sensitivity, not an execution downside. A separate linked12monthdelay/−10ppgrowth-shift case addresses commissioning/demand slippage. Additional bank-only liquidity,₹5/10crore opening-cash shortfalls,20%capexoverrun, margin−6pp and WCratio+20pp are retained. Proforma opening funds therefore cannot conceal deployment uncertainty. In the timing-only 12-month deferred-capex base sensitivity, subtracting the remaining machinery commitment from modeled cash leaves a minimum residual of ₹1.0574 crore, versus approximately ₹3.480 crore minimum aggregate cash. These minima occur at different months. Aggregate modeled cash is not free surplus; restricted proceeds and actual deployment status do not establish available bank liquidity at the cutoff.

{{DCF}}
DCF FCFF=EBIT−cash operating tax+DA−capex−ΔONWC. Add opening cash and subtract opening debt once; terminal equity multiple separately adds terminal retained cash, with no dividends double count. Mature reinvestment uses growth/14% marginalROIC, explicitly lower than average historical returns. WACC14–18%, terminal growth2/4/5%; all g<WACC. Enterprise DCF assumes a surviving operation; after unfunded failure it is diagnostic only, and rescue DCF is pre-financing—not diluted incumbent fair value. [A01]

{{REVERSE}}
Reverse expectations enumerate every1ppgrowth-shift point from−35to+100pp at7/11/15x multiples, with separate no-rescue and conditional-rescue regimes. Feasible regions, equity-issue regions and hurdle-met regions are recorded, not collapsed into a monotonic root. Gaps or disconnected intervals remain visible. The grid cannot claim sub-grid exact thresholds; `model_outputs.json` retains all816reverse points and funding states. [A01]

{{SENSITIVITY}}
Hurdle12/15/18% conditional base entry prices are reported with scenarios; these are assumption-dependent return thresholds, not observable fair value or buy recommendations. Illustrative1%/3% one-way entry/exit friction sensitivities reduce returns; actual spread/market impact ND. L remainsNS: the formula₹500,000/(participation×min(mean60,median60)) at2/5/10% cannot be evaluated without a reliable series. Eight potential weekdays since listing are not60observations; absent/prelisting days must not be filled with zero. Circuit-lock reports prevent equating traded price to execution. [S05;S06]

## 11. Bear Case & Permanent-Loss Path
The key thesis-break variable is **collection and conversion of working capital into cash**. Customer loss can reduce utilization/margins while existing inventory and advances remain stranded; debt maturity then consumes the cushion, forcing capital raising or contraction just as IPO machinery needs utilization. Aged balances and concentrated suppliers make this linked path credible. Deteriorating operational earning power and dilution are permanent-loss mechanisms; a circuit-bound quoted drawdown alone is not. Impairment risk **High**, not a proven current distress event. Counterevidence: real recurring profits, improving headline receivables inFY26, netIPO cash and low historical net-debt/EBITDA permit the core bear to fund itself in the proforma model. Those facts prevent a blanket default/fraud narrative. [S01;A01]

The financial-reliability question is proportionate: asset-label/old-account discrepancies, unconfirmed balances and mixed source tables require monitoring, but small bounded presentation differences do not alone establish earnings falsification. Evidence of disputed unrecoverable assets or material adverse audit changes would alterG2; explicit diversion would alterG1. Actual unfinanceable obligations would alterG3. Conditional model failure alone does none of those.

## 12. 5× / 10× Feasibility
Unsupported as a central investment thesis. Five-year5x/10x price outcomes require37.97%/58.49% annual returns. With unchanged share count and20x exitP/E,₹481.10/₹962.20 target prices require₹31.1272/₹62.2543crorePAT; at20%netmargin that means₹155.636/₹311.271croresales, around42.4%/63.6% five-year revenueCAGR fromFY26. Growth of that scale would need substantially more working capital and operating capability than the present evidence establishes; equity issuance raises the requirement further. These are algebraic feasibility hurdles, not forecasts or probabilities. Lower10xexitP/E doubles required earnings again. Even the modeled bull does not establish5x. [C01;A01]

## 13. Monitoring Plan
|KPI/event|Baseline/date|Milestone|Warning|Thesis-break evidence|Review|
|---|---|---|---|---|---|
|CFO/PAT|FY24–26−.423x|Positive cumulative operating cash as expansion matures|Another negative year despite profit|Material unrecoverable collections, not simply one weak half|Next audited/interim cash flow|
|Agedreceivables|FY26over1year₹3.1152cr|Demonstrated collection without write-off/re-aging|Over1year pool rises while sales slow|Material confirmed customer default/write-off undermines equity|Ageing note/results|
|Inventory/supplier advances|FY26₹16.4303/₹5.9239cr|Documented conversion to delivery/invoices/cash|Growth outpaces orders/collections|Major stranded/connected advance loss|Results plus auditor notes|
|IPO machinery|₹13.2164crplanned; quotation stage24Sep|Orders→delivery→commissioningFY27|No staged proof while funds consumed|Material diversion/abandonment|Use-of-proceeds disclosures|
|Funding cushion|Synthetic minbase₹1.4582cr|Actual bank cash/facilities/debt bridge reconciled|Actual cushion below₹1cr assumption|Verified unfinanceable maturity|Nextbalance/proceeds report|
|Capacity/orders|649actualFY26vs2050estimatedFY27|Qualified utilization not just equipmentcount|Output/revenue mix misses commissioning case|Sustained inability to monetize capacity|Operational update|
|Statutory exposure|EPF/ESICquantumND|Authority closure and accrued liability|New demands without provisioning|Material established concealment/diversion|Audit/official orders|
|Governance/assets|₹.6416crsoftware/Pune discrepancy|Single asset identity/ready-use evidence|Further inconsistent asset/confirmation notes|Material adverse reliability opinion|Nextaudit|
|Trading|2,000lot; short circuit-prone history|Verified20/60session data andtwo-way depth|Repeated one-sided sessions|Suspension/effectively untradeable|Before anyimplementation|

Thresholds are investigation triggers, not automated trading instructions or reminders. No recurring task created.

## 14. Final Classification & Conditional Action
**Hold — unresolved implementation; mixed-quality cash-conversion/capex execution watchlist.** BQS/GQS describe supported historical quality; IAS cannot be ranked becauseL isNS andG4 unresolved. No numeric matrix cell is forced for anNS aggregate. Even ignoring liquidity, base7.6% modeled return misses15%hurdle; this is not an attractive-entry designation. GOV/MOAT/REV/DUR/CAP andBQS/GQS also fail compounder requirements. Research priority: reconcile actual bank funds/proceeds, aged receivables/advances, commissioning and trading series before investment consideration. A lower price improves price-sensitive return only, not governance/cash quality. No buy/sell, portfolio allocation, global ranking or publication acceptance is authorized by this research handoff.

## 15. Sources, Assumptions & Open Questions
{{SOURCES}}
Primary PDFs/OCR/images remain private research inputs and are excluded from source-safe archives. Public packages retain compact analyst-transcribed facts, source URLs, calculations, all scenario inputs, raw current outputs and reproducible vintages—not entire source documents or personal identifiers. Source references adjacent to claims distinguish Vverified disclosure, Ccalculation, Mmanagement estimate and Aanalyst assumption; a filing containing management estimates does not verify outcomes.

**Open questions:** actual20Oct cash andproceeds utilization; bank facility renewals/covenants andsettlement of delayed instalments; EPF/ESICquantum; collection of>1yearAR; delivery/recoverability ofsupplier advances; Pune-versussoftware asset identity; comparable old balance-sheet bridge; independent peer CFO; primary BSE trading history/spread. Blocked retrieval actions are recorded in`market_inputs.json`; BSE listingPDF403 was not bypassed/retried. Official prospectus was too large for web reader but standard public download completed successfully; this was a size limitation, not an access-control denial. No local Chromium, escalation, global registry, Library upload or public Git publication was used.

**Update log:**v1 retained the initial coherent five-year cash/valuation engine. v2 adds20%capexoverrun, bank-only cash, lower opening-liquidity cases, and explicit linked commissioning-delay/revenue stress alongside timing-only deferral. Core quality evidence did not change; robustness tests were expanded. A v1 metadata label feasible_without_rescue incorrectly treated rescued paths as feasible; v2 corrects it, while v1 equity amounts and funding dates remain intact and its limitation is recorded in the vintage manifest. Both versions retain failure states and exact inputs; archive cold rebuild deletes generated outputs and reconstructs them offline before comparison. Independent review/acceptance remains with the parent; producer tests are not self-acceptance.
