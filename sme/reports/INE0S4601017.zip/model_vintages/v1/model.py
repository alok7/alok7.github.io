"""Monthly linked scenario engine. Nominal INR crore. No assumed rescue in core paths."""
import json,csv,itertools,math
from pathlib import Path
P=Path(__file__).resolve().parent
F=json.loads((P/'financial_inputs.json').read_text())['years']['2026'];M=json.loads((P/'market_inputs.json').read_text())
SC={'bear':{'growth':[-.15,0,.03,.05,.05],'margin':[.18,.19,.20,.20,.20],'wc_ratio':1.10,'multiple':7},'base':{'growth':[.20,.18,.15,.12,.10],'margin':[.29,.28,.27,.27,.27],'wc_ratio':.90,'multiple':11},'bull':{'growth':[.30,.25,.22,.20,.18],'margin':[.31]*5,'wc_ratio':.78,'multiple':15},'linked_failure':{'growth':[-.35,-.10,0,.02,.02],'margin':[.04,.06,.10,.12,.12],'wc_ratio':1.65,'multiple':5}}
INPUT={'version':'v1','start':'2026-10-20','end':'2031-10-20','months':60,'opening_cash':F['cash']+21.1864,'ipo_net':21.1864,'ipo_capex':13.2164,'opening_debt':F['debt'],'opening_wc':F['onwc'],'opening_ppe':F['ppe']+F['intangibles']+F['development'],'shares_crore':1.294,'tax':.2517,'cash_floor':1,'interest_rate':.12,'maintenance_capex_sales':.025,'depreciation_wdv':.15,'dilution_issue_price':M['price']*.6,'note':'Proforma FY26 balance sheet plus net IPO, not actual20Oct cash. All capex prospectus deployment reserved and spent; no gross/net double count. July–October operating movements ND; opening-cash sensitivities retain that gap. Demand loans repaid month1; all other original debt repaid month12; no automatic renewal. No dividends. Operating leases expensed in EBITDA; no Ind AS lease debt invented.','scenarios':SC}
def run(name='base',shift=0,margin_shift=0,multiple=None,opening_cash=None,delay=0,rescue=False,wc_shift=0):
 s=SC[name];cash=INPUT['opening_cash'] if opening_cash is None else opening_cash;initial_cash=cash;debt=F['debt'];wc=F['onwc'];ppe=INPUT['opening_ppe'];shares=1.294;rev=F['revenue'];rows=[];first=None;equity=0;fail=[]
 for y in range(5):
  rev*=max(.05,1+s['growth'][y]+shift)
  for mo in range(1,13):
   month=y*12+mo;r=rev/12;ebitda=r*(s['margin'][y]+margin_shift);da=ppe*(1-.85**(1/12));ebit=ebitda-da;interest=debt*.12/12;tax=max(ebit-interest,0)*.2517;pat=ebit-interest-tax
   target=rev*(s['wc_ratio']+wc_shift);newwc=wc+(target-wc)/(7-month) if month<=6 else target;dwc=newwc-wc
   expansion=13.2164/6 if delay<month<=delay+6 else 0;capex=r*.025+expansion;repay=min(debt,1.0772) if month==1 else debt if month==12 else 0
   cfo=pat+da-dwc;fcff=ebit-max(ebit,0)*.2517+da-capex-dwc;before=cash+cfo-capex-repay;need=max(0,1-before);raise_=0;newshares=0
   if need>1e-9:
    if first is None:first=month
    if rescue:raise_=need;newshares=raise_/INPUT['dilution_issue_price'];shares+=newshares;equity+=raise_
    else:fail.append({'month':month,'shortfall':need,'below_zero':before<0})
   close=before+raise_;debt-=repay;ppe+=capex-da
   rows.append(dict(month=month,year=y+1,revenue=r,ebitda=ebitda,da=da,ebit=ebit,interest=interest,tax=tax,pat=pat,opening_cash=cash,delta_wc=dwc,wc=newwc,cfo=cfo,capex=capex,expansion=expansion,fcff=fcff,repayment=repay,debt=debt,equity_raise=raise_,newshares=newshares,shares=shares,closing_cash=close,ppe=ppe,shortfall=need))
   wc=newwc;cash=close
 mult=s['multiple'] if multiple is None else multiple;last=rows[-12:];ebitda=sum(x['ebitda'] for x in last);ev=max(0,ebitda*mult);eq=max(0,ev+cash-debt);exitprice=eq/shares;irr=(exitprice/M['price'])**.2-1 if exitprice else -1
 dcf=[];nopat=sum(x['ebit'] for x in last)*.7483
 for rate,g in itertools.product([.14,.16,.18],[.02,.04,.05]):
  # Mature marginal ROIC14% is an explicit assumption, lower than headline historical ROCE.
  terminal=max(0,nopat*(1+g)*(1-g/.14))/(rate-g);pv=sum(x['fcff']/(1+rate)**(x['month']/12) for x in rows);tv=terminal/(1+rate)**5;enterprise=pv+tv
  dcf.append({'rate':rate,'g':g,'enterprise':enterprise,'equity_per_original_share':max(0,enterprise+initial_cash-F['debt'])/1.294,'terminal_fraction':tv/enterprise if enterprise>0 else None})
 summary={'feasible_without_rescue':not fail,'first_funding_month':first,'minimum_cash':min(x['closing_cash'] for x in rows),'max_gap':max([x['shortfall'] for x in fail]or[0]),'terminal_revenue':sum(x['revenue'] for x in last),'terminal_ebitda':ebitda,'terminal_cash':cash,'terminal_debt':debt,'terminal_shares':shares,'equity_raised':equity,'dilution':shares/1.294-1,'terminal_ev':ev,'terminal_equity':eq,'exit_price':exitprice,'diagnostic_irr':irr,'valid_return':not fail,'entry_at_hurdles':{str(h):exitprice/(1+h)**5 for h in [.12,.15,.18]},'dcf':dcf,'interpretation':'Unfunded continuation diagnostic only, not realizable forecast or claim of company default' if fail else 'Conditional assumption-driven path, no guaranteed funding/return','dcf_scope':'Pre-financing enterprise value, not rescue-holder fair value' if rescue else 'Not going-concern value after funding failure' if fail else 'Conditional proforma enterprise valuation'}
 return {'name':name,'parameters':{'growth_shift':shift,'margin_shift':margin_shift,'multiple':mult,'opening_cash':initial_cash,'capex_delay':delay,'rescue':rescue,'wc_shift':wc_shift},'summary':summary,'rows':rows,'funding_failures':fail}
def main():
 (P/'model_inputs.json').write_text(json.dumps(INPUT,indent=2)+'\n')
 paths=[run(n) for n in SC]+[run(n,opening_cash=INPUT['opening_cash']-d) for n,d in itertools.product(['base','bear','linked_failure'],[5,10])]+[run('linked_failure',rescue=True),run('base',delay=12),run('base',wc_shift=.2),run('base',margin_shift=-.06)]
 sens=[run('base',shift=g,margin_shift=m,multiple=k) for g,m,k in itertools.product([-.10,0,.10],[-.04,0,.04],[7,11,15])]
 reverse=[]
 # Enumerate feasible funding regimes: no bisection across failed regions or rescue discontinuities.
 for rescue,mult in itertools.product([False,True],[7,11,15]):
  grid=[]
  for i in range(-35,101):
   sh=i/100;r=run('base',shift=sh,multiple=mult,rescue=rescue);z=r['summary'];grid.append({'growth_shift':sh,'irr':z['diagnostic_irr'],'funded':z['valid_return'],'first_gap':z['first_funding_month'],'equity_raised':z['equity_raised'],'dilution':z['dilution']})
  regimes=[]
  for q in grid:
   state=(q['funded'],q['equity_raised']>0,q['irr']>=.15 and q['funded'])
   if not regimes or regimes[-1]['state']!=list(state):regimes.append({'state':list(state),'start_shift':q['growth_shift'],'end_shift':q['growth_shift']})
   else:regimes[-1]['end_shift']=q['growth_shift']
  reverse.append({'rescue':rescue,'multiple':mult,'step':.01,'regimes':regimes,'grid':grid,'meaning':'state=[funded,equity_required,hurdle_met]; all grid points retained; between-grid roots not claimed; rescue is hypothetical conditional dilution, not committed finance'})
 out={'paths':paths,'sensitivities':sens,'reverse_expectations':reverse}
 (P/'model_outputs.json').write_text(json.dumps(out,indent=2)+'\n')
 with (P/'model_main_monthly.csv').open('w') as f:
  w=csv.DictWriter(f,fieldnames=['scenario']+list(paths[0]['rows'][0]));w.writeheader()
  for x in paths[:4]:w.writerows({'scenario':x['name'],**r} for r in x['rows'])
 print([(r['name'],round(r['summary']['diagnostic_irr'],4),r['summary']['first_funding_month']) for r in paths[:4]])
if __name__=='__main__':main()
